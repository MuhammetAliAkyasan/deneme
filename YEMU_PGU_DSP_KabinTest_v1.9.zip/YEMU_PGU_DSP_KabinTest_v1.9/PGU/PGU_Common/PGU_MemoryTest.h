/*
 * PGU_MemoryTest.h
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_MEMORYTEST_H_
#define PGU_MEMORYTEST_H_

//MemoryTest.c
extern Uint16 * memTestAll(volatile Uint16 * MemoryAddress, unsigned long MemorySize, Uint16 TestPattern);
extern Uint16   memTestDataBus(volatile Uint16 * address);
extern Uint16 * memTestAddressBus(volatile Uint16 * baseAddress, unsigned long nBytes);
extern Uint16 * memTestDevice(volatile Uint16 * baseAddress, unsigned long nBytes);
extern Uint16   memFill(volatile Uint16 * address, unsigned long nBytes, volatile Uint16 pattern);

#endif /* PGU_MEMORYTEST_H_ */
