/*
 * PGU_GlobalVariables.h
 *
 *  Created on: 04 Oca 2013
 *      Author: AOB
 */

#ifndef PGU_GLOBALVARIABLES_H_
#define PGU_GLOBALVARIABLES_H_


//--FLAGS
extern volatile Uint16 	EnableFlag;		//	System enable flag
extern volatile Uint16  DebugTicker;    //  Back Ticker before enable system command


extern Uint16 SWResett ;		//

extern int ExtFlashTestResult;
extern Uint16 * ExtRamTestResult;
extern Uint16 * DualRamTestResult;

extern Uint16 STestErr;  // Tiva error
extern Uint16 GA;        // Card Slot

extern const char build_date[12];
extern const char build_time[10];
extern const char build_rev[4];
extern const char build_loco[8];

//volatile struct EPWM_REGS *ePWM[] =
//                  { &EPwm1Regs,         //intentional: (ePWM[0] not used)
//                    &EPwm1Regs,
//                    &EPwm2Regs,
//                    &EPwm3Regs,
//                    &EPwm4Regs,
//                    &EPwm5Regs,
//                    &EPwm6Regs,
//                  };

// STEST Fault Flags bit definitions */
struct STESTFLT_BITS {          // bits     description
   Uint16 STELLARIS:1;          // 0
   Uint16 DUALRAM:1;            // 1
   Uint16 EXTRAM:1;             // 2
   Uint16 EXTFLASH:1;           // 3
   Uint16 rsvd:12;              // 15:4     Reserved
};

typedef union  {
   Uint16    all;
   struct STESTFLT_BITS   bit;
}STESTFLT_REG;

/*-----------------------------------------------------------------------------
    Define the structure of the SPI ADC Values Object for PGU
-----------------------------------------------------------------------------*/
typedef struct {
        float32 CH0;              // Input: SPI ADC CH0 voltage
        float32 CH1;              // Input: SPI ADC CH1 voltage
        float32 CH2;              // Input: SPI ADC CH2 voltage
        float32 CH3;              // Input: SPI ADC CH3 voltage
        float32 CH4;              // Input: SPI ADC CH4 voltage
        float32 CH5;              // Input: SPI ADC CH5 voltage
        float32 CH6;              // Input: SPI ADC CH6 voltage
        float32 CH7;              // Input: SPI ADC CH7 voltage
        float32 CH8;              // Input: SPI ADC CH8 voltage
        float32 CH9;              // Input: SPI ADC CH9 voltage
        float32 CH10;             // Input: SPI ADC CH10 voltage
        float32 CH11;             // Input: SPI ADC CH11 voltage
        float32 CH12;             // Input: SPI ADC CH12 voltage
        float32 CH13;             // Input: SPI ADC CH13 voltage
        float32 CH14;             // Input: SPI ADC CH14 voltage
        float32 CH15;             // Input: SPI ADC CH15 voltage
}
SPIADC_VALUES;

typedef enum                    // PGU Card Types
{
    PGU = 0,
    PGUREC,
    PGUINV,
}PGUCardType;

extern PGUCardType ActivePGUCard;

//--MACRO VARIABLES and INSTANCES

extern STESTFLT_REG STestErrFlags;

extern SPIADC_VALUES SPIADCValues;

extern struct BUFF_POINT Buff_point;

// Used to indirectly access all EPWM modules
extern volatile struct EPWM_REGS *ePWM[];
// Used to indirectly access eQEP module
extern volatile struct EQEP_REGS *eQEP[];
// Used to indirectly access eQEP module
extern volatile struct ECAP_REGS *eCAP[];

#endif /* PGU_GLOBALVARIABLES_H_ */
