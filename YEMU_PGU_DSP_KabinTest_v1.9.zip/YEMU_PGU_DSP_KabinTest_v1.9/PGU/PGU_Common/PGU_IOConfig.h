/*
 * PGU_IOConfig.h
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_IOCONFIG_H_
#define PGU_IOCONFIG_H_

#define IO_SET(x)       \
    GpioDataRegs.x = 1; \

#define IO_CLR(x)       \
    GpioDataRegs.x = 0; \

#define IO_READ(x)      \
    GpioDataRegs.x      \

#define IO_TOGGLE(x)    \
    GpioDataRegs.x = 1; \

#define PGU_IO_SET(x)   \
    GpioDataRegs.x = 0; \

#define PGU_IO_CLR(x)   \
    GpioDataRegs.x = 1; \

#define PGU_IO_READ(x)  \
    GpioDataRegs.x      \


//#define IO_SET(x)       if(GpioDataRegs.x != 1) GpioDataRegs.x = 1;
//#define IO_CLR(x)       if(GpioDataRegs.x != 0) GpioDataRegs.x = 0;
//#define IO_READ(x)      GpioDataRegs.x
//#define IO_TOGGLE(x)    GpioDataRegs.x = 1;
//
//#define PGU_IO_SET(x)   if(GpioDataRegs.x != 0) GpioDataRegs.x = 0;
//#define PGU_IO_CLR(x)   if(GpioDataRegs.x != 1) GpioDataRegs.x = 1;
//#define PGU_IO_READ(x)  GpioDataRegs.x

// DSP_IOConfig.c
extern void     InitCommonPeripheralsGpio(void);
extern void     InitDSPPeripherals(void);
extern void     InitDSPEPwm1Gpio(void);
extern void     InitDSPEPwm2Gpio(void);
extern void     InitDSPEPwm3Gpio(void);
extern void     InitDSPEPwm4Gpio(void);
extern void     InitDSPEPwm5Gpio(void);
extern void     InitDSPEPwm6Gpio(void);
extern void     InitDSPEPwmSyncGpio(void);
extern void     InitDSPECapGpio(void);
extern void     InitDSPEQep1Gpio(void);
extern void     InitDSPEQep2Gpio(void);
extern void     InitDSPCanGpio(void);
extern void     InitDSPSpiGpio(void);
extern void     InitDSPI2cGpio(void);
extern void     InitDSPSciGpio(void);
extern void     InitDSPTz1Gpio(void);
extern void     InitDSPTz2Gpio(void);
extern void     InitDSPXintf16Gpio(void);
extern void     InitDSPIOGpio_REC(void);
extern void     InitDSPIOGpio_INV(void);

extern void     InitCommonIOsGpio(void);

#endif /* PGU_IOCONFIG_H_ */
