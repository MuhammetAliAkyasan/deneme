/*
 * PGU_Settings.h
 *
 *  Created on: 10 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_SETTINGS_H_
#define PGU_SETTINGS_H_


#ifndef TRUE
#define FALSE (0)           /* FALSE = 0    */
#define TRUE (!FALSE)       /* TRUE = 1     */
#endif

#ifndef NULL
#define NULL  (void *) 0    // Define NULL pointer value.
#endif

#define FAIL    0
#define SUCCESS 1

//Define system Math Type

#define FLOAT_MATH     1
#define IQ_MATH        0

#ifndef MATH_TYPE
#define MATH_TYPE   FLOAT_MATH  // Select Floating Math Type for 2833x
#endif

// CPU Timer definitions
#define mSec1  150000
#define mSec5  750000
#define mSec10 1500000
#define mSec50 7500000


//#define Vs_REF_MAX         (1485.0)
//#define Vs_REF_MIN         (80.0)            // ilk de�er

//////////////////////////////////////////////////////////////////////////////////////////////77
#define PGUVERSION         V3

#define PROJECT_REV         "012 "  // Proje dosyas� versiyonu (max. 12 karakter!!!)
#define LOCO_TYPE           "YEMU"  //



// Software block definitions
#define ACTIVE              TRUE
#define PASSIVE             FALSE

#define BISTTEST            ACTIVE
#define SYSTEST             PASSIVE
#define PGUINIT             PASSIVE
#define CKUINIT             ACTIVE
#define TRIPMANAGEMENT      ACTIVE
#define RECTIFIER_CONTROL   ACTIVE
#define INVERTER_CONTROL    ACTIVE
#define BREAK_CONTROL       ACTIVE


//---------------------------------------------------------------------------
#define EXTRAM_BASE             0x200000
#define EXTRAM_LENGTH           0x80000

#define DUALRAM_BASE            0x4000
#define DUALRAM_LENGTH          0x1000

//------------------  SWupdate Defines  -------------------------------------
#define PACKAGE_LENGTH    0x200         // 0x200 = 512, Package Size:512x2B = 1KB
#define MAX_PACKAGE_NUM   128           // 128KB Binary File = 128 Packages (Package Size 1KB)
#define PASSWORDS_LENGTH  8             //

//---------------------------------------------------------------------------
// ePWM Deadband value definitions:
// (based on 150MHz System Clock, CLKDIV_PRESCALE_X_2, HSPCLKDIV_PRESCALE_X_1)
#define DB_1uS              75              // 1.0 uS
#define DB_2uS              150             // 2.0 uS
#define DB_4uS              300             // 4.0 uS
#define DB_8uS              600             // 8.0 uS
#define DB_10uS             750             // 10.0 uS

// Common Parameters
#define SYSTEM_FREQUENCY     150
#define PI                   3.14159265358979

#define WDTog                     GPBTOGGLE.bit.GPIO49

extern Uint16 ramfuncs_loadstart;
extern Uint16 ramfuncs_loadsize;
extern Uint16 ramfuncs_runstart;

extern Uint16 econst_loadstart;
extern Uint16 econst_loadsize;
extern Uint16 econst_runstart;

extern Uint16 text_loadstart;
extern Uint16 text_loadsize;
extern Uint16 text_runstart;

#endif /* PGU_SETTINGS_H_ */
