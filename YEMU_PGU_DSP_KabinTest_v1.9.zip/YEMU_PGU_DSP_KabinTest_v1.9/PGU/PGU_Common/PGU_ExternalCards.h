/*
 * PGU_ExternalCards.h
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_EXTERNALCARDS_H_
#define PGU_EXTERNALCARDS_H_

extern void     InitSPIDAC();
extern void     InitSPIDAC2();
extern void     SPIDACWrite(Uint16 Channel,float32 ChannelVoltage);
extern void     SPIDAC2Write(Uint16 Channel,float32 ChannelVoltage);
extern void     InitSPIADC();
extern void     SPIADCRead(float32 *dest);

#endif /* PGU_EXTERNALCARDS_H_ */
