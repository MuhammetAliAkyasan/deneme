/*
 * PGU_GlobalPrototypes.h
 *
 *  Created on: 10 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_GLOBALPROTOTYPES_H_
#define PGU_GLOBALPROTOTYPES_H_

extern void BuildTimeInit(void);
extern void SWUpdateCheck(void);


#endif /* PGUREC_GLOBALPROTOTYPES_H_ */
