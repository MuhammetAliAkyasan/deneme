/*
 * PGU_I2C.h    CANRXFile
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_I2C_H_
#define PGU_I2C_H_

extern Uint16 InitCheckReg[4];      //

// i2c_slave.c
extern Uint16 * I2CBasedRAMTest(Uint16 * STestErr);

#endif /* PGU_I2C_H_ */
