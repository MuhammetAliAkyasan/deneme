/*
 * AnalogBuffer.h
 *
 *  Created on: 04.10.2018
 *      Author: fozturk
 */

#ifndef ANALOGBUFFER_H
#define ANALOGBUFFER_H

#ifdef __cplusplus
extern "C" {
#endif

// Analog Buffer Size defined in Memory
#define BUFFSIZE            1024

struct ANALOGBUFFER{
	float32 	buff1[BUFFSIZE];
	float32 	buff2[BUFFSIZE];
	float32 	buff3[BUFFSIZE];
	float32 	buff4[BUFFSIZE];
	float32 	buff5[BUFFSIZE];
	float32 	buff6[BUFFSIZE];
	float32 	buff7[BUFFSIZE];
	float32 	buff8[BUFFSIZE];
	float32 	buff9[BUFFSIZE];
	float32 	buff10[BUFFSIZE];
	float32 	buff11[BUFFSIZE];
	float32 	buff12[BUFFSIZE];
	float32 	buff13[BUFFSIZE];
	float32 	buff14[BUFFSIZE];
	float32 	buff15[BUFFSIZE];
	float32 	buff16[BUFFSIZE];
} ;

extern volatile struct ANALOGBUFFER AnaBuff;

extern void FillAnalogBuffer(volatile float32 AnalogData, volatile float32 buffer[BUFFSIZE],Uint16 Index);
extern void ClearAnalogBuffer(volatile float32 buffer[BUFFSIZE], Uint16 Index);

#ifdef __cplusplus
}
#endif /* extern "C" */

#endif  // end of ANALOGBUFFER_H definition

//
// End of file
//
