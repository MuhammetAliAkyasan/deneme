/*
 * PGU_Common.h
 *
 *  Created on: 14 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_COMMON_H_
#define PGU_COMMON_H_

#include "PGU_GlobalPrototypes.h"
#include "PGU_ExternalCards.h"
#include "PGU_Settings.h"
#include "PGU_AnalogBuffer.h"
#include "PGU_GlobalVariables.h"
#include "PGU_I2C.h"
#include "PGU_IOConfig.h"
#include "PGU_MemoryTest.h"
#include "PGU_PeripheralConfig.h"
#include "PGU_SharedMem.h"
#include "SPIdevs.h"
#include "SST39VF800A.h"
#include "f2833xbmsk.h"
#include "Example_Flash2833x_API.h"
#include <string.h>

#endif /* PGU_COMMON_H_ */
