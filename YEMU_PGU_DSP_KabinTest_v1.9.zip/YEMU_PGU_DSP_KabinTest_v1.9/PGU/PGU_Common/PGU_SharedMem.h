/*
 * PGU_SharedMem.h
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_SHAREDMEM_H_
#define PGU_SHAREDMEM_H_


//************************************************************************
//CONTROL REGISTER DEFINITIONS********************************************
//************************************************************************

// Control1 register bit definitions
// CAN MESSAGE: PGU_CONTROL1
typedef struct {                        // bits     description
    Uint64 TORQUE_REF:16            ;   // 15:0     Requested motor torque value; Range: 0=0.0Nm; 40000=4000.0Nm
    Uint64 SPEED_REF:16             ;   // 31:16    Requested motor speed value; Range: 0=0.0rpm; 40000=4000.0rpm
    Uint64 VEHICLE_SPEED:16         ;   // 47:32    Vehicle speed value;    Range: 0=0.0km/h; 65535=100.0km/h
    Uint64 RSV2:16                  ;   // 63:48
}
CONT1_REG;

// Control2 register bit definitions
// CAN MESSAGE: PGU_CONTROL2
typedef struct {                        // bits     description
    Uint64 REVERSER_STAT:2          ;   // 1:0      11:Neutral - 10:Forward - 01:Reverse - 00:initial
    Uint64 MASTERCONT_STAT:2        ;   // 3:2      11:Neutral - 10:Power   - 01:Brake   - 00:Em.Brake
    Uint64 ENABLE:1                 ;   // 4
    Uint64 TRACT_INH:1              ;   // 5
    Uint64 EDB_CUT:1                ;   // 6
    Uint64 VEH_SPD_EST_ERR:1        ;   // 7
    Uint64 VCB_STAT:1               ;   // 8
    Uint64 PRE_FUSE:1               ;   // 9
    Uint64 ERTMSBrake:1             ;   // 10
    Uint64 CKU_IDENT:2              ;   // 12:11
    Uint64 EME_DEGRADED:1           ;   // 13
    Uint64 EME_CON1:1               ;   // 14
    Uint64 EME_CON2:1               ;   // 15
    Uint64 EME_CON3:1               ;   // 16
    Uint64 RSV:47                   ;   // 17-63
}
CONT2_REG;


// CONTROL REGISTERS
typedef struct  {
    CONT1_REG       C1              ;   // Analog Control Data (R)
    CONT2_REG       C2              ;   // Binary Control Data (R)
    Uint64          C3              ;   // Binary Control Data (R)
    Uint64          C4              ;   // Binary Control Data (R)
    Uint64          C5              ;   // Binary Control Data (R)
    Uint64          C6              ;   // Binary Control Data (R)
    Uint64          C7              ;   // Binary Control Data (R)
    Uint64          C8              ;   // Binary Control Data (R)
}
CONTROL_REGS;

//***********************************************************************************
// FOIO Data Definitions ************************************************************
//***********************************************************************************
// FOIO PWMx Plus Faults Bit definitions
typedef struct  {
    Uint16 CROSS:1;
    Uint16 FREQ:1;
    Uint16 DUTY:1;
    Uint16 DEAD:1;
    Uint16 PWM:1;
    Uint16 STAT:1;
    Uint16 SC:1;
    Uint16 CFD:1;
    Uint16 rsv:8;
}PWMPlusFBits;

// FOIO PWMx Minus Faults Bit definitions
typedef struct  {
    Uint16 rsv:8;
    Uint16 CROSS:1;
    Uint16 FREQ:1;
    Uint16 DUTY:1;
    Uint16 DEAD:1;
    Uint16 PWM:1;
    Uint16 STAT:1;
    Uint16 SC:1;
    Uint16 CFD:1;
}PWMMinusFBits;

// FOIO PWMx Faults Bit definitions
typedef union
{
    Uint16       all;
    PWMPlusFBits Plus;
    PWMMinusFBits Minus;
}FOIOPWMFaultBits;

// FOIO BP Signals Bit definitions
typedef struct {
    Uint16 rsv2:8;
    Uint16 rsv:1;
    Uint16 OVP:1;
    Uint16 OVCRF_IN:1;
    Uint16 CFD2:1;
    Uint16 CFD:1;
    Uint16 HRecT:1;
//  Uint16 SRecT:1;
    Uint16 HGOFF:1;
    Uint16 SGOFF_:1;
}BPSignalsBits;

typedef union // FOIOBackplaneType
{
    Uint16          all;
    PWMPlusFBits    OVCRFOut;
    BPSignalsBits   BPSignals;
}FOIO_BP_OVCRF_Bits;

// FOIO CAN Message1 bit definitions */
// FOIO Status/Warning/Error Data
// CAN MESSAGE: FOIO_MSG1
typedef union
{
    Uint64 all;
    struct
    {
        FOIOPWMFaultBits Rect2U;
        FOIOPWMFaultBits Rect2V;

        FOIOPWMFaultBits Rect1U;
        FOIOPWMFaultBits Rect1V;

//        FOIOPWMFaultBits InvU;
//        FOIOPWMFaultBits InvV;
    }bit;
}FOIO_MSG1;

// FOIO CAN Message2 bit definitions */
// FOIO Status/Warning/Error Data
// CAN MESSAGE: FOIO_MSG2
typedef union
{
    Uint64 all;
    struct
    {
        FOIOPWMFaultBits InvU;
        FOIOPWMFaultBits InvV;

        FOIOPWMFaultBits InvW;
        FOIO_BP_OVCRF_Bits BP_OVCRFOut;
//
//        // Hardware-Software versions
//        Uint64 HardwareVer  :8;
//        Uint64 SoftwareVer  :8;
//        Uint64 SRAM0_F      :1;
//        Uint64 SRAM1_F      :1;
//        Uint64 reserved     :6;
//        Uint64 LifeCheck    :8;
    }bit;
}FOIO_MSG2;

typedef union
{
    Uint64 all;
    struct
    {
        // Hardware-Software versions
        Uint64 HardwareVer  :8;
        Uint64 reserved1    :8;

        Uint64 LifeCheck    :8;
        Uint64 SRAM0_F      :1;
        Uint64 SRAM1_F      :1;
        Uint64 reserved2    :6;

        Uint64 SW_Loco      :8;
        Uint64 SW_Processor :8;

        Uint64 SW_Board     :8;
        Uint64 SW_Version   :8;

    }bit;
}FOIO_MSG3;


//FOIO CAN Messages
typedef struct  {
    FOIO_MSG1        RX_MSG1;   // Status/Warning/Error Data
    FOIO_MSG2        RX_MSG2;   // Status/Warning/Error Data
    FOIO_MSG3        RX_MSG3;   // Status/Warning/Error Data
    Uint64           RX_MSG4;   // Status/Warning/Error Data
    Uint64           RX_MSG5;   // Status/Warning/Error Data
    Uint64           RX_MSG6;   // Status/Warning/Error Data
    Uint64           RX_MSG7;   // Status/Warning/Error Data
    Uint64           RX_MSG8;   // Status/Warning/Error Data
    FOIO_MSG1        RX_MSG9;   // Status/Warning/Error Data
    FOIO_MSG2        RX_MSG10;   // Status/Warning/Error Data
    FOIO_MSG3        RX_MSG11;   // Status/Warning/Error Data
    Uint64           RX_MSG12;   // Status/Warning/Error Data
    Uint64           RX_MSG13;   // Status/Warning/Error Data
    Uint64           RX_MSG14;   // Status/Warning/Error Data
    Uint64           RX_MSG15;   // Status/Warning/Error Data
    Uint64           RX_MSG16;   // Status/Warning/Error Data
}FOIO_CAN_RX_MSG;

typedef struct  {
    Uint64           RX_MSG1;   // Status/Warning/Error Data
    Uint64           RX_MSG2;   // Status/Warning/Error Data
    Uint64           RX_MSG3;   // Status/Warning/Error Data
    Uint64           RX_MSG4;   // Status/Warning/Error Data
    Uint64           RX_MSG5;   // Status/Warning/Error Data
    Uint64           RX_MSG6;   // Status/Warning/Error Data
    Uint64           RX_MSG7;   // Status/Warning/Error Data
    Uint64           RX_MSG8;   // Status/Warning/Error Data
    Uint64           RX_MSG9;   // Status/Warning/Error Data
    Uint64           RX_MSG10;   // Status/Warning/Error Data
    Uint64           RX_MSG11;   // Status/Warning/Error Data
    Uint64           RX_MSG12;   // Status/Warning/Error Data
    Uint64           RX_MSG13;   // Status/Warning/Error Data
    Uint64           RX_MSG14;   // Status/Warning/Error Data
    Uint64           RX_MSG15;   // Status/Warning/Error Data
    Uint64           RX_MSG16;   // Status/Warning/Error Data
}FOIO_CAN_TX_MSG;


//************************************************************************
//CONTROL REGISTER DEFINITIONS********************************************
//************************************************************************

// CAN TX Mesaages bit definitions

struct UINT16_BITS {           // bits   description
    Uint16 bit0:1;             // 0
    Uint16 bit1:1;             // 1
    Uint16 bit2:1;             // 2
    Uint16 bit3:1;             // 3
    Uint16 bit4:1;             // 4
    Uint16 bit5:1;             // 5
    Uint16 bit6:1;             // 6
    Uint16 bit7:1;             // 7
    Uint16 bit8:1;             // 8
    Uint16 bit9:1;             // 9
    Uint16 bit10:1;            // 10
    Uint16 bit11:1;            // 11
    Uint16 bit12:1;            // 12
    Uint16 bit13:1;            // 13
    Uint16 bit14:1;            // 14
    Uint16 bit15:1;            // 15
};

struct UINT16_BYTES {          // bits   description
    Uint16 byte0:8;            // 7-0
    Uint16 byte1:8;            // 15-8
};

typedef union  {
    Uint16              all;
    struct UINT16_BYTES byte;
    struct UINT16_BITS  bit;
}UINT16_REG;


typedef union
{
    Uint64      ullBuffer;
    UINT16_REG  uiBuffer[4];
}CAN_MESSAGE;

// CAN TX MESGAGES
typedef struct  {
    CAN_MESSAGE TX_MSG1;   //  Control Data (R)
    CAN_MESSAGE TX_MSG2;   //  Control Data (R)
    CAN_MESSAGE TX_MSG3;   //  Control Data (R)
    CAN_MESSAGE TX_MSG4;   //  Control Data (R)
    CAN_MESSAGE TX_MSG5;   //  Control Data (R)
    CAN_MESSAGE TX_MSG6;   //  Control Data (R)
    CAN_MESSAGE TX_MSG7;   //  Control Data (R)
    CAN_MESSAGE TX_MSG8;   //  Control Data (R)
    CAN_MESSAGE TX_MSG9;   //  Control Data (R)
    CAN_MESSAGE TX_MSG10;   //  Control Data (R)
    CAN_MESSAGE TX_MSG11;   //  Control Data (R)
    CAN_MESSAGE TX_MSG12;   //  Control Data (R)
    CAN_MESSAGE TX_MSG13;   //  Control Data (R)
    CAN_MESSAGE TX_MSG14;   //  Control Data (R)
    CAN_MESSAGE TX_MSG15;   //  Control Data (R)
    CAN_MESSAGE TX_MSG16;   //  Control Data (R)
}
CAN_TX_MSG;

// CAN RX MESGAGES
typedef struct  {
    CAN_MESSAGE RX_MSG1;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG2;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG3;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG4;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG5;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG6;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG7;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG8;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG9;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG10;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG11;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG12;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG13;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG14;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG15;   //  Monitor Data (W)
    CAN_MESSAGE RX_MSG16;   //  Monitor Data (W)
}
CAN_RX_MSG;

// CAN TX MESGAGES
typedef struct  {
    CAN_MESSAGE C1;   //  Control Data (R)
    CAN_MESSAGE C2;   //  Control Data (R)
    CAN_MESSAGE C3;   //  Control Data (R)
    CAN_MESSAGE C4;   //  Control Data (R)
    CAN_MESSAGE C5;   //  Control Data (R)
    CAN_MESSAGE C6;   //  Control Data (R)
    CAN_MESSAGE C7;   //  Control Data (R)
    CAN_MESSAGE C8;   //  Control Data (R)
}
CAN_TX_8MSG;

// CAN RX MESGAGES
typedef struct  {
    CAN_MESSAGE C1;   //  Monitor Data (W)
    CAN_MESSAGE C2;   //  Monitor Data (W)
    CAN_MESSAGE C3;   //  Monitor Data (W)
    CAN_MESSAGE C4;   //  Monitor Data (W)
    CAN_MESSAGE C5;   //  Monitor Data (W)
    CAN_MESSAGE C6;   //  Monitor Data (W)
    CAN_MESSAGE C7;   //  Monitor Data (W)
    CAN_MESSAGE C8;   //  Monitor Data (W)
}
CAN_RX_8MSG;

// PGU LEDs
typedef struct
{
    UINT16_REG  Top;
    UINT16_REG  Bot;
}LED_GROUP;


//typedef union
//{
//    Uint64      MSG_all;
//    UINT16_REG  MSG1;
//    UINT16_REG  MSG2;
//    UINT16_REG  MSG3;
//    UINT16_REG  MSG4;
//}DIOC_MSG;

typedef union
{
    Uint64      ullBuffer;
    UINT16_REG  uiBuffer[4];
}DIOC_MESSAGE;

// CONTROL REGISTERS
typedef struct  {
    DIOC_MESSAGE          C1              ;   // Analog Control Data (R)
    DIOC_MESSAGE          C2              ;   // Binary Control Data (R)
    DIOC_MESSAGE          C3              ;   // Binary Control Data (R)
    DIOC_MESSAGE          C4              ;   // Binary Control Data (R)
    DIOC_MESSAGE          C5              ;   // Binary Control Data (R)
    DIOC_MESSAGE          C6              ;   // Binary Control Data (R)
    DIOC_MESSAGE          C7              ;   // Binary Control Data (R)
    DIOC_MESSAGE          C8              ;   // Binary Control Data (R)
}DIOC_MSG;




typedef union
{
    Uint64      ullBuffer;
    UINT16_REG  uiBuffer[4];
}TCPU_MESSAGE;

// CONTROL REGISTERS
typedef struct  {
    TCPU_MESSAGE          C1              ;   // Analog Control Data (R)
    TCPU_MESSAGE          C2              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C3              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C4              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C5              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C6              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C7              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C8              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C9              ;   // Binary Control Data (R)
    TCPU_MESSAGE          C10              ;  // Binary Control Data (R)
    TCPU_MESSAGE          C11             ;   // Binary Control Data (R)
    TCPU_MESSAGE          C12             ;   // Binary Control Data (R)
    TCPU_MESSAGE          C13             ;   // Binary Control Data (R)
    TCPU_MESSAGE          C14             ;   // Binary Control Data (R)
    TCPU_MESSAGE          C15             ;   // Binary Control Data (R)
    TCPU_MESSAGE          C16             ;   // Binary Control Data (R)

}TCPU_MSG;




typedef union {
    unsigned short usAll;
    struct{
        unsigned int PackageNumber:8;
        unsigned int Sector:3;
        unsigned int Reset:1;
        unsigned int rsvd:1;
        unsigned int Error:1;
        unsigned int Finish:1;
        unsigned int Start:1;
    }bits;
}SWUpdateCtrlReg;

typedef union {
    unsigned short usAll;
    struct{
        unsigned int PackWriteTimeout:1;
        unsigned int PackUpdateTimeout:1;
        unsigned int CheckSumErr:1;
        unsigned int FlashEraseErr:1;
        unsigned int FlashProgramErr:1;
        unsigned int FlashVerifyErr:1;
        unsigned int SWUpdateStarted:1;
        unsigned int FileTransferOK:1;
        unsigned int SWUpdateOK:1;
        unsigned int rsvd:7;
    }bits;
}SWUpdateStatReg;

typedef union { // DualPortControlRegs
    unsigned char pucBuffer[16];
    unsigned short pusBuffer[8];
    unsigned long pulBuffer[4];
    unsigned long long pullBuffer[2];
    struct{
        unsigned short  CheckReg;
        SWUpdateCtrlReg SWUpdateCtrl;
        SWUpdateCtrlReg SWUpdateCtrln;
        SWUpdateStatReg SWUpdateStat;
        unsigned short  GA;
        unsigned short  reserved[2];
        unsigned short  checksum;
    }regs;
}DualPortControlRegs;

extern volatile CAN_TX_MSG CANBRDCSTMsg;

extern volatile FOIO_CAN_RX_MSG FOIO_CANRXMsg;
extern volatile FOIO_CAN_TX_MSG FOIO_CANTXMsg;

extern volatile TCPU_MSG TCPURXMsg;
extern volatile TCPU_MSG TCPUTXMsg;

extern volatile DIOC_MSG DIOC1RXMsg;
extern volatile DIOC_MSG DIOC2RXMsg;

extern volatile DIOC_MSG DIOC1TXMsg;
extern volatile DIOC_MSG DIOC2TXMsg;

extern volatile CAN_RX_MSG CC1RXMsg;
extern volatile CAN_TX_MSG CC1TXMsg;

extern volatile CAN_RX_8MSG PGURXMsg;
extern volatile CAN_TX_8MSG PGUTXMsg;

extern volatile UINT16_REG Faults[24];
extern volatile LED_GROUP  LedGroup;

extern volatile DualPortControlRegs DSP2TivaRegs;
extern volatile DualPortControlRegs Tiva2DSPRegs;
extern unsigned int MonitorData[240];
extern unsigned int EthRxData[128];
extern unsigned int SWUpdateBuff[2048];
extern unsigned int ExtRamBuff[65536];

#endif /* PGU_SHAREDMEM_H_ */
