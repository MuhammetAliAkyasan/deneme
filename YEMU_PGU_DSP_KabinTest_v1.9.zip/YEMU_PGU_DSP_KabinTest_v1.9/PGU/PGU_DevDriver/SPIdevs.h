//============================================================================
// FILE			: SPIdevs.h
// DESCRIPTION	: TLV5630, ADS7953 definitions & function prototypes
// AUTHOR		: AHO
// RELEASE		: 2.0
// DATE			: 31.01.2020
//============================================================================

#ifndef TLV5630_H_
#define TLV5630_H_

// SPI device channels
#define SPIDAC              0
#define SPIADC              1
#define SPIDAC2             2


/*----------------------------------------------------------------------------
 *  TLV5630 DEFINITIONS
 ---------------------------------------------------------------------------*/
// TLV5630 Register Addresses
#define TLV5630_DAC_A			0x0000	// DAC Channel A Register
#define TLV5630_DAC_B			0x0001	// DAC Channel B Register
#define TLV5630_DAC_C			0x0002	// DAC Channel C Register
#define TLV5630_DAC_D			0x0003	// DAC Channel D Register
#define TLV5630_DAC_E			0x0004	// DAC Channel E Register
#define TLV5630_DAC_F			0x0005	// DAC Channel F Register
#define TLV5630_DAC_G			0x0006	// DAC Channel G Register
#define TLV5630_DAC_H			0x0007	// DAC Channel H Register
#define TLV5630_CTRL0			0x0008	// CTRL0 Register
#define TLV5630_CTRL1			0x0009	// CTRL1 Register
#define TLV5630_PRESET			0x000A	// Preset Register
#define TLV5630_RESERVED		0x000B	// Reserved Register
#define TLV5630_DAC_A_nB		0x000C	// DAC Channel A and nB Register
#define TLV5630_DAC_C_nD		0x000D	// DAC Channel C and nD Register
#define TLV5630_DAC_E_nF		0x000E	// DAC Channel E and nF Register
#define TLV5630_DAC_G_nH		0x000F	// DAC Channel G and nH Register

// TLV5630 CTRL0 Register Bit Fields
#define POWER_DOWN				0x0010	// Power Down Mode Enabled
#define NO_POWER_DOWN			0x0000	// Normal Operation
#define DOUT_ENABLED			0x0008	// Dout Enabled
#define DOUT_DISABLED			0x0000	// Dout Disabled
#define EXT_REF_SEL				0x0002	// External Reference Selected
#define INT_1VREF_SEL			0x0004	// Internal 1.024V Reference Selected
#define INT_2VREF_SEL			0x0006	// Internal 2.048V Reference Selected
#define INP_MODE_ST_BIN			0x0000	// Input Mode = Straight Binary
#define INP_MODE_TWOS_COMP		0x0001	// Input Mode = Twos Complement

// TLV5630 CTRL1 Register Bit Fields
#define PO_DAC_GH				0x0080	// Power Down DAC G&H Enabled
#define NO_PD_DAC_GH			0x0000	// Power Down DAC G&H Disabled
#define PD_DAC_EF				0x0040	// Power Down DAC E&F Enabled
#define NO_PD_DAC_EF			0x0000	// Power Down DAC E&F Disabled
#define PD_DAC_CD				0x0020	// Power Down DAC C&D Enabled
#define NO_PD_DAC_CD			0x0000	// Power Down DAC C&D Disabled
#define PD_DAC_AB				0x0010	// Power Down DAC A&B Enabled
#define NO_PD_DAC_AB			0x0000	// Power Down DAC A&B Disabled
#define FAST_DAC_GH				0x0008	// Settling Time DAC G&H = Fast
#define SLOW_DAC_GH				0x0000	// Settling Time DAC G&H = Slow
#define FAST_DAC_EF				0x0004	// Settling Time DAC E&F = Fast
#define SLOW_DAC_EF				0x0000	// Settling Time DAC E&F = Slow
#define FAST_DAC_CD				0x0002	// Settling Time DAC C&D = Fast
#define SLOW_DAC_CD				0x0000	// Settling Time DAC C&D = Slow
#define FAST_DAC_AB				0x0001	// Settling Time DAC A&B = Fast
#define SLOW_DAC_AB				0x0000	// Settling Time DAC A&B = Slow

// TLV5630 Preset Register Definitions
#define PRESET_0V				0x0000	// DAC Channels Preset Value = 0V
#define PRESET_1_5V				0x0800	// DAC Channels Preset Value = 1.5V
#define PRESET_3V				0x0FFF	// DAC Channels Preset Value = 3V

/*----------------------------------------------------------------------------
 *  ADS7953 DEFINITIONS
 ---------------------------------------------------------------------------*/
// Special operations
#define ADS79XX_CONT_OP			0x0000	//Device continues operation in previously defined parameters

// Mode Operation Words
#define ADS79XX_MAN_MODE		0x1000	//Continue Operation in Manual Mode
#define ADS79XX_AUTO_MODE1		0x2000	//Continue Operation in Auto Mode 1
#define ADS79XX_AUTO_MODE2		0x3000	//Continue Operation in Auto Mode 2

// Mode Programming Words
#define ADS79XX_PROG_AUTO1		0x8000	//Enter Programming Mode for Auto Mode 1
#define	ADS79XX_PROG_AUTO2		0x9000	//Enter Programming Mode for Auto Mode 2

// Manual Mode Bit Fields
#define MAN_PROG_DISABLE		0x0000	//Disables Programming bits DI06-00
#define MAN_PROG_ENABLE			0x0800	//Enables Programming bits DI06-00

#define MAN_CHANNEL_SEL_0		0x0000	//Selects Channel 0 for next conversion
#define MAN_CHANNEL_SEL_1		0x0080	//Selects Channel 1 for next conversion
#define MAN_CHANNEL_SEL_2		0x0100	//Selects Channel 2 for next conversion
#define MAN_CHANNEL_SEL_3		0x0180	//Selects Channel 3 for next conversion
#define MAN_CHANNEL_SEL_4		0x0200	//Selects Channel 4 for next conversion
#define MAN_CHANNEL_SEL_5		0x0280	//Selects Channel 5 for next conversion
#define MAN_CHANNEL_SEL_6		0x0300	//Selects Channel 6 for next conversion
#define MAN_CHANNEL_SEL_7		0x0380	//Selects Channel 7 for next conversion
#define MAN_CHANNEL_SEL_8		0x0400	//Selects Channel 8 for next conversion
#define MAN_CHANNEL_SEL_9		0x0480	//Selects Channel 9 for next conversion
#define MAN_CHANNEL_SEL_10		0x0500	//Selects Channel 10 for next conversion
#define MAN_CHANNEL_SEL_11		0x0580	//Selects Channel 11 for next conversion
#define MAN_CHANNEL_SEL_12		0x0600	//Selects Channel 12 for next conversion
#define MAN_CHANNEL_SEL_13		0x0680	//Selects Channel 13 for next conversion
#define MAN_CHANNEL_SEL_14		0x0700	//Selects Channel 14 for next conversion
#define MAN_CHANNEL_SEL_15		0x0780	//Selects Channel 15 for next conversion

#define MAN_25VRANGE_SEL		0x0000	//Next conversion uses 2.5V range
#define MAN_5VRANGE_SEL			0x0040	//Next conversion uses 5V range

#define MAN_NORM_OP_SEL			0x0000	//Device continues in normal operation
#define	MAN_POW_DOWN_SEL		0x0020	//Device enters power down on 16th falling edge of SCLK

#define MAN_CHAN_ADDY_SEL		0x0000	//SDO outputs channel address on DO15-DO12 on next frame
#define MAN_GPIO_DATA_SEL		0x0010	//SDO outputs GPIO data on DO15-DO12 on next frame

//Auto Mode 1 Bit Fields
#define AUTO1_PROG_ENABLE		0x0800	//Enables programming bits DI10-DI00
#define AUTO1_PROG_DISABLE		0x0000	//Disables programming bits DI10-DI00
#define AUTO1_CHAN_COUNT_RESET	0x0400	//Resets channel counter to the lowest channel enabled
#define AUTO1_CHAN_COUNT_CONT	0x0000	//Channel counter continues incrementing normally
#define AUTO1_25VRANGE_SEL		0x0000	//Next conversion uses 2.5V range
#define AUTO1_5VRANGE_SEL		0x0040	//Next conversion uses 5V range
#define AUTO1_NORM_OP_SEL		0x0000	//Device continues in normal operation
#define AUTO1_POW_DOWN_SEL		0x0020	//Device enters power down on 16th falling edge of SCLK
#define AUTO1_CHAN_ADDY_SEL		0x0000	//SDO outputs channel address on DO15-DO12 on next frame
#define AUTO1_GPIO_DATA_SEL		0x0010	//SDO outputs GPIO data on DO15-DO12 on next frame

//Auto Mode 1 Programming Mode Bit Fields
//These words should only be used in Frame 2 programming sequence for auto mode 1
#define AUTO1_CHAN0_ENABLE		0x0001	//Enable channel 0 in Auto Mode 1 Sequence
#define AUTO1_CHAN1_ENABLE		0x0002	//Enable channel 1 in Auto Mode 1 Sequence
#define AUTO1_CHAN2_ENABLE		0x0004	//Enable channel 2 in Auto Mode 1 Sequence
#define AUTO1_CHAN3_ENABLE		0x0008	//Enable channel 3 in Auto Mode 1 Sequence
#define AUTO1_CHAN4_ENABLE		0x0010	//Enable channel 4 in Auto Mode 1 Sequence
#define AUTO1_CHAN5_ENABLE		0x0020	//Enable channel 5 in Auto Mode 1 Sequence
#define AUTO1_CHAN6_ENABLE		0x0040	//Enable channel 6 in Auto Mode 1 Sequence
#define AUTO1_CHAN7_ENABLE		0x0080	//Enable channel 7 in Auto Mode 1 Sequence
#define AUTO1_CHAN8_ENABLE		0x0100	//Enable channel 8 in Auto Mode 1 Sequence
#define AUTO1_CHAN9_ENABLE		0x0200	//Enable channel 9 in Auto Mode 1 Sequence
#define AUTO1_CHAN10_ENABLE		0x0400	//Enable channel 10 in Auto Mode 1 Sequence
#define AUTO1_CHAN11_ENABLE		0x0800	//Enable channel 11 in Auto Mode 1 Sequence
#define AUTO1_CHAN12_ENABLE		0x1000	//Enable channel 12 in Auto Mode 1 Sequence
#define AUTO1_CHAN13_ENABLE		0x2000	//Enable channel 13 in Auto Mode 1 Sequence
#define AUTO1_CHAN14_ENABLE		0x4000	//Enable channel 14 in Auto Mode 1 Sequence
#define AUTO1_CHAN15_ENABLE		0x8000	//Enable channel 15 in Auto Mode 1 Sequence

//Auto Mode 2 Programming Mode Bit Fields
//These words are used in the same frame as the entrance to Auto Mode 2 Programming
#define AUTO2_CHANRNG_SEL_0		0x0000	//Channel range is only channel 0
#define AUTO2_CHANRNG_SEL_1		0x0080	//Channel range is CH0-CH1
#define AUTO2_CHANRNG_SEL_2		0x0100	//Channel range is CH0-CH2
#define AUTO2_CHANRNG_SEL_3		0x0180	//Channel range is CH0-CH3
#define AUTO2_CHANRNG_SEL_4		0x0200	//Channel range is CH0-CH4
#define AUTO2_CHANRNG_SEL_5		0x0280	//Channel range is CH0-CH5
#define AUTO2_CHANRNG_SEL_6		0x0300	//Channel range is CH0-CH6
#define AUTO2_CHANRNG_SEL_7		0x0380	//Channel range is CH0-CH7
#define AUTO2_CHANRNG_SEL_8		0x0400	//Channel range is CH0-CH8
#define AUTO2_CHANRNG_SEL_9		0x0480	//Channel range is CH0-CH9
#define AUTO2_CHANRNG_SEL_10	0x0500	//Channel range is CH0-CH10
#define AUTO2_CHANRNG_SEL_11	0x0580	//Channel range is CH0-CH11
#define AUTO2_CHANRNG_SEL_12	0x0600	//Channel range is CH0-CH12
#define AUTO2_CHANRNG_SEL_13	0x0680	//Channel range is CH0-CH13
#define AUTO2_CHANRNG_SEL_14	0x0700	//Channel range is CH0-CH14
#define AUTO2_CHANRNG_SEL_15	0x0780	//Channel range is CH0-CH15

#define TEMPCH0		MAN_CHANNEL_SEL_0	// Selects Channel 0 for next conversion
#define	TEMPCH1		MAN_CHANNEL_SEL_1	// Selects Channel 1 for next conversion
#define TEMPCH2		MAN_CHANNEL_SEL_2	// Selects Channel 2 for next conversion
#define TEMPCH3		MAN_CHANNEL_SEL_3	// Selects Channel 3 for next conversion
#define TEMPCH4		MAN_CHANNEL_SEL_4	// Selects Channel 4 for next conversion
#define TEMPCH5		MAN_CHANNEL_SEL_5	// Selects Channel 5 for next conversion
#define TEMPCH6		MAN_CHANNEL_SEL_6	// Selects Channel 6 for next conversion
#define TEMPCH7		MAN_CHANNEL_SEL_7	// Selects Channel 7 for next conversion
#define TEMPCH8		MAN_CHANNEL_SEL_8	// Selects Channel 8 for next conversion
#define TEMPCH9		MAN_CHANNEL_SEL_9	// Selects Channel 9 for next conversion
#define TEMPCH10	MAN_CHANNEL_SEL_10	// Selects Channel 10 for next conversion
#define TEMPCH11	MAN_CHANNEL_SEL_11	// Selects Channel 11 for next conversion
#define TEMPCH12	MAN_CHANNEL_SEL_12	// Selects Channel 12 for next conversion
#define TEMPCH13	MAN_CHANNEL_SEL_13	// Selects Channel 13 for next conversion
#define TEMPCH14	MAN_CHANNEL_SEL_14	// Selects Channel 14 for next conversion
#define TEMPCH15	MAN_CHANNEL_SEL_15	// Selects Channel 15 for next conversion

//SPIdevs.c
extern void     tlv5630_init(void);
extern Uint16   tlv5630_registerWrite(Uint16 address, Uint16 value);
extern void     ads7953_init(void);
extern Uint16   ads7953_read(void);
extern void     delay_loop(void);
extern void     spi_xmit(Uint16 a);
extern void     spi_fifo_init(void);
extern void     spi_init(unsigned char device);
extern void     writeSPIADC(Uint16 data);
extern Uint16   SPIread(void);

#endif /* TLV5630_H_ */
