/*
 * SST39VF800A.h
 *
 *  Created on: 25 Eki 2012
 *      Author: AOB
 */
#ifndef SST39VF800A_H_
#define SST39VF800A_H_	1


#ifndef TRUE
#define FALSE 	0
#define TRUE  	1
#endif

#define SECTOR_SIZE		2048	/* Must be 2048 words for 39VFX00A */
#define BLOCK_SIZE		32768	/* Must be 32K words for 39VFX00A  */

#define SST_ID          0xBF    /* SST Manufacturer's ID code   */
#define SST_39VF800A    0x2781  /* SST39VF800A device code      */

//////SST39VF800A.c
//extern int    Check_SST_39VF800A();
//extern void   CFI_Query();
//extern void   Check_Toggle_Ready (Uint16 far *Dst);
//extern void   Erase_Entire_Chip();
//extern void   Erase_One_Sector (Uint16 far *Dst);
//extern void   Erase_One_Block (Uint16 far *Dst);
//extern void   Program_One_Word (Uint16 SrcWord, Uint16 far *Dst);
//extern void   Program_One_Sector (Uint16 far *Src, Uint16 far *Dst);
//extern void   Program_One_Block (Uint16 far *Src, Uint16 far *Dst);
//extern void   Check_Toggle_Ready (Uint16 far *Dst);
//extern void   Check_Data_Polling (Uint16 far *Dst, Uint16 TrueData);

#endif /* SST39VF800A_H_ */
