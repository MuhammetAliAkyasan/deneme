//============================================================================
// FILE         : SPIdevs.c
// DESCRIPTION  : TLV5630 DAC & ADS7953 ADC Drivers @ PGU
// AUTHOR       : AOB
// RELEASE      : 1.0
// DATE         : 29.09.2012
//============================================================================
#include "DSP28x_Project.h"
#include "SPIdevs.h"

Uint16 tlv5630_registerWrite(Uint16 address, Uint16 value)
{
    Uint16 sdata = 0x0000;
    sdata = (address << 12) | (value&0x0FFF);
    return sdata;
}

void tlv5630_init()
{
    spi_xmit(tlv5630_registerWrite(TLV5630_CTRL0, NO_POWER_DOWN | DOUT_DISABLED | EXT_REF_SEL | INP_MODE_ST_BIN));
    delay_loop();
    return;
}

void ads7953_init()
{   // AUTO-1 moduna ge�
    spi_xmit(ADS79XX_PROG_AUTO1);
    delay_loop();
    SPIread();          // dummy read
    // AUTO-1 modunda kullan�lacak kanallar� se�
    //spi_xmit(AUTO1_CHAN0_ENABLE | AUTO1_CHAN2_ENABLE | AUTO1_CHAN4_ENABLE | AUTO1_CHAN6_ENABLE | AUTO1_CHAN8_ENABLE | AUTO1_CHAN10_ENABLE);
    spi_xmit(0xFFFF);
    delay_loop();
    SPIread();          // dummy read
    // AUTO-1 modu �al��ma konfig�rasyonunu yap
    spi_xmit(ADS79XX_AUTO_MODE1 | AUTO1_PROG_ENABLE | AUTO1_CHAN_COUNT_CONT | AUTO1_25VRANGE_SEL | AUTO1_NORM_OP_SEL | AUTO1_CHAN_ADDY_SEL);
    delay_loop();
    SPIread();          // dummy read
    return;
}

Uint16 ads7953_read(void)
{
    spi_xmit(ADS79XX_CONT_OP);
    while(SpiaRegs.SPIFFRX.bit.RXFFST!=1) {}        // Wait until RXFIFO receives a character
    return SPIread();
}

Uint16 SPIread(void)
{
    Uint16 RXData;

    RXData=SpiaRegs.SPIRXBUF;
    return RXData;
}

void delay_loop()
{
    long      i;
    for (i = 0; i < 1000; i++) {}
    return;
}

void spi_init(unsigned char device)
{
    //SpiaRegs.SPICCR.all =0x004F;
    SpiaRegs.SPICCR.bit.SPISWRESET=0x0;     // SPI Reset on
    if (device==SPIDAC)
    SpiaRegs.SPICCR.bit.CLKPOLARITY=0x1;    // Rising Edge
    if (device==SPIDAC2)
    SpiaRegs.SPICCR.bit.CLKPOLARITY=0x1;    // Rising Edge
    if (device==SPIADC)
    SpiaRegs.SPICCR.bit.CLKPOLARITY=0x0;    // Falling Edge
    SpiaRegs.SPICCR.bit.SPILBK=0x0;         // Loopback disabled
    SpiaRegs.SPICCR.bit.SPICHAR=0xF;        // 16-bit character

    //SpiaRegs.SPICTL.all =0x000E;
    SpiaRegs.SPICTL.bit.OVERRUNINTENA=0x0;  // Overrun interrupt disabled
    SpiaRegs.SPICTL.bit.CLK_PHASE=0x1;      // Delayed phase
    SpiaRegs.SPICTL.bit.MASTER_SLAVE=0x1;   // Master mode
    SpiaRegs.SPICTL.bit.TALK=0x1;           // Enable transmission
    SpiaRegs.SPICTL.bit.SPIINTENA=0x0;      // SPI interrupt disabled

    SpiaRegs.SPIBRR =0x007F;                // Baudrate Value

    SpiaRegs.SPICCR.bit.SPISWRESET=0x1;     // Relinquish SPI from Reset

    SpiaRegs.SPIPRI.bit.FREE = 1;           // Set so breakpoints don't disturb xmission

    spi_fifo_init();                        // Initialize SPI FIFO registers

    /* Configure CS Decoding Pins - In normal use, configuration should be changed during program flow
    / A1-A0 = 00 -> DAC Active
    / A1-A0 = 10 -> DAC2 Active
    / A1-A0 = 01 -> ADC Active
     * A1 -> GPIO52
     * A0 -> GPIO53
    */

    EALLOW;
    if (device==SPIDAC)                            /*  SPIDAC in use -> A1-A0 = 00 */
    {
        while (GpioDataRegs.GPBDAT.bit.GPIO52 != 0)     // Clear CS Decoding Pin A1  GPIODAT de�erinin de�i�tirilmesine �al���ld���nda atlyarak de�eri de�i�tirmiyor. Bu nedenle while d�ng�s� i�erisine yaz�ld�.
            {
            GpioDataRegs.GPBDAT.bit.GPIO52= 0;
            }

        while (GpioDataRegs.GPBDAT.bit.GPIO53 != 0)     // Clear CS Decoding Pin A0
            {
            GpioDataRegs.GPBDAT.bit.GPIO53 = 0;
            }
    }

    if (device==SPIDAC2)                         /*  SPIDAC in use -> A1-A0 = 10 */
    {
        while (GpioDataRegs.GPBDAT.bit.GPIO52 != 1)     // Set CS Decoding Pin A1
            {
            GpioDataRegs.GPBDAT.bit.GPIO52= 1;
            }

        while (GpioDataRegs.GPBDAT.bit.GPIO53 != 0)     // Clear CS Decoding Pin A0
            {
            GpioDataRegs.GPBDAT.bit.GPIO53 = 0;
            }
    }

    if (device==SPIADC)                         /*  SPIADC in use -> A1-A0 = 01 */
    {
        while (GpioDataRegs.GPBDAT.bit.GPIO52 != 0)     // Clear CS Decoding Pin A1
            {
            GpioDataRegs.GPBDAT.bit.GPIO52= 0;
            }

        while (GpioDataRegs.GPBDAT.bit.GPIO53 != 1)     // Set CS Decoding Pin A0
            {
            GpioDataRegs.GPBDAT.bit.GPIO53 = 1;
            }
    }
    EDIS;
    return;
}

void spi_fifo_init()
{
// Initialize SPI FIFO registers
    SpiaRegs.SPIFFTX.all=0xE040;
    SpiaRegs.SPIFFRX.all=0x204f;
    SpiaRegs.SPIFFCT.all=0x0;
    return;
}

void spi_xmit(Uint16 a)
{
    SpiaRegs.SPITXBUF=a;
    return;
}
