//============================================================================
// FILE			: SST39VF800A.c
// DESCRIPTION	: SST39VF800A driver for PGU
// AUTHOR		: AOB
// RELEASE		: 1.0
// DATE			: 25.10.2012
// NOTES		:
//
//============================================================================
/*	Name              		Function
------------------------------------------------------------------
	Check_SST_39VF800A     	Check manufacturer and device ID
	CFI_Query               CFI Query Entry/Exit command sequence
	Erase_Entire_Chip       Erase the contents of the entire chip
	Erase_One_Sector        Erase a sector of 2048 words
	Erase_One_Block         Erase a block of 32K words
	Program_One_Word        Alter data in one word
	Program_One_Sector      Alter data in 2048 word sector
	Program_One_Block       Alter data in 32K word block
	Check_Toggle_Ready      End of internal program or erase detection using Toggle bit
	Check_Data_Polling      End of internal program or erase detection using Data# polling
*/

/************************************************************************/
/* Copyright Silicon Storage Technology, Inc. (SST), 1994-2001         	*/
/* Example "C" language Driver of 39VF800A 8 Mbitt Multi-Purpose Flash  */
/* Nelson Wang, Silicon Storage Technology, Inc.                       	*/
/*                                                                     	*/
/* Revision 1.0, Sept. 12, 2001                                         */
/*                                                                     	*/
/* This file requires these external "timing"  routines:               	*/
/*                                                                     	*/
/*      1.)  Delay_150_Nano_Seconds                                    	*/
/*      2.)  Delay_25_Milli_Seconds                                    	*/
/*      3.)  Delay_100_Milli_Seconds                                   	*/
/************************************************************************/
#include "DSP28x_Project.h"
#include "PGU_Settings.h"
#include "SST39VF800A.h"

/************************************************************************/
/* PROCEDURE:   Check_SST_39VF800A                						*/
/*                                                                      */
/* This procedure decides whether a physical hardware device has a      */
/* SST39VF800A 8 Mbit Multi-Purpose Flash installed or not  			*/
/*                                                                      */
/* Input:                                                               */
/*          None                                                        */
/*                                                                      */
/* Output:                                                              */
/*          return TRUE:  indicates a SST39VF800A     					*/
/*          return FALSE: indicates not a SST39VF800A                 	*/
/************************************************************************/

int Check_SST_39VF800A()
{
	Uint16 far *Temp;
	Uint16 SST_id1;
	Uint16 far *Temp1;
	Uint16 SST_id2;
	int  ReturnStatus;

	/*  Issue the Software Product ID code to 39VF800A   */

	Temp1 = (Uint16 far *)0x00105555; 	/* set up address to be 0010:5555h  */
	*Temp1= 0xAAAA;                 	/* write data 0xAAAA to the address */
	Temp1 = (Uint16 far *)0x00102AAA; 	/* set up address to be 0010:2AAAh  */
	*Temp1= 0x5555;                 	/* write data 0x5555 to the address */
	Temp1 = (Uint16 far *)0x00105555; 	/* set up address to be 0010:5555h  */
	*Temp1= 0x9090;                 	/* write data 0x9090 to the address */

	//Delay_150_Nano_Seconds();
	DELAY_US(1);
	/* Read the product ID from 39VF800A */

	Temp  = (Uint16 far *)0x00100000; 	/* set up address to be 0010:0000h */
	SST_id1  =  *Temp;              	/* get first ID word               */
	SST_id1  =  SST_id1 & 0xFF;     	/* mask of higher byte             */
	Temp1 = (Uint16 far *)0x00100001; 	/* set up address to be 0010:0001h */
	SST_id2  =  *Temp1;             	/* get second ID word              */

	/* Determine whether there is a SST39VF800 installed or not */

	if ((SST_id1 == SST_ID) && (SST_id2 ==SST_39VF800A))
			ReturnStatus = FALSE;
	else
			ReturnStatus = TRUE;

	/* Issue the Soffware Product ID Exit code thus returning the 39VF800A */
	/* to the read operating mode                                         */

	Temp1  = (Uint16 far *)0x00105555; 	/* set up address to be 0010:5555h   */
	*Temp1 = 0xAAAA;                 	/* write data 0xAAAA to the address  */
	Temp1  = (Uint16 far *)0x00102AAA; 	/* set up address to be 0010:2AAAh   */
	*Temp1 = 0x5555;                 	/* write data 0x5555 to the address  */
	Temp1  = (Uint16 far *)0x00105555; 	/* set up address to be 0010:5555h   */
	*Temp1 = 0xF0F0;                 	/* write data 0xF0F0 to the address  */

	//Delay_150_Nano_Seconds();
	DELAY_US(1);

	return(ReturnStatus);
}

/************************************************************************/
/* PROCEDURE:   CFI_Query												*/
/*																		*/
/* This procedure should be used to query for CFI information			*/
/*																		*/
/* Input:																*/
/*          None														*/
/*																		*/
/* Output:																*/
/*          None														*/
/************************************************************************/

void CFI_Query()
{
	Uint16 far *Temp1;

	// Issue the Software Product ID code to 39VF800A

	Temp1 = (Uint16 far *)0x00105555;	// set up address to be 0010:5555h
	*Temp1= 0xAAAA;                  	// write data 0xAAAA to the address
	Temp1 = (Uint16 far *)0x00102AAA;  	// set up address to be 0010:2AAAh
	*Temp1= 0x5555;                  	// write data 0x5555 to the address
	Temp1 = (Uint16 far *)0x00105555;  	// set up address to be 0010:5555h
	*Temp1= 0x9898;                  	// write data 0x9898 to the address

	//Delay_150_Nano_Seconds();
	DELAY_US(1);

	 /*---------------------------------
	  Perform all CFI operations here
	  NOTE:  no sample code provided
	 ---------------------------------*/
//	printf("Flash size is %d !\n", *(Uint16 far *)0x00100027);
//	printf("Flash device interface is %d !\n", *(Uint16 far *)0x00100028);
//	printf("Sector Information\n");
//	printf("------------------\n");
//	printf("Number of Sectors : %d\n", (*(Uint16 far *)0x0010002D)+1);
//	printf("Sector Size : %d kByte/sector\n", *(Uint16 far *)0x0010002F >>2);

	 /*Issue the CFI Exit code thus returning the 39VF800A
	 to the read operating mode*/

	Temp1  = (Uint16 far *)0x00105555;  	// set up address to be 0010:5555h
	*Temp1 = 0xAAAA;                  	// write data 0xAAAA to the address
	Temp1  = (Uint16 far *)0x00102AAA;  	// set up address to be 0010:2AAAh
	*Temp1 = 0x5555;                  	// write data 0x5555 to the address
	Temp1  = (Uint16 far *)0x00105555;  	// set up address to be 0010:5555h
	*Temp1 = 0xF0F0;                  	// write data 0xF0F0 to the address

	//Delay_150_Nano_Seconds();
	DELAY_US(1);
}

/************************************************************************/
/* PROCEDURE:   Erase_Entire_Chip                                       */
/*                                                                      */
/* This procedure can be used to erase the entire chip.                 */
/*                                                                      */
/* Input:                                                               */
/*      NONE                                                            */
/*                                                                      */
/* Output:                                                              */
/*      NONE                                                            */
/************************************************************************/

void Erase_Entire_Chip()
{
        Uint16 far *Temp;

        /*  Issue the Chip Erase command to 39VF800A  */

        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0xAAAA;                 /* write data 0xAAAA to the address */
        Temp  = (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh  */
        *Temp = 0x5555;                 /* write data 0x5555 to the address */
        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0x8080;                 /* write data 0x8080 to the address */
        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0xAAAA;                 /* write data 0xAAAA to the address */
        Temp  = (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh  */
        *Temp = 0x5555;                 /* write data 0x5555 to the address */
        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0x1010;                 /* write data 0x1010 to the address */
        //Delay_100_Milli_Seconds();      /* Delay Tsce time                  */
        DELAY_US(100000);
}

/************************************************************************/
/* PROCEDURE:   Erase_One_Sector                                        */
/*                                                                      */
/* This procedure can be used to erase a total of 2048 words.           */
/*                                                                      */
/* Input:                                                               */
/*      Dst     DESTINATION address where the erase operation starts    */
/*                                                                      */
/* Output:                                                              */
/*      NONE                                                            */
/************************************************************************/

void Erase_One_Sector (Uint16 far *Dst)
{
        Uint16 far *Temp;

        /*  Issue the Sector Erase command to 39VF800A  */

        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0xAAAA;                 /* write data 0xAAAA to the address */
        Temp  = (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh  */
        *Temp = 0x5555;                 /* write data 0x5555 to the address */
        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0x8080;                 /* write data 0x8080 to the address */
        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0xAAAA;                 /* write data 0xAAAA to the address */
        Temp  = (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh  */
        *Temp = 0x5555;                 /* write data 0x5555 to the address */

        Temp  = Dst;                    /* set up starting address to be erased */
        *Temp = 0x3030;                 /* write data 0x3030 to the address */
        //Delay_25_Milli_Seconds();       /* Delay time = Tse                 */
        DELAY_US(25000);
}

/************************************************************************/
/* PROCEDURE:   Erase_One_Block                                         */
/*                                                                      */
/* This procedure can be used to erase a total of 32K words.            */
/*                                                                      */
/* Input:                                                               */
/*      Dst     DESTINATION address where the erase operation starts    */
/*                                                                      */
/* Output:                                                              */
/*      NONE                                                            */
/************************************************************************/

void Erase_One_Block (Uint16 far *Dst)
{
        Uint16 far *Temp;

        /*  Issue the Sector Erase command to 39VF800A  */

        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0xAAAA;                 /* write data 0xAAAA to the address */
        Temp  = (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh  */
        *Temp = 0x5555;                 /* write data 0x5555 to the address */
        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0x8080;                 /* write data 0x8080 to the address */
        Temp  = (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0xAAAA;                 /* write data 0xAAAA to the address */
        Temp  = (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh  */
        *Temp = 0x5555;                 /* write data 0x5555 to the address */

	Temp  = Dst;                    /* set up starting address to be erased */
        *Temp = 0x5050;                 /* write data 0x5050 to the address */
        //Delay_25_Milli_Seconds();       /* Delay time = Tbe                 */
        DELAY_US(25000);
}

/************************************************************************/
/* PROCEDURE:   Program_One_Word                                        */
/*                                                                      */
/* This procedure can be used to program ONE word of data to the        */
/* 39VF800.                                                             */
/*                                                                      */
/* NOTE:  It is necessary to first erase the sector containing the      */
/*        word to be programmed.                                  */
/*                                                                      */
/* Input:                                                               */
/*           Src     The Uint16 which will be written to the 39VF800A      */
/*           Dst     DESTINATION address which will be written with the */
/*                   data passed in from Src                            */
/*                                                                      */
/* Output:                                                              */
/*           None                                                       */
/************************************************************************/

void Program_One_Word (Uint16 SrcWord,    Uint16 far *Dst)
{
		Uint16 far *Temp;
        Uint16 far *DestBuf;

        DestBuf = Dst;

        Temp =  (Uint16 far *)0x00105555; /* set up address to be 0010:555h   */
        *Temp = 0xAAAA;                 /* write data 0xAAAA to the address */
        Temp =  (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh  */
        *Temp = 0x5555;                 /* write data 0x5555 to the address */
        Temp =  (Uint16 far *)0x00105555; /* set up address to be 0010:5555h  */
        *Temp = 0xA0A0;                 /* write data 0xA0A0 to the address */
        *DestBuf = SrcWord;             /* transfer the byte to destination */
        Check_Toggle_Ready(DestBuf);    /* wait for TOGGLE bit to get ready */
}

/************************************************************************/
/* PROCEDURE:   Program_One_Sector                                      */
/*                                                                      */
/* This procedure can be used to program a total of 2048 words of data  */
/* to the SST39VF800A.                                                   */
/*                                                                      */
/* Input:                                                               */
/*           Src     SOURCE address containing the data which will be   */
/*                   written to the 39VF800                             */
/*           Dst     DESTINATION address which will be written with the */
/*                   data passed in from Src                            */
/*                                                                      */
/* Output:                                                              */
/*           None                                                       */
/************************************************************************/

void Program_One_Sector (Uint16 far *Src,    Uint16 far *Dst)
{
        Uint16 far *Temp;
        Uint16 far *SourceBuf;
        Uint16 far *DestBuf;
        int Index;

        SourceBuf = Src;
        DestBuf = Dst;

        Erase_One_Sector(Dst);          /* erase the sector first */

        for (Index = 0; Index < SECTOR_SIZE; Index++)
        {
            Temp =  (Uint16 far *)0x00105555; /* set up address to be 0010:555h           */
            *Temp = 0xAAAA;                 /* write data 0xAAAA to the address         */
            Temp =  (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh          */
            *Temp = 0x5555;                 /* write data 0x5555 to the address         */
            Temp =  (Uint16 far *)0x00105555; /* set up address to be 0010:5555h          */
            *Temp = 0xA0A0;                 /* write data 0xA0A0 to the address         */
            Temp = DestBuf;                 /* save the original Destination address    */
            *DestBuf++ = *SourceBuf++;      /* transfer data from source to destination */
            Check_Toggle_Ready(Temp);       /* wait for TOGGLE bit to get ready         */
        }
}

/************************************************************************/
/* PROCEDURE:   Program_One_Block                                       */
/*                                                                      */
/* This procedure can be used to program a total of 32k words of data   */
/* to the SST39VF800A.                                                   */
/*                                                                      */
/* Input:                                                               */
/*           Src     SOURCE address containing the data which will be   */
/*                   written to the 39VF800                             */
/*           Dst     DESTINATION address which will be written with the */
/*                   data passed in from Src                            */
/*                                                                      */
/* Output:                                                              */
/*           None                                                       */
/************************************************************************/

void Program_One_Block (Uint16 far *Src,    Uint16 far *Dst)
{
        Uint16 far *Temp;
        Uint16 far *SourceBuf;
        Uint16 far *DestBuf;
        int Index;

        SourceBuf = Src;
        DestBuf = Dst;

        Erase_One_Block(Dst);          /* erase the sector first */

        for (Index = 0; Index < BLOCK_SIZE; Index++)
        {
            Temp =  (Uint16 far *)0x00105555; /* set up address to be 0010:555h           */
            *Temp = 0xAAAA;                 /* write data 0xAAAA to the address         */
            Temp =  (Uint16 far *)0x00102AAA; /* set up address to be 0010:2AAAh          */
            *Temp = 0x5555;                 /* write data 0x5555 to the address         */
            Temp =  (Uint16 far *)0x00105555; /* set up address to be 0010:5555h          */
            *Temp = 0xA0A0;                 /* write data 0xA0A0 to the address         */
            Temp = DestBuf;                 /* save the original Destination address    */
            *DestBuf++ = *SourceBuf++;      /* transfer data from source to destination */
            Check_Toggle_Ready(Temp);       /* wait for TOGGLE bit to get ready         */
        }
}

/************************************************************************/
/* PROCEDURE:    Check_Toggle_Ready                                     */
/*                                                                      */
/* During the internal program cycle, any consecutive read operation    */
/* on DQ6 will produce alternating 0's and 1's (i.e. toggling between   */
/* 0 and 1). When the program cycle is completed, DQ6 of the data will  */
/* stop toggling. After the DQ6 data bit stops toggling, the device is  */
/* ready for next operation.                                            */
/*                                                                      */
/* Input:                                                               */
/*           Dst        must already be set-up by the caller            */
/*                                                                      */
/* Output:                                                              */
/*           None                                                       */
/************************************************************************/

void Check_Toggle_Ready (Uint16 far *Dst)
{
        Uint16 Loop = TRUE;
        Uint16 PreData;
        Uint16 CurrData;
        unsigned long TimeOut = 0;

        PreData = *Dst;
        PreData = PreData & 0x4040;
        while ((TimeOut< 0x07FFFFFF) && (Loop))
        {
            CurrData = *Dst;
            CurrData = CurrData & 0x4040;
            if (PreData == CurrData)
                    Loop = FALSE;   /* ready to exit the while loop */
            PreData = CurrData;
            TimeOut++;
        }
}

/************************************************************************/
/* PROCEDURE:   Check_Data_Polling                                      */
/*                                                                      */
/* During the internal program cycle, any attempt to read DQ7 of the    */
/* last byte loaded during the page/byte-load cycle will receive the    */
/* complement of the true data.  Once the program cycle is completed,   */
/* DQ7 will show true data.                                             */
/*                                                                      */
/* Input:                                                               */
/*           Dst        must already be set-up by the caller            */
/*           True       Data is the original (true) data                */
/*                                                                      */
/* Output:                                                              */
/*           None                                                       */
/************************************************************************/

void Check_Data_Polling (Uint16 far  *Dst,       Uint16 TrueData)
{
        Uint16 Loop = TRUE;
        Uint16 CurrData;
        unsigned long TimeOut = 0;

        TrueData = TrueData &  0x8080;
        while ((TimeOut< 0x07FFFFFF) && (Loop))
        {
                CurrData = *Dst;
                CurrData = CurrData & 0x8080;
                if (TrueData == CurrData)
                        Loop = FALSE;   /* ready to exit the while loop  */
                TimeOut++;
        }
}
