//============================================================================
// FILE			: DSP_IOConfig.c
// DESCRIPTION	: GPIO configuration for PGU
// AUTHOR		: GA & HFE
// RELEASE		: 1.0
// DATE			: 06.01.2021
// NOTES		:
//============================================================================
#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "PGU_Common.h"

//---------------------------------------------------------------------------
// InitDSPPeripherals:
//---------------------------------------------------------------------------
// This function initializes DSP GPIO pins according to PGU functions.
//
void InitDSPPeripherals(void)
{
    InitDSPEPwm1Gpio();       // Single Phase Rectifier Branch-REC1U
    InitDSPEPwm2Gpio();       // Single Phase Rectifier Branch-REC1V
    InitDSPEPwm3Gpio();       // Single Phase Rectifier Branch-REC2V   // Three phase Inverter Branch-InvU
    InitDSPEPwm4Gpio();       // Single Phase Rectifier Branch-REC1U   // OVCrf
    InitDSPEPwm5Gpio();       // RSV                                   // Three phase Inverter Branch-InvV
    InitDSPEPwm6Gpio();       // RSV                                   // Three phase Inverter Branch-InvW
    InitDSPEPwmSyncGpio();    // Reserved. EPWMSYNCI (GPIO32 in use)
//    InitDSPECapGpio();        // ZERO_SYNC is input to ECAP. ECAP Interrupt not in use.
	InitDSPEQep1Gpio();        // Speed measurement not in use at LOCO mode.
//    InitDSPEQep2Gpio();        // Speed measurement not in use at LOCO mode.
	InitDSPCanGpio();         // DSPCan in use at LOCO mode.
	InitDSPSpiGpio();         // Temperature Read(SPI-ADC)-Hardware Protection(SPI-DAC)
	InitDSPSciGpio();         // MCU and DSP Serial Communication Interface(SCI) RS-232
	InitDSPTz1Gpio();         // CFD Error ( FOIO to PGU)
	InitDSPTz2Gpio();         // Hardware Gate Off (HGOFF) (TCPU to PGU)
	InitDSPXintf16Gpio();     // External Interface (XINTF) configuration (DualPort_Ram- Flash -SRAM read/write operation)
	InitDSPIOGpio_REC();      // General Purpose Input/Output
}

void InitDSPEPwm1Gpio(void)
{
   EALLOW;
/* Configure ePWM1 pins using GPIO regs*/
   GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;      // Configure GPIO0 as EPWM1A
   GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;      // Configure GPIO1 as EPWM1B
/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPAPUD.bit.GPIO0 = 0;       // Enable pull-up on GPIO0 (EPWM1A)
   GpioCtrlRegs.GPAPUD.bit.GPIO1 = 0;       // Enable pull-up on GPIO1 (EPWM1B)
   EDIS;
}

void InitDSPEPwm2Gpio(void)
{
    EALLOW;
    /* Configure ePWM2 pins using GPIO regs*/
    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1;      // Configure GPIO2 as EPWM2A
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1;      // Configure GPIO3 as EPWM2B
    /* Enable internal pull-up for the selected pins */
    GpioCtrlRegs.GPAPUD.bit.GPIO2 = 0;       // Enable pull-up on GPIO2 (EPWM2A)
    GpioCtrlRegs.GPAPUD.bit.GPIO3 = 0;       // Enable pull-up on GPIO3 (EPWM3B)
    EDIS;
}

void InitDSPEPwm3Gpio(void)
{
   EALLOW;
/* Configure ePWM-3,5,6 pins using GPIO regs*/
   GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;      // Configure GPIO4 as EPWM3A
   GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1;      // Configure GPIO5 as EPWM3B
/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPAPUD.bit.GPIO4 = 0;       // Enable pull-up on GPIO4 (EPWM3A)
   GpioCtrlRegs.GPAPUD.bit.GPIO5 = 0;       // Enable pull-up on GPIO5 (EPWM3B)
   EDIS;
}


void InitDSPEPwm5Gpio(void)
{
    EALLOW;
 /* Configure ePWM5 pins using GPIO regs*/
    GpioCtrlRegs.GPAMUX1.bit.GPIO8 = 1;      // Configure GPIO8 as EPWM5A
    GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 1;      // Configure GPIO9 as EPWM5B
 /* Enable internal pull-up for the selected pins */
    GpioCtrlRegs.GPAPUD.bit.GPIO8 = 0;       // Enable pull-up on GPIO8 (EPWM5A)
    GpioCtrlRegs.GPAPUD.bit.GPIO9 = 0;       // Enable pull-up on GPIO9 (EPWM5B)
    EDIS;
}
void InitDSPEPwm6Gpio(void)
{
    EALLOW;
 /* Configure ePWM6 pins using GPIO regs*/
    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1;     // Configure GPIO10 as EPWM6A
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1;     // Configure GPIO11 as EPWM6B
 /* Enable internal pull-up for the selected pins */
    GpioCtrlRegs.GPAPUD.bit.GPIO10 = 0;      // Enable pull-up on GPIO10 (EPWM6A)
    GpioCtrlRegs.GPAPUD.bit.GPIO11 = 0;      // Enable pull-up on GPIO11 (EPWM6B)
    EDIS;
}

void InitDSPEPwm4Gpio(void)
{
    EALLOW;
 /* Configure ePWM6 pins using GPIO regs*/
    GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 1;     // Configure GPIO10 as EPWM6A
    GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 1;     // Configure GPIO11 as EPWM6B
 /* Enable internal pull-up for the selected pins */
    GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;      // Enable pull-up on GPIO10 (EPWM6A)
    GpioCtrlRegs.GPAPUD.bit.GPIO7 = 0;      // Enable pull-up on GPIO11 (EPWM6B)
    EDIS;
}


void InitDSPEPwmSyncGpio(void)
{
   EALLOW;

/* Configure EPWMSYNC pins using GPIO regs */
   GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 2;     // Configure GPIO32 for EPWMSYNCI operation
   GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 2;     // Configure GPIO33 for EPWMSYNC0 operation

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;      // Enable pull-up for GPIO32 (EPWMSYNCI)
   GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;      // Enable pull-up for GPIO33 (EPWMSYNC0)

/* Set qualification for selected pins to asynch only */
   GpioCtrlRegs.GPBQSEL1.bit.GPIO32 = 2;    // Asynch input GPIO32 (EPWMSYNCI)
   GpioCtrlRegs.GPBQSEL1.bit.GPIO33 = 2;    // Asynch input GPIO33 (EPWMSYNC0)

   EDIS;
}

//void InitDSPECapGpio()
//{
//   EALLOW;
//
///* Configure eCAP-1 pins using GPIO regs*/
//   GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 1;     // Configure GPIO24 as CAP1
//
///* Enable internal pull-up for the selected pins */
//   GpioCtrlRegs.GPAPUD.bit.GPIO24 = 0;      // Enable pull-up on GPIO24 (CAP1)
//
///* Inputs are synchronized to SYSCLKOUT by default*/
//   GpioCtrlRegs.GPAQSEL2.bit.GPIO24 = 0;    // Synch to SYSCLKOUT GPIO24 (CAP1)
//
//   EDIS;
//}


void InitDSPEQep1Gpio()
{
   EALLOW;

/* Configure eQEP-1 pins using GPIO regs*/
   GpioCtrlRegs.GPBMUX2.bit.GPIO50 = 1;     // Configure GPIO50 as EQEP1A
   GpioCtrlRegs.GPBMUX2.bit.GPIO51 = 1;     // Configure GPIO51 as EQEP1B

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPBPUD.bit.GPIO50 = 0;      // Enable pull-up on GPIO50 (EQEP1A)
   GpioCtrlRegs.GPBPUD.bit.GPIO51 = 0;      // Enable pull-up on GPIO51 (EQEP1B)

/* Inputs are synchronized to SYSCLKOUT by default*/
   GpioCtrlRegs.GPBQSEL2.bit.GPIO50 = 0;    // Sync to SYSCLKOUT GPIO50 (EQEP1A)
   GpioCtrlRegs.GPBQSEL2.bit.GPIO51 = 0;    // Sync to SYSCLKOUT GPIO51 (EQEP1B)

   EDIS;
}

void InitDSPEQep2Gpio()
{
   EALLOW;

/* Configure eQEP-2 pins using GPIO regs*/
   GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 2;     // Configure GPIO24 as EQEP2A
   GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 2;     // Configure GPIO25 as EQEP2B

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPAPUD.bit.GPIO24 = 0;      // Enable pull-up on GPIO24 (EQEP2A)
   GpioCtrlRegs.GPAPUD.bit.GPIO25 = 0;      // Enable pull-up on GPIO25 (EQEP2B)

/* Inputs are synchronized to SYSCLKOUT by default*/
   GpioCtrlRegs.GPAQSEL2.bit.GPIO24 = 0;    // Sync to SYSCLKOUT GPIO50 (EQEP1A)
   GpioCtrlRegs.GPAQSEL2.bit.GPIO25 = 0;    // Sync to SYSCLKOUT GPIO51 (EQEP1B)

   EDIS;
}


void InitDSPCanGpio(void)
{
   EALLOW;

/* Configure eCAN-B pins using GPIO regs*/
   GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 3;     // Configure GPIO16 for CANTXB operation
   GpioCtrlRegs.GPAMUX2.bit.GPIO17= 3;     // Configure GPIO17 for CANRXB operation

/* Enable internal pull-up for the selected CAN pins */
   GpioCtrlRegs.GPAPUD.bit.GPIO16 = 0;      // Enable pull-up for GPIO16 (CANTXB)
   GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0;      // Enable pull-up for GPIO17 (CANRXB)

/* Set qualification for selected CAN pins to asynch only */
//   GpioCtrlRegs.GPAQSEL2.bit.GPIO16 = 3;    // Asynch qual for GPIO16 (CANRXA)
   GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 3;    // Asynch qual for GPIO17 (CANRXB)

   EDIS;
}


void InitDSPSpiGpio()
{
   EALLOW;

/* Configure SPI-A pins using GPIO regs*/
   GpioCtrlRegs.GPBMUX2.bit.GPIO52 = 0;     // Configure GPIO52 as GPIO52 (SPICS_A1)
   GpioCtrlRegs.GPBMUX2.bit.GPIO53 = 0;     // Configure GPIO53 as GPIO53 (SPICS_A0)
   GpioCtrlRegs.GPBMUX2.bit.GPIO54 = 1;     // Configure GPIO54 as SPISIMOA
   GpioCtrlRegs.GPBMUX2.bit.GPIO55 = 1;     // Configure GPIO55 as SPISOMIA
   GpioCtrlRegs.GPBMUX2.bit.GPIO56 = 1;     // Configure GPIO56 as SPICLKA
   GpioCtrlRegs.GPBMUX2.bit.GPIO57 = 1;     // Configure GPIO57 as SPISTEA

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPBPUD.bit.GPIO52 = 0;      // Enable pull-up on GPIO52 (SPICS_A1)
   GpioCtrlRegs.GPBPUD.bit.GPIO53 = 0;      // Enable pull-up on GPIO53 (SPICS_A0)
   GpioCtrlRegs.GPBPUD.bit.GPIO54 = 0;      // Enable pull-up on GPIO54 (SPISIMOA)
   GpioCtrlRegs.GPBPUD.bit.GPIO55 = 0;      // Enable pull-up on GPIO55 (SPISOMIA)
   GpioCtrlRegs.GPBPUD.bit.GPIO56 = 0;      // Enable pull-up on GPIO56 (SPICLKA)
   GpioCtrlRegs.GPBPUD.bit.GPIO57 = 0;      // Enable pull-up on GPIO57 (SPISTEA)

/* Set qualification for selected pins to asynch only */
   GpioCtrlRegs.GPBQSEL2.bit.GPIO52 = 3;    // Asynch input GPIO52 (SPICS_A1)
   GpioCtrlRegs.GPBQSEL2.bit.GPIO53 = 3;    // Asynch input GPIO53 (SPICS_A0)
   GpioCtrlRegs.GPBQSEL2.bit.GPIO54 = 3;    // Asynch input GPIO54 (SPISIMOA)
   GpioCtrlRegs.GPBQSEL2.bit.GPIO55 = 3;    // Asynch input GPIO55 (SPISOMIA)
   GpioCtrlRegs.GPBQSEL2.bit.GPIO56 = 3;    // Asynch input GPIO56 (SPICLKA)
   GpioCtrlRegs.GPBQSEL2.bit.GPIO57 = 3;    // Asynch input GPIO57 (SPISTEA)

/* Configure CS Decoding Pins A1&A0 as Output */
   GpioCtrlRegs.GPBDIR.bit.GPIO52 = 1;      // Configure CS Decoding Pin A1 as Output
   GpioCtrlRegs.GPBDIR.bit.GPIO53 = 1;      // Configure CS Decoding Pin A0 as Output

   EDIS;
}

void InitDSPSciGpio()
{
   EALLOW;

/* Configure SCI-B pins using GPIO regs */
   GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 2;     // Configure GPIO18 for SCITXDB operation
   GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 2;     // Configure GPIO19 for SCIRXDB operation

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPAPUD.bit.GPIO18 = 0;      // Enable pull-up for GPIO18 (SCITXDB)
   GpioCtrlRegs.GPAPUD.bit.GPIO19 = 0;      // Enable pull-up for GPIO19 (SCIRXDB)

/* Set qualification for selected pins to asynch only */
   GpioCtrlRegs.GPAQSEL2.bit.GPIO18 = 3;    // Asynch input GPIO18 (SCITXDB)
   GpioCtrlRegs.GPAQSEL2.bit.GPIO19 = 3;    // Asynch input GPIO19 (SCIRXDB)

   EDIS;
}

void InitDSPTz1Gpio(void)
{
   EALLOW;

/* Configure TZ pins using GPIO regs*/
   GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 1;     // Configure GPIO12 as TZ1

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPAPUD.bit.GPIO12 = 0;      // Enable pull-up on GPIO12 (TZ1)

/* Set qualification for selected pins to asynch only */
   GpioCtrlRegs.GPAQSEL1.bit.GPIO12 = 2;    // Qualification using 6 samples. GPIO12 (TZ1)

   GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = 0x30; // Sampling Period = 96 � TSYSCLKOUT, 3.83us = 6*96*6.66ns

   EDIS;
}

void InitDSPTz2Gpio(void)
{
   EALLOW;

/* Configure TZ pins using GPIO regs*/
   GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1;     // Configure GPIO13 as TZ2

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPAPUD.bit.GPIO13 = 0;      // Enable pull-up on GPIO13 (TZ2)

/* Set qualification for selected pins to asynch only */
   GpioCtrlRegs.GPAQSEL1.bit.GPIO13 = 2;    // Qualification using 6 samples. GPIO13 (TZ2)

   GpioCtrlRegs.GPACTRL.bit.QUALPRD1 = 0x30; // Sampling Period = 96 � TSYSCLKOUT, 3.83us = 6*96*6.66ns

   EDIS;
}

void InitDSPXintf16Gpio()
{
   EALLOW;

/* Configure XINTF pins using GPIO regs*/
   GpioCtrlRegs.GPCMUX1.bit.GPIO64 = 3;     // XD15
   GpioCtrlRegs.GPCMUX1.bit.GPIO65 = 3;     // XD14
   GpioCtrlRegs.GPCMUX1.bit.GPIO66 = 3;     // XD13
   GpioCtrlRegs.GPCMUX1.bit.GPIO67 = 3;     // XD12
   GpioCtrlRegs.GPCMUX1.bit.GPIO68 = 3;     // XD11
   GpioCtrlRegs.GPCMUX1.bit.GPIO69 = 3;     // XD10
   GpioCtrlRegs.GPCMUX1.bit.GPIO70 = 3;     // XD19
   GpioCtrlRegs.GPCMUX1.bit.GPIO71 = 3;     // XD8
   GpioCtrlRegs.GPCMUX1.bit.GPIO72 = 3;     // XD7
   GpioCtrlRegs.GPCMUX1.bit.GPIO73 = 3;     // XD6
   GpioCtrlRegs.GPCMUX1.bit.GPIO74 = 3;     // XD5
   GpioCtrlRegs.GPCMUX1.bit.GPIO75 = 3;     // XD4
   GpioCtrlRegs.GPCMUX1.bit.GPIO76 = 3;     // XD3
   GpioCtrlRegs.GPCMUX1.bit.GPIO77 = 3;     // XD2
   GpioCtrlRegs.GPCMUX1.bit.GPIO78 = 3;     // XD1
   GpioCtrlRegs.GPCMUX1.bit.GPIO79 = 3;     // XD0

   GpioCtrlRegs.GPBMUX1.bit.GPIO40 = 3;     // XA0
   GpioCtrlRegs.GPBMUX1.bit.GPIO41 = 3;     // XA1
   GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 3;     // XA2
   GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 3;     // XA3
   GpioCtrlRegs.GPBMUX1.bit.GPIO44 = 3;     // XA4
   GpioCtrlRegs.GPBMUX1.bit.GPIO45 = 3;     // XA5
   GpioCtrlRegs.GPBMUX1.bit.GPIO46 = 3;     // XA6
   GpioCtrlRegs.GPBMUX1.bit.GPIO47 = 3;     // XA7
   GpioCtrlRegs.GPCMUX2.bit.GPIO80 = 3;     // XA8
   GpioCtrlRegs.GPCMUX2.bit.GPIO81 = 3;     // XA9
   GpioCtrlRegs.GPCMUX2.bit.GPIO82 = 3;     // XA10
   GpioCtrlRegs.GPCMUX2.bit.GPIO83 = 3;     // XA11
   GpioCtrlRegs.GPCMUX2.bit.GPIO84 = 3;     // XA12
   GpioCtrlRegs.GPCMUX2.bit.GPIO85 = 3;     // XA13
   GpioCtrlRegs.GPCMUX2.bit.GPIO86 = 3;     // XA14
   GpioCtrlRegs.GPCMUX2.bit.GPIO87 = 3;     // XA15
   GpioCtrlRegs.GPBMUX1.bit.GPIO39 = 3;     // XA16
   GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 3;     // XA17
   GpioCtrlRegs.GPAMUX2.bit.GPIO30 = 3;     // XA18
   GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 3;     // XA19

   GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 3;     // XREADY
//   GpioCtrlRegs.GPBMUX1.bit.GPIO35 = 3;     // XRNW
   GpioCtrlRegs.GPBMUX1.bit.GPIO38 = 3;     // XWE0
   GpioCtrlRegs.GPBMUX1.bit.GPIO36 = 3;     // XZCS0
   GpioCtrlRegs.GPBMUX1.bit.GPIO37 = 3;     // XZCS7
   GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 3;     // XZCS6

   GpioCtrlRegs.GPBMUX2.bit.GPIO63 = 0;     // Configure GPIO63 as GPIO63 (nSEMR for dualport memory)
   GpioCtrlRegs.GPBPUD.bit.GPIO63 = 0;      // Enable pull-up on GPIO63 (nSEMR)
   GpioCtrlRegs.GPBDIR.bit.GPIO63 = 1;      // Configure GPIO63 as Output
   GpioDataRegs.GPBDAT.bit.GPIO63 = 1;      // Set nSEMR

   GpioCtrlRegs.GPBMUX2.bit.GPIO62 = 0;     // Configure GPIO62 as GPIO62 (INTR for dualport memory)
   GpioCtrlRegs.GPBPUD.bit.GPIO62 = 0;      // Enable pull-up on GPIO62 (INTR)
   GpioCtrlRegs.GPBDIR.bit.GPIO62 = 0;      // Configure GPIO62 as Input
   GpioDataRegs.GPBDAT.bit.GPIO62 = 1;      // Set INTR


   EDIS;
}


void InitDSPIOGpio_REC()
{
    EALLOW;

/* Configure I/O pins using GPIO regs*/
    GpioCtrlRegs.GPAMUX2.bit.GPIO20 = 0; // Configure GPIO20 as DOEnable (OUT)
    GpioCtrlRegs.GPAMUX2.bit.GPIO21 = 0; // Configure GPIO21 as MCB (IN)
    GpioCtrlRegs.GPAMUX2.bit.GPIO22 = 0; // Configure GPIO22 as ES(IN)
    GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 0; // Configure GPIO23 as PCC (IN)
    GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 0; // Configure GPIO24 as MCAUX (IN)
    GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0; // Configure GPIO25 as MC (IN)
    GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0; // Configure GPIO26 as FOIOReset (OUT) (PT_DSPClk)
    GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0; // Configure GPIO27 as FDPCReset (OUT) (PT_SWReset)
    GpioCtrlRegs.GPBMUX2.bit.GPIO48 = 0; // Configure GPIO48 as SGOFF (OUT) (PGU_OptoEnable)
    GpioCtrlRegs.GPBMUX2.bit.GPIO49 = 0; // Configure GPIO49 as WDToggle (OUT)
    GpioCtrlRegs.GPBMUX2.bit.GPIO50 = 0; // Configure GPIO50 as Forward (IN)
    GpioCtrlRegs.GPBMUX2.bit.GPIO51 = 0; // Configure GPIO51 as Reverse (IN)
    GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 0; // Configure GPIO58 as DORes1 (OUT)
    GpioCtrlRegs.GPBMUX2.bit.GPIO59 = 0; // Configure GPIO59 as DORes2 (OUT)
    GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 0; // Configure GPIO60 as PCCSig (OUT)
    GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 0; // Configure GPIO61 as MCSig (OUT)

/* Configure I/O pins directions*/
    GpioCtrlRegs.GPADIR.bit.GPIO20 = 1;  // Configure GPIO22 as Output DOEnable
    GpioCtrlRegs.GPADIR.bit.GPIO21 = 0;  // Configure GPIO22 as Input MCB
    GpioCtrlRegs.GPADIR.bit.GPIO22 = 0;  // Configure GPIO22 as Input DCAUX
    GpioCtrlRegs.GPADIR.bit.GPIO23 = 0;  // Configure GPIO23 as Input PCC
    GpioCtrlRegs.GPADIR.bit.GPIO24 = 0;  // Configure GPIO24 as Input MCAXU
    GpioCtrlRegs.GPADIR.bit.GPIO25 = 0;  // Configure GPIO25 as Input MC
    GpioCtrlRegs.GPADIR.bit.GPIO26 = 1;  // Configure GPIO26 as Output FOIORst
    GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;  // Configure GPIO27 as Output FDPCRst
    GpioCtrlRegs.GPBDIR.bit.GPIO32 = 0;  // Configure GPIO32 as Input EPWMSYNCI operation
    GpioCtrlRegs.GPBDIR.bit.GPIO33 = 1;  // Configure GPIO33 as Input EPWMSYNC0 operation
    GpioCtrlRegs.GPBDIR.bit.GPIO48 = 1;  // Configure GPIO48 as Output SGOFF
    GpioCtrlRegs.GPBDIR.bit.GPIO49 = 1;  // Configure GPIO49 as Output WDTog
    GpioCtrlRegs.GPBDIR.bit.GPIO50 = 1;  // Configure GPIO50 as Input Forward
    GpioCtrlRegs.GPBDIR.bit.GPIO51 = 1;  // Configure GPIO51 as Input Reverse
    GpioCtrlRegs.GPBDIR.bit.GPIO58 = 1;  // Configure GPIO58 as Output PGUREC_DORes1
    GpioCtrlRegs.GPBDIR.bit.GPIO59 = 1;  // Configure GPIO59 as Output PGUREC_DORes2
    GpioCtrlRegs.GPBDIR.bit.GPIO60 = 1;  // Configure GPIO60 as Output PCCSig
    GpioCtrlRegs.GPBDIR.bit.GPIO61 = 1;  // Configure GPIO61 as Output MCSig

/* Enable internal pull-up for the selected pins */
    GpioCtrlRegs.GPAPUD.bit.GPIO20 = 0;    // Enable pull-up on GPIO20
    GpioCtrlRegs.GPAPUD.bit.GPIO21 = 0;    // Enable pull-up on GPIO22
    GpioCtrlRegs.GPAPUD.bit.GPIO22 = 0;    // Enable pull-up on GPIO22
    GpioCtrlRegs.GPAPUD.bit.GPIO23 = 0;    // Enable pull-up on GPIO23
    GpioCtrlRegs.GPAPUD.bit.GPIO24 = 0;    // Enable pull-up on GPIO24
    GpioCtrlRegs.GPAPUD.bit.GPIO25 = 0;    // Enable pull-up on GPIO25
    GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0;    // Enable pull-up on GPIO26
    GpioCtrlRegs.GPAPUD.bit.GPIO27 = 0;    // Enable pull-up on GPIO27
    GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;    // Enable pull-up on GPIO32
    GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;    // Enable pull-up on GPIO33
    GpioCtrlRegs.GPBPUD.bit.GPIO48 = 0;    // Enable pull-up on GPIO48
    GpioCtrlRegs.GPBPUD.bit.GPIO49 = 0;    // Enable pull-up on GPIO49
    GpioCtrlRegs.GPBPUD.bit.GPIO50 = 0;    // Enable pull-up on GPIO50
    GpioCtrlRegs.GPBPUD.bit.GPIO51 = 0;    // Enable pull-up on GPIO51
    GpioCtrlRegs.GPBPUD.bit.GPIO58 = 0;    // Enable pull-up on GPIO58
    GpioCtrlRegs.GPBPUD.bit.GPIO59 = 0;    // Enable pull-up on GPIO59
    GpioCtrlRegs.GPBPUD.bit.GPIO60 = 0;    // Enable pull-up on GPIO60
    GpioCtrlRegs.GPBPUD.bit.GPIO61 = 0;    // Enable pull-up on GPIO61

/* Set I/O initial values */
    GpioDataRegs.GPASET.bit.GPIO20 = 1;    // Force pin high on  DOEnable (OUT)
    GpioDataRegs.GPACLEAR.bit.GPIO21 = 0;    // Force pin high on MCB (IN)
    GpioDataRegs.GPACLEAR.bit.GPIO22 = 0;    // Force pin high on DCAUX (IN)
    GpioDataRegs.GPACLEAR.bit.GPIO23 = 0;    // Force pin high on PCC(IN)
    GpioDataRegs.GPACLEAR.bit.GPIO24 = 0;    // Force pin high on MCAUX (IN)
    GpioDataRegs.GPACLEAR.bit.GPIO25 = 0;    // Force pin high on MC (IN)
    GpioDataRegs.GPACLEAR.bit.GPIO26 = 0;    // Force pin high on FOIOReset (OUT)
    GpioDataRegs.GPACLEAR.bit.GPIO27 = 0;    // Force pin high on FDPCReset (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO32 = 0;    // Force pin high on EPWMSYNCI operation
    GpioDataRegs.GPBCLEAR.bit.GPIO33 = 0;    // Force pin high on EPWMSYNC0 operation
    GpioDataRegs.GPBCLEAR.bit.GPIO48 = 0;    // Force pin high on SGOFF (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO49 = 1;    // Force pin low on WDToggle (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO50 = 0;    // Force pin high on Forward (IN)
    GpioDataRegs.GPBCLEAR.bit.GPIO51 = 0;    // Force pin high on Reverse (IN)
    GpioDataRegs.GPBCLEAR.bit.GPIO58 = 0;    // Force pin high on DORes2 (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO59 = 0;    // Force pin high on DORes1 (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO60 = 0;    // Force pin high on PCCSig (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO61 = 0;    // Force pin high on MCSig (OUT)

    GpioCtrlRegs.GPAQSEL2.bit.GPIO21 = 2;    // Qualification using 6 samples MCB (IN)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO22 = 2;    // Qualification using 6 samples DCAUX (IN)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO23 = 2;    // Qualification using 6 samples PCC (IN)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO24 = 2;    // Qualification using 6 samples MCAUX (IN)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO25 = 2;    // Qualification using 6 samples MC (IN)
    GpioCtrlRegs.GPBQSEL2.bit.GPIO50 = 2;    // Qualification using 6 samples FORWARD (IN)
    GpioCtrlRegs.GPBQSEL2.bit.GPIO51 = 2;    // Qualification using 6 samples REVERSE (IN)

    EDIS;
}


void InitDSPIOGpio_INV()
{
    EALLOW;

/* Configure I/O pins using GPIO regs*/
    GpioCtrlRegs.GPAMUX2.bit.GPIO20 = 0; // Configure GPIO20 as DOEnable (OUT)
    GpioCtrlRegs.GPAMUX2.bit.GPIO21 = 0; // Configure GPIO21 as TPIO4 (IN) (Emergency_Loop)
    GpioCtrlRegs.GPAMUX2.bit.GPIO22 = 0; // Configure GPIO22 as TPIO1 (IN) (Traction_On_STA)
    GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 0; // Configure GPIO23 as TPIO2 (IN) (D2-DT_DI2_BP ---> Speed Limit Active)
    GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0; // Configure GPIO26 as FOIOReset (OUT) (PT_DSPClk)
    GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0; // Configure GPIO27 as FDPCReset (OUT) (PT_SWReset)
    GpioCtrlRegs.GPBMUX2.bit.GPIO48 = 0; // Configure GPIO48 as SGOFF (OUT) (PGU_OptoEnable)
    GpioCtrlRegs.GPBMUX2.bit.GPIO49 = 0; // Configure GPIO49 as WDToggle (OUT)
    GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 0; // Configure GPIO58 as PTIO1 (OUT) EDB_Active
    GpioCtrlRegs.GPBMUX2.bit.GPIO59 = 0; // Configure GPIO59 as PTIO2 (OUT) Traction_On
    GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 0; // Configure GPIO60 as PTIO3 (OUT) PT_IO5 (Unused)
    GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 0; // Configure GPIO61 as PTIO4 (OUT) R-RSV1_BP(pin goes to MCU input PGUREC)

/* Configure I/O pins directions*/
    GpioCtrlRegs.GPADIR.bit.GPIO20 = 1;  // Configure GPIO22 as Output DOEnable
    GpioCtrlRegs.GPADIR.bit.GPIO21 = 0;  // Configure GPIO22 as Input  Emergency_Loop
    GpioCtrlRegs.GPADIR.bit.GPIO22 = 0;  // Configure GPIO22 as Input  Traction_On_STA
    GpioCtrlRegs.GPADIR.bit.GPIO23 = 0;  // Configure GPIO23 as Input  Speed Limit Active
    GpioCtrlRegs.GPADIR.bit.GPIO26 = 1;  // Configure GPIO26 as Output DSPClk
    GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;  // Configure GPIO27 as Output SWReset
    GpioCtrlRegs.GPBDIR.bit.GPIO32 = 0;  // Configure GPIO32 as Input  EPWMSYNCI operation
    GpioCtrlRegs.GPBDIR.bit.GPIO33 = 1;  // Configure GPIO33 as Input  EPWMSYNC0 operation
    GpioCtrlRegs.GPBDIR.bit.GPIO48 = 1;  // Configure GPIO48 as Output OptoEnable
    GpioCtrlRegs.GPBDIR.bit.GPIO49 = 1;  // Configure GPIO49 as Output WDTog
    GpioCtrlRegs.GPBDIR.bit.GPIO58 = 1;  // Configure GPIO58 as Output EDB_Active
    GpioCtrlRegs.GPBDIR.bit.GPIO59 = 1;  // Configure GPIO59 as Output Traction_On
    GpioCtrlRegs.GPBDIR.bit.GPIO60 = 1;  // Configure GPIO60 as Output PT_IO5 (Unused)
    GpioCtrlRegs.GPBDIR.bit.GPIO61 = 1;  // Configure GPIO61 as Output RSV1(PGUINV_to_PGUREC)

/* Enable internal pull-up for the selected pins */
    GpioCtrlRegs.GPAPUD.bit.GPIO20 = 0;    // Enable pull-up on GPIO20
    GpioCtrlRegs.GPAPUD.bit.GPIO21 = 0;    // Enable pull-up on GPIO22
    GpioCtrlRegs.GPAPUD.bit.GPIO22 = 0;    // Enable pull-up on GPIO22
    GpioCtrlRegs.GPAPUD.bit.GPIO23 = 0;    // Enable pull-up on GPIO23
    GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0;    // Enable pull-up on GPIO26
    GpioCtrlRegs.GPAPUD.bit.GPIO27 = 0;    // Enable pull-up on GPIO27
    GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;    // Enable pull-up on GPIO32
    GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;    // Enable pull-up on GPIO33
    GpioCtrlRegs.GPBPUD.bit.GPIO48 = 0;    // Enable pull-up on GPIO48
    GpioCtrlRegs.GPBPUD.bit.GPIO49 = 0;    // Enable pull-up on GPIO49
    GpioCtrlRegs.GPBPUD.bit.GPIO58 = 0;    // Enable pull-up on GPIO58
    GpioCtrlRegs.GPBPUD.bit.GPIO59 = 0;    // Enable pull-up on GPIO59
    GpioCtrlRegs.GPBPUD.bit.GPIO60 = 0;    // Enable pull-up on GPIO60
    GpioCtrlRegs.GPBPUD.bit.GPIO61 = 0;    // Enable pull-up on GPIO61

/* Set I/O initial values */
    GpioDataRegs.GPASET.bit.GPIO20 = 1;      // Force pin high on  DOEnable (OUT)
    GpioDataRegs.GPACLEAR.bit.GPIO21 = 0;    // Force pin high on MCB (IN)
    GpioDataRegs.GPACLEAR.bit.GPIO22 = 0;    // Force pin high on DCAUX (IN)
    GpioDataRegs.GPACLEAR.bit.GPIO23 = 0;    // Force pin high on PCC(IN)
    GpioDataRegs.GPACLEAR.bit.GPIO26 = 0;    // Force pin high on FOIOReset (OUT)
    GpioDataRegs.GPACLEAR.bit.GPIO27 = 0;    // Force pin high on FDPCReset (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO32 = 0;    // Force pin high on EPWMSYNCI operation
    GpioDataRegs.GPBCLEAR.bit.GPIO33 = 0;    // Force pin high on EPWMSYNC0 operation
    GpioDataRegs.GPBCLEAR.bit.GPIO48 = 0;    // Force pin high on SGOFF (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO49 = 1;    // Force pin low on WDToggle (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO58 = 0;    // Force pin high on DORes2 (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO59 = 0;    // Force pin high on DORes1 (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO60 = 0;    // Force pin high on PCCSig (OUT)
    GpioDataRegs.GPBCLEAR.bit.GPIO61 = 0;    // Force pin high on MCSig (OUT)

//    GpioCtrlRegs.GPAQSEL2.bit.GPIO21 = 2;    // Qualification using 6 samples MCB (IN)
//    GpioCtrlRegs.GPAQSEL2.bit.GPIO22 = 2;    // Qualification using 6 samples DCAUX (IN)
//    GpioCtrlRegs.GPAQSEL2.bit.GPIO23 = 2;    // Qualification using 6 samples PCC (IN)

    EDIS;
}

