#include "DSP28x_Project.h"         //DSP28x Project Headerfile and Examples Include File
#include "PGU_Common.h"

//---------------------------------------------------------------------------
// Define Global External Memory Variables:
//
//----------------------------------------

//#ifdef __cplusplus
//#pragma DATA_SECTION("CANRXFile")
//#else
//#pragma DATA_SECTION(CANRXMsg,"CANRXFile");
//#endif
//volatile CONTROL_REGS CANRXMsg;
//
//#ifdef __cplusplus
//#pragma DATA_SECTION("CANTXFile")
//#else
//#pragma DATA_SECTION(CANTXMsg,"CANTXFile");
//#endif
//volatile CAN_TX_MSG CANTXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("CANBRDCSTFile")
#else
#pragma DATA_SECTION(CANBRDCSTMsg,"CANBRDCSTFile");
#endif
volatile CAN_TX_MSG CANBRDCSTMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("FOIORXFile")
#else
#pragma DATA_SECTION(FOIO_CANRXMsg,"FOIORXFile");
#endif
volatile FOIO_CAN_RX_MSG FOIO_CANRXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("FOIOTXFile")
#else
#pragma DATA_SECTION(FOIO_CANTXMsg,"FOIOTXFile");
#endif
volatile FOIO_CAN_TX_MSG FOIO_CANTXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("TCPURXFile")
#else
#pragma DATA_SECTION(TCPURXMsg,"TCPURXFile");
#endif
volatile TCPU_MSG TCPURXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("TCPUTXFile")
#else
#pragma DATA_SECTION(TCPUTXMsg,"TCPUTXFile");
#endif
volatile TCPU_MSG TCPUTXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("DIOC1RXFile")
#else
#pragma DATA_SECTION(DIOC1RXMsg,"DIOC1RXFile");
#endif
volatile DIOC_MSG DIOC1RXMsg;

//#ifdef __cplusplus
//#pragma DATA_SECTION("DIOCTXFile")
//#else
//#pragma DATA_SECTION(DIOCTXMsg,"DIOCTXFile");
//#endif
//volatile DIOC_REG DIOCTXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("DIOC2RXFile")
#else
#pragma DATA_SECTION(DIOC2RXMsg,"DIOC2RXFile");
#endif
volatile DIOC_MSG DIOC2RXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("DIOC1TXFile")
#else
#pragma DATA_SECTION(DIOC1TXMsg,"DIOC1TXFile");
#endif
volatile DIOC_MSG DIOC1TXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("DIOC2TXFile")
#else
#pragma DATA_SECTION(DIOC2TXMsg,"DIOC2TXFile");
#endif
volatile DIOC_MSG DIOC2TXMsg;

//#ifdef __cplusplus
//#pragma DATA_SECTION("DIOCNTXFile")
//#else
//#pragma DATA_SECTION(DIOCNTXMsg,"DIOCNTXFile");
//#endif
//volatile DIOC_REG DIOCNTXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("CC1RXFile")
#else
#pragma DATA_SECTION(CC1RXMsg,"CC1RXFile");
#endif
volatile CAN_RX_MSG CC1RXMsg;

//#ifdef __cplusplus
//#pragma DATA_SECTION("CC2RXFile")
//#else
//#pragma DATA_SECTION(CC2RXMsg,"CC2RXFile");
//#endif
//volatile CAN_RX_MSG CC2RXMsg;
//
//#ifdef __cplusplus
//#pragma DATA_SECTION("CC3RXFile")
//#else
//#pragma DATA_SECTION(CC3RXMsg,"CC3RXFile");
//#endif
//volatile CAN_RX_MSG CC3RXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("CC1TXFile")
#else
#pragma DATA_SECTION(CC1TXMsg,"CC1TXFile");
#endif
volatile CAN_TX_MSG CC1TXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("PGURXFile")
#else
#pragma DATA_SECTION(PGURXMsg,"PGURXFile");
#endif
volatile CAN_RX_8MSG PGURXMsg;

#ifdef __cplusplus
#pragma DATA_SECTION("PGUTXFile")
#else
#pragma DATA_SECTION(PGUTXMsg,"PGUTXFile");
#endif
volatile CAN_TX_8MSG PGUTXMsg;


#ifdef __cplusplus
#pragma DATA_SECTION("FaultFile")
#else
#pragma DATA_SECTION(Faults,"FaultFile");
#endif
volatile UINT16_REG Faults[24];

//#ifdef __cplusplus
//#pragma DATA_SECTION("LedFile")
//#else
//#pragma DATA_SECTION(LedGroup,"LedFile");
//#endif
//volatile LED_GROUP LedGroup;

#ifdef __cplusplus
#pragma DATA_SECTION("DualPortControlRegsFile1")
#else
#pragma DATA_SECTION(DSP2TivaRegs,"DualPortControlRegsFile1");
#endif
volatile DualPortControlRegs DSP2TivaRegs;

#ifdef __cplusplus
#pragma DATA_SECTION("DualPortControlRegsFile2")
#else
#pragma DATA_SECTION(Tiva2DSPRegs,"DualPortControlRegsFile2");
#endif
volatile DualPortControlRegs Tiva2DSPRegs;

#ifdef __cplusplus
#pragma DATA_SECTION("MonitorDataFile")
#else
#pragma DATA_SECTION(MonitorData,"MonitorDataFile");
#endif
unsigned int MonitorData[240];

#ifdef __cplusplus
#pragma DATA_SECTION("EthRxDataFile")
#else
#pragma DATA_SECTION(EthRxData,"EthRxDataFile");
#endif
unsigned int EthRxData[128];


#ifdef __cplusplus
#pragma DATA_SECTION("SWUpdateFile")
#else
#pragma DATA_SECTION(SWUpdateBuff,"SWUpdateFile");
#endif
unsigned int SWUpdateBuff[2048];

#ifdef __cplusplus
#pragma DATA_SECTION("ExtRamFile")
#else
#pragma DATA_SECTION(ExtRamBuff,"ExtRamFile");
#endif
unsigned int ExtRamBuff[65536];

#ifdef __cplusplus
#pragma DATA_SECTION("AnalogBufferSection")
#else
#pragma DATA_SECTION(AnaBuff,"AnalogBufferSection");
#endif
volatile struct ANALOGBUFFER AnaBuff;

//===========================================================================
// End of file.
//===========================================================================


