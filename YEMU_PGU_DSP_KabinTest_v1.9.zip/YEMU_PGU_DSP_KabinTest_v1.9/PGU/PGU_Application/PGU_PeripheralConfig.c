/*
 * PeripheralConfig.c
 *
 *  Created on: 10 Eki 2012
 *      Author: AOB
 */
#include "DSP28x_Project.h"         //DSP28x Project Headerfile and Examples Include File
#include "PGU_Common.h"
#include "PGUREC_Common.h"

//QEP Encoder = QEP_DEFAULTS;

void ConfigQEP(char m, Uint16 EncoderPulse)
{
    EALLOW;
    if(m==1)
    {
        SysCtrlRegs.PCLKCR1.bit.EQEP1ENCLK = 1;  // eQEP1
    }
    else
    {
        SysCtrlRegs.PCLKCR1.bit.EQEP2ENCLK = 1;  // eQEP2
    }
    EDIS;

    (*eQEP[m]).QDECCTL.all = QDECCTL_INIT_STATE;
    (*eQEP[m]).QEPCTL.all = QEPCTL_INIT_STATE;
    (*eQEP[m]).QPOSCTL.all = QPOSCTL_INIT_STATE;
    (*eQEP[m]).QUPRD = 1000000;		        		// Unit Timer for 150Hz
    (*eQEP[m]).QCAPCTL.all = QCAPCTL_INIT_STATE;
    (*eQEP[m]).QPOSMAX = (4*EncoderPulse)-1;       // QPOSMAX: Application specific variable
    //(*eQEP[m]).QPOSMAX = 4*ENCODER_PULSE;
}

void ConfigADC(Uint16* ChSel)
{
	EALLOW;

	// ADC Reference Select Register
	AdcRegs.ADCREFSEL.bit.REF_SEL = 0x1;      	// External reference, 2.048 V on ADCREFIN

	// ADC CTRL3 Register
	AdcRegs.ADCTRL3.bit.ADCBGRFDN = 0x3;		// The bandgap and reference circuitry is powered up.
	AdcRegs.ADCTRL3.bit.ADCPWDN   = 0x1;		// The analog circuitry inside the core is powered up.
	AdcRegs.ADCTRL3.bit.ADCCLKPS  = 0x0;		// Divided device peripheral clock. (Divided HSPCLK) = HSPCLK/(ADCCLKPS + 1)
	AdcRegs.ADCTRL3.bit.SMODE_SEL = 0x0;		// Sequential sampling mode is selected.
	DELAY_US(ADC_usDELAY);      				// Delay before converting ADC channels

	AdcRegs.ADCOFFTRIM.bit.OFFSET_TRIM -= 13;

    // ADC CTRL1 Register
    //AdcRegs.ADCTRL1.bit.SUSMOD = 0x0;			// Mode 0: Emulation suspend is ignored.
 	AdcRegs.ADCTRL1.bit.ACQ_PS = 0x1;			// Acquisition window size. The width of SOC pulse is (ACQ_PS + 1) times the ADCLK period.
	AdcRegs.ADCTRL1.bit.CPS = 0x0;				// Core clock prescaler. ADCCLK = (Divided HSPCLK)/(CPS + 1)
	//AdcRegs.ADCTRL1.bit.CONT_RUN = 0x0;			// Start-stop mode. Sequencer stops after reaching EOS.
	//AdcRegs.ADCTRL1.bit.SEQ_OVRD = 0x0;			// Sequencer override disabled.
	AdcRegs.ADCTRL1.bit.SEQ_CASC = 0x1;        	// // Setup cascaded sequencer mode

	// ADC CTRL2 Register
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 0x1;			// Immediately reset sequencer to state CONV00
	AdcRegs.ADCTRL2.bit.INT_ENA_SEQ1 = 0x1;		// Interrupt request by INT_SEQ1 is enabled.
	AdcRegs.ADCTRL2.bit.INT_MOD_SEQ1 = 0x0;		// INT_SEQ1 is set at the end of every SEQ1 sequence.
	AdcRegs.ADCTRL2.bit.EPWM_SOCA_SEQ1 = 0x1; 	// SEQ1 to be started by ePWMx SOCA trigger. ePWMx sources are configured at ePWM initialization.

	// ADC Maximum Conversion Channels Register
	AdcRegs.ADCMAXCONV.bit.MAX_CONV1 = 15;		// (MAX_CONV1 + 1) of conversions executed in an autoconversion session for SEQ1 operation.

	// ADC Input Channel Select Sequencing Control Registers   AdcMirror
	// ADC input channel is a function parameter. ChSel array should be configured before calling the init function.
	AdcRegs.ADCCHSELSEQ1.bit.CONV00 = ChSel[0];
	AdcRegs.ADCCHSELSEQ1.bit.CONV01 = ChSel[1];
	AdcRegs.ADCCHSELSEQ1.bit.CONV02 = ChSel[2];
	AdcRegs.ADCCHSELSEQ1.bit.CONV03 = ChSel[3];
	AdcRegs.ADCCHSELSEQ2.bit.CONV04 = ChSel[4];
	AdcRegs.ADCCHSELSEQ2.bit.CONV05 = ChSel[5];
	AdcRegs.ADCCHSELSEQ2.bit.CONV06 = ChSel[6];
	AdcRegs.ADCCHSELSEQ2.bit.CONV07 = ChSel[7];

	AdcRegs.ADCCHSELSEQ3.bit.CONV08 = ChSel[8];
	AdcRegs.ADCCHSELSEQ3.bit.CONV09 = ChSel[9];
	AdcRegs.ADCCHSELSEQ3.bit.CONV10 = ChSel[10];
	AdcRegs.ADCCHSELSEQ3.bit.CONV11 = ChSel[11];
	AdcRegs.ADCCHSELSEQ4.bit.CONV12 = ChSel[12];
	AdcRegs.ADCCHSELSEQ4.bit.CONV13 = ChSel[13];
	AdcRegs.ADCCHSELSEQ4.bit.CONV14 = ChSel[14];
	AdcRegs.ADCCHSELSEQ4.bit.CONV15 = ChSel[15];

	EDIS;
}

void ConfigPWM(void)
{

	EALLOW;
	SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;   	// Disable TBCLK within the ePWM
	EDIS;
	Uint16 i;

	for (i=1; i<=6; i++)							// Common PWM configuration settings for all PWMs
	{
		(*ePWM[i]).TBCTL.all 		= TBCTL_INIT;			//
		(*ePWM[i]).TBPHS.half.TBPHS = 0;					//
		(*ePWM[i]).CMPCTL.all 		= CMPCTL_INIT;			//
		(*ePWM[i]).AQCTLA.all 		= AQCTLA_INIT;			//
		(*ePWM[i]).PCCTL.all 		= PCCTL_INIT;			//
		EALLOW;
		(*ePWM[i]).TZSEL.all 		= TZSEL_INIT;			//
		(*ePWM[i]).TZCTL.all 		= TZCTL_INIT;			//
		(*ePWM[i]).TZFRC.bit.OST 	= 1;					//
		EDIS;
		(*ePWM[i]).DBCTL.all 		= DBCTL_INIT;			//
	}


//        EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;              // Change EPwm1 Sync Output to CTR = EPWMSYNCI
//
        EALLOW;
        SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;                   // Enable TBCLK within the ePWM
        EDIS;

//        EALLOW;
//        EPwm1Regs.TZEINT.bit.OST     = 1;                        // Enable TZ interrupt on any TZ event
//        EDIS;

}


void PGU_Reset(void)
{
EALLOW;
       SysCtrlRegs.WDCR = 0x0028;
       SysCtrlRegs.WDCR = 0x0000;
       EDIS;
}

void ConfigPWMModule(Uint16 PeriodMax,Uint16 Deadband,Uint16 ch,Uint16 TBPHS)
{
    (*ePWM[ch]).TBPRD = PeriodMax;              // PWM Module Timer-Base Period
    (*ePWM[ch]).TBPHS.half.TBPHS = TBPHS;       // Phase Register
    (*ePWM[ch]).DBFED = Deadband;               // PWM Module Dead-band falling edge delay
    (*ePWM[ch]).DBRED = Deadband;               // PWM Module Dead-band rising edge delay
}

void PWMDutyUpdate(Uint16 ch,float32 duty)
{
    Uint16 HalfPerMax;
    /*  duty range is (-1,1)                                                      */
    /*  The code below changes PeriodMax*Mfuncx range ....                          */
    /*  from (-PeriodMax,PeriodMax) to (0,PeriodMax) where HalfPerMax=PeriodMax/2   */
    HalfPerMax = (*ePWM[ch]).TBPRD*0.5;
    (*ePWM[ch]).CMPA.half.CMPA = (HalfPerMax * duty) + HalfPerMax;
}


void ConfigXintf(void)
{
EALLOW;
// XINTF configuration
XintfRegs.XINTCNF2.bit.XTIMCLK = 0; // XTIMCLK = SYSCLKOUT = 150MHz
XintfRegs.XINTCNF2.bit.CLKMODE = 0; // XCLKOUT = XTIMCLK = 150 MHz
XintfRegs.XINTCNF2.bit.CLKOFF = 0; // Enable XCLKOUT
XintfRegs.XINTCNF2.bit.WRBUFF = 0; // No write buffering
XintfRegs.XINTCNF2.bit.HOLD = 1; // Does not grant a request to an external device
// ZONE 0 - Timing for 4k x16 Dualport SRAM Access
XintfRegs.XTIMING0.bit.XWRLEAD = 1; // zone write timing
XintfRegs.XTIMING0.bit.XWRACTIVE = 1;
XintfRegs.XTIMING0.bit.XWRTRAIL = 0;
XintfRegs.XTIMING0.bit.XRDLEAD = 1; // zone read timing
XintfRegs.XTIMING0.bit.XRDACTIVE = 2;
XintfRegs.XTIMING0.bit.XRDTRAIL = 0;
XintfRegs.XTIMING0.bit.X2TIMING = 0; // don't double all zone read/write lead/active/trail timing
XintfRegs.XTIMING0.bit.USEREADY = 0; // does not sample XREADY signal
XintfRegs.XTIMING0.bit.READYMODE = 0; // sample asynchronous
XintfRegs.XTIMING0.bit.XSIZE = 3; // configured for 16-bit mode
// ZONE 6 - Timing for 512k x16 Flash Access
XintfRegs.XTIMING6.bit.XWRLEAD = 3; // zone write timing
XintfRegs.XTIMING6.bit.XWRACTIVE = 7;
XintfRegs.XTIMING6.bit.XWRTRAIL = 3;
XintfRegs.XTIMING6.bit.XRDLEAD = 3; // zone read timing
XintfRegs.XTIMING6.bit.XRDACTIVE = 7;
XintfRegs.XTIMING6.bit.XRDTRAIL = 3;
XintfRegs.XTIMING6.bit.X2TIMING = 1; // double all zone read/write lead/active/trail timing
XintfRegs.XTIMING6.bit.USEREADY = 0; // does not sample XREADY signal
XintfRegs.XTIMING6.bit.READYMODE = 0; // sample asynchronous
XintfRegs.XTIMING6.bit.XSIZE = 3; // configured for 16-bit mode
// ZONE 7 - Timing for 512k x16 SRAM Access
XintfRegs.XTIMING7.bit.XWRLEAD = 1; // zone write timing
XintfRegs.XTIMING7.bit.XWRACTIVE = 0;
XintfRegs.XTIMING7.bit.XWRTRAIL = 0;
XintfRegs.XTIMING7.bit.XRDLEAD = 1; // zone read timing
XintfRegs.XTIMING7.bit.XRDACTIVE = 1;
XintfRegs.XTIMING7.bit.XRDTRAIL = 0;
XintfRegs.XTIMING7.bit.X2TIMING = 0; // don't double all zone read/write lead/active/trail timing
XintfRegs.XTIMING7.bit.USEREADY = 0; // does not sample XREADY signal
XintfRegs.XTIMING7.bit.READYMODE = 0; // sample asynchronous
XintfRegs.XTIMING7.bit.XSIZE = 3; // configured for 16-bit mode
// Bank switching
// Zone 6 is slow, so add additional BCYC cycles
// when ever switching from Zone 6 to another Zone.
// This will help avoid bus contention.
XintfRegs.XBANK.bit.BANK = 6;
XintfRegs.XBANK.bit.BCYC = 7;
EDIS;
//Force a pipeline flush to ensure that the write to
//the last register configured occurs before returning.
asm(" RPT #7 || NOP");
}

void ConfigCPUTimers(Uint32 TaskA_Period,Uint32 TaskB_Period,Uint32 TaskC_Period)
{
    CpuTimer0Regs.PRD.all =  TaskA_Period;      // A tasks period
    CpuTimer1Regs.PRD.all =  TaskB_Period;      // B tasks period
    CpuTimer2Regs.PRD.all =  TaskC_Period;      // C tasks period
}
