//============================================================================
// FILE			: MemoryTest.c
// DESCRIPTION	: External Memory Devices Test Functions for TMS320F28335 @ PGU
// AUTHOR		: AOB
// RELEASE		: 1.0
// DATE			: 12.09.2012
//============================================================================

#include "DSP28x_Project.h"         //DSP28x Project Headerfile and Examples Include File
#include "PGU_Common.h"

Uint16 DataBusTestResult = 0;

Uint16 * AddressBusTestResult = NULL;

Uint16 * memTestAll(volatile Uint16 * MemoryAddress, unsigned long MemorySize, Uint16 TestPattern)
{
	DataBusTestResult = memTestDataBus(MemoryAddress);

	if(DataBusTestResult == 0)											// Data Bus Test OK
	{
		AddressBusTestResult = memTestAddressBus(MemoryAddress, MemorySize);

		if(AddressBusTestResult == NULL)								// Address Bus Test OK
		{
			AddressBusTestResult = memTestDevice(MemoryAddress, MemorySize);
			if(AddressBusTestResult == NULL)							// Device Test OK
			{
				memFill(MemoryAddress, MemorySize, TestPattern);		//Fill Memory
				return NULL;
			}
			else
			{
				return AddressBusTestResult;							// Device Test Fail
			}

		}
		else															// Address Bus Test Fail
		{
			return AddressBusTestResult;
		}

	}
	else																// Data Bus Test Fail
	{
		return (Uint16 *) DataBusTestResult;
	}

}
/**********************************************************************
 *
 * Function:    memFill()
 *
 * Description: Fill the memory in a memory region by data selected
 * 				by caller
 * Notes:
 * Returns:     0 if the test succeeds.
 *              A non-zero result is the memory address that failed.
 *
 **********************************************************************/
Uint16 memFill(volatile Uint16 * address, unsigned long nBytes, volatile Uint16 pattern)
{
	unsigned long offset;
	unsigned long nWords = nBytes / sizeof(Uint16);

    for (offset = 0; offset < nWords; offset++)
    {
    	address[offset] = pattern;
    	DELAY_US(1);

        if (address[offset] != pattern)
        {
            return (FAIL);
        }

    }
    return (SUCCESS);

}   /* memTestDataBus() */

/**********************************************************************
 *
 * Function:    memTestDataBus()
 *
 * Description: Test the data bus wiring in a memory region by
 *              performing a walking 1's test at a fixed address
 *              within that region.  The address (and hence the
 *              memory region) is selected by the caller.
 * Notes:
 * Returns:     0 if the test succeeds.
 *              A non-zero result is the first pattern that failed.
 *
 **********************************************************************/
Uint16 memTestDataBus(volatile Uint16 * address)
{
    Uint16 pattern;


    /*
     * Perform a walking 1's test at the given address.
     */
    for (pattern = 1; pattern != 0; pattern <<= 1)
    {
        /*
         * Write the test pattern.
         */
        *address = pattern;
        DELAY_US(1);

        /*
         * Read it back (immediately is okay for this test).
         */
        if (*address != pattern)
        {
            return (pattern);
        }
    }

    return (0);

}   /* memTestDataBus() */


/**********************************************************************
 *
 * Function:    memTestAddressBus()
 *
 * Description: Test the address bus wiring in a memory region by
 *              performing a walking 1's test on the relevant bits
 *              of the address and checking for aliasing. This test
 *              will find single-bit address failures such as stuck
 *              -high, stuck-low, and shorted pins.  The base address
 *              and size of the region are selected by the caller.
 *
 * Notes:       For best results, the selected base address should
 *              have enough LSB 0's to guarantee single address bit
 *              changes.  For example, to test a 64-Kbyte region,
 *              select a base address on a 64-Kbyte boundary.  Also,
 *              select the region size as a power-of-two--if at all
 *              possible.
 *
 * Returns:     NULL if the test succeeds.
 *              A non-zero result is the first address at which an
 *              aliasing problem was uncovered.  By examining the
 *              contents of memory, it may be possible to gather
 *              additional information about the problem.
 *
 **********************************************************************/
Uint16 * memTestAddressBus(volatile Uint16 * baseAddress, unsigned long nBytes)
{
    unsigned long addressMask = (nBytes/sizeof(Uint16) - 1);
    unsigned long offset;
    unsigned long testOffset;

    Uint16 pattern     = (Uint16) 0xAAAAAAAA;
    Uint16 antipattern = (Uint16) 0x55555555;


    /*
     * Write the default pattern at each of the power-of-two offsets.
     */
    for (offset = 1; (offset & addressMask) != 0; offset <<= 1)
    {
        baseAddress[offset] = pattern;
        //DELAY_US(10);
    }

    /*
     * Check for address bits stuck high.
     */
    testOffset = 0;
    baseAddress[testOffset] = antipattern;

    for (offset = 1; (offset & addressMask) != 0; offset <<= 1)
    {
    	//DELAY_US(10);
        if (baseAddress[offset] != pattern)
        {
            return ((Uint16 *) &baseAddress[offset]);
        }
    }

    baseAddress[testOffset] = pattern;

    /*
     * Check for address bits stuck low or shorted.
     */
    for (testOffset = 1; (testOffset & addressMask) != 0; testOffset <<= 1)
    {
        baseAddress[testOffset] = antipattern;
        //DELAY_US(10);

		if (baseAddress[0] != pattern)
		{
			return ((Uint16 *) &baseAddress[testOffset]);
		}

        for (offset = 1; (offset & addressMask) != 0; offset <<= 1)
        {
            if ((baseAddress[offset] != pattern) && (offset != testOffset))
            {
                return ((Uint16 *) &baseAddress[testOffset]);
            }
        }

        baseAddress[testOffset] = pattern;
    }

    return (NULL);

}   /* memTestAddressBus() */


/**********************************************************************
 *
 * Function:    memTestDevice()
 *
 * Description: Test the integrity of a physical memory device by
 *              performing an increment/decrement test over the
 *              entire region.  In the process every storage bit
 *              in the device is tested as a zero and a one.  The
 *              base address and the size of the region are
 *              selected by the caller.
 *
 * Notes:
 * Returns:     NULL if the test succeeds.
 *
 *              A non-zero result is the first address at which an
 *              incorrect value was read back.  By examining the
 *              contents of memory, it may be possible to gather
 *              additional information about the problem.
 *
 **********************************************************************/
Uint16 * memTestDevice(volatile Uint16 * baseAddress, unsigned long nBytes)
{
    unsigned long offset;
    unsigned long nWords = nBytes / sizeof(Uint16);

    Uint16 pattern;
    Uint16 antipattern;

    /*
     * Fill memory with a known pattern.
     */
    for (pattern = 1, offset = 0; offset < nWords; pattern++, offset++)
    {
        baseAddress[offset] = pattern;
        DELAY_US(1);
    }

    /*
     * Check each location and invert it for the second pass.
     */
    for (pattern = 1, offset = 0; offset < nWords; pattern++, offset++)
    {
        if (baseAddress[offset] != pattern)
        {
            return ((Uint16 *) &baseAddress[offset]);
        }

        antipattern = ~pattern;
        baseAddress[offset] = antipattern;
        DELAY_US(1);
    }

    /*
     * Check each location for the inverted pattern and zero it.
     */
    for (pattern = 1, offset = 0; offset < nWords; pattern++, offset++)
    {
        antipattern = ~pattern;
        if (baseAddress[offset] != antipattern)
        {
            return ((Uint16 *) &baseAddress[offset]);
        }
        DELAY_US(1);
    }

    return (NULL);

}   /* memTestDevice() */

