//###########################################################################
//
// FILE:    i2c_slave.c
//
// TITLE:   DSP2835x I2C SLAVE EXAMPLE
//
// ASSUMPTIONS:
//
//          This program requires the DSP280x header files.  
//          This project is configured for "boot to SARAM" operation.
//
//			This program will allow the I2C to act as a slave. External
//          connections must be made to the I2C Clock and Data pins.
//
// DESCRIPTION:
//
// This program will create 6 read/write locations in the 28335 RAM. It will
// allow communications with those registers by the following I2C commands:
//
//  I2C Write (from host)
//
//  S  ADDR  W  A  DATA  A  DATA  A  DATA  A  P
//
//     S = Start bit
//  ADDR = Device Address (7 bits - to this 28335)
//     W = Write
//     A = Acknowledge (from 28335 to host)
//  DATA = location number (0 - 5)
//     A = Acknowledge (from 28335)
//  DATA = High byte of word to be stored
//     A = Ack
//  DATA = Low byte of word to be stored
//     A = Ack
//     P = Stop bit 
//
//
//  I2C Read (from host)
//
//  S   ADDR  W  A  DATA  A  S   ADDR R A  DATA  A  DATA  A  P
//
//     S = Start bit
//  ADDR = Device Address (7 bits - to this 28335)
//     W = Write
//     A = Acknowledge (from 28335 to host)
//  DATA = location number (0 - 5)
//     A = Acknowledge (from 28335)
//
//     S = Repeated Start Bit
//  ADDR = Device Address (7 bits - to this 28335)
//     R = Read
//     A = Acknowlege (from 28335)
//  DATA = High byte of word to be read
//     A = Ack (from host)
//  DATA = Low byte of word to be read
//     A = (N)Ack (from host)
//     P = Stop bit   
//
//###########################################################################
// Author: Todd Anderson
//
// September, 2006
//###########################################################################
// Change Log
//---------------------------------------------------------------------------
//   Date               Change
//---------------------------------------------------------------------------
//  9/08/2006         Initial slave code received from Houston.
//                    Sent slave address with value AA to verify initial
//                     operation.
//                    Added 6 registers that can be updated: Reg[0] - Reg[5].
//                    Flag register added. (Use DataReady bit on I2C.)
//                    Added InData and OutData arrays to process I2C data.
//                    Added Main "while" loop to update regs with received data.
//---------------------------------------------------------------------------

#include "DSP28x_Project.h"         //DSP28x Project Headerfile and Examples Include File
#include "PGU_Common.h"

// Prototype statements for functions found within this file.

void   I2CA_Init(void);
interrupt void i2c_int1a_isr(void);

void Enable_i2c_interrupt(void);
void Disable_i2c_interrupt(void);


struct FLAGREG_BITS
{
	volatile unsigned int Rsvd:15;		//bits 0-14
	volatile unsigned int DataReady:1; // Bit 15
};
union FLAG_REG
{
	volatile unsigned int all;
	struct FLAGREG_BITS   bit;
}Flags;

Uint16 Register;
Uint16 InData[3];
Uint16 OutData[3];
Uint16 I2cIndex;
Uint16 Counter = 0;
Uint16 TestFinish = 0;

Uint16 RamTestDone = 0;

Uint16 InitCheckReg[4]= {0,0,0,0};      //

#define COUNTER_MAX_VALUE 50000


Uint16 * I2CBasedRAMTest(Uint16 * STestErr)
{
	EALLOW;	// This is needed to write to EALLOW protected registers
	PieVectTable.I2CINT1A = &i2c_int1a_isr;
	EDIS;   // This is needed to disable write to EALLOW protected registers 

	I2cIndex = 0;
	Uint16 * DualRamTestResult = NULL;

	Flags.bit.DataReady = 0;

	I2CA_Init();

	Enable_i2c_interrupt();

   // Application loop
	while(!TestFinish)
	{
		GpioDataRegs.GPBTOGGLE.bit.GPIO49 = 1; // External Watchdog Reset

		/*------------------------------------------------------------------------------
					InitCheckReg Register update based on I2C
		------------------------------------------------------------------------------*/
		if (Flags.bit.DataReady == 1)
		{
			switch (Register)
			{
				case 0:
					InitCheckReg[0] = (InData[1]<<8) | InData[2]; // Update register value.
					break;

				case 1:
					InitCheckReg[1] = (InData[1]<<8) | InData[2]; // Update register value.
					break;

				case 2:
					InitCheckReg[2] = (InData[1]<<8) | InData[2]; // Update register value.
					break;

				case 3:
					InitCheckReg[3] = (InData[1]<<8) | InData[2]; // Update register value.
					break;

				default: 
				    break;
            }
			Flags.bit.DataReady = 0;
        }
		/*------------------------------------------------------------------------------
						Tiva Dual Ram Test Check
		------------------------------------------------------------------------------*/

		if(InitCheckReg[0] == 0xAAAA && RamTestDone == 0)	// Tiva Dual Ram Test OK
		{
			DualRamTestResult = memTestAll((Uint16 *)DUALRAM_BASE, DUALRAM_LENGTH-2, 0x0000);
			RamTestDone = 1;
			InitCheckReg[2] = 0x5555;

		}
		else if(InitCheckReg[0] == 0xBBBB && RamTestDone == 0)	//Tiva Dual Ram Test FAIL
		{
		    *STestErr	= 1;
			DualRamTestResult = memTestAll((Uint16 *)DUALRAM_BASE, DUALRAM_LENGTH-2, 0x0000);
			RamTestDone = 1;
			InitCheckReg[2] = 0x5555;
		}
		else if(InitCheckReg[0] ==0xCCCC)   //DSP and Tiva Dual Ram Test completed
		{
			TestFinish = 1;
		}
		else
		{
			Counter++;
			if(Counter == COUNTER_MAX_VALUE)		// Tiva i�in Maks bekleme s�resine ula��ld�.
			{
			    *STestErr  = 1;
				TestFinish = 1;
			}
		}

		DELAY_US(100); // 100micros bekle
	}

   Disable_i2c_interrupt();

   EALLOW;

/* Configure I2C pins using GPIO regs */
   GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 0;   	// Configure GPIO32 for GPIO operation
   GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 0;   	// Configure GPIO33 for GPIO operation

   GpioCtrlRegs.GPBDIR.bit.GPIO32 = 0;		// Configure GPIO7 as Input
   GpioCtrlRegs.GPBDIR.bit.GPIO33 = 0;		// Configure GPIO7 as Input

/* Enable internal pull-up for the selected pins */
   GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;    	// Enable pull-up for GPIO32
   GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;	   	// Enable pull-up for GPIO33

   EDIS;

   return DualRamTestResult;

}   // end of main


void I2CA_Init(void)
{
   // Initialize I2C
	I2caRegs.I2COAR = 0x002C;		// Own address
    I2caRegs.I2CPSC.all = 14;   	// Prescaler - need 7-12 Mhz on module clk (150/15 = 10MHz)
	I2caRegs.I2CCLKL = 10;			// NOTE: must be non zero
	I2caRegs.I2CCLKH = 5;			// NOTE: must be non zero
	I2caRegs.I2CCNT = 1;	        // Get 1 byte
	I2caRegs.I2CIER.all = 0x18;		// Clear interrupts (was 0)
	I2caRegs.I2CSTR.bit.RRDY = 1;	// Clear flag
	I2caRegs.I2CIER.bit.RRDY = 1;   // Enable Receive Interrupt

	I2caRegs.I2CMDR.all = 0x0020;	// Take I2C out of reset
   									// Stop I2C when suspended
	return;   

//	   I2caRegs.I2CFFTX.all = 0x6000;	// Enable FIFO mode and TXFIFO
//	   I2caRegs.I2CFFRX.all = 0x2040;	// Enable RXFIFO, clear RXFFINT,
}


interrupt void i2c_int1a_isr(void)     // I2C-A
{
	Uint16 IntSource;

   // Read interrupt source
	IntSource = I2caRegs.I2CISRC.bit.INTCODE & 0x7;
	
	switch(IntSource)
	{
		case I2C_NO_ISRC:   // =0
			break;

		case I2C_ARB_ISRC:  // =1
			break;

		case I2C_NACK_ISRC: // =2
			break;

		case I2C_ARDY_ISRC: // =3
			break;

		case I2C_RX_ISRC:   // =4
			InData[I2cIndex++] = I2caRegs.I2CDRR;

			Register = InData[0];           // Used on data transmit.
			OutData[1] = (InitCheckReg[Register]>>8)&0xFF; //Get most significant byte.
			OutData[2] = (InitCheckReg[Register])&0xFF;    //Get least significant byte.

			if (I2cIndex == 3)   // If index is at 3, we have received 2 data bytes.
			{
				I2cIndex = 0;    // Reset index.
				Flags.bit.DataReady = 1; // Set flag to update outside of this loop.
			}
			break;

		case I2C_TX_ISRC:   // =5
            if (I2cIndex == 0) break;              // If reset already, break.
			I2caRegs.I2CDXR = OutData[I2cIndex++]; // Output Data to Host

			if (I2cIndex ==3)	// if index is at 3, we are done.
			{
				I2cIndex =0;	// reset index.
			}
			break;

		case I2C_SCD_ISRC:  // =6
			break;

		case I2C_AAS_ISRC:  // =7
			break;
	
		default:
			asm("   ESTOP0"); // Halt on invalid number.
	}

   // Enable further I2C (PIE Group 8) interrupts by acknowledging this one.
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
}

void Enable_i2c_interrupt(void)     // I2C-A
{
	// Enable I2C interrupt 1 in the PIE: Group 8 interrupt 1
	PieCtrlRegs.PIEIER8.bit.INTx1 = 1;

    // Enable the PIE
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;

	// Enables PIE to drive a pulse into the CPU
	PieCtrlRegs.PIEACK.all = 0xFFFF;

	// Enable CPU INT8 which is connected to PIE group 8
	IER |= M_INT8;

	// Enable Interrupts at the CPU level
	EINT;   // Enable Global interrupt INTM
	ERTM;	// Enable Global realtime interrupt DBGM
}

void Disable_i2c_interrupt(void)     // I2C-A
{
	// Disable Interrupts at the CPU level
	DINT;   // Disable Global interrupt INTM

	// Disable CPU INT8 which is connected to PIE group 8
	IER = 0x0000;

	// Disable I2C interrupt 1 in the PIE: Group 8 interrupt 1
	PieCtrlRegs.PIEIER8.bit.INTx1 = 0;

    // Disable the PIE
    PieCtrlRegs.PIECTRL.bit.ENPIE = 0;

    // Enable further I2C (PIE Group 8) interrupts by acknowledging this one.
 	PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
}

//===========================================================================
// No more.
//===========================================================================

