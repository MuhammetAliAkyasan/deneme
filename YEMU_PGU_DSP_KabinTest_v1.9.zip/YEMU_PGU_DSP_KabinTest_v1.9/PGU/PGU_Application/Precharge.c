/*
 * Precharge.c
 *
 *  Created on: 17 Oca 2013
 *      Author: fozturk
 */
#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include "PGU_Common.h"
#include "PGUREC_Common.h"

#include "PGU_IOConfig.h"                    //"DSP_IORW.h"           // IO R/W macro
#include "PGU_GlobalVariables.h"

Uint16 	Ticker1 		= 0;
Uint16  Ticker2         = 0;

Uint16  PCCSon      = 0;

void PGU_PreChargeRoutine1(void)
{

   PreCh.Ticker1++;						// PreChargeRoutine Ticker

	if(PRECHCTL_REG1.bit.STATE == 0)					// PreCharge rutini ba�lang�� durumunda.
	{
		if(!MCAUX_REG1.bit.STATUS && MC1_Status)		// PreCharge kontakt�r� Kapama �ncesi Ana kontakt�r kontrol edildi.
		{
			PCC1_REG.bit.CLOSE 	= 1;		// Precharge kontakt�r� kapatma sinyali uyguland�
			PRECHCTL_REG1.bit.STATE 		= 1;		// Precharge kontakt�r� kapatma durumuna ge�ildi.
			Ticker1 	= PreCh.Ticker1;		// Precharge kontakt�r� kapatma zaman� kaydedildi.
		}
		else
		{
			PRECHCTL_REG1.bit.STATUS 	= 2;		    // PreCharge esnas�nda hata meydana geldi
			PRECHCTL_REG1.bit.STATE     = 20;		    // PreCharge state 0 s�ras�nda hata var
		}

	}

	if(PRECHCTL_REG1.bit.STATE == 1)
	{
		if(PCC1_REG.bit.STATUS)				// Precharge kontakt�r�n�n kapand��� kontrol edildi.
		{
			PreCh.DCinit = PGUREC_Measure.Result.Volt_DCLink; // Precharge ba�lang�c�ndaki DC gerilim
			PreCh.Energy = 0.0;						 // Precharge enerjisi
			PRECHCTL_REG1.bit.STATE = 2;				// DC bara y�kselme durumuna ge�ildi.
			Ticker1 	= PreCh.Ticker1;		// DC bara y�kselme ba�lang�� zaman� kaydedildi.
		}
		else if (PreCh.Ticker1 > Ticker1 + PreCh.PCCmaxclosetime) // Precharge kontakt�r�n�n kapanma s�resi doldu
		{
			PRECHCTL_REG1.bit.STATUS 	    = 2;		// PreCharge esnas�nda hata meydana geldi
			PRECHCTL_REG1.bit.STATE 		= 21;		// PreCharge state 1 s�ras�nda hata var
		}

	}

	if(PRECHCTL_REG1.bit.STATE == 2)
	{
		if(PreCh.DCinit < PreCh.DClimit * 0.4)  	// �arjl� durum i�in enerji hesaplamamak i�in
		{
//			PreCh.Energy = PreCh.Energy + (Volt_LabGiris * PGU_1PHRectFdbHs.Cur_RectInput1) * PGUREC_TS_INV;
		}

		if(PreCh.Ticker1 > Ticker1 + PreCh.DCbuildtime) 	// DC bara y�kselme zaman� kontrol edildi.
		{
			if (PreCh.Energy < -10.0)			// Konverter ba�lant�lar� ile primer gerilim �rne�i ba�lant�s� kontrol� i�in(-10 rastgele negatif de�er)
			{
			    PGUREC_FLT_REG.bit.VSPOL	= 1;
			}

		    if(PGUREC_Measure.Result.Volt_DCLink <= PreCh.DClimit)	// DC bara gerilimi %90'a ula�mad�ysa
//			if(0)
			{
				PRECHCTL_REG1.bit.STATUS 	= 2;				// PreCharge esnas�nda hata meydana geldi
				PRECHCTL_REG1.bit.STATE 		= 22;				// PreCharge state 2 s�ras�nda hata var
			}
			else										// DC bara limit de�ere ula�t�ysa
			{
//	            DELAY_US(1000000);
			    if(PCC1_REG.bit.STATUS)
			    {
                    MCAUX_REG1.bit.CLOSE 			= 1;				// Ana kontakt�r� kapatma sinyali uygula
                    PRECHCTL_REG1.bit.STATE 		= 3;				// Ana kontakt�r kapatma durumuna ge�ildi.
                    Ticker1 	= PreCh.Ticker1;							// Ana kontakt�r� kapatma zaman� kaydedildi.
			    }
			}
		}
	}

	if(PRECHCTL_REG1.bit.STATE == 3)
	{
		if(MCAUX_REG1.bit.STATUS && !MC1_Status)			// Ana kontakt�r ve yard�mc�s� kapand��� kontrol edildi.
		{
			PRECHCTL_REG1.bit.STATE 		= 4;			// Precharge kontakt�r� a�ma durumuna ge�ildi.
			Ticker1 	= PreCh.Ticker1;			// Precharge biti� s�resi kaydedildi.
		}
		else if (PreCh.Ticker1 > Ticker1 + PreCh.MCmaxclosetime) // Ana kontakt�r�n kapanma s�resi doldu
		{
			PRECHCTL_REG1.bit.STATUS 	= 2;	  	// PreCharge esnas�nda hata meydana geldi
			PRECHCTL_REG1.bit.STATE 		= 23;		// PreCharge state 3 s�ras�nda hata var
		}
	}

	if(PRECHCTL_REG1.bit.STATE == 4)
	{
		if(PreCh.Ticker1 > Ticker1 + PreCh.PCCopentime) // Precharge kontakt�r�n� a�mak i�in gerekli s�re doldu
		{
			PRECHCTL_REG1.bit.STATE 	= 5;			// Precharge tamamland� durumu
			PRECHCTL_REG1.bit.STATUS = 4;			// Ana kontakt�r kapand�, PCCopentime s�re ge�ti, PreCharge ba�ar�l�
			PCC1_REG.bit.OPEN 		= 1;			// PreCharge kontakt�r�n� a�
			PCCSon=1;
//			IO_SET(PCCSig)
			PGUREC_TCPU_Outputs.bit.PCC1_SIG = 1;
		}
	}

	if(PRECHCTL_REG1.bit.STATUS == 2)
	{
		PCC1_REG.bit.OPEN 	= 1;                // Hata var PreCharge kontakt�r�n� a�
//		IO_SET(PCCSig)
		PGUREC_TCPU_Outputs.bit.PCC1_SIG = 1;
		MCAUX_REG1.bit.OPEN 	= 1;            // Hata var Ana kontakt�r� a�
		IO_SET(MCSig1)

		PGUREC_CTL_REG.bit.OPMODE 	= 2;		// Hata var
		PGUREC_CTL_REG.bit.STATE   = 11;		// Precharge tamamlanamadi
		PGUREC_FLT_REG.bit.PRECH 	= 1;
	}
}


void PGU_PreChargeRoutine2(void)
{
    PreCh.Ticker2++;                       // PreChargeRoutine Ticker

       if(PRECHCTL_REG2.bit.STATE == 0)                 // PreCharge rutini ba�lang�� durumunda.
       {
           if(!MCAUX_REG2.bit.STATUS && MC2_Status)             // PreCharge kontakt�r� Kapama �ncesi Ana kontakt�r kontrol edildi.
           {
               PCC2_REG.bit.CLOSE  = 1;        // Precharge kontakt�r� kapatma sinyali uyguland�
               PRECHCTL_REG2.bit.STATE      = 1;        // Precharge kontakt�r� kapatma durumuna ge�ildi.
               Ticker2     = PreCh.Ticker2;        // Precharge kontakt�r� kapatma zaman� kaydedildi.
           }
           else
           {
               PRECHCTL_REG2.bit.STATUS     = 2;        // PreCharge esnas�nda hata meydana geldi
               PRECHCTL_REG2.bit.STATE      = 20;       // PreCharge state 0 s�ras�nda hata var
           }

       }

       if(PRECHCTL_REG2.bit.STATE == 1)
       {
           if(PCC2_REG.bit.STATUS)             // Precharge kontakt�r�n�n kapand��� kontrol edildi.
           {
               PreCh.DCinit = PGUREC_Measure.Result.Volt_DCLink; // Precharge ba�lang�c�ndaki DC gerilim
               PreCh.Energy = 0.0;                      // Precharge enerjisi
               PRECHCTL_REG2.bit.STATE = 2;             // DC bara y�kselme durumuna ge�ildi.
               Ticker2     = PreCh.Ticker2;        // DC bara y�kselme ba�lang�� zaman� kaydedildi.
           }
           else if (PreCh.Ticker2 > Ticker2 + PreCh.PCCmaxclosetime) // Precharge kontakt�r�n�n kapanma s�resi doldu
           {
               PRECHCTL_REG2.bit.STATUS     = 2;        // PreCharge esnas�nda hata meydana geldi
               PRECHCTL_REG2.bit.STATE      = 21;       // PreCharge state 1 s�ras�nda hata var
           }

       }

       if(PRECHCTL_REG2.bit.STATE == 2)
       {
           if(PreCh.DCinit < PreCh.DClimit * 0.4)      // �arjl� durum i�in enerji hesaplamamak i�in
           {
//               PreCh.Energy = PreCh.Energy + (Volt_LabGiris * PGU_1PHRectFdbHs.Cur_RectInput2) * PGUREC_TS_INV;
           }

           if(PreCh.Ticker2 > Ticker2 + PreCh.DCbuildtime)     // DC bara y�kselme zaman� kontrol edildi.
           {
               if (PreCh.Energy < -10.0)           // Konverter ba�lant�lar� ile primer gerilim �rne�i ba�lant�s� kontrol� i�in(-10 rastgele negatif de�er)
               {
                   PGUREC_FLT_REG.bit.VSPOL   = 1;
               }

              if(PGUREC_Measure.Result.Volt_DCLink <= PreCh.DClimit)    // DC bara gerilimi %90'a ula�mad�ysa
//               if(0)
               {
                   PRECHCTL_REG2.bit.STATUS     = 2;                // PreCharge esnas�nda hata meydana geldi
                   PRECHCTL_REG2.bit.STATE      = 22;               // PreCharge state 2 s�ras�nda hata var
               }
               else                                        // DC bara limit de�ere ula�t�ysa
               {
   //              DELAY_US(1000000);
                   if(PCC2_REG.bit.STATUS)
                   {
                       MCAUX_REG2.bit.CLOSE             = 1;                // Ana kontakt�r� kapatma sinyali uygula
                       PRECHCTL_REG2.bit.STATE      = 3;                // Ana kontakt�r kapatma durumuna ge�ildi.
                       Ticker2     = PreCh.Ticker2;                            // Ana kontakt�r� kapatma zaman� kaydedildi.
                   }
               }
           }
       }

       if(PRECHCTL_REG2.bit.STATE == 3)
       {
           if(MCAUX_REG2.bit.STATUS && !MC2_Status)          // Ana kontakt�r ve yard�mc�s� kapand��� kontrol edildi.
           {
               PRECHCTL_REG2.bit.STATE      = 4;            // Precharge kontakt�r� a�ma durumuna ge�ildi.
               Ticker2     = PreCh.Ticker2;            // Precharge biti� s�resi kaydedildi.
           }
           else if (PreCh.Ticker2 > Ticker2 + PreCh.MCmaxclosetime) // Ana kontakt�r�n kapanma s�resi doldu
           {
               PRECHCTL_REG2.bit.STATUS     = 2;        // PreCharge esnas�nda hata meydana geldi
               PRECHCTL_REG2.bit.STATE      = 23;       // PreCharge state 3 s�ras�nda hata var.
           }
       }

       if(PRECHCTL_REG2.bit.STATE == 4)
       {
           if(PreCh.Ticker2 > Ticker2 + PreCh.PCCopentime) // Precharge kontakt�r�n� a�mak i�in gerekli s�re doldu
           {
               PRECHCTL_REG2.bit.STATE  = 5;            // Precharge tamamland� durumu
               PRECHCTL_REG2.bit.STATUS = 4;            // Ana kontakt�r kapand�, PCCopentime s�re ge�ti, PreCharge ba�ar�l�
               PCC2_REG.bit.OPEN       = 1;            // PreCharge kontakt�r�n� a�
               PCCSon=1;
//               IO_SET(PCCSig)
               PGUREC_TCPU_Outputs.bit.PCC2_SIG = 1;

           }
       }

       if(PRECHCTL_REG2.bit.STATUS == 2)
       {
           PCC2_REG.bit.OPEN   = 1;      // Hata var PreCharge kontakt�r�n� a�
//           IO_SET(PCCSig)
           PGUREC_TCPU_Outputs.bit.PCC2_SIG = 1;
           MCAUX_REG2.bit.OPEN  = 1;      // Hata var Ana kontakt�r� a�
           IO_SET(MCSig2)

           PGUREC_CTL_REG.bit.OPMODE  = 2;        // Hata var
           PGUREC_CTL_REG.bit.STATE   = 11;       // Precharge tamamlanamadi
           PGUREC_FLT_REG.bit.PRECH   = 1;
       }
}

