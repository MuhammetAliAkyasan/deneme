/*
 * PGU_GlobalVariables.c
 *
 *  Created on: 7 Eki 2018
 *      Author: fozturk
 */

/* ==============================================================================
System Name:
File Name:      PGU_GlobalVariables.c
Description:
Originator:
Note:
=====================================================================================*/

#include "DSP28x_Project.h"         //DSP28x Project Headerfile and Examples Include File
#include "PGU_Common.h"

//--FLAGS
volatile Uint16 EnableFlag      = TRUE;     //  System enable flag
volatile Uint16 DebugTicker     = 0;        //  Back Ticker before enable system command

Uint16 SWResett             = 0;        //
Uint16 GA                   = 0;        //
PGUCardType ActivePGUCard   = PGU;


int ExtFlashTestResult = 0;
Uint16 * ExtRamTestResult = NULL;
Uint16 * DualRamTestResult = NULL;

Uint16 STestErr = 0;

const char build_date[12]   = {__DATE__};
const char build_time[10]   = {__TIME__};
const char build_rev[4]     = {PROJECT_REV};
const char build_loco[8]    = {LOCO_TYPE};

STESTFLT_REG    STestErrFlags   = {0x0000};

SPIADC_VALUES SPIADCValues = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

// Used to indirectly access all EPWM modules
volatile struct EPWM_REGS *ePWM[] =
                  { &EPwm1Regs,         //intentional: (ePWM[0] not used)
                    &EPwm1Regs,
                    &EPwm2Regs,
                    &EPwm3Regs,
                    &EPwm4Regs,
                    &EPwm5Regs,
                    &EPwm6Regs,
                  };

// Used to indirectly access eQEP module
volatile struct EQEP_REGS *eQEP[] =
                  { &EQep1Regs,
                    &EQep1Regs,
                    &EQep2Regs,
                  };

// Used to indirectly access eQEP module
volatile struct ECAP_REGS *eCAP[] =
                  { &ECap1Regs,
                    &ECap1Regs,
                    &ECap2Regs,
                    &ECap3Regs,
                    &ECap4Regs,
                    &ECap5Regs,
                    &ECap6Regs,
                  };

void BuildTimeInit(void)
{
    // Project Revision Monitoring
    MonitorData[224]  = (Uint16) (build_rev[1]<<8)  | (Uint16) (build_rev[0] & 0x00FF);
    MonitorData[225]  = (Uint16) (build_rev[3]<<8)  | (Uint16) (build_rev[2] & 0x00FF);
    MonitorData[226]  = (Uint16) (build_loco[1]<<8)  | (Uint16) (build_loco[0] & 0x00FF);
    MonitorData[227]  = (Uint16) (build_loco[3]<<8)  | (Uint16) (build_loco[2] & 0x00FF);
    MonitorData[228]  = (Uint16) (build_loco[5]<<8)  | (Uint16) (build_loco[4] & 0x00FF);
    MonitorData[229]  = (Uint16) (build_loco[7]<<8)  | (Uint16) (build_loco[6] & 0x00FF);

    // Project Build Date Monitoring
    MonitorData[230] = (Uint16) (build_date[1]<<8) | (Uint16) (build_date[0] & 0x00FF);
    MonitorData[231] = (Uint16) (build_date[3]<<8) | (Uint16) (build_date[2] & 0x00FF);
    MonitorData[232] = (Uint16) (build_date[5]<<8) | (Uint16) (build_date[4] & 0x00FF);
    MonitorData[233] = (Uint16) (build_date[7]<<8) | (Uint16) (build_date[6] & 0x00FF);
    MonitorData[234] = (Uint16) (build_date[9]<<8) | (Uint16) (build_date[8] & 0x00FF);
    MonitorData[235] = (Uint16) (build_date[11]<<8)| (Uint16) (build_date[10] & 0x00FF);

    // Project Build Time Monitoring
    MonitorData[236] = (Uint16) (build_time[1]<<8) | (Uint16) (build_time[0] & 0x00FF);
    MonitorData[237] = (Uint16) (build_time[3]<<8) | (Uint16) (build_time[2] & 0x00FF);
    MonitorData[238] = (Uint16) (build_time[5]<<8) | (Uint16) (build_time[4] & 0x00FF);
    MonitorData[239] = (Uint16) (build_time[7]<<8) | (Uint16) (build_time[6] & 0x00FF);
}

void SWUpdateCheck(void)
{
// Watchdog dikkat edilecek... (dahili ve harici !!!)
    // CodeSecurity mod�l !!!!

    if(Tiva2DSPRegs.regs.SWUpdateCtrl.usAll == ~Tiva2DSPRegs.regs.SWUpdateCtrln.usAll)
    {
        if(Tiva2DSPRegs.regs.SWUpdateCtrl.bits.Start == 1)
        {
                DisableDog();
                IO_TOGGLE(WDTog)

                EALLOW;                                              //PGUGateOFF
                EPwm6Regs.TZFRC.bit.OST = 1;
                EPwm5Regs.TZFRC.bit.OST = 1;
                EPwm4Regs.TZFRC.bit.OST = 1;
                EPwm3Regs.TZFRC.bit.OST = 1;
                EPwm2Regs.TZFRC.bit.OST = 1;
                EPwm1Regs.TZFRC.bit.OST = 1;
                EDIS;

                if(GpioDataRegs.GPBDAT.bit.GPIO48 != 1) GpioDataRegs.GPBDAT.bit.GPIO48 = 1; //FOIOGateOFF

                InitPeripheralClocks();         // initializes the Peripheral Clocks to a known state.

                InitPieCtrl();                  // initializes the PIE to a known state.

                IER = 0x0000;                   // Disable all PIE Interrupts

                DSPFlashUpdate();
        }

//      if(Tiva2DSPRegs.regs.SWUpdateCtrl.bits.Reset == 1)
//      {
//
//              DisableDog();
//              IO_TOGGLE(WDTog)
//
//              PGUGateOFF
//              FOIOGateOFF
//
//              DINT;   // Disable Global interrupt INTM
//
//              while(Tiva2DSPRegs.regs.SWUpdateCtrl.bits.Reset == 1)
//              {
//                  Tiva2DSPRegs.regs.SWUpdateCtrl.bits.Reset = 0;
//              }
//
//              asm("    LCR #0x33FFF6");       // FLASHA Entry point: 0x33FFF6
//      }
    }

}
