/*
 * AnalogBuffer.c
 *
 *  Created on: 04.10.2018
 *  Modified  :
 *      Author: fozturk
 */

//#include "PGU_Project.h"

#include "DSP28x_Project.h"
#include "PGU_Common.h"

Uint16 Pointer[16]= {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

void FillAnalogBuffer(volatile float32 AnalogData, volatile float32 buffer[BUFFSIZE], Uint16 Index)
{
	if (Pointer[Index-1]<BUFFSIZE)
	{
		buffer[Pointer[Index-1]]=AnalogData;
		Pointer[Index-1]++;
	}
	else
	{
		Pointer[Index-1]=0;
	}
}

void ClearAnalogBuffer(volatile float32 buffer[BUFFSIZE], Uint16 Index)
{
	for (Pointer[Index-1]=0;Pointer[Index-1]<BUFFSIZE;Pointer[Index-1]++)
	{
		buffer[Pointer[Index-1]]=0.0;
	}
	Pointer[Index-1]=0;
}






