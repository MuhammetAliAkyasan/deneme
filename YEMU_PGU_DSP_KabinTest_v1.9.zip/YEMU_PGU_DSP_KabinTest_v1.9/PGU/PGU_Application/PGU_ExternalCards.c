/*
 * PGU_ExternalCards.h
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 *  Revised on: 31.01.2020
 *      Author: AHO
 */

#include "DSP28x_Project.h"         //DSP28x Project Headerfile and Examples Include File
#include "PGU_Common.h"

void InitSPIDAC()
{
	// SPI configuration & initialization for DAC use
    spi_init(SPIDAC);					// SPI module init for TLV5630
	tlv5630_init();						// TLV5630 init
	SPIread();							// dummy read to clear RX buffer
}

void InitSPIDAC2()
{
    // SPI configuration & initialization for DAC use
    spi_init(SPIDAC2);                   // SPI module init for TLV5630
    tlv5630_init();                     // TLV5630 init
    SPIread();                          // dummy read to clear RX buffer
}

void SPIDACWrite(Uint16 Channel,float32 ChannelVoltage)
{
	Uint16 ChannelValue;
	ChannelValue=(Uint16)(1365.333*ChannelVoltage);

	spi_init(SPIDAC);
	spi_xmit(tlv5630_registerWrite(Channel, ChannelValue));
	delay_loop();
	SPIread();
}

void SPIDAC2Write(Uint16 Channel,float32 ChannelVoltage)
{
    Uint16 ChannelValue;
    ChannelValue=(Uint16)(1365.333*ChannelVoltage);

    spi_init(SPIDAC2);
    spi_xmit(tlv5630_registerWrite(Channel, ChannelValue));
    delay_loop();
    SPIread();
}

// Initialize SPI ADC
void InitSPIADC()
{
	// SPI configuration & initialization for ADC use
	spi_init(SPIADC);										// SPI module init for ADS7953
	ads7953_init();											// ADS7953 init
}

// Arguman olarak &(SPIADCValues.CH0) g�nderilecek;

void SPIADCRead(float32  *dest)
{
    Uint16 ADCData;
    Uint16 ChVal;
    Uint16 ChNo;

    Uint16    ind;

    spi_init(SPIADC);

    for(ind=0;ind<16;ind++)
    {
        ADCData         = ads7953_read();
        ChNo            = (ADCData&0xF000)>>12;
        ChVal           = (ADCData&0x0FFF);
        *(dest+ChNo)    = (float32)(ChVal * (0.000732421875)); // 3.0 / 4096.0 = 0.000732421875
    }
}




