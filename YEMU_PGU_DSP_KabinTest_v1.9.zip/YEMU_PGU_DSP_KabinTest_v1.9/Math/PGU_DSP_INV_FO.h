#ifndef __FO_H__
#define __FO_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 Is_alpha; /*Stator current alpha-axis value in stationary coordinates*/
	float32 Is_beta; /*Stator current beta-axis value in stationary coordinates*/
	float32 Us_alpha; /*Stator voltage alpha-axis reference value in stationary coordinates*/
	float32 Us_beta; /*Stator voltage beta-axis reference value in stationary coordinates*/
	float32 w; /*Electrical angular frequency of rotation*/
} FO_IN;
typedef struct 
{
	float32 cosTheta; /*Cosine of rotor flux vector angle*/
	float32 sinTheta; /*Sine of rotor flux vector angle*/
	float32 ws; /*Angular frequency of rotor flux vector*/
	float32 Te; /*Calculated torque*/
	float32 PsiS_d; /*Stator flux d-axis value in field coordinates*/
	float32 PsiS_q; /*Stator flux q-axis value in field coordinates*/
	float32 PsiR; /*Rotor flux magnitude(compensated)*/
} FO_OUT;
typedef struct 
{
	float32 cosThetaR; /*Cosine of electrical rotor angle*/
	float32 sinThetaR; /*Sine of electrical rotor angle*/
	float32 Is_x; /*Stator current x-axis value in rotor coordinates*/
	float32 Is_y; /*Stator current y-axis value in rotor coordinates*/
	float32 PsiR_x; /*Rotor flux x-axis value in rotor coordinates*/
	float32 PsiR_y; /*Rotor flux y-axis value in rotor coordinates*/
	float32 PsiRc_alpha; /*Rotor flux alpha-axis value calculated by current model in stationary coordinates*/
	float32 PsiRc_beta; /*Rotor flux beta-axis value calculated by current model in stationary coordinates*/
	float32 PsiRv_alpha; /*Rotor flux alpha-axis value calculated by voltage model in stationary coordinates*/
	float32 PsiRv_beta; /*Rotor flux beta-axis value calculated by voltage model in stationary coordinates*/
	float32 PsiRErr_alpha; /*Rotor flux alpha-axis difference of two flux models in stationary coordinates*/
	float32 PsiRErr_beta; /*Rotor flux beta-axis difference of two flux models in stationary coordinates*/
	float32 Uoi_alpha; /*Observer controller integrator alpha-axis in stationary coordinates*/
	float32 Uoi_beta; /*Observer controller integrator beta-axis in stationary coordinates*/
	float32 Uo_alpha; /*Observer controller output alpha-axis in stationary coordinates*/
	float32 Uo_beta; /*Observer controller output beta-axis in stationary coordinates*/
	float32 h; /*Flux angle compensation hypotenuse*/
	float32 cosGamma; /*Cosine of rotor flux compensation angle*/
	float32 sinGamma; /*Sine of rotor flux compensation angle*/
	float32 PsiR_alpha; /*Rotor flux alpha-axis value in stationary coordinates (compensated)*/
	float32 PsiR_beta; /*Rotor flux beta-axis value in stationary coordinates (compensated)*/
	float32 PsiRD_alpha; /*Delayed rotor flux alpha-axis value in stationary coordinates (compensated)*/
	float32 PsiRD_beta; /*Delayed rotor flux beta-axis value in stationary coordinates (compensated)*/
	float32 PsiS_alpha; /*Stator flux alpha-axis value in stationary coordinates*/
	float32 PsiS_beta; /*Stator flux beta-axis value in stationary coordinates*/
	float32 Theta; /*Rotor flux angle value for field orientation*/
	float32 wr; /*Rotor electrical frequency in rad/s*/
	float32 wrLPF; /*Low-pass filtered rotor electrical frequency in rad/s*/
	float32 ThetaR; /*Electrical angle of rotor*/
} FO_VAR;
typedef struct 
{
	Uint16 Enable; /*Enable for flux observer*/
	float32 T; /*Sample time in seconds*/
	float32 T_Tr; /*T/Tr, Tr: Rotor time constant*/
	float32 Lm; /*Magnetizing inductance*/
	float32 Lr; /*Rotor inductance*/
	float32 Lsig; /*Total leakage inductance referred to stator*/
	float32 Rs; /*Stator phase resistance*/
	float32 Kpo; /*Proportional gain of observer controller*/
	float32 Kio; /*Integration gain of observer controller*/
	float32 p; /*Number of pole pairs*/
	float32 PsiRMin; /*Minimum rotor flux magnitude for angle estimation*/
	float32 T_Twr; /*Twr: Rotor electrical frequency LPF time constant*/
} FO_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	FO_IN	i;
	FO_OUT 	o;
	FO_VAR	v;
	FO_PAR	p;
} FO;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define FO_IN_DEFAULTS  {0.0,0.0,0.0,0.0,0.0}
#define FO_OUT_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0,0.0}
#define FO_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}
#define FO_PAR_DEFAULTS {0,0.001,0.0,0.01,0.01,0.01,0.01,0.0,0.0,3.0,0.1,0.1}

/********** DEFINITON OF MACRO **********/
#define FO_MACRO(x)\
if (x.p.Enable == 1)\
{\
/* Current Model */\
	/* Rotor angle from filtered rotor speed */\
	x.v.ThetaR = x.v.ThetaR + x.p.T*x.i.w;\
	if (x.v.ThetaR >  PI) x.v.ThetaR = x.v.ThetaR-2*PI;\
	if (x.v.ThetaR < -PI) x.v.ThetaR = x.v.ThetaR+2*PI;\
	/* Transformation angle to rotor coordinates */\
	x.v.cosThetaR = cos(x.v.ThetaR);\
	x.v.sinThetaR = sin(x.v.ThetaR);\
	/* Currents in rotor coordinates (w) */\
	/* exp(-jThetaR)*/\
	x.v.Is_x =  x.v.cosThetaR*x.i.Is_alpha + x.v.sinThetaR*x.i.Is_beta;\
	x.v.Is_y = -x.v.sinThetaR*x.i.Is_alpha + x.v.cosThetaR*x.i.Is_beta;\
	/* Rotor fluxes in in rotor coordinates */\
    /* PsiR(k)=(1-T/Tr)*PsiR(k-1) + Lm*T/Tr*Is(k) */\
	x.v.PsiR_x = (1.0 - x.p.T_Tr)*x.v.PsiR_x + x.p.Lm*x.p.T_Tr*x.v.Is_x;\
	x.v.PsiR_y = (1.0 - x.p.T_Tr)*x.v.PsiR_y + x.p.Lm*x.p.T_Tr*x.v.Is_y;\
	/* exp(jThetaR) */\
	x.v.PsiRc_alpha = x.v.cosThetaR*x.v.PsiR_x - x.v.sinThetaR*x.v.PsiR_y;\
	x.v.PsiRc_beta  = x.v.sinThetaR*x.v.PsiR_x + x.v.cosThetaR*x.v.PsiR_y;\
\
/* PsiR(k)=(PsiS(k)-Lsig*Is(k))/kr */\
    x.v.PsiRv_alpha = x.p.Lr/x.p.Lm*(x.v.PsiS_alpha - x.p.Lsig*x.i.Is_alpha);\
	x.v.PsiRv_beta  = x.p.Lr/x.p.Lm*(x.v.PsiS_beta  - x.p.Lsig*x.i.Is_beta );\
\
/* Observer Controller */\
	/* Observer error */\
    x.v.PsiRErr_alpha = x.v.PsiRc_alpha - x.v.PsiRv_alpha;\
	x.v.PsiRErr_beta  = x.v.PsiRc_beta  - x.v.PsiRv_beta;\
	/* Observer integrator */\
	x.v.Uoi_alpha = x.v.Uoi_alpha + x.p.Kio*x.p.T*x.v.PsiRErr_alpha;\
	x.v.Uoi_beta  = x.v.Uoi_beta  + x.p.Kio*x.p.T*x.v.PsiRErr_beta;\
	/* Observer controller output */\
	x.v.Uo_alpha  = x.p.Kpo*x.v.PsiRErr_alpha + x.v.Uoi_alpha;\
	x.v.Uo_beta   = x.p.Kpo*x.v.PsiRErr_beta  + x.v.Uoi_beta;\
    \
/* Transformation Angle Calculation */\
	/* Phase compensation */\
	x.v.h = sqrt(SQR(x.p.Kpo*x.o.ws) + SQR(SQR(x.o.ws)-x.p.Kio));\
    if (x.v.h > 0.0)\
    {\
		x.v.sinGamma = x.p.Kpo*x.o.ws/x.v.h;\
        x.v.cosGamma = (SQR(x.o.ws)-x.p.Kio)/x.v.h;\
        x.v.PsiR_alpha = x.v.PsiRc_alpha - ( x.v.cosGamma*x.v.PsiRErr_alpha + x.v.sinGamma*x.v.PsiRErr_beta);\
        x.v.PsiR_beta  = x.v.PsiRc_beta  - (-x.v.sinGamma*x.v.PsiRErr_alpha + x.v.cosGamma*x.v.PsiRErr_beta);\
    }\
	else\
	{\
        x.v.PsiR_alpha = x.v.PsiRv_alpha;\
        x.v.PsiR_beta  = x.v.PsiRv_beta;\
    }\
    \
    x.v.PsiR_alpha = x.v.PsiRv_alpha;\
    x.v.PsiR_beta  = x.v.PsiRv_beta;\
    /* Rotor flux magnitude */\
	x.o.PsiR = sqrt(SQR(x.v.PsiRc_alpha)+SQR(x.v.PsiRc_beta));\
	if ( x.o.PsiR < x.p.PsiRMin )\
	{\
		x.v.Theta = x.v.ThetaR;\
		x.v.wr = 0.0;\
	}\
	else\
	{\
		/* Rotor flux magnitude */\
		x.o.PsiR = sqrt(SQR(x.v.PsiR_alpha)+SQR(x.v.PsiR_beta));\
		x.v.Theta = atan2(x.v.PsiR_beta,x.v.PsiR_alpha);\
		/*wr = ws - w*/\
		x.v.wr = (x.v.PsiR_beta*x.v.PsiRD_alpha-x.v.PsiR_alpha*x.v.PsiRD_beta)/(x.p.T*SQR(x.o.PsiR)) - x.i.w;\
	}\
	/*Low-pass filter for wr*/\
	x.v.wrLPF = (1.0-x.p.T_Twr)*x.v.wrLPF + x.p.T_Twr*x.v.wr;\
	/*Synchronous frequency calculation*/\
	x.o.ws = x.i.w + x.v.wrLPF;\
	\
	x.o.cosTheta = cos(x.v.Theta);\
	x.o.sinTheta = sin(x.v.Theta);\
/* Torque Calculation */\
	x.o.Te = 1.5*x.p.p*(x.v.PsiS_alpha*x.i.Is_beta - x.v.PsiS_beta*x.i.Is_alpha);\
\
/* Stator flux in field coordinates ( exp(-jTheta) )*/\
	x.o.PsiS_d =  x.o.cosTheta*x.v.PsiS_alpha + x.o.sinTheta*x.v.PsiS_beta;\
	x.o.PsiS_q = -x.o.sinTheta*x.v.PsiS_alpha + x.o.cosTheta*x.v.PsiS_beta;\
\
/* Rotor flux in field coordinates ( exp(-jTheta) )*/\
/*    x.o.PsiR_d = x.o.cosTheta*x.v.PsiR_alpha + x.o.sinTheta*x.v.PsiR_beta;*/\
/*  x.o.PsiR_q = -x.o.sinTheta*x.v.PsiR_alpha + x.o.cosTheta*x.v.PsiR_beta; */\
\
/* Next value calculation */    \
/* Voltage Model */\
    /* PsiS(k+1)=PsiS(k)+T*(Uo(k)+Us(k)-Rs*Is(k)) */\
    x.v.PsiS_alpha = x.v.PsiS_alpha + x.p.T*(x.v.Uo_alpha + x.i.Us_alpha - x.p.Rs*x.i.Is_alpha); /* k-1 instant */\
	x.v.PsiS_beta  = x.v.PsiS_beta  + x.p.T*(x.v.Uo_beta  + x.i.Us_beta  - x.p.Rs*x.i.Is_beta);\
    \
/* Old value update */\
	x.v.PsiRD_alpha = x.v.PsiR_alpha;\
	x.v.PsiRD_beta  = x.v.PsiR_beta;\
}\
else\
{\
/* States */\
    x.v.PsiR_x 		= 0.0;\
	x.v.PsiR_y 		= 0.0;\
	x.v.Uoi_alpha 	= 0.0;\
	x.v.Uoi_beta  	= 0.0;\
	x.v.wrLPF		= 0.0;\
	x.v.PsiS_alpha  = 0.0;\
	x.v.PsiS_beta   = 0.0;\
	x.v.ThetaR      = 0.0;\
/* Outputs */\
    x.o.cosTheta 	= 0.0;\
    x.o.sinTheta 	= 0.0;\
    x.o.ws 			= 0.0;\
    x.o.Te 			= 0.0;\
    x.o.PsiS_d 		= 0.0;\
    x.o.PsiS_q 		= 0.0;\
    x.o.PsiR 		= 0.0;\
}
// END OF MACRO DEFINITON

#endif // __FO_H__
