#ifndef __VC_H__
#define __VC_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 UsMax; /*Maximum avaliable stator voltage vector magnitude*/
	float32 Us; /*Stator voltage vector magnitude*/
	float32 Is_q; /*Stator current q-axis (reference) value in field coordinates*/
	float32 PsiR_d;/*Rotor flux d-axis value*/
	float32 ws; /*Stator synchronous angular frequency*/
} VC_IN;
typedef struct 
{
	float32 IsRef_d; /*Stator current d-axis reference value in field coordinates*/
} VC_OUT;
typedef struct 
{
	float32 UsLPF; /*Lowpass filtered stator voltage vector magnitude*/
	float32 UsErr; /*Voltage controller error*/
	float32 UvFF; /*Voltage controller feed-forward value*/
	float32 Uvi; /*Voltage controller integrator output*/
	float32 Uv; /*Voltage controller output*/
	float32 Ka; /*Voltage controller adaptive gain*/
} VC_VAR;
typedef struct 
{
	Uint16 Enable; /*Enable for voltage controller*/
	float32 T_Tr; /*T/Tr, Tr: Rotor time constant*/
	float32 T_Tusf; /*T/Tusf, Tusf: LPF time constant for stator voltage magnitude*/
	float32 ws0; /*Minimum absolute angular frequency for adaptive gain*/
	float32 Lsig; /*Total leakage inductance referred to stator*/
	float32 K; /*Voltage controller constant proportional gain*/
	float32 IsMin_d; /*Minimum positive limit for stator current d-axis reference*/
	float32 IsMax_d; /*Maximum positive limit for stator current d-axis reference*/
} VC_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	VC_IN	i;
	VC_OUT 	o;
	VC_VAR	v;
	VC_PAR	p;
} VC;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define VC_IN_DEFAULTS  {0.0,0.0,0.0,0.0,0.0}
#define VC_OUT_DEFAULTS {0.0}
#define VC_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0}
#define VC_PAR_DEFAULTS {0,0.0,0.0,5.0,0.01,0.01,0.0,0.0}

/********** DEFINITON OF MACRO **********/
#define VC_MACRO(x)\
if (x.p.Enable == 1)\
{	\
/* Voltage feedback filter */\
	x.v.UsLPF = (1.0-x.p.T_Tusf)*x.v.UsLPF + x.p.T_Tusf*x.i.Us;\
\
/* Voltage error calculation */\
	x.v.UsErr = x.i.UsMax - x.v.UsLPF;\
\
/* Adaptive gain adjustment */\
    x.v.Ka = ( ABS(x.i.ws) > x.p.ws0 ) ? 1.0/(ABS(x.i.ws)*x.p.Lsig) : 1.0/(x.p.ws0*x.p.Lsig);\
\
/* Voltage controller */\
	/* Feed-forward calculation */\
    x.v.UvFF = ( SQR(x.i.UsMax*x.v.Ka) < SQR(x.i.Is_q) ) ? 0.0 : sqrt(SQR(x.i.UsMax*x.v.Ka) - SQR(x.i.Is_q)) - x.i.PsiR_d/x.p.Lsig;\
    /* Feed-forward clamping */\
    x.v.UvFF = CLAMP(x.v.UvFF, x.p.IsMin_d, x.p.IsMax_d);\
    /* PI compensator */\
	x.v.Uvi = x.v.Uvi + x.p.K*x.v.Ka*x.p.T_Tr*x.v.UsErr + x.p.T_Tr*(x.o.IsRef_d - x.v.Uv);\
	x.v.Uv = x.p.K*x.v.Ka*x.v.UsErr + x.v.Uvi + 0.0*x.v.UvFF;\
\
/* Limitation of voltage controller output */\
	x.o.IsRef_d = CLAMP(x.v.Uv, x.p.IsMin_d, x.p.IsMax_d);\
}\
else\
{\
/* x.p.Enable=0 then reset states and set outputs to zero */\
/* Outputs: */\
    x.o.IsRef_d = 0.0;\
/* States: */\
    x.v.UsLPF 	= 0.0;\
    x.v.Uvi 	= 0.0;\
}
// END OF MACRO DEFINITON

#endif // __VC_H__
