#ifndef __INVDEFS_H__
#define __INVDEFS_H__

/* Constants */
#define PI 		3.14159265358979			/* pi constant 	*/
#define SQRT3   1.73205080756888			/* sqrt(3) 		*/
#define SQRT3_2 0.866025403784439			/* sqrt(3)/2 	*/
#define ISQRT3	0.577350269189626			/* 1/sqrt(3) 	*/
#define TWO_THR 0.666666666666667 			/* 2/3 */
#define TWO_PI  0.63661977236				/* 2/pi */
#define FALSE (0)							/* FALSE = 0	*/
#define TRUE (!FALSE)						/* TRUE = 1		*/

/* Operations */
#define SQR(x) 	(x)*(x)						/* x^2 			*/
#define SIGN(x) ((float32) ((x) > 0.0) - ((x) < 0.0))	/* sign(x) 		*/
#define ABS(x)	(((x) < 0.0) ? -(x) : (x))	/* abs(x)		*/
#define DEADZONE(x, low, high) (((x) > (high)) ? (x) : (((x) < (low)) ? (x) : (0.0))) /* dead-zone */ 
#define CLAMP(x, low, high)  (((x) > (high)) ? (high) : (((x) < (low)) ? (low) : (x))) /* saturation */
#define CLAMPRATE(u, y_d, T, low, high) ((y_d) + CLAMP(((u)-(y_d)), (T)*(low), (T)*(high))) /*u:input, y_d:delayed output, T:sample time*/
#define MIN(a, b)  (((a) < (b)) ? (a) : (b))
#define MAX(a, b)  (((a) > (b)) ? (a) : (b))
#define LPF(u, y_d, wcT) (1.0-(wcT))*(y_d) + (wcT)*(u) /*u:filter input, y_d:delayed output, wcT:corner ang. freq. times sampling time*/
#define RELAY(u, y_d, onVal, offVal) ( ((u) > (onVal)) ? TRUE : ( ((u) < (offVal)) ? FALSE : y_d ) ) /*hysteresis control: u:input, y_d:delayed output*/

#endif // __INVDEFS_H__
