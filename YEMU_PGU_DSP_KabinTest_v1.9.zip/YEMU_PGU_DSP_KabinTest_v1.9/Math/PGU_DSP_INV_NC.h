#ifndef __NC_H__
#define __NC_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 Udc; 		/*Measured DC bus voltage*/
	float32 Us_alpha; 	/*Stator reference voltage alpha-axis voltage*/
	float32 Us_beta; 	/*Stator reference voltage beta-axis voltage*/
	float32 signIs_a; 	/*Stator a-phase current*/
	float32 signIs_b; 	/*Stator b-phase current*/
	float32 signIs_c; 	/*Stator c-phase current*/
} NC_IN;
typedef struct 
{
	float32 Usn_alpha; 	/*Normalized stator voltage alpha-axis reference value*/
	float32 Usn_beta; 	/*Normalized stator voltage beta-axis reference value*/
} NC_OUT;
typedef struct 
{
	float32 dUs; 		/*Compensation factor*/
	float32 dUs_alpha; 	/*Compensation voltage alpha-axis value*/
	float32 dUs_beta; 	/*Compensation voltage beta-axis value*/
	float32 Usc_alpha; 	/*Compensated voltage alpha-axis value*/
	float32 Usc_beta; 	/*Compensated voltage beta-axis value*/
} NC_VAR;
typedef struct 
{
	Uint16 	Enable; 	/*Enable for inverter nonlinearity correction*/
	float32 Uth; 		/*Average threshold voltage of switching devices*/
	float32 fsw; 		/*Switching frequency*/
	float32 Tdt; 		/*Blanking time for switching devices*/
} NC_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	NC_IN	i;
	NC_OUT 	o;
	NC_VAR	v;
	NC_PAR	p;
} NC;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define NC_IN_DEFAULTS 	{0.0,0.0,0.0,0.0,0.0,0.0}
#define NC_OUT_DEFAULTS {0.0,0.0}
#define NC_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0}
#define NC_PAR_DEFAULTS {0,0.0,0.0,0.0}

/********** DEFINITON OF MACRO **********/
#define NC_MACRO(x)\
if (x.p.Enable == 1)\
{																					\
	/* Inverter nonlinearity compensation */										\
	x.v.dUs = TWO_THR*(x.p.Uth + x.p.Tdt*x.p.fsw*x.i.Udc);							\
	x.v.dUs_alpha = x.v.dUs*(x.i.signIs_a - 0.5*x.i.signIs_b - 0.5*x.i.signIs_c);	\
	x.v.dUs_beta  = x.v.dUs*SQRT3_2*(x.i.signIs_b - x.i.signIs_c);					\
	/*compensated phase voltage references*/										\
	x.v.Usc_alpha = x.i.Us_alpha + x.v.dUs_alpha;									\
	x.v.Usc_beta  = x.i.Us_beta  + x.v.dUs_beta;									\
																					\
	/* Reference signal generation for modulator */									\
	/* Warning: One should check UdcEst for minimum of its value */					\
	x.o.Usn_alpha = SQRT3/x.i.Udc*x.v.Usc_alpha;									\
	x.o.Usn_beta  = SQRT3/x.i.Udc*x.v.Usc_beta;										\
}																					\
else																				\
{																					\
	/*set outputs to zero*/															\
	x.o.Usn_alpha = 0.0;															\
	x.o.Usn_beta  = 0.0;															\
}
// END OF MACRO DEFINITON

#endif // __NC_H__
