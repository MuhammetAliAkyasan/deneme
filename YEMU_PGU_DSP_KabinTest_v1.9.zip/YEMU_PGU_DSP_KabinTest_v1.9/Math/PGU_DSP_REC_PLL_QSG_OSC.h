/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_pll.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	Oscillator macro for Single phase PLL module based on QSG
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_PLL_QSG_OSC_H_
#define PGU_DSP_REC_PLL_QSG_OSC_H_


typedef struct {
					float32  w_err;		// Input: 		Supply Frequency error in rad/s (PI controller output)
					float32  w_ff;		// Parameter: 	Supply Frequency in rad/s
					float32  w;			// Variable:  	Instantaneous Supply Frequency in rad/s (w_err + w_c)
					float32  Sine;	 	// Output:	 	Sin(Supply phase angle)
					float32  Cosine;	// Output: 		Cos(Supply phase angle)
					float32  Phase;		// Output: 		Supply phase angle
					float32  Freq;		// Output: 		Supply Frequency in Hz
					float32  Ts;		// Parameter: 	(Sampling Time)
					float32  M;			// Variable: 	Memory (integrator)
		 	 	} PLL_QSG_OSC;

/*-----------------------------------------------------------------------------
Default initializer for the PLL_QSG_OSC Object.
-----------------------------------------------------------------------------*/
#define PLL_QSG_OSC_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}

/*------------------------------------------------------------------------------
 	PLL_QSG_OSC Macro Definition
------------------------------------------------------------------------------*/
#define PLL_QSG_OSC_MACRO(v)														\
	v.w				=   v.w_err + v.w_ff;										\
	v.Freq			=	v.w * (0.159154943091895);     			/*1/(2*pi)*/ 	\
	v.M				=	v.M + (v.w * v.Ts);										\
	if (v.M > 6.28318530717959) 	v.M-=6.28318530717959; 						\
	v.Sine			=	sin(v.M);												\
	v.Cosine		=	cos(v.M);												\
	v.Phase			=	v.M + (v.Ts*2*PI*50);    // 2*pi*50*Ts = 0.041887902,   Ts = 1/7500

#endif /* PGU_DSP_REC_PLL_QSG_OSC_H_ */
