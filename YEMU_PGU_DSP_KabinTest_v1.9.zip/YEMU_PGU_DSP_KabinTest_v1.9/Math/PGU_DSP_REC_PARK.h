/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_park.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	Park Transformation module for Rectifier C files
Originator:
Note:
=====================================================================================*/

#ifndef PGU_DSP_REC_PARK_H_
#define PGU_DSP_REC_PARK_H_

typedef struct {
					float  Alpha;  		// Input: stationary d-axis stator variable
					float  Beta;	 	// Input: stationary q-axis stator variable
					float  Angle;		// Input: rotating angle (pu)
					float  Ds;			// Output: rotating d-axis stator variable
					float  Qs;			// Output: rotating q-axis stator variable
					float  Sine;
					float  Cosine;
		 	 	} PPARK;

//-----------------------------------------------------------------------------
//Default initalizer for the PPARK object.
//-----------------------------------------------------------------------------

#define PPARK_DEFAULTS { 	(0.0), 			\
							(0.0), 			\
							(0.0), 			\
							(0.0), 			\
							(0.0), 			\
							(0.0), 			\
							(0.0) }


/*------------------------------------------------------------------------------
	PARK Transformation Macro Definition
------------------------------------------------------------------------------*/

#define PPARK_MACRO(v)											\
																\
	v.Ds = v.Alpha * v.Cosine  + v.Beta  * v.Sine;				\
	v.Qs = v.Beta  * v.Cosine  - v.Alpha * v.Sine;




#endif /* PGU_DSP_REC_PARK_H_ */
