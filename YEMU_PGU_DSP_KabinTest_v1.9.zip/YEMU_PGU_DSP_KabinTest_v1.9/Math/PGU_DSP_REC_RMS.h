/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	RMS.h
Author: 		fozturk
Date:			22 May 2014
Description:	RMS module
Originator:
Note:
=====================================================================================*/

#ifndef PGU_DSP_REC_RMS_H_
#define PGU_DSP_REC_RMS_H_

typedef struct {
					float  In;  		// Input:
					float  Period;		// Input:
					float  RMS;			// Output:
					float  Ts;			// Parameter:
					float  Sum;			// Variable:
					Uint32 Count;		// Variable:
		 	 	} RMS;

//-----------------------------------------------------------------------------
//Default initalizer for the RMS object.
//-----------------------------------------------------------------------------

#define RMS_DEFAULTS { 	    (0.0), 			\
							(0.0), 			\
							(0.0), 			\
							(0.0),          \
		 	 				(0.0), 			\
		 	 				(0)           }


/*------------------------------------------------------------------------------
	RMS Macro Definition
------------------------------------------------------------------------------*/

#define RMS_MACRO(v)											\
	if((v.Count * v.Ts)< v.Period)								\
	{															\
		v.Sum = v.Sum + (v.In * v.In) * v.Ts;					\
		v.Count++;												\
	}															\
	else														\
	{															\
		v.RMS   = sqrt(v.Sum /(v.Count * v.Ts));				\
		v.Sum   = 0.0;											\
		v.Count = 0;											\
	}

#endif /* PGU_DSP_REC_RMS_H_ */
