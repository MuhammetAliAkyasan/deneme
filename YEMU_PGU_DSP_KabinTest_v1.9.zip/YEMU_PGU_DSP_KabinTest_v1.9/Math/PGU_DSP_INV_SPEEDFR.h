/* =================================================================================
File name:        SPEED_FR.H  
===================================================================================*/


#ifndef __SPEED_FR_H__
#define __SPEED_FR_H__

typedef struct {
       float32 ElecTheta;  		// Input: Electrical angle (pu) 
       Uint32  DirectionQep; 	// Variable: Direction of rotation (Q0) - independently with global Q
       float32 OldElecTheta;   	// History: Electrical angle at previous step (pu)
       float32 Speed;       	// Output: Speed in per-unit  (pu)
       float32 BaseRpm;      	// Parameter: Base speed in rpm (Q0) - independently with global Q
       float32 K1;         		// Parameter: Constant for differentiator (Q21) - independently with global Q
       float32 K2;         		// Parameter: Constant for low-pass filter (pu)
       float32 K3;         		// Parameter: Constant for low-pass filter (pu)
       int32   SpeedRpm;      	// Output : Speed in rpm  (Q0) - independently with global Q
       float32 Tmp;				//Variable: Temp variable
       } SPEED_MEAS_QEP;   		// Data type created

/*-----------------------------------------------------------------------------
Default initalizer for the SPEED_MEAS_QEP object.
-----------------------------------------------------------------------------*/                     
#define SPEED_MEAS_QEP_DEFAULTS   { 0, \
                                    1, \
                                    0, \
                                    0, \
                                    0, \
                                    0, \
                                    0, \
                                    0, \
                                    0, \
                                    0  \
                               	  }	

/*------------------------------------------------------------------------------
 SPEED_FR Macro Definition
------------------------------------------------------------------------------*/


#define SPEED_FR_MACRO(v)											\
/* Differentiator*/													\
/* Motor speed computation   		*/								\
   if ((v.ElecTheta < 0.9) && (v.ElecTheta > 0.1))					\
/* Q21 = Q21*(GLOBAL_Q-GLOBAL_Q)*/									\
		v.Tmp = v.K1 * (v.ElecTheta - v.OldElecTheta);				\
   else v.Tmp = v.Speed;											\
/* Low-pass filter*/												\
/* Q21 = GLOBAL_Q*Q21 + GLOBAL_Q*Q21*/								\
   	v.Tmp = v.K2*v.Speed + v.K3*v.Tmp;								\
/* Saturate the output */											\
	v.Tmp = (v.Tmp>3.0) ?   3.0 : v.Tmp;							\
	v.Tmp = (v.Tmp<-3.0) ? -3.0 : v.Tmp;							\
	v.Speed = v.Tmp;												\
/* Update the electrical angle */									\
    v.OldElecTheta = v.ElecTheta;									\
/* Change motor speed from pu value to rpm value (GLOBAL_Q -> Q0)*/	\
/* Q0 = Q0*GLOBAL_Q => _IQXmpy(), X = GLOBAL_Q*/					\
    v.SpeedRpm = v.BaseRpm*v.Speed;									\

#endif // __SPEED_FR_H__
