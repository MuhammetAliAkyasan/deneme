/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_resonant2.h
Author: 		fozturk
Date:			05 Ara 2012
Description:	Resonant controller module for Rectifier control loops
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_RESONANT3_H_
#define PGU_DSP_REC_RESONANT3_H_


typedef struct {
					float32 	In	;   		// Variable :   One step forward (Summation)
					float32 	Out	;			// Output: 		PR output
					Uint16		Enable;			// Parameter:	Enable for resonant controller
				  	float32 	M[2];			// Variable:	History vector
				  	float32		A[3];			// Parameter:	Coefficients
				  	float32		B[3];			// Parameter:	Coefficients
				  	float32     Error;          // Input:       Actual input signal to controller
                } RESONANT3;

/*-----------------------------------------------------------------------------
Default initializer for the RESONANT3 Object.
-----------------------------------------------------------------------------*/
#define RESONANT3_DEFAULTS {0.0,0.0,                            \
                            0,                                  \
                            0.0,0.0,                            \
                            0.0,0.0,0.0,                        \
                            0.0,0.0,0.0,0.0 }

/*------------------------------------------------------------------------------
 	RESONANT3 Macro Definition (260 ns)
------------------------------------------------------------------------------*/
#define RESONANT3_MACRO(v)											\
if (v.Enable == 1)													\
{																	\
    v.In        = v.Error + (v.M[0]*(v.B[1])) +  (v.M[1]*(v.B[2]));  \
    v.Out		=	(v.In*(v.A[0])) 								\
					+(v.M[0]*(v.A[1]))								\
					+(v.M[1]*(v.A[2]));								\
	v.M[1]		=	v.M[0];											\
	v.M[0]		=	v.In;											\
}																	\
else																\
{	                                                                \
    v.In        =   0.0;                                            \
	v.Out		=	0.0;											\
	v.M[1]		=	0.0;											\
	v.M[0]		=	0.0;											\
}


#endif /* PGU_DSP_REC_RESONANT3_H_ */
