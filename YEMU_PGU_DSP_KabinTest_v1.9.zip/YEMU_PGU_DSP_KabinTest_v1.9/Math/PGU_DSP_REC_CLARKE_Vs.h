/* =================================================================================
File name:       CLARKE.H  
===================================================================================*/


#ifndef __CLARKE_Vs_H__
#define __CLARKE_Vs_H__

typedef struct {  float32  Vs_a;  		// Input: phase-a stator variable
				  float32  Vs_b;		// Input: phase-b stator variable
				  float32  Vs_c;		// Input: phase-c stator variable
				  float32  Vs_alpha;	// Output: stationary axis stator variable
				  float32  Vs_beta;		// Output: stationary axis stator variable
		 	 	} CLARKE_Vs;

/*-----------------------------------------------------------------------------
	Default initalizer for the CLARKE object.
-----------------------------------------------------------------------------*/                     
#define CLARKE_Vs_DEFAULTS { 0.0, \
                          0.0, \
                          0.0, \
                          0.0, \
                          0.0, \
              			} 

/*------------------------------------------------------------------------------
	CLARKE Transformation Macro Definition
------------------------------------------------------------------------------*/
	
#define CLARKE_MACRO_Vs(x)											\
																\
x.Vs_alpha = TWO_THR*(x.Vs_a - 0.5*x.Vs_b - 0.5*x.Vs_c);		\
x.Vs_beta  = TWO_THR*SQRT3_2*(x.Vs_b - x.Vs_c);					\

#endif // __CLARKE_H__

