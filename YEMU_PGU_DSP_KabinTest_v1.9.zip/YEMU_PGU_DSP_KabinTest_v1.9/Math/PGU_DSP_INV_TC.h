#ifndef __TC_H__
#define __TC_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 TeRef; /*Reference torque*/
	float32 PsiR; /*Rotor flux d-axis value in field coordinates*/
	float32 PsiS_d; /*Stator flux d-axis value in field coordinates*/
	float32 PsiS_q; /*Stator flux q-axis value in field coordinates*/
	float32 IsRef_d; /*Stator current d-axis reference value in field coordinates*/
} TC_IN;
typedef struct 
{
	float32 IsRef_q; /*Stator current q-axis reference value in field coordinates*/
} TC_OUT;
typedef struct 
{
	float32 IsLimC_q; /*Stator current q-axis limit due to stator current limitation*/
	float32 IsLimV_q; /*Stator current q-axis limit due to stator voltage limitation*/
} TC_VAR;
typedef struct 
{
	Uint16 Enable; /*Enable for torque controller*/
	float32 Ks; /*Safety factor for breakdown slip*/
	float32 Lsig; /*Total leakage inductance referred to stator*/
    float32 Lm; /*Magnetizing inductance*/
    float32 Lr; /*Rotor inductance*/
	float32 p; /*Number of pole pairs*/
	float32 IsMax; /*Maximum stator phase current*/
	float32 IsMax_d; /*Maximum positive limit for stator current d-axis reference*/
	float32 PsiRMin; /*Minimum rotor flux magnitude for torque reference genetation*/
} TC_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	TC_IN	i;
	TC_OUT 	o;
	TC_VAR	v;
	TC_PAR	p;
} TC;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define TC_IN_DEFAULTS {0.0,0.0,0.0,0.0,0.0}
#define TC_OUT_DEFAULTS {0.0}
#define TC_VAR_DEFAULTS {0.0,0.0}
#define TC_PAR_DEFAULTS {0,0.9,0.050,0.065,0.068,3.0,0.0,0.0,0.1}

/********** DEFINITON OF MACRO **********/
#define TC_MACRO(x)\
/* Torque Controller (Warning! Place first voltage controller on the main code) */\
if (x.p.Enable == 1)\
{\
/* Torque Controller */\
	if (x.i.PsiS_d != 0.0)\
	{\
		if(x.i.IsRef_d<x.p.IsMax_d)\
		{\
			x.o.IsRef_q = (( x.i.TeRef/(1.5*x.p.p) + x.i.PsiS_q*x.i.IsRef_d )/x.i.PsiS_d);\
		}\
		else\
		{\
	        x.o.IsRef_q =SIGN(x.i.TeRef)*MAX(ABS(( x.i.TeRef/(1.5*x.p.p) + x.i.PsiS_q*x.i.IsRef_d )/x.i.PsiS_d),ABS(x.i.TeRef/(1.5*x.p.p*x.i.IsRef_d*(x.p.Lm*x.p.Lm/x.p.Lr))));\
		}\
	}\
    else\
        x.o.IsRef_q = 0.0;\
        \
    if (x.i.PsiR < x.p.PsiRMin)\
    	x.o.IsRef_q = 0.0;\
        \
/* Limitation of q-axis current reference */\
	x.v.IsLimC_q = sqrt(SQR(x.p.IsMax) - SQR(x.i.IsRef_d));\
	x.v.IsLimV_q = ABS(x.p.Ks*x.i.PsiR/x.p.Lsig);\
    if (ABS(x.o.IsRef_q) > x.v.IsLimC_q)\
		x.o.IsRef_q = SIGN(x.o.IsRef_q)*x.v.IsLimC_q;\
	if (ABS(x.o.IsRef_q) > x.v.IsLimV_q)\
        x.o.IsRef_q = SIGN(x.o.IsRef_q)*x.v.IsLimV_q;\
}\
else\
{\
/* Outputs */\
    x.o.IsRef_q = 0.0;\
}
// END OF MACRO DEFINITON

#endif // __TC_H__
