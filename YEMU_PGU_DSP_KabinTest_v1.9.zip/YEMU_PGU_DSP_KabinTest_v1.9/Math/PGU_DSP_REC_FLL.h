/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_QSG.h
Author: 		fozturk
Date:			25 OCA 2013
Description:	Frequency Locked Loop
Originator:
Note:
=====================================================================================*/

#ifndef PGU_DSP_REC_FLL_H_
#define PGU_DSP_REC_FLL_H_

typedef struct {
					float32 	QSG_Err;   		// Input: 		Quadrature Signal G. Error
					float32  	QSG_Beta;       // Input: 		Beta component of Quadrature Signal G.
					float32   	VsPeak;			// Input: 		Input voltage peak value
					float32		w;				// Output:		Estimated Grid Frequency in rad/s
					float32		wPreSat;		// Variable:    Pre-Saturated grid frequency
					float32		wSatErr;		// Variable:	Saturated difference
					float32		kwg;			// Parameter:	Gain normalization constant (k*w_ff*Gamma) Gamma = -50 for 50 Hz
					float32		w_ff;			// Parameter: 	Grid Center Frequency in rad/s
					float32		w_max;			// Parameter: 	Maximum Grid Frequency in rad/s
					float32		w_min;			// Parameter: 	Minimum Grid Frequency in rad/s
					float32   	VsPeakSqr;		// Variable: 	Square of Peak value
					float32 	w_Err;			// Variable: 	Error in Grid frequency
					float32  	w_ErrInteg;		// Variable: 	Integrated Error in Grid frequency
					float32		VsPeakSqrMin;	// Parameter: 	Square of Peak value (Minimum)
					float32		VsPeakSqrMax;	// Parameter: 	Square of Peak value (Maximum)
				  	float32 	Ts;				// Parameter:	Sampling Time
				  	Uint16		Enable;			// Parameter: 	Enable for frequency estimation
		 	 	} FLL;

/*-----------------------------------------------------------------------------
Default initializer for the FLL Object.
-----------------------------------------------------------------------------*/
#define FLL_DEFAULTS {	0.0,0.0,0.0,0.0,0.0,			\
						0.0,0.0,0.0,0.0,0.0,			\
						0.0,0.0,0.0,0.0,0.0,0.0,		\
						0}

/*------------------------------------------------------------------------------
	FLL Macro Definition
------------------------------------------------------------------------------*/
#define FLL_MACRO(v)													\
if (v.Enable == 1)													\
{																	\
	v.VsPeakSqr = v.VsPeak * v.VsPeak;								\
	v.VsPeakSqr = sat(v.VsPeakSqr,v.VsPeakSqrMax,v.VsPeakSqrMin);	\
	v.w_Err 	= (v.kwg/v.VsPeakSqr)* v.QSG_Beta * v.QSG_Err;		\
	v.w_ErrInteg= v.w_ErrInteg + (v.w_Err * v.Ts);					\
	v.wPreSat	= v.w_ErrInteg + v.w_ff;							\
	v.w			= sat(v.wPreSat,v.w_max,v.w_min);					\
	v.wSatErr	= v.w - v.wPreSat;									\
}																	\
else																\
{																	\
	v.w_ErrInteg = 0.0;												\
	v.w			 = v.w_ff;											\
}


#endif /* PGU_DSP_REC_FLL_H_ */
