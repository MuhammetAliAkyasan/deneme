#ifndef __CC_H__
#define __CC_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 IsRef_d; /*Stator current d-axis reference value in field coordinates*/
	float32 IsRef_q; /*Stator current q-axis reference value in field coordinates*/
	float32 Is_d; /*Stator current d-axis value in field coordinates*/
	float32 Is_q; /*Stator current q-axis value in field coordinates*/
	float32 UsMax; /*Maximum avaliable stator voltage vector magnitude*/
	float32 PsiR_d; /*Rotor flux d-axis value in field coordinates: krPsiR_d*/
	float32 ws; /*Angular frequency of rotor flux vector*/
} CC_IN;
typedef struct 
{
	float32 Usr_d; /*Stator voltage d-axis reference value in field coordinates*/
	float32 Usr_q; /*Stator voltage q-axis reference value in field coordinates*/
	float32 Us_d; /*Stator voltage d-axis unsaturated reference value in field coordinates*/
	float32 Us_q; /*Stator voltage q-axis unsaturated reference value in field coordinates*/
	float32 Us; /*Stator voltage vector magnitude*/
	Uint16 SatFlg; /*Current controller saturation flag*/
} CC_OUT;
typedef struct 
{
	float32 IsErr_d; /*Stator current error d-axis value in field coordinates*/
	float32 IsErr_q; /*Stator current error q-axis value in field coordinates*/
	float32 IsErrD_d; /*Delayed stator current error d-axis value in field coordinates*/
	float32 IsErrD_q; /*Delayed stator current error q-axis value in field coordinates*/
	float32 Ysr_d; /*Rectified (delay compensated) current error d-axis value*/
	float32 Ysr_q; /*Rectified (delay compensated) current error q-axis value*/
	float32 YsrD_d; /*Delayed rectified current error d-axis value*/
	float32 YsrD_q; /*Delayed rectified current error q-axis value*/
	float32 Xst_d; /*Internal state of tracking in d-axis*/
	float32 Xst_q; /*Internal state of tracking in q-axis*/
	float32 Yst_d; /*Transient compensation voltage in d-axis*/
	float32 Yst_q; /*Transient compensation voltage in q-axis*/
	float32 Ysc_d; /*Coupling compensation voltage in d-axis*/
	float32 Ysc_q; /*Coupling compensation voltage in q-axis*/
	float32 Yse_d; /*EMF compensation voltage in d-axis*/
	float32 Yse_q; /*EMF compensation voltage in q-axis*/
	float32 Ysa_d; /*Active damping voltage in d-axis*/
	float32 Ysa_q; /*Active damping voltage in q-axis*/
} CC_VAR;
typedef struct 
{
	Uint16 Enable; /*Enable for current controller*/
	float32 T; /*Sample time in seconds*/
	float32 T_Td; /*T/Td, Td: delay time. Approx.: 1.5T*/
	float32 T_Tdp; /*T/Tdp, Tdp: modified delay time*/
	float32 Tdp_Td; /*Tdp/Td*/
	float32 T_Tsigp; /*T/Tsigp, Tsigp: modified stator transient time constant*/
	float32 KRsigpT; /*K*Rsigp*T, K: proportional gain of controller; Rsigp: modified total resistance*/
	float32 KRsigpTsigp; /*K*Rsigp*Tsigp*/
	float32 Ra; /*Active damping resistance*/
} CC_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	CC_IN	i;
	CC_OUT 	o;
	CC_VAR	v;
	CC_PAR	p;
} CC;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define CC_IN_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0,0.0}
#define CC_OUT_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0}
#define CC_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}
#define CC_PAR_DEFAULTS {0,0.001,0.0,0.0,0.0,0.0,0.0,0.0,0.0}

/********** DEFINITON OF MACRO **********/
#define CC_MACRO(x)\
if (x.p.Enable == 1)\
{\
/* Error calculation */\
	x.v.IsErr_d = x.i.IsRef_d - x.i.Is_d;\
	x.v.IsErr_q = x.i.IsRef_q - x.i.Is_q;\
\
/* Controller output calculation */\
	/* Ysr: rectified (delay compensated) current error vector 	*/\
	x.v.Ysr_d = (1.0-x.p.T_Td)*x.v.Ysr_d + x.p.Tdp_Td*(x.v.IsErr_d - (1.0-x.p.T_Tdp)*x.v.IsErrD_d -         x.i.ws*x.p.T*x.v.IsErrD_q);\
	x.v.Ysr_q = (1.0-x.p.T_Td)*x.v.Ysr_q + x.p.Tdp_Td*(x.v.IsErr_q +         x.i.ws*x.p.T*x.v.IsErrD_d - (1.0-x.p.T_Tdp)*x.v.IsErrD_q);\
\
	/* Xst: internal state of tracking */\
	x.v.Xst_d = x.v.Xst_d + x.p.KRsigpT*x.v.YsrD_d + x.p.T_Tsigp*(x.o.Usr_d - x.o.Us_d);\
	x.v.Xst_q = x.v.Xst_q + x.p.KRsigpT*x.v.YsrD_q + x.p.T_Tsigp*(x.o.Usr_q - x.o.Us_q);\
\
	/* Yst: transient compensation voltage */ \
	x.v.Yst_d = x.v.Xst_d + x.p.KRsigpTsigp*x.v.Ysr_d;\
	x.v.Yst_q = x.v.Xst_q + x.p.KRsigpTsigp*x.v.Ysr_q;\
\
	/* Ysc: coupling compensation voltage */ \
	x.v.Ysc_d = x.v.Ysc_d - x.p.KRsigpTsigp*x.i.ws*x.p.T*x.v.YsrD_q;\
	x.v.Ysc_q = x.v.Ysc_q + x.p.KRsigpTsigp*x.i.ws*x.p.T*x.v.YsrD_d;\
\
	/* Yse: emf compensation voltage */\
    x.v.Yse_d = 0.0;\
    x.v.Yse_q = x.i.ws*x.i.PsiR_d;\
	\
	/* Ysa: active damping voltage */\
	x.v.Ysa_d = x.p.Ra*x.i.Is_d;\
	x.v.Ysa_q = x.p.Ra*x.i.Is_q;\
	\
	/* x.o.Us: Voltage vector construction */\
	x.o.Us_d = x.v.Yst_d + x.v.Ysc_d + x.v.Yse_d - x.v.Ysa_d;\
	x.o.Us_q = x.v.Yst_q + x.v.Ysc_q + x.v.Yse_q - x.v.Ysa_q;\
	\
/* Limitation of voltage vector: minimum magnitude error */\
	/* Magnitude calculation */\
	x.o.Us = sqrt( SQR(x.o.Us_d) + SQR(x.o.Us_q) );\
    if ( x.o.Us > x.i.UsMax )\
	{\
		x.o.SatFlg = 1;\
		x.o.Usr_d = x.o.Us_d*x.i.UsMax/x.o.Us;\
		x.o.Usr_q = x.o.Us_q*x.i.UsMax/x.o.Us;\
	}\
	else\
	{\
		x.o.SatFlg = 0;\
		x.o.Usr_d = x.o.Us_d;\
		x.o.Usr_q = x.o.Us_q;\
    }\
/* Delayed variable assignments */\
    x.v.IsErrD_d = x.v.IsErr_d;\
	x.v.IsErrD_q = x.v.IsErr_q;\
	\
    x.v.YsrD_d = x.v.Ysr_d; \
	x.v.YsrD_q = x.v.Ysr_q;\
}\
else\
{\
/* x.p.Enable=0 then reset states and set outputs to zero */\
/* States */\
       x.v.Ysr_d = 0.0;      x.v.Ysr_q = 0.0;\
    x.v.IsErrD_d = 0.0;   x.v.IsErrD_q = 0.0; \
       x.v.Xst_d = 0.0;      x.v.Xst_q = 0.0;\
      x.v.YsrD_d = 0.0;     x.v.YsrD_q = 0.0;\
       x.v.Ysc_d = 0.0;      x.v.Ysc_q = 0.0;\
/* Outputs */\
       x.o.Usr_d = 0.0;      x.o.Usr_q = 0.0;\
        x.o.Us_d = 0.0;       x.o.Us_q = 0.0; \
          x.o.Us = 0.0;     x.o.SatFlg = 0;\
}
// END OF MACRO DEFINITON

#endif // __CC_H__
