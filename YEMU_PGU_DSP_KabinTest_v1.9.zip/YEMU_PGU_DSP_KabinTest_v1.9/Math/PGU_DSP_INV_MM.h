#ifndef __MM_H__
#define __MM_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 Us_a; /*Stator voltage alpha-axis reference value*/
	float32 Us_b; /*Stator voltage beta-axis reference value*/
	float32 w; /*Angular frequency of rotor */
} MM_IN;
typedef struct 
{
	float32 Is_a; /*Stator current alpha-axis value*/
	float32 Is_b; /*Stator current beta-axis value*/
	float32 krPsiR_a; /*Scaled rotor flux alpha-axis value*/
	float32 krPsiR_b; /*Scaled rotor flux beta-axis value*/
	float32 PsiS_a; /*Stator flux alpha-axis value*/
	float32 PsiS_b; /*Stator flux beta-axis value*/
} MM_OUT;
typedef struct 
{
	float32 Im_a; /*Pseudo-magnetizing current alpha-axis value*/
	float32 Im_b; /*Pseudo-magnetizing current beta-axis value*/
	float32 Es_a; /*Back EMF voltage alpha-axis value*/
	float32 Es_b; /*Back EMF voltage beta-axis value*/
	float32 Ut_a; /*Difference voltage alpha-axis value*/
	float32 Ut_b; /*Difference voltage beta-axis value*/
} MM_VAR;
typedef struct 
{
	Uint16 Enable; /*Enable for motor model*/
	float32 T; /*Sample time in seconds*/
	float32 Rsig; /*Equivalent motor resistance*/
	float32 Tr; /*Rotor time constant in seconds*/
	float32 Lsig; /*Total leakage inductance referred to stator*/
	float32 Lsigp; /*Pseudo-magnetizing inductance*/
} MM_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	MM_IN	i;
	MM_OUT 	o;
	MM_VAR	v;
	MM_PAR	p;
} MM;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define MM_IN_DEFAULTS {0.0,0.0,0.0}
#define MM_OUT_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0}
#define MM_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0}
#define MM_PAR_DEFAULTS {0,0.001,0.1,0.1,0.001,0.01}

/********** DEFINITON OF MACRO **********/
#define MM_MACRO(x)\
if (x.p.Enable == 1) \
{ \
	/* Im(k+1) = (1-T/Tr+jwT)*Im(k) + T/Tr*Is(k) */ \
	x.v.Im_a = (1.0-x.p.T/x.p.Tr)*x.v.Im_a         -x.i.w*x.p.T*x.v.Im_b + x.p.T/x.p.Tr*x.o.Is_a; \
	x.v.Im_b = 	      x.i.w*x.p.T*x.v.Im_a + (1.0-x.p.T/x.p.Tr)*x.v.Im_b + x.p.T/x.p.Tr*x.o.Is_b; \
	/* Ut(k) = Us(k)+Es(k) */ \
	x.v.Ut_a = x.i.Us_a + x.v.Es_a; \
	x.v.Ut_b = x.i.Us_b + x.v.Es_b; \
	/* Is(k+1) = (1-x.p.T/x.p.Tsig)*Is(k) + x.p.T/x.p.Tsig*Ut(k)/Rsig */ \
	x.o.Is_a = (1.0-x.p.T/x.p.Lsig*x.p.Rsig)*x.o.Is_a + x.p.T/x.p.Lsig*x.v.Ut_a; \
	x.o.Is_b = (1.0-x.p.T/x.p.Lsig*x.p.Rsig)*x.o.Is_b + x.p.T/x.p.Lsig*x.v.Ut_b; \
	/* krPsiR(k+1) = x.p.Lsigp*Im(k+1) */ \
	x.o.krPsiR_a = x.p.Lsigp*x.v.Im_a; \
	x.o.krPsiR_b = x.p.Lsigp*x.v.Im_b; \
	/* PsiS(k+1) = krPsiR(k+1) + x.p.Lsig*Is(k+1) */ \
	x.o.PsiS_a = x.o.krPsiR_a + x.p.Lsig*x.o.Is_a; \
	x.o.PsiS_b = x.o.krPsiR_b + x.p.Lsig*x.o.Is_b; \
	/* Es(k+1) =  (-1/x.p.Tr+jx.i.w)*krPsiR(k+1) */ \
	x.v.Es_a = -1.0/x.p.Tr*x.o.krPsiR_a      -x.i.w*x.o.krPsiR_b; \
	x.v.Es_b =       x.i.w*x.o.krPsiR_a -1.0/x.p.Tr*x.o.krPsiR_b; \
} \
else \
{ \
	x.o.Is_a = 0.0; \
	x.o.Is_b = 0.0; \
	x.v.Im_a = 0.0; \
	x.v.Im_b = 0.0; \
}
// END OF MACRO DEFINITON

#endif // __MM_H__
