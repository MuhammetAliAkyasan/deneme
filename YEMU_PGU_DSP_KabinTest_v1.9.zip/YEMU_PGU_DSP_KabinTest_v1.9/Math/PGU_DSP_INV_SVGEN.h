/* =================================================================================
File name:       SVGEN.H  
===================================================================================*/


#ifndef __SVGEN_H__
#define __SVGEN_H__

typedef struct 	{ float32  Usn_alpha; 		// Input: reference alpha-axis phase voltage 
				  float32  Usn_beta;		// Input: reference beta-axis phase voltage 
				  float32  Ta;				// Output: reference phase-a switching function		
				  float32  Tb;				// Output: reference phase-b switching function 
				  float32  Tc;				// Output: reference phase-c switching function
				  float32  Ux;				// Variable: temp variable
				  float32  Uy;				// Variable: temp variable
				  float32  Uz;				// Variable: temp variable
				  Uint16 VecSector;			// Space vector sector
				} SVGEN;
																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				

/*-----------------------------------------------------------------------------
Default initalizer for the SVGEN object.
-----------------------------------------------------------------------------*/                     
#define SVGEN_DEFAULTS { 0,0,0,0,0 }                       

/*------------------------------------------------------------------------------
	Space Vector  Generator (SVGEN) Macro Definition
------------------------------------------------------------------------------*/


#define SVGEN_MACRO(x)														\
	x.Ux= x.Usn_beta;														\
	x.Uy= 0.5*x.Usn_beta + (SQRT3_2*x.Usn_alpha);							\
    x.Uz= x.Uy - x.Ux;														\
																			\
	x.VecSector=3;															\
	x.VecSector=(x.Uy> 0)?( x.VecSector-1):x.VecSector;						\
	x.VecSector=(x.Uz> 0)?( x.VecSector-1):x.VecSector;						\
	x.VecSector=(x.Ux< 0)?(7-x.VecSector) :x.VecSector;						\
																			\
	if     (x.VecSector==1 || x.VecSector==4)                               \
      {     x.Ta= x.Uy; 													\
      		x.Tb= x.Ux-x.Uz; 												\
      		x.Tc=-x.Uy;														\
      }								    									\
   																			\
    else if(x.VecSector==2 || x.VecSector==5)                               \
      {     x.Ta= x.Uz+x.Uy; 												\
      		x.Tb= x.Ux; 													\
      		x.Tc=-x.Ux;														\
      }																		\
   																			\
    else                                                                    \
      {     x.Ta= x.Uz; 													\
      		x.Tb=-x.Uz; 													\
      		x.Tc=-(x.Ux+x.Uy);												\
      }
#endif // __SVGEN_H__
