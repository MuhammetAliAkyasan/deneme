#ifndef __AG_H__
#define __AG_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 Theta;/* Output: Angle output */
	float32 Alpha;/* Variable: Internal angle */
	float32 f;/* Input: Reference frequency in hertz */
	float32 T;/* Parameter: Sample time in seconds*/
	float32  Direction; /* Input: Reference direction */
	Uint16 Enable;
} AG;

/********** DEFAULT VALUES FOR STRUCT **********/
#define AG_DEFAULTS {0.0,0.0,0.0,0.0,1,0}

/********** DEFINITON OF MACRO **********/
#define AG_MACRO(x)\
if(x.Enable == 1)\
{\
	/*Angle generator module */ \
	x.Alpha = x.Alpha + SIGN(x.Direction)*2.0*PI*x.T*x.f; \
	x.Alpha = (x.Alpha > 2.0*PI) ? x.Alpha-2.0*PI : x.Alpha; \
	x.Alpha = (x.Alpha < -2.0*PI) ? x.Alpha+2.0*PI : x.Alpha; \
	x.Theta = x.Alpha;\
	if(x.Direction < 0)\
		x.Theta = x.Alpha+4.0*PI;\
}\
else\
{\
	x.Alpha = 0.0;\
	x.Theta = 0.0;\
}
// END OF MACRO DEFINITON

#endif // __AG_H__
