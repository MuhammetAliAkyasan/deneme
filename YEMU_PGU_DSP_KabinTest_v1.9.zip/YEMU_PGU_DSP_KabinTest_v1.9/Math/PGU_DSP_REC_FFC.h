/*
 * PGU_DSP_REC_FFC.h
 *
 *  Created on: 25 Oca 2013
 *      Author: fozturk
 */

#ifndef PGU_DSP_REC_FFC_H_
#define PGU_DSP_REC_FFC_H_

/********** DECLARATION OF STRUCTS **********/
typedef struct {
					float32  	Is;  		// Input:		Secondary current
					float32  	IsRefVCp;  	// Input:		Reference Secondary current (Peak value)
					float32  	VsPhase;  	// Input:		Instantaneous Phase angle of Suplly
					float32		VsPeak;		// Input:		Secondary voltage Peak value
					float32  	Is_ff;  	// Input:		Secondary current feedforward
					float32		VsHarm;		// Input:		Sum of Harmonic components of Secondary voltage
				} FFC_IN;


typedef struct {
					float32 	Vf;			// Output:	    Compansating total secondary voltage for delayless feed-forward
					float32  	IsErr;		// Output:		Secondary current error
				} FFC_OUT;

typedef struct {
					float32  	IsRef;		// Variable:	Secondary current phasor type
					float32		IsRefSump;	// Variable:	Sum of Reference Secondary current (Peakvalue)
					float32		Vs_ff;		// Variable:	Compansating Secondary voltage
					float32 	VsSin_ff;	// Variable:	PLL reference unit cosine(wt + ff)
					float32 	VsCos_ff;	// Variable:	PLL reference unit cosine(wt + ff)
					float32 	VLs_ff;		// Variable:	Compansating inductance voltage for delayless feed-forward
					float32		VRs_ff;		// Variable:    Compansating resistance voltage for delayless feed-forward
				} FFC_VAR;

typedef struct {
					float32		Theta;		// Parameter:	Angle for delayless feed-forward compensation
					float32		wLs;		// Parameter:	Impedance of total secondary Inductance
					float32		R;			// Parameter:	Total secondary resistance
				} FFC_PAR;


/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	FFC_IN	i;
	FFC_OUT o;
	FFC_VAR	v;
	FFC_PAR	p;
} FFC;



/********** DEFAULT VALUES FOR STRUCTS **********/
#define FFC_IN_DEFAULTS  {0.0,0.0,0.0,0.0,0.0,0.0}
#define FFC_OUT_DEFAULTS {0.0,0.0}
#define FFC_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0,0.0}
#define FFC_PAR_DEFAULTS {0.0,0.0,0.0}


/********** DEFINITON OF MACRO **********/
#define FFC_MACRO(x)															\
	x.v.IsRefSump 	=   x.i.IsRefVCp 	+ x.i.Is_ff;							\
	x.v.IsRef	 	=   x.v.IsRefSump 	* sin(x.i.VsPhase);						\
	x.o.IsErr		=	x.v.IsRef  	- x.i.Is;									\
	x.v.VsSin_ff	=	sin(x.i.VsPhase + x.p.Theta);							\
	x.v.VsCos_ff	=	cos(x.i.VsPhase + x.p.Theta);							\
	x.v.Vs_ff		=	x.i.VsPeak 	* x.v.VsSin_ff;								\
	x.v.VLs_ff		= 	x.v.VsCos_ff	* (-x.p.wLs)*(x.v.IsRefSump);	/*w*L*/	\
	x.v.VRs_ff		=	x.v.IsRef 	* x.p.R;									\
	x.o.Vf			= 	x.v.Vs_ff 	+ x.v.VLs_ff + x.i.VsHarm - x.v.VRs_ff; /* */

#endif /* PGU_DSP_REC_FFC_H_ */
