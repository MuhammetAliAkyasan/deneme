/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_resonant2.h
Author: 		fozturk
Date:			05 Ara 2012
Description:	Resonant controller module for Rectifier control loops
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_RESONANT2_H_
#define PGU_DSP_REC_RESONANT2_H_


typedef struct {
					float32 	In	;   		// Input : 		PR input
					float32 	Out	;			// Output: 		PR output
					Uint16		Enable;			// Parameter:	Enable for resonant controller
				  	float32 	M[4];			// Variable:	History vector
				  	float32		A[3];			// Parameter:	Coefficients
				  	float32		B[3];			// Parameter:	Coefficients
		 	 	} RESONANT2;

/*-----------------------------------------------------------------------------
Default initializer for the RESONANT2 Object.
-----------------------------------------------------------------------------*/
#define RESONANT2_DEFAULTS {0.0,0.0,							\
		 	 				0,									\
		 	 				0.0,0.0,0.0,0.0,					\
		 	 				0.0,0.0,0.0,						\
		 	 				0.0,0.0,0.0	}

/*------------------------------------------------------------------------------
 	RESONANT2 Macro Definition (260 ns)
------------------------------------------------------------------------------*/
#define RESONANT2_MACRO(v)											\
if (v.Enable == 1)													\
{																	\
	v.Out		=	 (v.In*(v.A[0]))								\
					+(v.M[0]*(v.A[1]))								\
					+(v.M[1]*(v.A[2]))								\
					-(v.M[2]*(v.B[1]))								\
					-(v.M[3]*(v.B[2]));								\
	v.M[1]		=	v.M[0];											\
	v.M[0]		=	v.In;											\
	v.M[3]		=	v.M[2];											\
	v.M[2]		=	v.Out ;											\
}																	\
else																\
{																	\
	v.Out		=	0.0;											\
	v.M[1]		=	0.0;											\
	v.M[0]		=	0.0;											\
	v.M[3]		=	0.0;											\
	v.M[2]		=	0.0;											\
}


#endif /* PGU_DSP_REC_RESONANT2_H_ */
