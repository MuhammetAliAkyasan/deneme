/*
 * PGU_DSP_INV_DCRC.h
 *
 *  Created on: 20 May 2013
 *      Author: fozturk
 */

#ifndef PGU_DSP_INV_DCRC_H_
#define PGU_DSP_INV_DCRC_H_


/********** DECLARATION OF STRUCTS **********/
typedef struct
{
    float32 Udc; 		/*DC voltage measurement*/
    float32 Ur_alpha; 	/*DC ripple voltage alpha-axis value*/
    float32 Ur_beta; 	/*DC ripple voltage beta-axis value*/
    float32 we; 		/*DC ripple voltage angular frequency in rad/s*/
} DCRC_IN;
typedef struct
{
	float32 UdcEst; 	/*Estimated DC link voltage*/
} DCRC_OUT;
typedef struct
{
    float32 Ud; 	  	/*Average value of DC link voltage*/
    float32 Urc;      	/*Estimated DC link ripple voltage*/

} DCRC_VAR;
typedef struct
{
    Uint16  Enable;   	/*Enable for DC ripple compensation*/
    float32 Tadv;     	/*Advance time for estimation*/
    float32 Cterm;		/*Cosine Term*/
    float32 Sterm;		/*Sine Term*/
    float32 w;			/*DC ripple voltage angular frequency in rad/s*/
    float32 ThetaAdv; 	/*Advancing angle for ripple estimation*/
} DCRC_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
    DCRC_IN     i;
    DCRC_OUT    o;
    DCRC_VAR    v;
    DCRC_PAR    p;
} DCRC;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define DCRC_IN_DEFAULTS {0.0,0.0,0.0,0.0}
#define DCRC_OUT_DEFAULTS {0.0}
#define DCRC_VAR_DEFAULTS {0.0,0.0}
#define DCRC_PAR_DEFAULTS {0,0.0,0.0,0.0,0.0,0.0}

/********** DEFINITON OF MACRO **********/
#define DCMACRO(x)																	\
if (x.p.Enable == 1)																\
{																					\
        x.v.Ud = x.i.Udc - x.i.Ur_alpha;											\
        x.v.Urc = x.p.Cterm*x.i.Ur_alpha - (x.p.Sterm)*(x.i.we/x.p.w)*x.i.Ur_beta;	\
        x.o.UdcEst = x.v.Ud + x.v.Urc;												\
}																					\
else																				\
{																					\
	  x.o.UdcEst = x.i.Udc;															\
}
// END OF MACRO DEFINITON


#endif /* PGU_DSP_INV_DCRC_H_ */
