/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_pictrl.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	PI controller module for Rectifier control loops
Originator:
Note:
=====================================================================================*/

#ifndef PGU_DSP_REC_RECPI_H_
#define PGU_DSP_REC_RECPI_H_


typedef struct {
					float  Ref;   			// Input: Reference input
					float  Fdb;   			// Input: Feedback input
				}RECPI_IN;

typedef struct {
					float  Out;   			// Output: PI output
				}RECPI_OUT;
typedef struct {
					float  Err;				// Variable: Error
					float  Up;				// Variable: Proportional output
					float  Ui;				// Variable: Integral output
					float  OutPreSat; 		// Variable: Pre-saturated output
					float  SatErr;			// Variable: Saturated difference
					float  Up1;		   	    // Variable: History, Previous proportional output
				}RECPI_VAR;
typedef struct {
					Uint16 Enable;			//            Enable for duty generation
					float  Ki;			    // Parameter: Integral gain
					float  Kc;		     	// Parameter: Integral correction gain
					float  Kp;				// Parameter: Proportional gain
					float  OutMax;		    // Parameter: Maximum output
					float  OutMin;	    	// Parameter: Minimum output
		 	 	} RECPI_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	RECPI_IN	i;
	RECPI_OUT 	o;
	RECPI_VAR	v;
	RECPI_PAR	p;
} RECPI;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define RECPI_IN_DEFAULTS  {0.0,0.0}
#define RECPI_OUT_DEFAULTS {0.0}
#define RECPI_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0}
#define RECPI_PAR_DEFAULTS {0,0.0,0.0,0.0,0.0,0.0}

/*------------------------------------------------------------------------------
 	RECPI	 Macro Definition
------------------------------------------------------------------------------*/
#define RECPI_MACRO(x)																									\
if (x.p.Enable == 1)																									\
{																														\
	x.v.Err 		= 	x.i.Ref - x.i.Fdb; 									/* Compute the error */						\
	x.v.Up			= 	x.p.Kp * x.v.Err ;									/* Compute the proportional output */		\
	x.v.Ui			= 	x.v.Ui + (x.p.Ki * x.v.Up) + (x.p.Kc * x.v.SatErr);	/* Compute the integral output */			\
	x.v.OutPreSat	= 	x.v.Up + x.v.Ui;									/* Compute the pre-saturated output */		\
	x.o.Out 		= 	sat(x.v.OutPreSat, x.p.OutMax, x.p.OutMin);			/* Saturate the output */					\
	x.v.SatErr 		= 	x.o.Out - x.v.OutPreSat;							/* Compute the saturate difference */		\
	x.v.Up1 		= 	x.v.Up;												/* Update the previous proportional output*/\
}																									\
else																								\
{																									\
	x.v.Ui		=  0.0;																				\
	x.v.Up1		=  0.0;																				\
	x.o.Out		=  0.0;																				\
}


#endif /* PGU_DSP_REC_RECPI_H_ */
