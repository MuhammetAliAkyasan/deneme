/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_QSG.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	Quadrature Signal Generator (QSG) module based on SOGI
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_QSG_H_
#define PGU_DSP_REC_QSG_H_


typedef struct {
					float32 	In	;   		// Input:  Reference input
					float32   	wc;				// Input:  Center frequency
					float32 	Alpha;          // Output: Alpha component of Input
					float32  	Beta;           // Output: Beta component of Input
					float32  	Err_a;			// Output: Error (Input - Alpha)
					float32   	Err_a1;			// Variable: Error (Err_a * Gain)
					float32   	Err_b;			// Variable: Error (Err_a1 - Beta)
				  	float32 	M1[3];			// Variable: Memory vector for forward path integrator
				  	float32 	M2[3];			// Variable: Memory vector for backward path integrator
					float32 	Gain;			// Parameter: QSG gain
				  	float32 	Ts_12;			// Parameter: (Sampling Time)/12
		 	 	} QSG;

/*-----------------------------------------------------------------------------
Default initializer for the QSG Object.
-----------------------------------------------------------------------------*/
#define QSG_DEFAULTS { 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,			\
		 	 		   0.0,0.0,0.0,								\
		 	 		   0.0,0.0,0.0,								\
		 	 		   0.0}

/*------------------------------------------------------------------------------
 	QSG Macro Definition (460 ns)
------------------------------------------------------------------------------*/
#define QSG_MACRO(v)													\
	v.Alpha		= 	(v.M1[0] * 23) - (v.M1[1] * 16) + (v.M1[2] * 5) ;	\
	v.Beta		=	(v.M2[0] * 23) - (v.M2[1] * 16) + (v.M2[2] * 5) ;	\
	v.Err_a		= 	v.In - v.Alpha ;									\
	v.Err_a1	=	v.Err_a	 * v.Gain ;									\
	v.Err_b		=   v.Err_a1 - v.Beta ;									\
	v.M1[2]		=	v.M1[1];											\
	v.M1[1]		=	v.M1[0];											\
	v.M1[0]		=	v.M1[0] + ((v.Err_b * v.wc)* v.Ts_12);				\
	v.M2[2]		=	v.M2[1];											\
	v.M2[1]		=	v.M2[0];											\
	v.M2[0]		=	v.M2[0] + ((v.Alpha * v.wc)* v.Ts_12);


#endif /* PGU_DSP_REC_QSG_H_ */
