/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_pll2.h
Author: 		fozturk
Date:			22 Eyl 2012
Description:	Single phase PLL module
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_PLL_LS_H_
#define PGU_DSP_REC_PLL_LS_H_

typedef struct {
					float32  In;  			//	Input:		Input voltage
					float32	 PIcOut;		//  Input:		PI controller output for Frequency tracking
					float32  Vsest;			//	Variable:	Estimated voltage
					float32  Peak;			//  Output:		Peak value of input voltage
					float32  Sine;			//  Output:		Reference sine wave
					float32	 Phase;			//  Output:     Instantaneous phase angle
					float32  Phi;     		//	Variable:	Phase difference
					float32  Phiold;    	//	Variable:	Previous Phase angle
					float32  Phierr;    	//	Variable:	Change in Phase angle
					float32  Phierrold;		//	Variable:	Previous change in Phase angle
					float32  Error;			//	Variable:	Error between input voltage and estimated voltage
					float32  intg;			//  Variable:	Integrator for reference
					float32  Errlim;		//	Parameter:	Error limit
					float32  Ts;			//	Parameter:  Sampling time
					float32  ilamda;		//	Parameter:	1/lamda
					float32  wc;			//  Parameter:	Initial center frequency
					float32  w;				//	Variable:	Frequency (rad/sec)
					float32  r;				//
					float32  k[2];			//
					float32  h[2];			//	h[0]=cos(wt)  h[1]=sin(wt)
					float32  x[2];			//	x[0]=Ed(t(i)) x[1]=Eq(t(i))
					float32  p[2][2];		//
					float32  v[2];			//
					float32  z[2];			//
					float32  Pinit;			//  Initial value for P1-P4
					int16	 Counter;		//
					int16    Counterinit;	// 	Initial value for counter
					Uint16   Errnum;		//	Number of detected errors
					Uint16	 PIcEnable;		//  Enable of PI controller for Frequency tracking
		 	 	} PLL_LS;

/*-----------------------------------------------------------------------------
Default initializer for the PLL_LS Object.
-----------------------------------------------------------------------------*/
#define PLL_LS_DEFAULTS {	0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,		\
		 	 				0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,				\
		 	 				0.0,0.0,										\
		 	 				0.0,0.0,										\
		 	 				0.0,0.0,										\
		 	 				0.0,0.0,0.0,0.0,								\
		 	 				0.0,0.0,										\
		 	 				0.0,0.0,										\
		 	 				0.0,											\
		 	 				0,0,0,											\
		 	 				0 }
/*------------------------------------------------------------------------------
 	PLL_LS Macro Definition
------------------------------------------------------------------------------*/
#define PLL_LS_MACRO(t)												\
	t.w		=	t.wc + t.PIcOut;									\
	t.intg  =	t.intg + (t.w*t.Ts);							    \
	if (t.intg >=6.28318530717959) t.intg-=6.28318530717959;		\
	t.h[0]	=	sin(t.intg);										\
	t.h[1]	=	cos(t.intg);										\
	t.Vsest = 	(t.h[0]*t.x[0] + t.h[1]*t.x[1]) ;					\
	t.Error	= 	t.In - 	t.Vsest;									\
	if(fabs(t.Error)>t.Errlim)										\
	{																\
		t.p[0][0]=t.Pinit;											\
		t.p[0][1]=0.0;												\
		t.p[1][0]=0.0;												\
		t.p[1][1]=t.Pinit;											\
		t.Counter=t.Counterinit;									\
		t.Phierr= 0.0;												\
		t.Errnum++;													\
	}																\
 	else															\
 	{																\
 		if(t.Counter >= -1)											\
 		{t.Counter = t.Counter -1;}									\
 	}																\
	t.v[0]		=	(t.p[0][0]*t.h[0]) + (t.p[0][1]*t.h[1]) ;		\
	t.v[1]		=	(t.p[1][0]*t.h[0]) + (t.p[1][1]*t.h[1]) ;		\
	t.r			=	1.0 + (t.h[0]*t.v[0]) + (t.h[1]*t.v[1]) ;		\
	t.k[0]		=	(t.v[0] / t.r) ;								\
	t.k[1]		=	(t.v[1] / t.r) ;								\
	t.z[0]		=	(t.p[0][0]*t.h[0]) + (t.p[1][0]*t.h[1]) ;		\
	t.z[1]		=	(t.p[0][1]*t.h[0]) + (t.p[1][1]*t.h[1]) ;		\
	t.p[0][0]	=	(t.p[0][0]- t.k[0]*t.z[0])*t.ilamda ;			\
	t.p[0][1]	=	(t.p[0][1]- t.k[0]*t.z[1])*t.ilamda ;			\
	t.p[1][0]	=	(t.p[1][0]- t.k[1]*t.z[0])*t.ilamda ;			\
	t.p[1][1]	=	(t.p[1][1]- t.k[1]*t.z[1])*t.ilamda ;			\
	t.x[0]		= 	t.x[0] + t.k[0]*t.Error ;						\
	t.x[1]		=	t.x[1] + t.k[1]*t.Error ;						\
	t.Phi		=	atan2(t.x[1],t.x[0]);							\
	t.Peak		=   sqrt(t.x[0]*t.x[0] + t.x[1]*t.x[1]);			\
	t.Phase		=   t.intg + t.Phi;									\
	t.Sine		=	sin(t.Phase);									\
	if(t.Counter < 0)												\
	{																\
		if(t.Counter < -1)											\
		{															\
			t.Phierr= t.Phi-t.Phiold;								\
			if(fabs(t.Phierr)>1.5)									\
			{														\
				t.Phierr=t.Phierrold;								\
			}														\
			else													\
			{														\
				t.Phierrold = t.Phierr;								\
			}														\
			t.PIcEnable = 1;										\
		}															\
		t.Phiold	=	t.Phi;										\
	}																\
	else															\
	{																\
		t.PIcEnable = 0;											\
	}

#endif /* PGU_DSP_REC_PLL_LS_H_ */
