/* =================================================================================
File name:       IPARK.H   
===================================================================================*/

#ifndef __IPARK_H__
#define __IPARK_H__

typedef struct {  float32  Us_alpha;  	// Output: stationary Us_d-axis stator variable
				  float32  Us_beta;		// Output: stationary Us_q-axis stator variable
				  float32  Us_d;		// Input: rotating d-axis stator variable
				  float32  Us_q;		// Input: rotating q-axis stator variable
				  float32  sinTheta;	// Input: Sine term
				  float32  cosTheta;	// Input: Cosine term
		 	    } IPARK;	            

/*-----------------------------------------------------------------------------
Default initalizer for the IPARK object.
-----------------------------------------------------------------------------*/                     
#define IPARK_DEFAULTS {  0.0, \
                          0.0, \
                          0.0, \
                          0.0, \
						  0.0, \
                          0.0, \
              		   }

/*------------------------------------------------------------------------------
	Inverse PARK Transformation Macro Definition: exp(j*ws)
------------------------------------------------------------------------------*/


#define IPARK_MACRO(x)										\
															\
x.Us_alpha = x.cosTheta*x.Us_d - x.sinTheta*x.Us_q;			\
x.Us_beta  = x.sinTheta*x.Us_d + x.cosTheta*x.Us_q;			\

#endif // __IPARK_H__

