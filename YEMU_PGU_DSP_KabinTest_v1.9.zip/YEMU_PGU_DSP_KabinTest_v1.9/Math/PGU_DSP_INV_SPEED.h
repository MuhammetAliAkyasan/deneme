/*
 * PGU_DSP_INV_SPEED.h
 *
 *  Created on: 19 Mar 2013
 *      Author: AOB
 */

#ifndef PGU_DSP_INV_SPEED_H_
#define PGU_DSP_INV_SPEED_H_

//#include "f2833xbmsk.h"
//#include "f2833xdrvlib.h"


/*-----------------------------------------------------------------------------
Define the structure of the QEP (Quadrature Encoder) Driver Object
-----------------------------------------------------------------------------*/
typedef struct {float32 ElecTheta;   	// Output: Motor Electrical angle
				float32 OldElecTheta;   // History: Electrical angle at previous step
                Uint16  DirectionQep;   // Variable: Motor rotation direction
                int32   RawTheta;       // Variable: Raw angle from EQEP Postiion counter
                float32 MechScaler;     // Parameter: 1/total count
                Uint16  LineEncoder;    // Parameter: Number of line encoder
                Uint16  PolePairs;      // Parameter: Number of pole pairs
                float32 Tsample;		// Parameter: QEP Sampling Period
                float32	wc;				// Parameter: Low pass filter corner freq
                float32 SpeedRPM;      	// Output : Speed in rpm
                float32 ElecSpeed;		// Output : Electrical speed in rad/s
                float32 Tmp;			// History: Electrical speed at previous step
                }  SPEED;

/*-----------------------------------------------------------------------------
Default initializer for the QEP Object.
-----------------------------------------------------------------------------*/

#define SPEED_DEFAULTS { 0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0}


/*-----------------------------------------------------------------------------
	QEP Init and QEP Update Macro Definitions
-----------------------------------------------------------------------------*/


//
//#define QEP_INIT_MACRO(m,v)																		\
//																								\
//     (*eQEP[m]).QDECCTL.all = QDECCTL_INIT_STATE;												\
//     (*eQEP[m]).QEPCTL.all = QEPCTL_INIT_STATE;													\
//     (*eQEP[m]).QPOSCTL.all = QPOSCTL_INIT_STATE;												\
//     (*eQEP[m]).QUPRD = 1500000;		        	/* Unit Timer for 150Hz*/					\
//     (*eQEP[m]).QCAPCTL.all = QCAPCTL_INIT_STATE;												\
//     (*eQEP[m]).QPOSMAX = 4*v.LineEncoder;														\
//																								\



#define SPEED_MACRO(m,v)											\
																	\
/* Check the rotational direction */								\
	v.DirectionQep = (*eQEP[m]).QEPSTS.bit.QDF;						\
/* Check the position counter for EQEPx */							\
	v.RawTheta = (*eQEP[m]).QPOSCNT;								\
/* Compute the electrical angle (rad)  */							\
    v.ElecTheta = v.PolePairs*v.MechScaler*v.RawTheta;				\
    v.ElecTheta = (v.ElecTheta - floor(v.ElecTheta));				\
/* Motor speed computation   		*/								\
	v.Tmp = v.ElecTheta - v.OldElecTheta;							\
/* Compute the electrical speed (rad/s)  */							\
	if (v.Tmp < -0.5)												\
		v.Tmp = v.Tmp + 1.0;										\
	else if (v.Tmp > 0.5)											\
		v.Tmp = v.Tmp - 1.0;										\
	v.Tmp = (v.Tmp/v.Tsample)*2*PI;									\
	/* Low-pass filter*/											\
	v.ElecSpeed = (1.0-v.wc*v.Tsample)*v.ElecSpeed + v.wc*v.Tsample*v.Tmp;\
/* Saturate the output */											\
	v.Tmp = sat(v.Tmp, 950.0, -950.0);							\
/* Compute the mechanical speed (RPM)  */							\
	v.SpeedRPM = v.ElecSpeed*30.0/(v.PolePairs*PI);					\
/* Update the electrical angle */									\
	v.OldElecTheta = v.ElecTheta;

#endif /* PGU_DSP_INV_SPEED_H_ */
