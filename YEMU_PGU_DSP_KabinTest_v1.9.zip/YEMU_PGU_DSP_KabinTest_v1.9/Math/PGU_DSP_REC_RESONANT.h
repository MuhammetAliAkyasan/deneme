/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_resonant.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	Resonant controller module for Rectifier control loops
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_RESONANT_H_
#define PGU_DSP_REC_RESONANT_H_


typedef struct {
					float32 	In	;   		// Input : PR input
					float32 	Out	;			// Output: PR output
					float32 	Alpha;          // Variable: Resonant alpha component
					float32  	Beta;           // Variable: Resonant beta component
					float32     wc_sqr;			// Parameter: Square of Center frequency
					float32 	Kr;				// Parameter: Resonant gain
					float32 	Ts_12;			// Parameter: (Sampling Time)/12
				  	float32 	M1[3];			// Variable: Memory vector for forward path integrator
				  	float32 	M2[3];			// Variable: Memory vector for backward path integrator
		 	 	} RESONANT;


/*-----------------------------------------------------------------------------
Default initializer for the RESONANT Object.
-----------------------------------------------------------------------------*/
#define RESONANT_DEFAULTS { 0.0,0.0,0.0,0.0,0.0,	\
							0.0,0.0,				\
		 	 				0.0,0.0,0.0,			\
							0.0,0.0,0.0}

/*------------------------------------------------------------------------------
 	RESONANT Macro Definition
------------------------------------------------------------------------------*/
#define RESONANT_MACRO(v)												\
	v.Alpha		= 	(v.M1[0] * 23) - (v.M1[1] * 16) + (v.M1[2] * 5) ;	\
	v.Beta		=	(v.M2[0] * 23) - (v.M2[1] * 16) + (v.M2[2] * 5) ;	\
	v.Out		=	v.Alpha ;											\
	v.In		= 	v.In * v.Kr ;										\
	v.In		=   v.In - (v.Beta*v.wc_sqr) ;							\
	v.M1[2]		=	v.M1[1];											\
	v.M1[1]		=	v.M1[0];											\
	v.M1[0]		=	v.M1[0] + (v.In * v.Ts_12);							\
	v.M2[2]		=	v.M2[1];											\
	v.M2[1]		=	v.M2[0];											\
	v.M2[0]		=	v.M2[0] + (v.Alpha * v.Ts_12);





#endif /* PGU_DSP_REC_RESONANT_H_ */
