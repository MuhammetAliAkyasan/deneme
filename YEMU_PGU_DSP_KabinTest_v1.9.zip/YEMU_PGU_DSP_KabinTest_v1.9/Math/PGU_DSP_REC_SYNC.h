/*
 * PGU_DSP_REC_SYNC.h
 *
 *  Created on: 06 �ub 2013
 *      Author: fozturk
 */

#ifndef PGU_DSP_REC_SYNC_H_
#define PGU_DSP_REC_SYNC_H_

typedef struct {
			Uint16  Enable;
			Uint16 	StartCntr;
			Uint16 	Sync;
			Uint16 	ErrCntr;
			float32 Error;
			float32 Vspeak;
		}SYNC;

/*-----------------------------------------------------------------------------
Default initializer for the SYNC Object.
-----------------------------------------------------------------------------*/
#define SYNC_DEFAULTS {	0,0,0,0,				\
						0.0,0.0}

/*------------------------------------------------------------------------------
	SYNC Macro Definition
------------------------------------------------------------------------------*/
#define SYNC_MACRO(v)													\
if (v.Enable == 1)														\
{																		\
	if(v.StartCntr==75)			/* 75/7500 = 10 ms*/					\
	{																	\
		if(fabs(v.Error)< v.Vspeak*0.2)									\
		{																\
			v.Sync	= 1;												\
			v.ErrCntr	= 0;											\
		}																\
		else															\
		{																\
			if(v.ErrCntr==35)	/* 35/7500 = 5 ms*/						\
			{															\
				v.Sync=0;												\
			}															\
			else														\
			{															\
				v.ErrCntr++;											\
			}															\
		}																\
	}																	\
	else																\
	{																	\
		v.Sync=0;														\
		v.ErrCntr=0;													\
		v.StartCntr ++;													\
	}																	\
}																		\
else																	\
{																		\
	v.Sync 	= 0;														\
	v.StartCntr	= 0;													\
	v.ErrCntr	= 0;													\
}
#endif /* PGU_DSP_REC_SYNC_H_ */
