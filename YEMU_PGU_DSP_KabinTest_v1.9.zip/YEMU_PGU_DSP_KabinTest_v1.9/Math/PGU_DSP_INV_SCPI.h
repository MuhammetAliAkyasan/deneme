/* ========================================================================
TUBITAK MAM E1000 PI Slip/Slide Controller Module
===========================================================================

File name	: SCPI.H
Date		: 19.03.2014
Revision	: v1.1
Author		: Oncu Ararat

---------------------------------------------------------------------------
Description:
---------------------------------------------------------------------------
Velocity Based Slip/Slide Controller with:
*Calculation of Slip/Slide Ratio Using Estimated Velocity and Motor Speed
*PI Control: Reference Torque Using Desired and Calculated Slip/Slide Ratio

---------------------------------------------------------------------------
Interface:
---------------------------------------------------------------------------
Inputs(3)		: Td, w, EstVel
Parameters(12)	: SampleTime, CompValBoolean, R, GR, Kp, Ki, ...
                  DesiredSlipRatioP, DesiredSlipRatioN, TrTh, nSandTh, vTh
                  Enable
Variables(9)	: TotSlipRatioError, SlipRatioError, DesiredSlipRatio, ...
                  SlipRatio, wWheel, TrC, Ll, Lu, nSand
Outputs(3)		: Tr, SSSignal, Sanding

=========================================================================*/

#ifndef __PGU_DSP_INV_SCPI_H__
#define __PGU_DSP_INV_SCPI_H__

typedef struct {  float32  Td;   		                                   // Input: Desired Motor Torque [Nm]
				  float32  w;   		                                   // Input: Motor Speed [rad/s]
				  float32  EstVel;		                                   // Input: Estimated Velocity [m/s]
			   } SCPI_INPUTS;
#define SCPI_IN_DEFAULTS { 0.0, 0.0, 0.0 }

typedef struct {  float32  SampleTime;				                       // Parameter: Sample Time [s]
				  float32  CompValBoolean;				                   // Parameter: Comparison Value for Boolean Operations
				  float32  R;				                               // Parameter: Wheel Radius [m]
				  float32  GR;			                                   // Parameter: Gear Ratio
				  float32  Kp;			                                   // Parameter: Gain Coefficient of PI Control
                  float32  Ki;			                                   // Parameter: Integral Coefficient of PI Control
                  float32  DesiredSlipRatioP;			                   // Parameter: Desired Slip Ratio for Slip/Slide Control (Positive Case)
                  float32  DesiredSlipRatioN;			                   // Parameter: Desired Slip Ratio for Slip/Slide Control (Negative Case)
                  float32  TrTh;			                               // Parameter: Threshold Difference between Desired and Reference Torque for Slip/Slide Status Detection
                  float32  nSandTh;			                               // Parameter: Maximum Sanding Period = nSandTh * SampleTime = 0.8 s
                  float32  vTh;			                                   // Parameter: Minimum Velocity for Sanding [m/s]
				  float32  Enable;   		                               // Parameter: PI Slip/Slide Controller Starter
				} SCPI_PARAMETERS;
#define SCPI_PAR_DEFAULTS { 0.01, 0.5, 0.5, 6.21, 40.0, 80.0, 0.13, -0.13, 10.0, 80.0, 2.0, 0.0 }
				
typedef struct {  float32  TotSlipRatioError;			                   // Variable: Total Slip Ratio Error
                  float32  SlipRatioError;			                       // Variable: Slip Ratio Error
                  float32  DesiredSlipRatio;			                   // Variable: Desired Slip Ratio
                  float32  SlipRatio;			                           // Variable: Slip Ratio
				  float32  wWheel;			                               // Variable: Wheel Speed [rad/s]
				  float32  TrC;			                                   // Variable: Unconstrained Reference Torque [Nm]
				  float32  Ll;			                                   // Variable: Lower Limit for Reference Torque [Nm]
				  float32  Lu;			                                   // Variable: Upper Limit for Reference Torque [Nm]
				  float32  nSand;			                               // Variable: Sanding Time Counter
				} SCPI_VARIABLES;
#define SCPI_VAR_DEFAULTS { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }

typedef struct {  float32  Tr;			                                   // Output: Motor Reference Torque [Nm]
				  float32  SSSignal;			                           // Output: Slip/Slide Detection Signal (0: No Slip Slide, 1: Slip/Slide)
				  float32  Sanding;			                               // Output: Sanding Signal (0: Off, 1: On)
			   } SCPI_OUTPUTS;		
#define SCPI_OUT_DEFAULTS { 0.0, 0.0, 0.0 }

typedef struct {  SCPI_INPUTS		i;
				  SCPI_OUTPUTS		o;
				  SCPI_VARIABLES	v;
				  SCPI_PARAMETERS 	p;
			   } SCPI;

/*-------------------------------------------------------------------------
                      SCPI Macro Definition
-------------------------------------------------------------------------*/

#define SCPI_MACRO(x)                                                                                                                                                                 \
/*************************** Enable flag check ***************************/                                                                                                           \
if (x.p.Enable > x.p.CompValBoolean)                                                                                                                                                  \
{                                                                                                                                                                                     \
    /************** Motor Speed to Wheel Speed Conversion ****************/                                                                                                           \
    x.v.wWheel = x.i.w/x.p.GR;                                                                                                                                                        \
    /*********************************************************************/                                                                                                           \
    /***************** Reference Slip Ratio Selection ********************/                                                                                                           \
    if (x.i.Td < 0.0)                                                                                                                                                                 \
    {                                                                                                                                                                                 \
    x.v.DesiredSlipRatio = x.p.DesiredSlipRatioN;                          /* Negative Case      */                                                                                   \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
    x.v.DesiredSlipRatio = x.p.DesiredSlipRatioP;                          /* Positive Case      */                                                                                   \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /********************* Slip Ratio Calculation ************************/                                                                                                           \
    if (x.v.wWheel*x.p.R > 0.0 && x.i.EstVel > 0.0)                                                                                                                                   \
    {                                                                                                                                                                                 \
        if (x.v.wWheel*x.p.R >= x.i.EstVel)                                                                                                                                           \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/(x.v.wWheel*x.p.R);/* Positive Traction Case                 */                                                             \
        }                                                                                                                                                                             \
        else                                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/x.i.EstVel;      /* Positive Braking Case                    */                                                             \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    else if (x.v.wWheel*x.p.R < 0.0 && x.i.EstVel > 0.0)                                                                                                                              \
    {                                                                                                                                                                                 \
        if (-x.v.wWheel*x.p.R >= x.i.EstVel)                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/(-x.v.wWheel*x.p.R);/* Positive Ultra Excessive Braking Case */                                                             \
        }                                                                                                                                                                             \
        else                                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/x.i.EstVel;      /* Positive Excessive Braking Case          */                                                             \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    else if(x.v.wWheel*x.p.R > 0.0 && x.i.EstVel < 0.0)                                                                                                                               \
    {                                                                                                                                                                                 \
        if (x.v.wWheel*x.p.R >= -x.i.EstVel)                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/(x.v.wWheel*x.p.R);/* Negative Ultra Excessive Braking Case  */                                                             \
        }                                                                                                                                                                             \
        else                                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/-x.i.EstVel;     /* Negative Excessive Braking Case          */                                                             \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    else if(x.v.wWheel*x.p.R < 0.0 && x.i.EstVel < 0.0)                                                                                                                               \
    {                                                                                                                                                                                 \
        if (x.v.wWheel*x.p.R <= x.i.EstVel)                                                                                                                                           \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/(-x.v.wWheel*x.p.R);/* Negative Traction Case                */                                                             \
        }                                                                                                                                                                             \
        else                                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.SlipRatio = (x.v.wWheel*x.p.R-x.i.EstVel)/-x.i.EstVel;     /* Negative Braking Case                    */                                                             \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
            x.v.SlipRatio = 0.0;                                           /* Static Case                            */                                                               \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /********* Slip Ratio and Total Slip Ratio Error Calculation *********/                                                                                                           \
    x.v.SlipRatioError    = x.v.DesiredSlipRatio-x.v.SlipRatio;                                                                                                                       \
    x.v.TotSlipRatioError = x.v.TotSlipRatioError+x.p.SampleTime*x.v.SlipRatioError;                                                                                                  \
    /*********************************************************************/                                                                                                           \
    /************ Unconstrained Reference Torque Calculation *************/                                                                                                           \
    x.v.TrC = 1000.0*(x.p.Kp*x.v.SlipRatioError+x.p.Ki*x.v.TotSlipRatioError);                                                                                                        \
    /*********************************************************************/                                                                                                           \
    /********* Limitation of Reference Torque with Desired Torque ********/                                                                                                           \
    if (x.i.Td < 0.0)                                                                                                                                                                 \
    {                                                                                                                                                                                 \
    x.v.Ll     = x.i.Td;                                                   /* Lower Limit for Reference Torque (Brake) [Nm]    */                                                     \
    x.v.Lu     = 0.0;                                                      /* Upper Limit for Reference Torque (Brake) [Nm]    */                                                     \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
    x.v.Ll     = 0.0;                                                      /* Lower Limit for Reference Torque (Traction) [Nm] */                                                     \
    x.v.Lu     = x.i.Td;                                                   /* Upper Limit for Reference Torque (Traction) [Nm] */                                                     \
    }                                                                                                                                                                                 \
    if (x.v.TrC < x.v.Ll)                                                                                                                                                             \
    {                                                                                                                                                                                 \
    x.o.Tr                = x.v.Ll;                                        /* Limitation of Reference Torque (Brake) [Nm]      */                                                     \
    x.v.TotSlipRatioError = 0.0;                                           /* Resetting Total Slip Ratio Error for Anti-Windup */                                                     \
    }                                                                                                                                                                                 \
    else if (x.v.TrC > x.v.Lu)                                                                                                                                                        \
    {                                                                                                                                                                                 \
    x.o.Tr                = x.v.Lu;                                        /* Limitation of Reference Torque (Traction) [Nm]   */                                                     \
    x.v.TotSlipRatioError = 0.0;                                           /* Resetting Total Slip Ratio Error for Anti-Windup */                                                     \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
    x.o.Tr                = x.v.TrC;                                                                                                                                                  \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /********* Slip/Slide Signal and Sanding Signal Generation ***********/                                                                                                           \
    if ((((x.i.Td-x.o.Tr) >= 0.0) && ((x.i.Td-x.o.Tr) < x.p.TrTh)) || (((x.i.Td-x.o.Tr) < 0.0) && ((x.i.Td-x.o.Tr) > -x.p.TrTh)))                                                     \
    {                                                                                                                                                                                 \
    x.o.SSSignal = 0.0;                                                    /* Slip/Slide Situation is not Detected             */                                                     \
    x.o.Sanding  = 0.0;                                                    /* Sanding is Off                                   */                                                     \
    x.v.nSand    = 0.0;                                                    /* Resetting Sanding Counter                        */                                                     \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
    x.o.SSSignal = 1.0;                                                    /* Slip/Slide Situation is Detected                 */                                                     \
        if ((((x.i.EstVel >= 0.0) && (x.i.EstVel < x.p.vTh)) || ((x.i.EstVel < 0.0) && (x.i.EstVel > -x.p.vTh))))                                                                     \
        {                                                                                                                                                                             \
            if (x.v.nSand < x.p.nSandTh)                                                                                                                                              \
            {                                                                                                                                                                         \
            x.o.Sanding   = 1.0;                                           /* Sanding is On                                    */                                                     \
            x.v.nSand     = x.v.nSand+1.0;                                                                                                                                            \
            }                                                                                                                                                                         \
            else                                                           /* Maximum Sanding Time has Elapsed                 */                                                     \
            {                                                                                                                                                                         \
            x.o.Sanding   = 0.0;                                           /* Sanding is Off                                   */                                                     \
            }                                                                                                                                                                         \
        }                                                                                                                                                                             \
        else                                                               /* Velocity is Higher than Minimum Sanding Velocity */                                                     \
        {                                                                                                                                                                             \
        x.o.Sanding = 0.0;                                                 /* Sanding is Off                                   */                                                     \
        x.v.nSand   = 0.0;                                                 /* Resetting Sanding Counter                        */                                                     \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
/*************************************************************************/                                                                                                           \
}                                                                                                                                                                                     \
else                                                                                                                                                                                  \
{                                                                                                                                                                                     \
/****** Enable=0 Then Reset Variables and Outputs to Default Values ******/                                                                                                           \
	x.v.TotSlipRatioError = 0.0;                                                                                                                                                      \
	x.v.SlipRatioError    = 0.0;                                                                                                                                                      \
	x.v.DesiredSlipRatio  = 0.0;                                                                                                                                                      \
    x.v.SlipRatio         = 0.0;                                                                                                                                                      \
	x.v.wWheel            = 0.0;                                                                                                                                                      \
    x.v.TrC               = 0.0;                                                                                                                                                      \
    x.v.Ll                = 0.0;                                                                                                                                                      \
	x.v.Lu                = 0.0;                                                                                                                                                      \
    x.v.nSand             = 0.0;                                                                                                                                                      \
    x.o.Tr                = 0.0;                                                                                                                                                      \
	x.o.SSSignal          = 0.0;                                                                                                                                                      \
	x.o.Sanding           = 0.0;                                                                                                                                                      \
/*************************************************************************/                                                                                                           \
}
#endif // __PGU_DSP_INV_SCPI__
