/* =================================================================================
File name:       PARK.H 
===================================================================================*/

#ifndef __PARK_H__
#define __PARK_H__

typedef struct {  float32  Is_alpha;  	// Input: stationary Is_d-axis stator variable
				  float32  Is_beta;	 	// Input: stationary Is_q-axis stator variable
				  float32  Is_d;		// Output: rotating Is_d-axis stator variable
				  float32  Is_q;		// Output: rotating Is_q-axis stator variable
				  float32  cosTheta; 	 
  				  float32  sinTheta;
		 	 	} PARK;

/*-----------------------------------------------------------------------------
Default initalizer for the PARK object.
-----------------------------------------------------------------------------*/                     
#define PARK_DEFAULTS {   0.0, \
                          0.0, \
                          0.0, \
                          0.0, \
						  0.0, \
                          0.0, \
              			  }

/*------------------------------------------------------------------------------
	PARK Transformation Macro Definition : exp(-j*ws)
------------------------------------------------------------------------------*/


#define PARK_MACRO(x)											\
																\
	x.Is_d =  x.cosTheta*x.Is_alpha + x.sinTheta*x.Is_beta;		\
    x.Is_q = -x.sinTheta*x.Is_alpha + x.cosTheta*x.Is_beta;		\

#endif // __PARK_H__
