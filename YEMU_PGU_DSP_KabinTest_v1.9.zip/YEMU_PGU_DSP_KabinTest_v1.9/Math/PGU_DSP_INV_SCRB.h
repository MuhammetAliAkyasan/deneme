/* ========================================================================
TUBITAK MAM E1000 Rule Based Slip/Slide Controller Module
===========================================================================

File name	: SCRB.H
Date		: 29.09.2015
Revision	: v2.01
Author		: Oncu Ararat

---------------------------------------------------------------------------
Description:
---------------------------------------------------------------------------
Wheel Speed Based Slip/Slide Controller with:
*Detection of Sign Change of Desired Torque
*Detection of Slip/Slide Situation
*Maximum Available Adhesion Torque Calculation
*Re-adhesion Period
*Achieving Maximum Available Adhesion Period
*Checking Driver Intent

---------------------------------------------------------------------------
Revisions:
---------------------------------------------------------------------------
*****************************Parameter Values******************************
*Default Cut-Off Frequency of the Low Pass Filter has changed to 2.5 Hz
*Default J value has changed to 25 kgm2
*Default dwTh value has changed to 15 rad/s2
*Default CtrConTh value has changed to 4200 Sample
*Default IntRateLim has changed to 4 Nm/Sample
*Default ConRateLim has changed to 0.5 Nm/Sample
*Default PosRateLim has changed to 0.5 Nm/Sample
************************Algorithmic Additions******************************
*Slip-Slide Detection has been put in front of Sign Change Detection
*Condition of Slip-Slide Detection is simplified
*Zero Reference has skipped away in Slip-Slide Detection
*All counters reset incaseof Slip-Slide Detection
*All counters and Available Adhesion reset incaseof Sign Change Detection
*Unnecessesary Resets are removed in All Periods
*Comparison with TrK1 has changed with TdK1 at the start of submodules
 
---------------------------------------------------------------------------
Interface:
---------------------------------------------------------------------------
Inputs(3)		: Td, w, Enable
Parameters(12)	: SampleTime, ComVal, K1, K2, J, dwTh, CtrIntTh, CtrConTh
                  IntRateLim, ConRateLim, PosRateLim, IntGain
Variables(14)	: wK1, dw, dwK1, TdK1, TrK1, TrT, TMax, StaInt, StaCon,
                  StaPos, CtrInt, CtrCon, Ll, Lu                 
Outputs(3)		: Tr, SSSignal, Sanding

=========================================================================*/

#ifndef __PGU_DSP_INV_SCRB_H__
#define __PGU_DSP_INV_SCRB_H__

typedef struct {  float32  Td;   		                                   // Input: Desired Motor Torque [Nm]
				  float32  w;   		                                   // Input: Motor Speed [rad/s]
				  float32  Enable;   		                               // Input: RB Slip/Slide Controller Starter
			   } SCRB_INPUTS;
#define SCRB_IN_DEFAULTS { 0.0, 0.0, 0.0 }

typedef struct {  float32  SampleTime;				                       // Parameter: Sample Time [s]
				  float32  ComVal;         				                   // Parameter: Comparison Value for Boolean Operations (>ComVal: 1, <ComVal: 0)
				  float32  K1;			                                   // Parameter: Filter Parameter 1 (exp(-K2*SampleTime))
                  float32  K2;			                                   // Parameter: Filter Parameter 2 (2*pi*Filter Cut-Off Frequency[Hz])
                  float32  J;			                                   // Parameter: Total Induced Inertia of Traction Model on Motor [kgm2]
                  float32  dwTh;			                               // Parameter: MotorAccelerationThreshold[rad/s2]=MaxiumumVehicleAcceleration[m/s2]/WheelRadius[m]*GearRatio
                  float32  CtrIntTh;			                           // Parameter: Initial Mode Duration [1Second/SampleTime]
                  float32  CtrConTh;			                           // Parameter: Control Mode Duration [5Second/SampleTime]
                  float32  IntRateLim;			                           // Parameter: Initial Period Torque Change Rate Limit [5000Nm*SampleTime]
                  float32  ConRateLim;		                               // Parameter: Control Period Torque Change Rate Limit [500Nm*SampleTime]
                  float32  PosRateLim;		                               // Parameter: Post Control Period Torque Change Rate Limit [500Nm*SampleTime]
                  float32  IntGain;			                               // Parameter: Gain Used to Multiply Maximum Adhesion Torque to Use in Initial Period
				} SCRB_PARAMETERS;
//#define SCRB_PAR_DEFAULTS { 0.001, 0.5, 0.969072426304811, 31.415926535897931, 20.8119, 12.42, 1000.0, 5000.0, 5.0, 0.5, 0.5, 0.8 }
#define SCRB_PAR_DEFAULTS { 1/2100, 0.5, 0.992547922939847, 15.707963267948966, 25.0, 14.0, 2100.0, 4200.0, 1.0, 0.1, 0.1, 0.8 }

typedef struct {  float32  wK1;        		                               // Variable: (K-1)th Value of Motor Speed [rad/s]
				  float32  dw;   			                               // Variable: Motor Acceleration [rad/s2]
	              float32  dwMean;                                         // Variable: Motor Acceleration Mean [rad/s2]
	              float32  dwSum;                                          // Variable: Motor Acceleration Sum for Mean[rad/s2]
	              Uint16   dwMeanCntr;                                     // Variable: Motor Acceleration Mean Ctr[rad/s2]
				  float32  dwK1; 			                               // Variable: (K-1)th Value of Motor Acceleration [rad/s2]
				  float32  TdK1; 			                               // Variable: (K-1)th Value of Desired Motor Torque [Nm]
				  float32  TrK1; 			                               // Variable: (K-1)th Value of Reference Motor Torque [Nm]
				  float32  TrT;  			                               // Variable: Temporary Reference Motor Torque [Nm]
				  float32  TMax;			                               // Variable: Maximum Available Adhesion Torque [Nm]
                  float32  StaInt;		                                   // Variable: Initial Mode Status (0: Off, 1: On)
                  float32  StaCon;		                                   // Variable: Control Mode Status (0: Off, 1: On)
                  float32  StaPos;		                                   // Variable: Post Control Mode Status (0: Off, 1: On)
                  float32  CtrInt;			                               // Variable: Initial Mode Counter
                  float32  CtrCon;			                               // Variable: Control Mode Counter
                  float32  Ll;			                                   // Variable: Lower Limit for Reference Motor Torque [Nm]
                  float32  Lu;			                                   // Variable: Upper Limit for Reference Motor Torque [Nm]
				} SCRB_VARIABLES;
#define SCRB_VAR_DEFAULTS { 0.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }

typedef struct {  float32  Tr;			                                   // Output: Motor Reference Torque [Nm]
				  float32  SSSignal;			                               // Output: Slip/Slide Detection Signal (0: No Slip Slide, 1: Slip/Slide)
				  float32  Sanding;			                               // Output: Sanding Signal (0: Off, 1: On)
				} SCRB_OUTPUTS;		
#define SCRB_OUT_DEFAULTS { 0.0, 0.0, 0.0 }

typedef struct {  SCRB_INPUTS		i;
				  SCRB_OUTPUTS		o;
				  SCRB_VARIABLES	v;
				  SCRB_PARAMETERS 	p;				  
				} SCRB;

/*-------------------------------------------------------------------------
                      SCRB Macro Definition
-------------------------------------------------------------------------*/

#define SCRB_MACRO(x)                                                                                                                                                                 \
/*************************** Enable flag check ***************************/                                                                                                           \
if (x.i.Enable > x.p.ComVal)                                                                                                                                                          \
{                                                                                                                                                                                     \
    /************************ Low-Pass Filter ****************************/                                                                                                           \
    x.v.dw         = x.p.K1*x.v.dwK1+x.p.K2*(x.i.w-x.v.wK1);                                                                                                                          \
    /*********************************************************************/                                                                                                           \
    /************************ Mean Acceleration **************************/                                                                                                           \
    x.v.dwMeanCntr++;                                                                                                                                                                 \
	x.v.dwSum += x.v.dw;                                                                                                                                                              \
    if(x.v.dwMeanCntr>=10)                                                                                                                                                             \
    {                                                                                                                                                                                 \
        x.v.dwMeanCntr  = 0;                                                                                                                                                          \
        x.v.dwMean      = x.v.dwSum*(1.0/10.0);                                                                                                                                        \
        x.v.dwSum       = 0.0;                                                                                                                                                        \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
	/**************** Default State Reference Generation *****************/                                                                                                           \
    x.v.TrT        = x.i.Td;                                                                                                                                                          \
    x.o.Sanding    = 0.0;                                                                                                                                                             \
    /*********************************************************************/                                                                                                           \
    /********************** Slip/Slide Detection *************************/                                                                                                           \
    if (((x.v.TrK1 > 0.0) && (x.v.dwMean > x.p.dwTh)) || ((x.v.TrK1 < 0.0) && (x.v.dwMean < -x.p.dwTh)))                                                                                      \
    {                                                                                                                                                                                 \
        x.v.StaInt   = 1.0;                                                /* Initial Mode is Activated for Traction     */                                                           \
        x.v.StaCon   = 0.0;                                                /* Control Mode Reset                         */                                                           \
        x.v.StaPos   = 0.0;                                                /* Post Control Mode Reset                    */                                                           \
        x.v.CtrInt   = 0.0;                                                /* Initial Period Counter Reset               */                                                           \
        x.v.CtrCon   = 0.0;                                                /* Control Period Counter Reset               */                                                           \
        x.v.TMax     = x.v.TrK1-x.p.J*x.v.dw;                              /* Detected Available Adhesion Torque         */                                                           \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /************ Detection of Sign Change in Desired Motor Torque *******/                                                                                                           \
    if (((x.i.Td >= 0.0) && (x.v.TdK1 < 0.0)) || ((x.i.Td < 0.0) && (x.v.TdK1 >= 0.0)))                                                                                               \
    {                                                                                                                                                                                 \
        x.v.StaInt   = 0.0;                                                /* Initial Mode Reset                         */                                                           \
        x.v.StaCon   = 0.0;                                                /* Control Mode Reset                         */                                                           \
        x.v.StaPos   = 0.0;                                                /* Post Control Mode Reset                    */                                                           \
        x.v.CtrInt   = 0.0;                                                /* Initial Period Counter Reset               */                                                           \
        x.v.CtrCon   = 0.0;                                                /* Control Period Counter Reset               */                                                           \
        x.v.TMax     = 0.0;                                                /* Available Adhesion Torque Reset            */                                                           \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /************************** Initial Mode *****************************/                                                                                                           \
    if (x.v.StaInt > x.p.ComVal)                                           /* Start of Initial Period                    */                                                           \
    {                                                                                                                                                                                 \
        if (x.v.CtrInt < x.p.CtrIntTh)                                                                                                                                                \
        {                                                                                                                                                                             \
            x.v.CtrInt    = x.v.CtrInt+1.0;                                /* Increase Initial Mode Counter              */                                                           \
            if (x.v.TdK1 >= 0.0)                                                                                                                                                      \
            {                                                                                                                                                                         \
                x.v.TrT = x.v.TrK1-x.p.IntRateLim;                         /* Decrease Reference Torque to TMax*IntGain  */                                                           \
                if (x.v.TrT < x.v.TMax*x.p.IntGain)                                                                                                                                   \
                {                                                                                                                                                                     \
                    x.v.TrT = x.v.TMax*x.p.IntGain;                                                                                                                                   \
                }                                                                                                                                                                     \
            }                                                                                                                                                                         \
            else                                                                                                                                                                      \
            {                                                                                                                                                                         \
                x.v.TrT = x.v.TrK1+x.p.IntRateLim;                         /* Increase Reference Torque to TMax*IntGain  */                                                           \
                if (x.v.TrT > x.v.TMax*x.p.IntGain)                                                                                                                                   \
                {                                                                                                                                                                     \
                    x.v.TrT = x.v.TMax*x.p.IntGain;                                                                                                                                   \
                }                                                                                                                                                                     \
            }                                                                                                                                                                         \
        }                                                                                                                                                                             \
        else                                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.CtrInt   = 0.0;                                            /* Initial Mode Counter Reset                 */                                                           \
            x.v.StaInt   = 0.0;                                            /* End of Initial Mode                        */                                                           \
            x.v.StaCon   = 1.0;                                            /* Control Mode is Activated                  */                                                           \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /*********************** Control Mode ********************************/                                                                                                           \
    if (x.v.StaCon > x.p.ComVal)                                           /* Start of Control Period                    */                                                           \
    {                                                                                                                                                                                 \
        if (x.v.CtrCon < x.p.CtrConTh)                                                                                                                                                \
        {                                                                                                                                                                             \
            x.v.CtrCon = x.v.CtrCon+1.0;                                   /* Increase Control Mode Counter              */                                                           \
            if (x.v.TdK1 >= 0.0)                                                                                                                                                      \
            {                                                                                                                                                                         \
                x.v.TrT = x.v.TrK1+x.p.ConRateLim;                         /* Increase Reference Torque to TMax          */                                                           \
                if (x.v.TrT > x.v.TMax)                                                                                                                                               \
                {                                                                                                                                                                     \
                    x.v.TrT = x.v.TMax;                                    /* Hold Reference Value Constant              */                                                           \
                }                                                                                                                                                                     \
            }                                                                                                                                                                         \
            else                                                                                                                                                                      \
            {                                                                                                                                                                         \
                x.v.TrT = x.v.TrK1-x.p.ConRateLim;                         /* Decrease Reference Torque to TMax          */                                                           \
                if (x.v.TrT < x.v.TMax)                                                                                                                                               \
                {                                                                                                                                                                     \
                    x.v.TrT = x.v.TMax;                                    /* Hold Reference Value Constant              */                                                           \
                }                                                                                                                                                                     \
            }                                                                                                                                                                         \
        }                                                                                                                                                                             \
        else                                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.CtrCon  = 0.0;                                             /* Control Mode Counter Reset                 */                                                           \
            x.v.StaCon  = 0.0;                                             /* End of Control Period                      */                                                           \
            x.v.StaPos  = 1.0;                                             /* Post Control Mode is Activated             */                                                           \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /************************** Post Control Mode ************************/                                                                                                           \
    if (x.v.StaPos > x.p.ComVal)                                           /* Start of Post Slip/Slide Period            */                                                           \
    {                                                                                                                                                                                 \
        if (x.v.TdK1 >= 0.0)                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.TrT = x.v.TrK1+x.p.PosRateLim;                             /* Increase Reference Torque to Td            */                                                           \
            if (x.v.TrT > x.i.Td)                                                                                                                                                     \
            {                                                                                                                                                                         \
                x.v.TrT     = x.i.Td;                                      /* Hold Reference Value Constant              */                                                           \
                x.v.StaPos  = 0.0;                                         /* End of Post Control Period                 */                                                           \
            }                                                                                                                                                                         \
        }                                                                                                                                                                             \
        else                                                                                                                                                                          \
        {                                                                                                                                                                             \
            x.v.TrT = x.v.TrK1-x.p.PosRateLim;                             /* Decrease Reference Torque to Td            */                                                           \
            if (x.v.TrT < x.i.Td)                                                                                                                                                     \
            {                                                                                                                                                                         \
                x.v.TrT     = x.i.Td;                                      /* Hold Reference Value Constant              */                                                           \
                x.v.StaPos  = 0.0;                                         /* End of Post Control Period                 */                                                           \
            }                                                                                                                                                                         \
        }                                                                                                                                                                             \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /******* Limitation of Reference Torque with Desired Torque **********/                                                                                                           \
    if  (x.i.Td < 0.0)                                                                                                                                                                \
    {                                                                                                                                                                                 \
    x.v.Ll      = x.i.Td;                                                  /* Lower Limit for Reference Torque (Brake) [Nm]    */                                                     \
    x.v.Lu      = 0.0;                                                     /* Upper Limit for Reference Torque (Brake) [Nm]    */                                                     \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
    x.v.Ll      = 0.0;                                                     /* Lower Limit for Reference Torque (Traction) [Nm] */                                                     \
    x.v.Lu      = x.i.Td;                                                  /* Upper Limit for Reference Torque (Traction) [Nm] */                                                     \
    }                                                                                                                                                                                 \
    if (x.v.TrT < x.v.Ll)                                                                                                                                                             \
    {                                                                                                                                                                                 \
    x.o.Tr      = x.v.Ll;                                                  /* Limitation of Reference Torque (Brake) [Nm]      */                                                     \
    }                                                                                                                                                                                 \
    else if (x.v.TrT > x.v.Lu)                                                                                                                                                        \
    {                                                                                                                                                                                 \
    x.o.Tr      = x.v.Lu;                                                  /* Limitation of Reference Torque (Traction) [Nm]   */                                                     \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
    x.o.Tr      = x.v.TrT;                                                                                                                                                            \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /******************** Slip/Slide Signal Generation *******************/                                                                                                           \
    if ((x.v.StaInt > x.p.ComVal) || (x.v.StaCon > x.p.ComVal) || (x.v.StaPos > x.p.ComVal))                                                                                          \
    {                                                                                                                                                                                 \
    x.o.SSSignal    = 1.0;                                                 /* Slip/Slide Control is Active     */                                                                     \
    x.o.Sanding     = 1.0;                                           	   /* Sanding is Activated             */		                                                           	  \
    }                                                                                                                                                                                 \
    else                                                                                                                                                                              \
    {                                                                                                                                                                                 \
    x.o.SSSignal    = 0.0;                                                 /* Slip/Slide Control is not Active */                                                                     \
    x.o.Sanding     = 0.0;                                            	   /* Sanding is Deactivated           */			                                                          \
    }                                                                                                                                                                                 \
    /*********************************************************************/                                                                                                           \
    /********************* Update of Internal States *********************/                                                                                                           \
    x.v.TdK1 = x.i.Td;                                                     /* Update of (K-1)th Value of Desired Motor Torque [Nm]   */                                               \
    x.v.TrK1 = x.o.Tr;                                                     /* Update of (K-1)th Value of Reference Motor Torque [Nm] */                                               \
    x.v.dwK1 = x.v.dw;                                                     /* Update of (K-1)th Value of Motor Acceleration [rad/s2] */                                               \
    x.v.wK1  = x.i.w;                                                      /* Update of (K-1)th Value of Motor Speed [rad/s]         */                                               \
    /*********************************************************************/                                                                                                           \
/*************************************************************************/                                                                                                           \
}                                                                                                                                                                                     \
else                                                                                                                                                                                  \
{                                                                                                                                                                                     \
/******* Enable=0 Then Reset Variables and Outputs to Default Values *****/                                                                                                           \
    x.o.Tr          = 0.0;                                                                                                                                                            \
    x.o.SSSignal    = 0.0;                                                                                                                                                            \
    x.o.Sanding     = 0.0;                                                                                                                                                            \
    x.v.StaInt      = 0.0;                                                                                                                                                            \
    x.v.StaCon      = 0.0;                                                                                                                                                            \
    x.v.StaPos      = 0.0;                                                                                                                                                            \
    x.v.CtrInt      = 0.0;                                                                                                                                                            \
    x.v.CtrCon      = 0.0;                                                                                                                                                            \
    x.v.wK1         = x.i.w;                                                                                                                                                          \
    x.v.dw          = 0.0;                                                                                                                                                            \
    x.v.dwMean      = 0.0;                                                                                                                                                            \
    x.v.dwSum       = 0.0;                                                                                                                                                            \
    x.v.dwMeanCntr  = 0;                                                                                                                                                              \
    x.v.dwK1        = 0.0;                                                                                                                                                            \
    x.v.TdK1        = 0.0;                                                                                                                                                            \
    x.v.TrK1        = 0.0;                                                                                                                                                            \
    x.v.TrT         = 0.0;                                                                                                                                                            \
    x.v.TMax        = 0.0;                                                                                                                                                            \
    x.v.Ll          = 0.0;                                                                                                                                                            \
    x.v.Lu          = 0.0;                                                                                                                                                            \
/*************************************************************************/                                                                                                           \
}
#endif // __PGU_DSP_INV_SCRB_H__
