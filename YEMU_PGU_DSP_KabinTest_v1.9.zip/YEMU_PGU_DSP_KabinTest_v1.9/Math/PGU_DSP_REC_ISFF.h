/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_isff.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	Feedforward calculation module for Input current of Rectifier
Originator:
Note:
=====================================================================================*/

#ifndef PGU_DSP_REC_ISFF_H_
#define PGU_DSP_REC_ISFF_H_


typedef struct {
					float32 	Vdc	;   		// Input: DC voltage
					float32 	Idc	;			// Input: DC current
					float32 	Vspeak;			// Input: Secondary voltage peak
					float32   	Isff;			// Output: Secondary current feedforward(peak)
					float32 	DCpower;		// Variable: DC power
					float32		Vspeaksat;		// Variable: Saturated Vspeak
					float32		Vspeakmin;		// Parameter: Secondary voltage min. value (peak)
					float32		Vspeakmax;		// Parameter: Secondary voltage max. value (peak)
					float32		Kff;			// Parameter: Feedforward coefficient (Normal=2)
		 	 	} ISFF;

/*-----------------------------------------------------------------------------
Default initializer for the ISFF Object.
-----------------------------------------------------------------------------*/
#define ISFF_DEFAULTS {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}

/*------------------------------------------------------------------------------
 	ISFF Macro Definition
------------------------------------------------------------------------------*/
#define ISFF_MACRO(v)											\
	/*v.DCpower	= 	v.Vdc * v.Idc;	*/							\
	v.Vspeaksat	=	sat(v.Vspeak,v.Vspeakmax,v.Vspeakmin);		\
	v.Isff		= 	v.DCpower / v.Vspeaksat ;					\
	v.Isff		=   v.Isff * v.Kff ;



#endif /* PGU_DSP_REC_ISFF_H_ */
