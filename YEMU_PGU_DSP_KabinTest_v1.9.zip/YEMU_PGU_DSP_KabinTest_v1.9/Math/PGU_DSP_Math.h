/*
 * PGU_DSP_Math.h
 *
 *  Created on: 12 Eki 2018
 *      Author: fozturk
 */

#ifndef PGU_DSP_MATH_H_
#define PGU_DSP_MATH_H_

#include "PGU_DSP_INV_DEFS.h"
#include "PGU_DSP_INV_AG.h"
#include "PGU_DSP_INV_CC.h"
#include "PGU_DSP_INV_CLARKE.h"     // Include header for the CLARKE object
#include "PGU_DSP_REC_CLARKE_Vs.h"     // Include header for the CLARKE object
#include "PGU_DSP_REC_CLARKE_Is.h"     // Include header for the CLARKE object

#include "PGU_DSP_INV_DCRC.h"
#include "PGU_DSP_INV_FO.h"
#include "PGU_DSP_INV_IPARK.h"      // Include header for the IPARK object
//#include "PGU_DSP_INV_MM.h"
#include "PGU_DSP_INV_NC.h"
#include "PGU_DSP_INV_PARK.h"       // Include header for the PARK object
#include "PGU_DSP_INV_SCPI.h"
#include "PGU_DSP_INV_SCRB.h"
#include "PGU_DSP_INV_SPEED.h"    // Include header for the SPEED_MEAS_QEP object
//#include "PGU_DSP_INV_SPEEDFR.h"
#include "PGU_DSP_INV_SVGEN.h"      // Include header for the SVGENDQ object
#include "PGU_DSP_INV_TC.h"
#include "PGU_DSP_INV_VC.h"

#include "PGU_DSP_REC_DG.h"
#include "PGU_DSP_REC_FFC.h"
#include "PGU_DSP_REC_FLL.h"
#include "PGU_DSP_REC_ISFF.h"
#include "PGU_DSP_REC_PARK.h"
#include "PGU_DSP_REC_PEAK.h"
#include "PGU_DSP_REC_PLL_LS.h"
#include "PGU_DSP_REC_PLL_QSG_OSC.h"
#include "PGU_DSP_REC_QSG.h"
#include "PGU_DSP_REC_RECPI.h"
#include "PGU_DSP_REC_RESONANT.h"
#include "PGU_DSP_REC_RESONANT2.h"
#include "PGU_DSP_REC_RESONANT3.h"
#include "PGU_DSP_REC_RMS.h"
#include "PGU_DSP_REC_SYNC.h"
#include "PGU_DSP_REC_ZEROCROSS.h"
#include "volt_calc.h"

#include <math.h>

// Saturation macro
#define sat(A, Pos, Neg)    (__fmax(((__fmin((A),(Pos)))),(Neg)))

#endif /* PGU_DSP_MATH_H_ */
