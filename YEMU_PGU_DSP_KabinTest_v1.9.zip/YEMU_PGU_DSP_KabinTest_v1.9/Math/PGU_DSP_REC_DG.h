/*
 * PGU_DSP_REC_DG.h
 *
 *  Created on: 25 Oca 2013
 *      Author: fozturk
 */
/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_control.h
Author: 		fozturk
Date:			4 Oca 2012
Description:	Main  loop of Rectifier control
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_DG_H_
#define PGU_DSP_REC_DG_H_


typedef struct {
					float32  	IsErr;  	// Input:		Secondary current
					float32		Vdc;		// Input:		DC link voltage for duty scaling(+1,-1)
					float32  	Vf;  		// Input:		Compansating secondary voltage for delayless feed-forward
					float32		Resonant;	// Input:       Resonant controller output
				} DG_IN;
typedef struct {
					float32		Duty;		// Output:		PWM duty (+1,-1)
				} DG_OUT;

typedef struct {
					float32		CCOut;		// Variable:	Output of Current Controller (Resonant + Proportional)
					float32		Vr;			// Variable:    Rectifier input voltage
					float32  	VrSatErr;	// Variable: 	Saturated difference Retifier Input voltage
					float32  	VrPreSat; 	// Variable: 	Pre-saturated Rectifier Input voltage
					float32		DutyPreSat; // Variable:	Pre-saturated Duty
				} DG_VAR;

typedef struct {
					Uint16 		Enable; 	//              Enable for duty generation
					float32		Kp;			// Parameter: 	Proportional Gain of inner Current loop
					float32  	VrMax;		// Parameter: 	Maximum Rectifier Input voltage
					float32  	VrMin;	   	// Parameter:	Minimum Rectifier Input voltage
					float32		Dmax;		// Parameter:   Maximum PWM Duty
					float32		Dmin;		// Parameter:	Minimum PWM Duty
				} DG_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
	DG_IN	i;
	DG_OUT  o;
	DG_VAR	v;
	DG_PAR	p;
} DG;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define DG_IN_DEFAULTS  {0.0,0.0,0.0,0.0}
#define DG_OUT_DEFAULTS {0.0}
#define DG_VAR_DEFAULTS {0.0,0.0,0.0,0.0,0.0}
#define DG_PAR_DEFAULTS {0,0.0,0.0,0.0,0.0,0.0}

/*------------------------------------------------------------------------------
 	DG Macro Definition
------------------------------------------------------------------------------*/
#define DG_MACRO(x)																					\
if (x.p.Enable == 1)																				\
{																									\
	x.v.CCOut			=	(x.i.IsErr * x.p.Kp) + x.i.Resonant;									\
	x.v.VrPreSat		=	x.i.Vf - x.v.CCOut;														\
	x.v.Vr				= 	sat(x.v.VrPreSat, x.p.VrMax, x.p.VrMin);	/* Saturate the output */	\
	x.v.VrSatErr 		= 	x.v.Vr - x.v.VrPreSat;			/* Compute the saturate difference */	\
	x.v.DutyPreSat		=	x.v.Vr / x.i.Vdc;														\
	x.o.Duty			= 	sat(x.v.DutyPreSat, x.p.Dmax, x.p.Dmin);	/* Saturate the output */   \
}																									\
else																								\
{																									\
	x.o.Duty			=  0.0;																		\
}



#endif /* PGU_DSP_REC_DG_H_ */
