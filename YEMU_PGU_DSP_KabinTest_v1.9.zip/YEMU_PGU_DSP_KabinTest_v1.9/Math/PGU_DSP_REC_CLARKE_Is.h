/* =================================================================================
File name:       CLARKE.H  
===================================================================================*/


#ifndef __CLARKE_Is_H__
#define __CLARKE_Is_H__

typedef struct {  float32  Is_a;  		// Input: phase-a stator variable
				  float32  Is_b;		// Input: phase-b stator variable
				  float32  Is_c;		// Input: phase-c stator variable  
				  float32  Is_alpha;	// Output: stationary axis stator variable 
				  float32  Is_beta;		// Output: stationary axis stator variable
		 	 	} CLARKE_Is;

/*-----------------------------------------------------------------------------
	Default initalizer for the CLARKE object.
-----------------------------------------------------------------------------*/                     
#define CLARKE_Is_DEFAULTS { 0.0, \
                          0.0, \
                          0.0, \
                          0.0, \
                          0.0, \
              			} 

/*------------------------------------------------------------------------------
	CLARKE Transformation Macro Definition
------------------------------------------------------------------------------*/
	
#define CLARKE_MACRO_Is(x)											\
																\
x.Is_alpha = TWO_THR*(x.Is_a - 0.5*x.Is_b - 0.5*x.Is_c);		\
x.Is_beta  = TWO_THR*SQRT3_2*(x.Is_b - x.Is_c);					\

#endif // __CLARKE_H__

