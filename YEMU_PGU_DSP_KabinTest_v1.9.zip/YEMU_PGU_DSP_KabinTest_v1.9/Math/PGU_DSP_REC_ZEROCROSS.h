/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_zerocross.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	Zerocross detection module
Originator:
Note:
=====================================================================================*/
#ifndef PGU_DSP_REC_ZEROCROSS_H_
#define PGU_DSP_REC_ZEROCROSS_H_


typedef struct {  float32  	Vin;   				// Input: Sine Signal
				  float32  	Threshold;   		// Parameter: Voltage level corresponding to zero i/p
				  Uint16  	ZCD;   				// Output: Zero Cross detected
				  Uint16 	prev_sign ;
				  Uint16 	curr_sign ;
				  Uint16 	zc_counter;
				  Uint16 	zc_cntinit;
				  Uint16 	zc_flag;
				  Uint16 	Enable;
				  } ZEROCROSS;

//-----------------------------------------------------------------------------
//Default initalizer for the ZEROCROSS object.
//-----------------------------------------------------------------------------

#define ZEROCROSS_DEFAULTS {  (0.0), 			\
                           	  (0.0), 			\
                           	  0,				\
                           	  0, 				\
                           	  0,				\
                           	  7, 				\
                           	  7, 				\
                           	  0,0 }

//------------------------------------------------------------------------------
// 	ZEROCROSS Macro Definition
//------------------------------------------------------------------------------

#define ZEROCROSS_MACRO(v)									\
if (v.Enable == 1)											\
{															\
	if ( v.Vin > v.Threshold)								\
	{														\
		v.curr_sign = 1;									\
	}														\
	else													\
	{														\
		v.curr_sign = 0;									\
	}														\
	if((v.prev_sign != v.curr_sign) && (v.curr_sign == 1))	\
	{ 														\
    	v.ZCD=1;											\
    	v.prev_sign = v.curr_sign;							\
	}														\
	else													\
	{														\
		v.ZCD=0;											\
		v.prev_sign = v.curr_sign;							\
	}														\
	if(v.zc_counter<v.zc_cntinit)							\
	{														\
		v.zc_flag	=1;										\
		v.zc_counter++;										\
	}														\
	else													\
	{														\
		v.zc_flag=0;										\
	}														\
															\
	if(v.ZCD==1)											\
	{														\
		v.zc_counter=0;										\
	}														\
}															\
else														\
{															\
	v.ZCD		= 0;										\
	v.zc_flag	= 0;										\
	v.zc_counter= v.zc_cntinit;								\
}




#endif /* PGU_DSP_REC_ZEROCROSS_H_ */
