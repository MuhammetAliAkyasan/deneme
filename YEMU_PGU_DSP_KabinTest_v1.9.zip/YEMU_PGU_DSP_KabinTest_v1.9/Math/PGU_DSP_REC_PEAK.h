/* ==============================================================================
System Name:  	E1000_Converter
File Name:	  	Rec_peak.h
Author: 		fozturk
Date:			25 Tem 2012
Description:	Calculation module for Input voltage
Originator:
Note:
=====================================================================================*/

#ifndef PGU_DSP_REC_PEAK_H_
#define PGU_DSP_REC_PEAK_H_
//#include "../E1000_Globals.h"


typedef struct {
					float  Alpha;  		// Input: stationary d-axis Vs variable
					float  Beta;	 	// Input: stationary q-axis Vs variable
					float  Peak;		// Output: Peak amplitude
		 	 	} PEAK;

//-----------------------------------------------------------------------------
//Default initalizer for the VSPEAK object.
//-----------------------------------------------------------------------------

#define PEAK_DEFAULTS { 	(0.0), 			\
							(0.0), 			\
							(0.0) }


/*------------------------------------------------------------------------------
	PEAK Macro Definition
------------------------------------------------------------------------------*/

#define PEAK_MACRO(v)														\
		v.Peak			=  sqrt((v.Alpha*v.Alpha) + (v.Beta*v.Beta));


#endif /* PGU_DSP_REC_PEAK_H_ */
