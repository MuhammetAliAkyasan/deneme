//###########################################################################
//
// FILE:  Example_Flash2833x_API.c	
//
// TITLE: F2833x Flash API Example
//
// NOTE:  This example runs from Flash.  First program the example
//        into flash.  The code will then copy the API's to RAM and 
//        modify the flash. 
//
//
//###########################################################################
// $TI Release: F28335 API Release V1.0 $
// $Release Date: September 14, 2007 $
//###########################################################################
#include "DSP28x_Project.h"
#include "PGU_Common.h"


/*---- Flash API include file -------------------------------------------------*/
#include "Flash2833x_API_Library.h"

/*---- example include file ---------------------------------------------------*/
#include "Example_Flash2833x_API.h"

/*---- Standard headers -------------------------------------------------------*/
#include <stdio.h>                              

/*--- Callback function.  Function specified by defining Flash_CallbackPtr */
void MyCallbackFunction(void); 
Uint32 MyCallbackCounter; // Just increment a counter in the callback function
                              
/*--- Global variables used to interface to the flash routines */
FLASH_ST FlashStatus;

/*---------------------------------------------------------------------------
  Data/Program Buffer used for testing the flash API functions
---------------------------------------------------------------------------*/
//#define  WORDS_IN_FLASH_BUFFER 0x400               // Programming data buffer, Words
//Uint16  Buffer[WORDS_IN_FLASH_BUFFER];


/*---------------------------------------------------------------------------
  Sector address info
---------------------------------------------------------------------------*/
typedef struct {
     Uint16 *StartAddr;
     Uint16 *EndAddr;
} SECTOR;

#define OTP_START_ADDR  0x380400
#define OTP_END_ADDR    0x3807FF

#if FLASH_F28335
#define FLASH_START_ADDR  0x300000
#define FLASH_END_ADDR    0x33FFFF

SECTOR Sector[8] = {
         (Uint16 *)0x338000,(Uint16 *)0x33FFFF,
         (Uint16 *)0x330000,(Uint16 *)0x337FFF,
         (Uint16 *)0x328000,(Uint16 *)0x32FFFF,
         (Uint16 *)0x320000,(Uint16 *)0x327FFF,
         (Uint16 *)0x318000,(Uint16 *)0x31FFFF,
         (Uint16 *)0x310000,(Uint16 *)0x317FFF,
         (Uint16 *)0x308000,(Uint16 *)0x30FFFF,
         (Uint16 *)0x300000,(Uint16 *)0x307FFF

};

#endif


#if FLASH_F28334
#define FLASH_START_ADDR  0x320000
#define FLASH_END_ADDR    0x33FFFF

SECTOR Sector[8] = {
         (Uint16 *)0x33C000,(Uint16 *)0x33FFFF,
         (Uint16 *)0x338000,(Uint16 *)0x33BFFF,
         (Uint16 *)0x334000,(Uint16 *)0x337FFF,
         (Uint16 *)0x330000,(Uint16 *)0x333FFF,
         (Uint16 *)0x32C000,(Uint16 *)0x32FFFF,
         (Uint16 *)0x328000,(Uint16 *)0x32BFFF,
         (Uint16 *)0x324000,(Uint16 *)0x327FFF,
         (Uint16 *)0x320000,(Uint16 *)0x323FFF

};

#endif


#if FLASH_F28332
#define FLASH_START_ADDR  0x330000
#define FLASH_END_ADDR    0x33FFFF

SECTOR Sector[4] = {
         (Uint16 *)0x33C000,(Uint16 *)0x33FFFF,
         (Uint16 *)0x338000,(Uint16 *)0x33BFFF,
         (Uint16 *)0x334000,(Uint16 *)0x337FFF,
         (Uint16 *)0x330000,(Uint16 *)0x333FFF

};

#endif


extern Uint32 Flash_CPUScaleFactor;

void DSPFlashUpdate( void )
{   

   //Uint16 Status;

    // Copy the Flash API functions to SARAM
    Example_MemCopy(&Flash28_API_LoadStart, &Flash28_API_LoadEnd, &Flash28_API_RunStart);

    // We must also copy required user interface functions to RAM. 
    Example_MemCopy(&SWRamfuncsLoadStart, &SWRamfuncsLoadEnd, &SWRamfuncsRunStart);


/*------------------------------------------------------------------
  Initalize Flash_CPUScaleFactor.

------------------------------------------------------------------*/
   
   Flash_CPUScaleFactor = SCALE_FACTOR;


/*------------------------------------------------------------------
  Initalize Flash_CallbackPtr.

------------------------------------------------------------------*/
   
   Flash_CallbackPtr = &MyCallbackFunction; 
   
   MyCallbackCounter = 0; // Increment this counter in the callback function
   
   // Jump to SARAM and call the Flash API functions
   Example_CallFlashAPI();

}

/*------------------------------------------------------------------
   Example_CallFlashAPI

   This function will interface to the flash API.  
 
   Parameters:  
  
   Return Value:
        
   Notes:  This function will be executed from SARAM
     
-----------------------------------------------------------------*/

#pragma CODE_SECTION(Example_CallFlashAPI,"SWramfuncs");

Uint16 FlashEnable = 1;
void Example_CallFlashAPI(void)
{
   Uint16  i;
   Uint16  Status;
   Uint16  Status2;
   Uint16  *Flash_ptr;     	// Pointer to a location in flash
   Uint16  *ExtRam_ptr;     // Pointer to a location in ExtRam
   Uint32  Length;         	// Number of 16-bit values to be programmed
   Uint16  Sector_x;        // Flash Sector
   Uint16  SectorMask;		//

   while(DSP2TivaRegs.regs.SWUpdateCtrl.usAll > 0)
   {
	   DSP2TivaRegs.regs.SWUpdateCtrl.usAll = 0;		// Register temizlendi
   }


   while( DSP2TivaRegs.regs.SWUpdateCtrl.bits.Start != 1)
   {
	   DSP2TivaRegs.regs.SWUpdateCtrl.bits.Start = 1;
   }

   while( DSP2TivaRegs.regs.SWUpdateCtrln.usAll != 0x7FFF)
   {
	   DSP2TivaRegs.regs.SWUpdateCtrln.usAll =0x7FFF;
   }

   Uint16 TivaPackageNumber = 0;
   Uint16 DSPPackageNumber 	= 0;
   Uint16 DelayCounter 		= 0;

   Uint16 PackWriteWaitCounter = 0;
   Uint16 PackUpdateWaitCounter= 0;

   Uint16 CheckSum 	= 0;

   Uint16 FlashWrInd = 0;  // FLASH write index

   while(1)
   {
       IO_TOGGLE(WDTog) // External Watchdog Reset

	   DSP2TivaRegs.regs.SWUpdateStat.bits.SWUpdateStarted = 1;				// SWUpdate ba�lat�ld�

       TivaPackageNumber = Tiva2DSPRegs.regs.SWUpdateCtrl.bits.PackageNumber;
	   if( TivaPackageNumber > 0 && TivaPackageNumber <= MAX_PACKAGE_NUM)			// DualportRam e package yaz�ld�
	   {
		   PackWriteWaitCounter = 0;

		   if(TivaPackageNumber == DSPPackageNumber + 1)
		   {
			   	PackUpdateWaitCounter = 0;

			    Length = ((TivaPackageNumber-1)*PACKAGE_LENGTH);

			   	for(i=0;i<PACKAGE_LENGTH;i++)
			   	{
			   		ExtRamBuff[i+Length] = SWUpdateBuff[i];

			   		CheckSum += ExtRamBuff[i+Length];
			   	}

			    DSPPackageNumber = TivaPackageNumber;
			    while(DSP2TivaRegs.regs.SWUpdateCtrl.bits.PackageNumber != DSPPackageNumber)
			    {
				    DSP2TivaRegs.regs.SWUpdateCtrl.bits.PackageNumber = DSPPackageNumber;

				   while(DelayCounter < 1000)			// gecikme sa�lamak i�in
				   {
					   DelayCounter++;
				   }
				   DelayCounter = 0;
			    }

		   }
		   else
		   {
			   if(Tiva2DSPRegs.regs.SWUpdateCtrl.bits.Finish == 1)				// Dosya transferi tamamland�
			   {
				   DSP2TivaRegs.regs.SWUpdateStat.bits.FileTransferOK = 1;

//				   if(Tiva2DSPRegs.regs.checksum == CheckSum)					// CheckSum kontrol�
//				   {
			    	   Sector_x = (Uint16)Tiva2DSPRegs.regs.SWUpdateCtrl.bits.Sector;
			    	   SectorMask = 1 << (Sector_x);

			    	   if(FlashEnable == 1)
			    	   {
		                    Status = Flash_Erase(SectorMask,&FlashStatus);           // Hedef flash sekt�r� silindi
                            Status2 = Flash_Erase(SectorMask>>1,&FlashStatus);           // Hedef flash sekt�r� silindi
			    	   }

			    	   if((Status != STATUS_SUCCESS)||(Status2 != STATUS_SUCCESS))		// Silme i�lemi ba�ar�s�z ise
			    	   {
			    		   DSP2TivaRegs.regs.SWUpdateStat.bits.FlashEraseErr = 1;
			    	       Example_Error(Status);
			    	   }
			    	   else														// Silme i�lemi ba�ar�l�
			    	   {
			    		   for(FlashWrInd=0;FlashWrInd<MAX_PACKAGE_NUM;FlashWrInd++)  // Extramdeki dosya flasha yaz�l�yor
			    		   {
								Flash_ptr  = Sector[Sector_x].StartAddr + (FlashWrInd*PACKAGE_LENGTH);
								ExtRam_ptr = (Uint16 *)EXTRAM_BASE + (FlashWrInd*PACKAGE_LENGTH);

								//Program Flash
                               if(FlashEnable == 1)
                               {
                                   if(FlashWrInd == MAX_PACKAGE_NUM-1) // Password b�lgesine yazmamak i�in kontrol
                                   {
                                       Status = Flash_Program(Flash_ptr,ExtRam_ptr,PACKAGE_LENGTH-PASSWORDS_LENGTH,&FlashStatus);
                                   }
                                   else
                                   {
                                       Status = Flash_Program(Flash_ptr,ExtRam_ptr,PACKAGE_LENGTH,&FlashStatus);
                                   }
                               }
								if(Status != STATUS_SUCCESS)
								{
									DSP2TivaRegs.regs.SWUpdateStat.bits.FlashProgramErr = 1;  // Flash program hatas�
									Example_Error(Status);
								}

								// Verify the values programmed.
                               if(FlashEnable == 1)
                               {
                                   if(FlashWrInd == MAX_PACKAGE_NUM-1)
                                   {
                                       Status = Flash_Verify(Flash_ptr,ExtRam_ptr,PACKAGE_LENGTH-PASSWORDS_LENGTH,&FlashStatus);
                                   }
                                   else
                                   {
                                       Status = Flash_Verify(Flash_ptr,ExtRam_ptr,PACKAGE_LENGTH,&FlashStatus);
                                   }
                               }
								if(Status != STATUS_SUCCESS)
								{
									DSP2TivaRegs.regs.SWUpdateStat.bits.FlashVerifyErr = 1;  // Flash verify hatas�
									Example_Error(Status);
								}
			    		   }

			    		   if(FlashWrInd == MAX_PACKAGE_NUM)					// Dosya flasha yaz�ld� m�?
			    		   {
								while(DSP2TivaRegs.regs.SWUpdateCtrl.bits.Finish != 1)
								{
									DSP2TivaRegs.regs.SWUpdateCtrl.bits.Finish = 1;
								}

								DSP2TivaRegs.regs.SWUpdateStat.usAll = 0;
								DSP2TivaRegs.regs.SWUpdateStat.bits.SWUpdateOK = 1;
								asm("    LCR #0x33FFF6");				// Jump to FLASHA Entry point.
			    		   }
			    	   }
//				   }
//				   else							// CheckSum hatas�
//				   {
//					   DSP2TivaRegs.regs.SWUpdateStat.bits.CheckSumErr = 1;
//					   DSP2TivaRegs.regs.checksum = CheckSum;
//
//						while(DSP2TivaRegs.regs.SWUpdateCtrl.bits.Error != 1)
//						{
//							DSP2TivaRegs.regs.SWUpdateCtrl.bits.Error = 1;
//						}
//
//						asm("    LCR #0x33FFF6");				// Jump to FLASHA Entry point.
//				   }
			   }

			   PackUpdateWaitCounter++;

			   if(PackUpdateWaitCounter >= 1000)				// Package Update Hatas�
			   {
				   DSP2TivaRegs.regs.SWUpdateStat.bits.PackUpdateTimeout = 1;

					while(DSP2TivaRegs.regs.SWUpdateCtrl.bits.Error != 1)
					{
						DSP2TivaRegs.regs.SWUpdateCtrl.bits.Error = 1;
					}

				   asm("    LCR #0x33FFF6");					// Jump to FLASHA Entry point.
			   }

		   }
	   }
	   else
	   {
		   PackWriteWaitCounter++;

		   if(PackWriteWaitCounter >= 1000)						// Package Write hatas�
		   {
			   DSP2TivaRegs.regs.SWUpdateStat.bits.PackWriteTimeout = 1;

				while(DSP2TivaRegs.regs.SWUpdateCtrl.bits.Error != 1)
				{
					DSP2TivaRegs.regs.SWUpdateCtrl.bits.Error = 1;
				}

			   asm("    LCR #0x33FFF6");								// Jump to FLASHA Entry point.
		   }
	   }

	   while(DelayCounter < 10000)			// gecikme sa�lamak i�in
	   {
		   DelayCounter++;
	   }
	   DelayCounter = 0;
   }


/*------------------------------------------------------------------
  Program Flash Examples

------------------------------------------------------------------*/

// A buffer can be supplied to the program function.  Each word is
// programmed until the whole buffer is programmed or a problem is
// found.  If the buffer goes outside of the range of OTP or Flash
// then nothing is done and an error is returned.


    // Example: Program 0x400 values in Flash Sector B

//    // In this case just fill a buffer with data to program into the flash.
//    for(i=0;i<WORDS_IN_FLASH_BUFFER;i++)
//    {
//        Buffer[i] = 0x100+i;
//    }
//
//    Flash_ptr = Sector[1].StartAddr;
//    Length = 0x400;
//    Status = Flash_Program(Flash_ptr,Buffer,Length,&FlashStatus);
//    if(Status != STATUS_SUCCESS)
//    {
//        Example_Error(Status);
//    }
//
//    // Verify the values programmed.  The Program step itself does a verify
//    // as it goes.  This verify is a 2nd verification that can be done.
//    Status = Flash_Verify(Flash_ptr,Buffer,Length,&FlashStatus);
//    if(Status != STATUS_SUCCESS)
//    {
//        Example_Error(Status);
//    }

//
//    //Example_Done();
//
//    DSP2TivaRegs.regs.Deneme = 42;
//
//	asm("    LCR #0x33FFF6");
//
} 


/*------------------------------------------------------------------
  Simple memory copy routine to move code out of flash into SARAM
-----------------------------------------------------------------*/

void Example_MemCopy(Uint16 *SourceAddr, Uint16* SourceEndAddr, Uint16* DestAddr)
{
    while(SourceAddr < SourceEndAddr)
    { 
       *DestAddr++ = *SourceAddr++;
    }
    return;
}


/*------------------------------------------------------------------
  For this example, if an error is found just stop here
-----------------------------------------------------------------*/
#pragma CODE_SECTION(Example_Error,"SWramfuncs");
void Example_Error(Uint16 Status)
{

//  Error code will be in the AL register. 
    asm("    ESTOP0");
    asm("    SB 0, UNC");
}


/*------------------------------------------------------------------
  For this example, once we are done just stop here
-----------------------------------------------------------------*/
#pragma CODE_SECTION(Example_Done,"SWramfuncs");
void Example_Done(void)
{

    asm("    ESTOP0");
    asm("    SB 0, UNC");
}       


/*------------------------------------------------------------------
  Callback function - must be executed from outside flash/OTP
-----------------------------------------------------------------*/
#pragma CODE_SECTION(MyCallbackFunction,"SWramfuncs");
void MyCallbackFunction(void)
{       
    // Toggle pin, service external watchdog etc
    MyCallbackCounter++;
    asm("    NOP");

}







