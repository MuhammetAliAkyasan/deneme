//###########################################################################
//
// FILE:  Example_Flash2833x_API.h	
//
// TITLE: F2833x Flash API example include file
//
// DESCRIPTION:
//
// Function prototypes and macros for the F2833x Flash API library examples.
//
//###########################################################################
// $TI Release: F2833x API Release V1.0 $
// $Release Date: September 14, 2007 $
//###########################################################################


#ifndef EXAMPLE_FLASH2833x_API_H
#define EXAMPLE_FLASH2833x_API_H


//---------------------------------------------------------------------------
// For Portability, User Is Recommended To Use Following Data Type Size
// Definitions For 16-bit and 32-Bit Signed/Unsigned Integers:
//

#ifndef DSP28_DATA_TYPES
#define DSP28_DATA_TYPES
typedef int             int16;
typedef long            int32;
typedef unsigned int    Uint16;
typedef unsigned long   Uint32;
typedef float           float32;
typedef long double     float64;
#endif

/*---- DSP2833x Header Files -- from TI's website. ----------*/
#include "DSP2833x_Gpio.h"
#include "DSP2833x_SysCtrl.h"

/*---- flash program files -------------------------------------------------*/
#include "Flash2833x_API_Library.h"

/*---------------------------------------------------------------------------
   Functions used by this example
*---------------------------------------------------------------------------*/
extern void DSPFlashUpdate(void);

void Example_CallFlashAPI(void);        // Kernel function that interfaces to the API
void Example_Error(Uint16 Status);      // If an error, stop here
void Example_Done(void);                // If done, stop here
void Example_MemCopy(Uint16 *SourceAddr, Uint16* SourceEndAddr, Uint16* DestAddr);

/*---------------------------------------------------------------------------
  Symbols used to copy support functions from Flash to RAM 
  These symbols are assigned by the linker.  Refer to the .cmd file
---------------------------------------------------------------------------*/

extern Uint16 SWRamfuncsLoadStart;
extern Uint16 SWRamfuncsLoadEnd;
extern Uint16 SWRamfuncsRunStart;

//---------------------------------------------------------------------------
// Common CPU Definitions used by this example:
//

#define	 EALLOW	asm(" EALLOW")
#define	 EDIS	asm(" EDIS")
#define  DINT   asm(" setc INTM")


#endif // ---- End of EXAMPLE_FLASH2833x_API_H     
