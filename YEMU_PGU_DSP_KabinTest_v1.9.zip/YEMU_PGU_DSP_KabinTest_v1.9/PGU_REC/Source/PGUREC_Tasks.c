#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUREC_Common.h"

// Virtual Timers
int16	PGUREC_VTimer0[4]={0,0,0,0};		// 	Virtual Timers slaved off CPU Timer 0 (A events)
int16	PGUREC_VTimer1[4]={0,0,0,0}; 	// 	Virtual Timers slaved off CPU Timer 1 (B events)
int16	PGUREC_VTimer2[4]={0,0,0,0};     // 	Virtual Timers slaved off CPU Timer 2 (C events)

float32 PriPowSign =  0.0;
float32 SecPowSign =  0.0;

Uint16  PGUREC_FaultDataDelayCnt = 0;          // Delay Counter for writing first fault data


// State Machine variable declarations
void (*PGUREC_Alpha_State_Ptr)(void);    //  Base States pointer
void (*PGUREC_A_Task_Ptr)(void);         //  State pointer A branch
void (*PGUREC_B_Task_Ptr)(void);         //  State pointer B branch
void (*PGUREC_C_Task_Ptr)(void);         //  State pointer C branch

//=================================================================================
//	STATE-MACHINE SEQUENCING AND SYNCRONIZATION FOR SLOW BACKGROUND TASKS
//=================================================================================

void PGUREC_TaskInit(void)
{
    // Tasks State-machine init
    PGUREC_Alpha_State_Ptr = &PGUREC_A0;
    PGUREC_A_Task_Ptr = &PGUREC_A1;
    PGUREC_B_Task_Ptr = &PGUREC_B1;
    PGUREC_C_Task_Ptr = &PGUREC_C1;
}

void PGUREC_TaskLoop(void)
{
    // State machine entry & exit point
    //===========================================================
    (*PGUREC_Alpha_State_Ptr)();   // jump to an Alpha state (A0,B0,...)
    //===========================================================
}

//--------------------------------- FRAMEWORK -------------------------------------
void PGUREC_A0(void)
{
	// loop rate synchronizer for A-tasks
	if(CpuTimer0Regs.TCR.bit.TIF == 1)
	{
		CpuTimer0Regs.TCR.bit.TIF = 1;	// clear flag
		//-----------------------------------------------------------
		(*PGUREC_A_Task_Ptr)();		    // jump to an A Task (A1,A2,A3,...)
		//-----------------------------------------------------------

		PGUREC_VTimer0[0]++;			    // virtual timer 0, instance 0 (spare)
	}

	PGUREC_Alpha_State_Ptr = &PGUREC_B0;	// Jump to State B0
}

void PGUREC_B0(void)
{
	// loop rate synchronizer for B-tasks
	if(CpuTimer1Regs.TCR.bit.TIF == 1)
	{
		CpuTimer1Regs.TCR.bit.TIF = 1;	// clear flag

		//-----------------------------------------------------------
		(*PGUREC_B_Task_Ptr)();		    // jump to a B Task (B1,B2,B3,...)
		//-----------------------------------------------------------
		PGUREC_VTimer1[0]++;			    // virtual timer 1, instance 0 (spare)
	}

	PGUREC_Alpha_State_Ptr = &PGUREC_C0;	// Jump to State C0
}

void PGUREC_C0(void)
{
	// loop rate synchronizer for C-tasks
	if(CpuTimer2Regs.TCR.bit.TIF == 1)
	{
		CpuTimer2Regs.TCR.bit.TIF = 1;	// clear flag

		//-----------------------------------------------------------
		(*PGUREC_C_Task_Ptr)();		    // jump to a C Task (C1,C2,C3,...)
		//-----------------------------------------------------------
		PGUREC_VTimer2[0]++;			    //virtual timer 2, instance 0 (spare)
	}

	PGUREC_Alpha_State_Ptr = &PGUREC_A0;	// Back to State A0
}

//=================================================================================
//	PGUREC_A - TASKS
//=================================================================================


//-----------------------------------------
void PGUREC_A1(void)
//-----------------------------------------
{
    SWUpdateCheck();

    PGUREC_HWFaultLimitCalc();
    PGUREC_HWFaultLimitSet();            // HW Protection Value Set

	PGUREC_A_Task_Ptr = &PGUREC_A2;		//the next time CpuTimer0 'counter' reaches Period value go to A2
	PGUREC_VTimer0[1]++;
}

//-----------------------------------------
void PGUREC_A2(void)
//-----------------------------------------
{
	PGUREC_A_Task_Ptr = &PGUREC_A3;		//the next time CpuTimer0 'counter' reaches Period value go to A3
	PGUREC_VTimer0[2]++;
}

//-----------------------------------------
void PGUREC_A3(void)
//-----------------------------------------
{
	PGUREC_A_Task_Ptr = &PGUREC_A1;		//the next time CpuTimer0 'counter' reaches Period value go to A1
	PGUREC_VTimer0[3]++;
}

//=================================================================================
//	PGUREC_B - TASKS
//=================================================================================
//----------------------------------------
void PGUREC_B1(void)
//----------------------------------------
{
	PGUREC_B_Task_Ptr = &PGUREC_B2;		//the next time CpuTimer1 'counter' reaches Period value go to B2
	PGUREC_VTimer1[1]++;
}

//----------------------------------------
void PGUREC_B2(void)
//----------------------------------------
{
    SPIADCRead(&(SPIADCValues.CH0));

    if(PGUREC_CKU1 == 1)         // 6s Delay = 400*15ms
        {
        PGUREC_TemperatureRead1();            // Temperature Read from TSC
        }

    if(PGUREC_CKU2 == 1)         // 6s Delay = 400*15ms
        {
        PGUREC_TemperatureRead2();            // Temperature Read from TSC
        }

	PGUREC_B_Task_Ptr = &PGUREC_B3;		//the next time CpuTimer1 'counter' reaches Period value go to B3
	PGUREC_VTimer1[2]++;
}

//----------------------------------------
void PGUREC_B3(void)
//----------------------------------------
{
    PGUREC_WriteMonData(PGUREC_VTimer1[3]);     // Ethernet Monitoring Data Exchange via Dual Port Memory

	PGUREC_B_Task_Ptr = &PGUREC_B1;		//the next time CpuTimer1 'counter' reaches Period value go to B1
	PGUREC_VTimer1[3]++;
}

//=================================================================================
//	PGUREC_C - TASKS
//=================================================================================
//----------------------------------------
void PGUREC_C1(void)
//----------------------------------------
{

	PGUREC_C_Task_Ptr = &PGUREC_C2;		//the next time CpuTimer2 'counter' reaches Period value go to C2
	PGUREC_VTimer2[1]++;
}

//----------------------------------------
void PGUREC_C2(void)
//----------------------------------------
{

    PriPowSign =  ((float32) ((RealP_p.Power) > 0.0) - ((RealP_p.Power) < 0.0))*1.0;
    SecPowSign =  ((float32) ((RealP_s.Power) > 0.0) - ((RealP_s.Power) < 0.0))*1.0;

    PGUREC_WriteCANData((Uint16)PGUREC_VTimer2[2]);     // CAN Data Exchange via Dual Port Memory

	PGUREC_C_Task_Ptr = &PGUREC_C3;				//the next time CpuTimer2 'counter' reaches Period value go to C3
	PGUREC_VTimer2[2]++;
}

//-----------------------------------------
void PGUREC_C3(void)
//-----------------------------------------
{

    if(PGUREC_FaultDataDelayCnt< 400)         // 6s Delay = 400*15ms
      {
          PGUREC_FaultDataDelayCnt++;
      }
      else
      {
          PGUREC_WriteFaultData();
      }
	PGUREC_C_Task_Ptr = &PGUREC_C1;		//the next time CpuTimer2 'counter' reaches Period value go to C1
	PGUREC_VTimer2[3]++;
}


