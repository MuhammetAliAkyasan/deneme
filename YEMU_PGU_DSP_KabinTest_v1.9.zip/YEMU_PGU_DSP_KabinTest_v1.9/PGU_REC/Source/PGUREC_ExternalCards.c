#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUREC_Common.h"

// FOIO Functions
void PGUREC_InitFOIO(void)
{
//    // FOIO Initial Reset Procedure
//    IO_CLR(PGUREC_FOIORst)                     //  Boot-up reset value is high. Clear FOIO reset signal
//    DELAY_US(1);
//    IO_SET(PGUREC_FOIORst)                     //  Set FOIO reset signal
//    DELAY_US(1);
//    IO_CLR(PGUREC_FOIORst)                     //  Clear FOIO reset signal
}

// FDPC Functions
void PGUREC_InitTCPU(void)
{
    // FDPC Initial Reset Procedure
//    IO_CLR(PGUREC_FDPCRst)                     //  Boot-up reset value is high. Clear FDPC reset signal
    DELAY_US(1);
//    IO_SET(PGUREC_FDPCRst)                     //  Set FDPC reset signal
    DELAY_US(1);
//    IO_CLR(PGUREC_FDPCRst)                     //  Clear FDPC reset signal
}

void PGUREC_HWFaultLimitSet()
{
#ifdef LAB_DYNO

    SPIDACWrite(0,     PGUREC_DACChannels.MOCErrVoltage);
    SPIDACWrite(1,     2.9);
    SPIDACWrite(2,     2.9);
    SPIDACWrite(3,     2.9);
    SPIDACWrite(4,     2.9);
    SPIDACWrite(5,     2.869); // DC Voltage (1900V/40000.0)*60.4ohm = 2.869V
    SPIDACWrite(6,     2.869); // DC Voltage (1900V/40000.0)*60.4ohm = 2.869V
    SPIDACWrite(7,     2.9);


#else
    SPIDACWrite (0,     3.0);         //Giri� ak�m�
    SPIDACWrite (1,     PGUREC_DACChannels.VDCA1ErrVoltage);       //��k�� ak�m� PGUREC_DACChannels.Rsvd1
    SPIDACWrite (2,     PGUREC_DACChannels.RICC1ErrVoltage);
    SPIDACWrite (3,     PGUREC_DACChannels.RICC2ErrVoltage); //
    SPIDACWrite (4,     3.0);
    SPIDACWrite (5,     3.0);
    SPIDACWrite (6,     3.0);//PGUREC_DACChannels.COVErrVoltage);
    SPIDACWrite (7,     3.0);
    SPIDAC2Write(0,     PGUREC_DACChannels.COVErrVoltage); //3.0
    }
#endif

void PGUREC_HWFaultLimitCalc()
{

    PGUREC_DACChannels.VDCA1ErrVoltage    =        (PGUREC_HWProtLevels.VDCA1ErrVoltage    / PGUREC_Measure.Ratio.Volt_DCLink)       *0.99;      // DC link over voltage limit value
    PGUREC_DACChannels.RICC1ErrVoltage    = 1.50 + (PGUREC_HWProtLevels.RICC1ErrVoltage    / PGUREC_Measure.Ratio.Cur_RectInput1)    *0.99;      // Rectifier over current limit value
    PGUREC_DACChannels.RICC2ErrVoltage    = 1.50 + (PGUREC_HWProtLevels.RICC2ErrVoltage    / PGUREC_Measure.Ratio.Cur_RectInput2)    *0.99;        // Primer over current limit value
    PGUREC_DACChannels.COVErrVoltage      = 1.50 + (PGUREC_HWProtLevels.COVErrVoltage      / PGUREC_Measure.Ratio.Volt_Catenary)     *0.99;      // Catenary over voltage limit value
}

void PGUREC_TemperatureRead1()
{
    // NTC denklemi - y=Sicaklik x=Gerilim - y = -14,05x3 + 70,352x2 - 151,78x + 188,13


    float32   ChV;
    Uint16    Ch;
    Uint16    SType;
    Uint16    ind;
    float32  *dest;
    float32  *destLPF;
    float32  *source;
    Uint16   *ChSelSource;

    dest        = &(PGUREC_Temperature_CKU1.RectifierTemp1);
    destLPF     = &(PGUREC_TemperatureLPF_CKU1.RectifierTemp1);
    source      = &(SPIADCValues.CH0);
    ChSelSource = &(PGUREC_Temperature_ChSel_CKU1.RECTTemp1);

    for(ind=0;ind<PGUREC_TEMPChNUM_CKU1;ind++)
    {
        Ch    = ((*(ChSelSource+ind))&0xFF00)>>8;
        SType = ((*(ChSelSource+ind))&0x00FF);

        ChV   = (*(source+(Ch)));


#ifdef LAB_DYNO

        if(SType==NTCTYPE)
        {
            *(dest+ind)= 0.0; //-14.05*(ChV*ChV*ChV) + 70.352*(ChV*ChV) - 151.78*ChV + 188.13;
        }
        else if (SType==PT100TYPE)
        {
            *(dest+ind)=56.67 * ChV - 24.00;
        }
        else
        {
            *(dest+ind)=0.0;
        }

#else

        if      (SType==NTCTYPE)
                {
                    *(dest+ind)=-16.265*(ChV*ChV*ChV) + 80.591*(ChV*ChV) - 160.55*ChV + 165.59;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else if (SType==NTC2TYPE)
                {
                   *(dest+ind)=-19.724*(ChV*ChV*ChV) + 98.216*(ChV*ChV)- 180.48*ChV + 141.65;//-31.05*logf(ChV) + 25.085;
                }

        else if (SType==HUMTYPE )
                {
                   *(dest+ind)=37.491 * ChV;
                   *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else if (SType==HUMTYPE_NTC )
                {
                    *(dest+ind)=(44.989*ChV-40.0);
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else if (SType==PT100TYPE)
                {
        //          *(dest+ind)=59.567 * ChV - 18.495;    //Eski PT100 denklemi
                    *(dest+ind)=96.918 * ChV - 30.161;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else
                {
                    *(dest+ind)=0.0;
                }

#endif

    }
}


void PGUREC_TemperatureRead2()
{
    // NTC denklemi - y=Sicaklik x=Gerilim - y = -14,05x3 + 70,352x2 - 151,78x + 188,13


    float32   ChV;
    Uint16    Ch;
    Uint16    SType;
    Uint16    ind;
    float32  *dest;
    float32  *destLPF;
    float32  *source;
    Uint16   *ChSelSource;

    dest        = &(PGUREC_Temperature_CKU2.RectifierTemp1);
    destLPF     = &(PGUREC_TemperatureLPF_CKU2.RectifierTemp1);
    source      = &(SPIADCValues.CH0);
    ChSelSource = &(PGUREC_Temperature_ChSel_CKU2.RECTTemp1);

    for(ind=0;ind<PGUREC_TEMPChNUM_CKU2;ind++)
    {
        Ch    = ((*(ChSelSource+ind))&0xFF00)>>8;
        SType = ((*(ChSelSource+ind))&0x00FF);

        ChV   = (*(source+(Ch)));


#ifdef LAB_DYNO

        if(SType==NTCTYPE)
        {
            *(dest+ind)= 0.0; //-14.05*(ChV*ChV*ChV) + 70.352*(ChV*ChV) - 151.78*ChV + 188.13;
        }
        else if (SType==PT100TYPE)
        {
            *(dest+ind)=56.67 * ChV - 24.00;
        }
        else
        {
            *(dest+ind)=0.0;
        }

#else

        if      (SType==NTCTYPE)
                {
                    *(dest+ind)=-16.265*(ChV*ChV*ChV) + 80.591*(ChV*ChV) - 160.55*ChV + 165.59;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else if (SType==NTC2TYPE)
                {
                   *(dest+ind)=-19.724*(ChV*ChV*ChV) + 98.216*(ChV*ChV)- 180.48*ChV + 141.65;//-31.05*logf(ChV) + 25.085;
                }

        else if (SType==FLOWTYPE )
                {
                    if (ChV < 0.48)
                    {
                        *(dest+ind)=0;
                    }
                    else
                    {
                        *(dest+ind)=(344.12 *ChV - 154.21);
                    }
//                    *(dest+ind)=(300.47 *ChV - 127.82);
//                    *(dest+ind)=(436.04 *ChV - 209.57);
//                    *(dest+ind)=(268.75 *ChV-128.78); //16.667 m^3/h to L/min
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else if (SType==FLOWTYPE_NTC )
                {
                    *(dest+ind)=(91.146 *ChV - 68.75);
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);

                }

        else if (SType==PT100TYPE)
                {
        //          *(dest+ind)=59.567 * ChV - 18.495;    //Eski PT100 denklemi
                    *(dest+ind)=96.918 * ChV - 30.161;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else
                {
                    *(dest+ind)=0.0;
                }

#endif

    }
}









