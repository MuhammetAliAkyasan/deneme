#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUREC_Common.h"


//--MACRO VARIABLES and INSTANCES
Uint16   PGUREC_DSPADCChSel[16]   = PGUREC_ADC_CHANNELS;     //  ADC init macro channel assignment for PGUREC

PGUREC_MEASUREMENT                 PGUREC_Measure         = PGUREC_MEASUREMENT_INIT;         //  ADC measurement instance and initialization for PGUREC
PGUREC_MEASUREMENTVARIABLES        PGUREC_ADCOffsets      = PGUREC_ADC_OFFSET_INIT;          //  ADC measurement offset instance for PGUREC
PGUREC_ADC_FLT_REG                 PGUREC_ADCErrFlags     = PGUREC_ADC_ERR_INIT;             //  Measurement error flags initialization


MASTERC_REGS        PGUREC_MasterContr             = {0x0000,0x0000,0x0000,0.0};
TORQUELIM_REG       TORQLIM_REG             = {0x0000};

CONVCTL_REG		    PGUREC_CTL_REG 	        = {0x0000};
CONVFLT_REG		    PGUREC_FLT_REG 	        = {0x0000};

VS                  Vs                      = {0.0,0.0,0.0,0.0,0.0};

PGUREC_TEMPSTS_REG_CKU1   PGUREC_TempErrFlags_CKU1 	    = {0x0000};
PGUREC_TEMPSTS_REG_CKU1   PGUREC_TempWarnFlags_CKU1	    = {0x0000};

PGUREC_TEMPSTS_REG_CKU2   PGUREC_TempErrFlags_CKU2      = {0x0000};
PGUREC_TEMPSTS_REG_CKU2   PGUREC_TempWarnFlags_CKU2     = {0x0000};

PGUREC_SWPROTFLT_REG	  PGUREC_SWProtErrFlags         = {0x0000};
PGUREC_SWPROTFLT_REG	  PGUREC_SWProtWarnFlags        = {0x0000};

PGUREC_SWPROTFLTCatenary_REG    PGUREC_SWProtCatenaryErrFlags      = {0x0000};
PGUREC_SWPROTFLTCatenary_REG    PGUREC_SWProtCatenaryWarnFlags     = {0x0000};

PRECCTL_REG         PRECHCTL_REG1            = {0x0000};
PRECCTL_REG         PRECHCTL_REG2            = {0x0000};

PRECH               PreCh                   = PRECH_INIT;

CONTACTOR_REG       PCC1_REG                 = {0x0000};
CONTACTOR_REG       PCC2_REG                 = {0x0000};

CONTACTOR_REG       MCAUX_REG1                  = {0x0000};
CONTACTOR_REG       MCAUX_REG2                  = {0x0000};


CONTACFLT_REG       PGU_ContacErrFlags1    = {0x0000};
CONTACFLT_REG       PGU_ContacErrFlags2    = {0x0000};

// 501
PGUREC_TEMPERATURE_CKU1 	   PGUREC_Temperature_CKU1 	         = PGUREC_TEMP_MEAS_INIT_CKU1;			 //  Temperature measurement instance and initialization
PGUREC_TEMPERATURE_CKU1        PGUREC_TemperatureLPF_CKU1        = PGUREC_TEMP_MEAS_INIT_CKU1;           //  Temperature measurement instance and initialization
PGUREC_TEMPERATURE_CKU1 	   PGUREC_TempWarnLimits_CKU1        = PGUREC_TEMP_WARN_INIT_CKU1;			 //	 Temperature measurement warning limits
PGUREC_TEMPERATURE_CKU1 	   PGUREC_TempErrLimits_CKU1	     = PGUREC_TEMP_ERR_INIT_CKU1;			 //	 Temperature measurement error limits

PGUREC_TEMP_CHSEL_CKU1         PGUREC_Temperature_ChSel_CKU1     = PGUREC_TEMP_CHSEL_INIT_CKU1;          //  Temperature measurement initialization for channel selection and sensor types

PGUREC_TEMPERATURE_CKU2        PGUREC_Temperature_CKU2           = PGUREC_TEMP_MEAS_INIT_CKU2;           //  Temperature measurement instance and initialization
PGUREC_TEMPERATURE_CKU2        PGUREC_TemperatureLPF_CKU2        = PGUREC_TEMP_MEAS_INIT_CKU2;           //  Temperature measurement instance and initialization
PGUREC_TEMPERATURE_CKU2        PGUREC_TempWarnLimits_CKU2        = PGUREC_TEMP_WARN_INIT_CKU2;           //  Temperature measurement warning limits
PGUREC_TEMPERATURE_CKU2        PGUREC_TempErrLimits_CKU2         = PGUREC_TEMP_ERR_INIT_CKU2;            //  Temperature measurement error limits

PGUREC_TEMP_CHSEL_CKU2         PGUREC_Temperature_ChSel_CKU2     = PGUREC_TEMP_CHSEL_INIT_CKU2;          //  Temperature measurement initialization for channel selection and sensor types


PGUREC_SWPROT 		           PGUREC_SWProtFdbs		         = PGUREC_SWPROT_INIT;
PGUREC_SWPROTLEVELS	           PGUREC_SWProtWarnLimits           = PGUREC_SWPROT_WARN_INIT;   	         //  Feedback Signals warning limits
PGUREC_SWPROTLEVELS	           PGUREC_SWProtErrLimits	         = PGUREC_SWPROT_ERR_INIT;  	         //  Feedback Signals error limits
PGUREC_SWPROTCOUNT	           PGUREC_SWProtErrTime	             = PGUREC_SWPROT_COUNT_INIT;
PGUREC_SWPROTCOUNT	           PGUREC_SWProtErrCount	         = PGUREC_SWPROT_COUNT_INIT;


PGUREC_SWPROT_Catenary         PGUREC_SWProtFdbsCatenary         = PGUREC_SWPROTCatenay_INIT;
PGUREC_SWPROTLEVELS_Catenary   PGUREC_SWProtWarnLimitsCatenary   = PGUREC_SWPROTCatenary_WARN_INIT;       //  Feedback Signals warning limits
PGUREC_SWPROTLEVELS_Catenary   PGUREC_SWProtErrLimitsCatenary    = PGUREC_SWPROTCatenary_ERR_INIT;        //  Feedback Signals error limits
PGUREC_SWPROTCOUNTCatenary     PGUREC_SWProtErrTimeCatenary      = PGUREC_SWPROTCatenary_COUNT_INIT;
PGUREC_SWPROTCOUNTCatenary     PGUREC_SWProtErrCountCatenary     = PGUREC_SWPROTCatenary_COUNT_INIT;



PGUREC_HWPROT	    PGUREC_DACChannels      = PGUREC_HW_PROT_DAC_LIMITS_INIT;	// 	HW Protection Limit instance, FDPC LIMIT VALUES (RAW Data)
PGUREC_HWPROT	    PGUREC_HWProtLevels	    = PGUREC_HW_PROT_LEVELS_INIT;		// 	HW Protection Levels (actual values)





