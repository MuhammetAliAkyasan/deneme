
#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUREC_Common.h"

Uint16    PGUREC_CCU1_Lifesign                     = 0;
//    ActualTime
Uint16    PGUREC_S_Coupling                        = 0;
Uint16    PGUREC_S_Lead_Follow_consist             = 0;
Uint16    PGUREC_S_CAB_Active                      = 0;
Uint16    PGUREC_S_Direction                       = 0;
Uint16    PGUREC_CouplingStatus                    = 0;
Uint16    PGUREC_1stTrainSetConfiguration          = 0;
Uint16    PGUREC_2ndTrainSetConfiguration          = 0;

Uint16    PGUREC_CCU2_Lifesign                         = 0;
Uint16    PGUREC_TL_Enable_TC1_SKA1                    = 0;
Uint16    PGUREC_TL_Enable_TC2_SKA1                    = 0;
Uint16    PGUREC_TL_Enable_TC1_SKA2                    = 0;
Uint16    PGUREC_TL_Enable_TC2_SKA2                    = 0;
Uint16    PGUREC_TL_Normal_Rescue_SKA1                 = 0;
Uint16    PGUREC_TL_Normal_Rescue_SKA2                 = 0;
Uint16    PGUREC_TL_Speed_Limit_SKA1                   = 0;
Uint16    PGUREC_TL_Speed_Limit_SKA2                   = 0;
Uint16    PGUREC_TL_Cabs_Mode                          = 0;
Uint16    PGUREC_TL_SKA1_Forward                       = 0;
Uint16    PGUREC_TL_SKA1_Reverse                       = 0;
Uint16    PGUREC_TL_SKA2_Forward                       = 0;
Uint16    PGUREC_TL_SKA2_Reverse                       = 0;
Uint16    PGUREC_TL_Traction_CutOff_SKA1               = 0;
Uint16    PGUREC_TL_Traction_CutOff_SKA2               = 0;
Uint16    PGUREC_TL_Relay_Security_Emergency_Loop_SKA1 = 0;
Uint16    PGUREC_TL_Relay_Security_Emergency_Loop_SKA2 = 0;
Uint16    PGUREC_TL_MC_S1                              = 0;
Uint16    PGUREC_TL_MC_S2                              = 0;
Uint16    PGUREC_TL_MC_S3                              = 0;
Uint16    PGUREC_TL_MC_S4                              = 0;
Uint16    PGUREC_TL_MC_S5                              = 0;
Uint16    PGUREC_TL_MC_S6                              = 0;
Uint16    PGUREC_STS_Cutoff_bypass                     = 0;
Uint16    PGUREC_TL_VCB_On_Off_OA1                     = 0;
Uint16    PGUREC_TL_VCB_On_Off_OA2                     = 0;
Uint16    PGUREC_VCB_Opening_Warning                   = 0;
Uint16    PGUREC_TC_SKA1_HV_Expected                   = 0;
Uint16    PGUREC_TC_SKA2_HV_Expected                   = 0;
Uint16    PGUREC_Cmd_Traction_Null                     = 0;
Uint16    PGUREC_Cmd_Traction_Cutoff                   = 0;
Uint16    PGUREC_Cmd_EDB_Deactivate                    = 0;
Uint16    PGUREC_Cmd_Speed_Limit                       = 0;
Uint16    PGUREC_Cmd_ASC_Mode                          = 0;
Uint16    PGUREC_Cmd_Traction_Reduction_Lvl1_SKA1      = 0;
Uint16    PGUREC_Cmd_Traction_Reduction_Lvl2_SKA1      = 0;
Uint16    PGUREC_Cmd_Traction_Reduction_Lvl1_SKA2      = 0;
Uint16    PGUREC_Cmd_Traction_Reduction_Lvl2_SKA2      = 0;
Uint16    PGUREC_Cmd_Reset_SKA1_TC1                    = 0;
Uint16    PGUREC_Cmd_Reset_SKA1_TC2                    = 0;
Uint16    PGUREC_Cmd_Reset_SKA2_TC1                    = 0;
Uint16    PGUREC_Cmd_Reset_SKA2_TC2                    = 0;
Uint16    PGUREC_Cmd_OOS_SKA1_TC1                      = 0;
Uint16    PGUREC_Cmd_OOS_SKA1_TC2                      = 0;
Uint16    PGUREC_Cmd_OOS_SKA2_TC1                      = 0;
Uint16    PGUREC_Cmd_OOS_SKA2_TC2                      = 0;
Uint16    PGUREC_ASC_Target                            = 0;
Uint16    PGUREC_Train_Speed                           = 0;
Uint16    PGUREC_SKA1_wheel_diameter_1                 = 0;
Uint16    PGUREC_SKA1_wheel_diameter_2                 = 0;
Uint16    PGUREC_SKA1_wheel_diameter_3                 = 0;
Uint16    PGUREC_SKA1_wheel_diameter_4                 = 0;
Uint16    PGUREC_SKA2_wheel_diameter_1                 = 0;
Uint16    PGUREC_SKA2_wheel_diameter_2                 = 0;
Uint16    PGUREC_SKA2_wheel_diameter_3                 = 0;
Uint16    PGUREC_SKA2_wheel_diameter_4                 = 0;
Uint16    PGUREC_Catenary_Voltage                      = 0;

extern Uint16 PGUREC_Lifesign;

extern float32 VCatenary;


void PGUREC_ReadCANData(void)
{
//      DIOC_Inputs1.all = DIOCRXMsg.MSG1.all;         // Read DIOC Inputs
//      DIOC_Inputs2.all = DIOCRXMsg.MSG2.all;
//
//      DIOC_Inputs1N.all = DIOCRXMsgN.MSG1.all;
//      DIOC_Inputs2N.all = DIOCRXMsgN.MSG2.all;

//      PGUREC_TCPU_Inputs.all   = TCPURXMsg.MSG1.all;         // Read DIOC Inputs



//      PGU_TeRefCAN            = ((float32)CANRXMsg.C1.TORQUE_REF)- 5000.0;
//      PGUREC_Reverser          = (Uint16)CANRXMsg.C2.REVERSER_STAT;
//      PGUREC_MasterContrStat   = (Uint16)CANRXMsg.C2.MASTERCONT_STAT;
//      PGUREC_ConvEnable        = (Uint16)CANRXMsg.C2.ENABLE;
////      PGUREC_VCBStatus         = (Uint16)CANRXMsg.C2.VCB_STAT;

      PGUREC_ERTMSBrake        = (Uint16)PGUREC_TCPU_Inputs.bit.RSVD1;
      PGUREC_TractInh          = (Uint16)PGUREC_TCPU_Inputs.bit.Trac_CuttOff;
//      PGUREC_EDBrakeCut        = (Uint16)PGUREC_TCPU_Inputs.bit.EDB_Cutout;
      PGUREC_Trac_Null        = (Uint16)PGUREC_TCPU_Inputs.bit.Trac_Null;


//      PreFuse                 = (Uint16)DIOC_Inputs1.bit.Prefuse ;
//      CKU_Ident0_REC              = (Uint16)DIOC_Inputs1.bit.ID0 ;
//      CKU_Ident1_REC              = (Uint16)DIOC_Inputs1.bit.ID1 ;
//      CKU_Ident2_REC              = (Uint16)DIOC_Inputs1.bit.ID2 ;
//      CKU_Ident3_REC              = (Uint16)DIOC_Inputs1.bit.ID3 ;


//      PGUREC_Emergency_Degraded      = (Uint16)(DIOC_Inputs1.bit.Emerge_DEGRADED && !DIOC_Inputs1N.bit.Emerge_DEGRADED);
//      PGUREC_Emergency1              = (Uint16)(DIOC_Inputs2.bit.Emerge_POWER1  && !DIOC_Inputs2N.bit.Emerge_POWER1);
//      PGUREC_Emergency2              = (Uint16)(DIOC_Inputs2.bit.Emerge_POWER2  && !DIOC_Inputs2N.bit.Emerge_POWER2);
//      PGUREC_Emergency3              = (Uint16)(DIOC_Inputs2.bit.Emerge_POWER3  && !DIOC_Inputs2N.bit.Emerge_POWER3);

}


void PGUREC_WriteCANData(Uint16 WriteCount)
{
//      PGUREC_TCPU_Outputs.bit.MCCAUX_SIG = 1 ;

//
//
//    // ***************************************************
//    // CAN MESSAGE:1
//    //  Motor Data */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG1.uiBuffer[0].all   = (Uint16) (10.0 * PGUINV_MotSpeed     + 30000.0);
//    CANTXMsg.TX_MSG1.uiBuffer[1].all   = (Uint16) (10.0 * PGUINV_MotTorque    + 30000.0);
//    CANTXMsg.TX_MSG1.uiBuffer[2].all   = (Uint16) (10.0 * PGUINV_AvailMotTorque     + 30000.0);
//    CANTXMsg.TX_MSG1.uiBuffer[3].all   = (Uint16) (PGUREC_VTimer1[1]);
//
//    // ***************************************************
//    // CAN MESSAGE:2
//    // Primary Circuit Data */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG2.uiBuffer[0].all   = (Uint16) (VCatenary);
//    CANTXMsg.TX_MSG2.uiBuffer[1].all   = (Uint16) ((10.0* PriPowSign* IPrimer )+10000.0);
//    CANTXMsg.TX_MSG2.uiBuffer[2].all   = (Uint16) (0.001   * RealP_p.Power + 2000);
//    CANTXMsg.TX_MSG2.uiBuffer[3].all   = (Uint16) (10000.0 * PowerFactor_p   + 15000.0);
//
//    // ***************************************************
//    // CAN MESSAGE:3
//    //  Converter Data  */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG3.uiBuffer[0].all   = (Uint16) ((10.0 * SecPowSign*IRec)+10000.0);
//    CANTXMsg.TX_MSG3.uiBuffer[1].all   = (Uint16) (10.0  * UdcLPF);
//    CANTXMsg.TX_MSG3.uiBuffer[2].all   = (Uint16) ((10.0 * SecPowSign*Imot)+10000.0);
//    CANTXMsg.TX_MSG3.uiBuffer[3].all   = (Uint16) (0.001 * RealP_s.Power + 500);
//
//    // ***************************************************
//    // CAN MESSAGE:4
//    // Temperature Data  */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG4.uiBuffer[0].all   = (Uint16) (10.0  * PGUINV_Temperature.InverterTemp1  );
//    CANTXMsg.TX_MSG4.uiBuffer[1].all   = (Uint16) (10.0  * PGUINV_Temperature.RectifierTemp1 );
//    CANTXMsg.TX_MSG4.uiBuffer[2].all   = (Uint16) (10.0  * PGUINV_Temperature.CabinTemp );
//    CANTXMsg.TX_MSG4.uiBuffer[3].all   = (Uint16) (10.0  * PGUINV_Temperature.MotorTemp1 );
//
//    // ***************************************************
//    // CAN MESSAGE:5
//    // DSP Software Status/Warning/Error Data */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit0  = (PGUREC_FLT_REG.all>0?1:0);                   // PGU has some faults;  1 = Failure,  0 = No failureOpen
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit1  = !PGUREC_CTL_REG.bit.ENABLE;                   // 1 = Converter/PGU is Cutout,  0 = Converter/PGU is not Cutout
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit2  = PGUREC_Trac_Null;                          // 1 = EDBrake is CutOut,  0 = EDBrake is not CutOut
//    //  CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit2  = PGUREC_EDBrakeCut;                          // 1 = EDBrake is CutOut,  0 = EDBrake is not CutOut
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit3  = SCActive;                                  // 1 = Slide Control Function is correcting slide,  0 = Not correcting slide
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit4  = SCActive;                                  // 1 = Spin Control Function is correcting spin,    0 = Not correcting sping
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit5  = PGUREC_RCTL_REG.bit.Enable;                   // 1 = Converter in Gate-Start condition,  0 = Converter not in Gate-Start condition
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit6  = PGUREC_MasterContr.REV_SW.bit.FORWARD;            // 1 = PGU in Forward mode         //   0 = PGU not in Forward
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit7  = PGUREC_MasterContr.REV_SW.bit.REVERSE;            // 1 = PGU in Reverse mode         //   0 = PGU not in Reverse
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit8  = PGUREC_MasterContr.MAIN_HAND.bit.POWERING;           // 1 = PGU in traction mode        //   0 = PGU not in traction mode
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit9  = PGUREC_MasterContr.MAIN_HAND.bit.BRAKING;            // 1 = PGU in braking mode         //   0 = PGU not in braking mode
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit10 = PGUREC_MasterContr.MAIN_HAND.bit.EMG_BRAKE;          // 1 = PGU in Emer Brake           //   0 = PGU not in Emer Brake
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit11 = PGUREC_CTL_REG.bit.DEGRADED;                  // 1 = PGU in Degraded mode        //   0 = PGU not in degraded mode
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit12 = PGUREC_EDBrakeActive*(!PGUREC_Trac_Null);   // 1 = PGU can apply EDB           //   0 = PGU can not apply EDB
//    //CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit12 = PGUREC_EDBrakeActive*(!PGUREC_EDBrakeCut);   // 1 = PGU can apply EDB           //   0 = PGU can not apply EDB
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit13 = MCAUX_REG.bit.STATUS;                      // 1 = Main Contactor Auxiliary Closed       //   0 = Main Contactor Auxiliary Open
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit14 = PCC_REG.bit.STATUS;                        // 1 = PreCharge Contactor Closed  //   0 = PreCharge Contactor Open
//    CANTXMsg.TX_MSG5.uiBuffer[0].bit.bit15 = ;                   // 1 = Earting Switch Closed       //   0 = Earting Switch Open
//
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit0  = MC1_Status;                                 // 1 = Main Contactor Closed       //   0 = Main Contactor Open
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit1  = 0;                                         // DSP WD Fault ;   1 = WD Fault     //    0 = WD OK
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit2  = 0                    ;                     // DSP Memory Fault ;   1 = Memory Fault     //    0 = Memory OK
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit3  = PGUREC_FLT_REG.bit.STEST;                     // DSP Self-Test Fault ;    1 = Fault     //    0 = OK
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit4  = 0;                                         // Converter Self-Test Fault ;    1 = Fault     //    0 = OK
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit5  = PGUREC_RCTL_REG.bit.PoweringMode;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit6  = PGUREC_RCTL_REG.bit.RegenMode;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit7  = 0;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit8  = 0;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit9  = 0;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit10 = 0;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit11 = 0;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit12 = 0;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit13 = SCSanding;
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit14 = PGUREC_FLT_REG.bit.VSPOL;                    // Vs �rnekleme Y�n hatas�
//    CANTXMsg.TX_MSG5.uiBuffer[1].bit.bit15 = PGUREC_SWProtErrFlags.bit.VdcSF;             // DC Sens�r hatas� olarak atand�.
//
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit0  = (PGUREC_SWProtCatenaryErrFlags.bit.VsOFreq || PGUREC_SWProtCatenaryErrFlags.bit.VsLFreq) ;    // Frequency irregular ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit1  = PGUREC_SWProtCatenaryErrFlags.bit.VsWave;         // Waveform irregular ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit2  = PGUREC_FLT_REG.bit.PRECH;                         // Fault of charging circuit ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit3  = PGU_ContacErrFlags.bit.MC_CER;                 // MC failure for "not closed" ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit4  = PGU_ContacErrFlags.bit.MC_OER;                 // MC failure for "not opened" ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit5  = PGU_ContacErrFlags.bit.PCC_CER;                // PCC failure for "not closed" ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit6  = PGU_ContacErrFlags.bit.PCC_OER;                // PCC failure for "not opened" ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit7  = PGUREC_SWProtCatenaryErrFlags.bit.VsOV;           // Overvoltage of Primary Circuit ;   1 = Overvoltage of Primary Circuit present    //    0 = Not overvoltage present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit8  = PGUREC_SWProtCatenaryErrFlags.bit.VsLV;;          // Low voltage of Primary Circuit ;   1 = Low voltage present    //    0 = Not low voltage present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit9  = PGUREC_SWProtErrFlags.bit.IsOC;                   // Overcurrent of Secondary Circuit 1 ;   1 = Overcurrent present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit10 = PGUREC_SWProtErrFlags.bit.RecOL;                  // Overload of Secondary Circuit 2 ;   1 = Overload present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit11 = PGUREC_SWProtCatenaryErrFlags.bit.Vs_Low_PF;      // Low Power Factor Fault 1 ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit12 = PGUREC_SWProtErrFlags.bit.InvGF;                  // Inverter Ground Fault 2 ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit13 = PGUREC_SWProtErrFlags.bit.VdcOV;                  // Overvoltage of DC Circuit 1 ;   1 = Overvoltage present    //    0 = Overvoltage not present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit14 = PGUREC_SWProtErrFlags.bit.VdcLV;                  // Low voltage of DC circuit 1 ;   1 = Low voltage present    //    0 = Not low voltage present
//    CANTXMsg.TX_MSG5.uiBuffer[2].bit.bit15 = PGUREC_SWProtErrFlags.bit.IpOC;                   // Overcurrent of Primer Circuit 1 ;   1 = Overcurrent present    //    0 = Overcurrent not present
//
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit0  = PGUREC_SWProtErrFlags.bit.MotOC_U;        // Overcurrent of traction motor-U ;   1 = Overcurrent present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit1  = PGUREC_SWProtErrFlags.bit.MotOC_W;        // Overcurrent of traction motor-V ;   1 = Overcurrent present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit2  = PGUREC_SWProtErrFlags.bit.MotOC_W;           // Overcurrent of traction motor-W ;   1 = Overcurrent present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit3  = PGUREC_SWProtErrFlags.bit.InvOL;             // Overload of traction motor ;   1 = Overload present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit4  = PGUREC_SWProtErrFlags.bit.InvGF;             // Phase unbalance of Motor current ;   1 = Phase unbalance   //   0 = Not Phase unbalance
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit5  = PGUREC_SWProtErrFlags.bit.MotSpeed;          // Overspeed of traction motor ;   1 = Overspeed present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit6  = PGU_TempErrFlags.bit.RECTTemp1;           // Overtemperature of heatsink for rectifier-U ;   1 = Overtemperature present   //  0 = Not overtemperature
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit7  = PGU_TempErrFlags.bit.RECTTemp2;           // Overtemperature of heatsink for rectifier-V ;   1 = Motor stall   //   0 = Motor not stall
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit8  = PGU_TempErrFlags.bit.INVTemp1;            // Overtemperature of heatsink for inverter ;   1 = Overtemperature present   //  0 = Not overtemperature
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit9  = PGU_TempErrFlags.bit.INVTemp2;            // Overtemperature of heatsink for inverter ;   1 = Overtemperature present   //  0 = Not overtemperature
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit10 = PGU_TempErrFlags.bit.COOLTemp;            // Overtemperature for Cooling Liquid ;   1 = Overtemperature present   //  0 = Not overtemperature
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit11 = PGU_TempErrFlags.bit.CABINTemp;            // Overtemperature for Converter Cabin ;   1 = Overtemperature present   //  0 = Not overtemperature
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit12 = PGU_TempErrFlags.bit.CABINHum;             // Overhumunity for Converter Cabin ;   1 = Overhuminity present   //  0 = Not overhuminity
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit13 = PGU_TempErrFlags.bit.COOLFlow;            // Overflow for Cooling Liquid  ;   1 = Overflow present   //  0 = Not overflow
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit14 = (PGU_TempErrFlags.bit.MOTTemp1 || PGU_TempErrFlags.bit.MOTTemp2 || PGU_TempErrFlags.bit.MOTTemp3 ) ;            // Overtemperature of ambient for motor ;   1 = Overtemperature present   //  0 = Not overtemperature
//    CANTXMsg.TX_MSG5.uiBuffer[3].bit.bit15 = PGU_TempErrFlags.bit.MOTTempBear;         // Overtemperature for motor bearing;   1 = Overtemperature present   //  0 = Not overtemperature
//
//
//    // ***************************************************
//    // CAN MESSAGE:6
//    // TCPU (63:0) Fault/Status/Warning Data */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit0  = 0;         // Global HWF Flag
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit1  = 0;         // HW Overvoltage of Primary Circuit ;   1 = Overvoltage of Primary Circuit present    //    0 = Not overvoltage present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit2  = 0;         // HW Low voltage of Primary Circuit ;   1 = Low voltage present    //    0 = Not low voltage present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit3  = 0;         // HW Over current of Primary Circuit ;   1 = Low voltage present    //    0 = Not low voltage present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit4  = 0;         // Primary reserved fault
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit5  = 0;         // Digital Power Supply +3.3V Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit6  = 0;         // Digital Power Supply +5V Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit7  = 0;         // Digital Power Supply -5V Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit8  = 0;         // Digital Power Supply Battery Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit9  = 0;         // Analog Power Supply +15V Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit10 = 0;         // Analog Power Supply -15V Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit11 = 0;         // Analog Power Supply +5V Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit12 = 0;         // Analog Power Supply -5V Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit13 = 0;         // Analog Power Supply Battery Fault;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit14 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[0].bit.bit15 = 0;         // reserved
//
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit0  = 0;         // External Fault
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit1  = 0;         // VCB opened signal (not)
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit2  = 0;         // Reserved Digital Input
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit3  = 0;         // Reserved Digital Input
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit4  = 0;         // VCB open Signal
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit5  = 0;         // Reserved Digital Output
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit6  = 0;         // Reserved Digital Output
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit7  = 0;         // Reserved Digital Output
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit8  = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit9  = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit10 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit11 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit12 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit13 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit14 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[1].bit.bit15 = 0;         // reserved
//
//    // ConvX Fault Area
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit0  = 0;         // Overvoltage level1 of DC Circuit (SensorA) ;    1 = Overvoltage present    //    0 = Overvoltage not present
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit1  = 0;         // Overvoltage level2 of DC Circuit (SensorA);     1 = Overvoltage present    //    0 = Overvoltage not present
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit2  = 0;         // Overcurrent of Secondary Circuit ;              1 = Overcurrent present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit3  = 0;         // Overcurrent of traction motor ;                 1 = Overcurrent present    //    0 = Overcurrent not present
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit4  = 0;         // Overvoltage level2 of DC Circuit (SensorB);     1 = Overvoltage present    //    0 = Overvoltage not present
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit5  = 0;         // Analog Input Card not found fault
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit6  = 0;         // Analog Input Card reserved fault
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit7  = 0;         // Analog Input Card reserved fault
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit8  = 0;         // Low voltage of Gate Power Supply ;   1 = Low voltage present    //    0 = Not low voltage present
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit9  = 0;         // Speed Sensor Card Failure ;   1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit10 = 0;         // IGBT Self protection ;   1 = IGBT protection actuating  //  0 = IGBT protect not active
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit11 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit12 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit13 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit14 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[2].bit.bit15 = 0;         // reserved
//
//    // ConvX Action Area
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit0  = 0;         // MC open due to Fault ;                      1 = MC open due to fault    //    0 =  MC not open
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit1  = 0;         // OVP protection due to Fault ;               1 = Fault present    //    0 =  Fault not present
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit2  = 0;         // Converter stop due to Fault/protection ;    1 = CI stop due to fault   //    0 =  CI not stop (HGOFF)
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit3  = 0;         // PWMs stop due to Fault/protection ;         1 = CI stop due to fault   //    0 =  CI not stop (PGUTrip)
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit4  = 0;         // Record trig due to Fault/protection ;       1 = Trig present   //    0 =  Trig not present (HRecTrig)
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit5  = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit6  = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit7  = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit8  = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit9  = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit10 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit11 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit12 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit13 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit14 = 0;         // reserved
//    CANTXMsg.TX_MSG6.uiBuffer[3].bit.bit15 = 0;         // reserved
//
//    // ***************************************************
//    // CAN MESSAGE:7
//    // FOIO Status/Warning/Error Data */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG7.uiBuffer[0].all   = (Uint16) (100.0 * (0.001*InvPowMean) + 32767.0);
//    CANTXMsg.TX_MSG7.uiBuffer[1].all   = (Uint16) (!PGUREC_CTL_REG.bit.ENABLE); // (Traction Motor Status) 0:Normal; 1:Cancel
//    CANTXMsg.TX_MSG7.uiBuffer[2].all   = 0;
//    CANTXMsg.TX_MSG7.uiBuffer[3].all   = (Uint16) (100.0 * (PGUINV_IMotURMS.RMS) + 32767.0);
//
//
//    // ***************************************************
//    // CAN MESSAGE:8
//    // Hardware-Software versions */
//    // ***************************************************
//
//    CANTXMsg.TX_MSG8.uiBuffer[0].all   = (Uint16) (5.0   * (PGUINV_MotTorque)  + 32767.0);;
//    CANTXMsg.TX_MSG8.uiBuffer[1].all   = (Uint16) (5.0   * (PGUINV_MotSpeedMean) + 32767.0);;
//    CANTXMsg.TX_MSG8.uiBuffer[2].all   = 0;
//    CANTXMsg.TX_MSG8.uiBuffer[3].all   = 0;

}

void PGUREC_WriteMonData(Uint16 WriteCount)
{
//    MonitorData[0]  = 1;//PGUREC_FLT_REG.all;
//    MonitorData[1]  = 12;//STestErrFlags.all;
//    MonitorData[2]  = PGUREC_ADCErrFlags.all;
//    MonitorData[3]  = PGUREC_SWProtErrFlags.all;
//    MonitorData[4]  = PGU_TempErrFlags.all;
//    MonitorData[5]  = PGU_ContacErrFlags.all;
//    MonitorData[6]  = PGUREC_SWProtWarnFlags.all;
//    MonitorData[7]  = PGU_TempWarnFlags.all;
//
//    MonitorData[8]  = PGUREC_CTL_REG.all;
//    MonitorData[9]  = PGUREC_RCTL_REG.all;
//    MonitorData[10] = PCC_REG.all;
//    MonitorData[11] = MCAUX_REG.all;
//    MonitorData[12] = ;
//    MonitorData[13] = PRECHCTL_REG1.all;
//    MonitorData[14] = (Uint16) (10.0 * PGUREC_MainIsrTotalTime);
//    MonitorData[15] = MC1_Status;
//
//    MonitorData[16] = PGUREC_MasterContr.REV_SW.all;
//    MonitorData[17] = PGUREC_MasterContr.MAIN_HAND.all;
//    MonitorData[18] = PGUREC_MasterContr.STA.all;
    // MonitorData[19] = 0;
    //MonitorData[20] = 0;
    //MonitorData[21] = 0;
    //MonitorData[22] = 0;
    //MonitorData[23] = 0;

    //MonitorData[24] = 0;
    //MonitorData[25] = 0;
    //MonitorData[26] = 0;
    //MonitorData[27] = 0;
    //MonitorData[28] = 0;
    //MonitorData[29] = 0;
    //MonitorData[30] = 0;
    //MonitorData[31] = 0;

    //MonitorData[32] = 0;
    //MonitorData[33] = 0;
    //MonitorData[34] = 0;
    //MonitorData[35] = 0;

    MonitorData[36] = WriteCount;                  //InitCheckReg[0];;
//    MonitorData[37] = (Uint16) (100.0*fabs(Is_q)); //InitCheckReg[1];
//    MonitorData[38] = (Uint16) (100.0*Is_d);       //InitCheckReg[2];
//    MonitorData[39] = GA;
//
//    MonitorData[40] = (Uint16) (100.0*fabs(ws_mot));
//    MonitorData[41] = (Uint16) (1000*PGUREC_Torque.TotalLimFactor);
//    MonitorData[42] = (Uint16) (100.0*IsRef_d);
//    MonitorData[43] = (Uint16) (fabs(100.0*IsRef_q));
//    MonitorData[132] = (Uint16);
//
//    Uint16  ind;
//    Uint16  size;
//    float32 *source;
//    Uint16  *source1;
//
//// PGUREC_DACChannels Monitoring
//    size    = sizeof(PGUREC_DACChannels);
//    source  = &(PGUREC_DACChannels.MOCErrVoltage);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[44+ind] = (Uint16)((*(source+ind))*10000);}
//
//// PGU_HWProtLevels Monitoring
//    size    = sizeof(PGU_HWProtLevels);
//    source  = &(PGU_HWProtLevels.MOCErrVoltage);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[60+ind] = (Uint16)*(source+ind);}
//
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[68+ind] = (Uint16)*(source+ind);}
//
//// SWProtFdbsCatenay Monitoring
//    size    = sizeof(PGU_SWProtFdbs);
//    source  = &(PGU_SWProtFdbsCatenary.Vs);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[80+ind] = (Uint16)(*(source+ind)*10.0);}
//
//// SWProtFdbs Monitoring
//    size    = sizeof(PGU_SWProtFdbs);
//    source  = &(PGU_SWProtFdbs.Ip);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[85+ind] = (Uint16)(*(source+ind)*10.0);}
//
//// SWProtErrLimitsCatenay Monitoring
//    size    = sizeof(PGU_SWProtErrLimitsCatenary);
//    source  = &(PGU_SWProtErrLimitsCatenary.VsOV);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[99+ind] = (Uint16)*(source+ind);}
//
//// SWProtErrLimits Monitoring
//    size    = sizeof(PGU_SWProtErrLimits);
//    source  = &(PGU_SWProtErrLimits.IpOC);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[107+ind] = (Uint16)*(source+ind);}
//
//// SWProtWarnLimitsCatenay Monitoring
//    size    = sizeof(PGU_SWProtWarnLimitsCatenary);
//    source  = &(PGU_SWProtWarnLimitsCatenary.VsOV);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[121+ind] = (Uint16)*(source+ind);}
//
//// SWProtWarnLimits Monitoring
//    size    = sizeof(PGU_SWProtWarnLimits);
//    source  = &(PGU_SWProtWarnLimits.IpOC);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[129+ind] = (Uint16)*(source+ind);}
//
//// SWProtErrTimeCatenay Monitoring
//    size    = sizeof(PGU_SWProtErrTimeCatenary);
//    source1  = &(PGU_SWProtErrTimeCatenary.VsOV);
//
//    for(ind=0;ind<(size);ind++)
//    {MonitorData[143+ind] = (Uint16)*(source1+ind);}
//
//// SWProtErrTime Monitoring
//    size    = sizeof(PGU_SWProtErrTime);
//    source1  = &(PGU_SWProtErrTime.IpOC);
//
//    for(ind=0;ind<(size);ind++)
//    {MonitorData[151+ind] = (Uint16)*(source1+ind);}
//
//// Temperature Monitoring
//    size    = sizeof(PGUREC_Temperature);
//    source  = &(PGUREC_Temperature.RectifierTemp1);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[165+ind] = (int16)*(source+ind);}
//
//// PGU_TempErrLimits Monitoring
//    size    = sizeof(PGU_TempErrLimits);
//    source  = &(PGU_TempErrLimits.RectifierTemp1);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[180+ind] = (int16)*(source+ind);}
//
//// PGU_TempWarnLimits Monitoring
//    size    = sizeof(PGU_TempWarnLimits);
//    source  = &(PGU_TempWarnLimits.RectifierTemp1);
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[195+ind] = (int16)*(source+ind);}
//
//
//    for(ind=0;ind<(size)/2;ind++)
//    {MonitorData[210+ind]= (int16)(*(source+ind));}

/******************   BuildTimeInit()  **************************************************/
//    // Project Revision Monitoring
//    MonitorData[224]  = (Uint16) (build_rev[1]<<8)  | (Uint16) (build_rev[0] & 0x00FF);
//    MonitorData[225]  = (Uint16) (build_rev[3]<<8)  | (Uint16) (build_rev[2] & 0x00FF);
//    MonitorData[226]  = (Uint16) (build_loco[1]<<8)  | (Uint16) (build_loco[0] & 0x00FF);
//    MonitorData[227]  = (Uint16) (build_loco[3]<<8)  | (Uint16) (build_loco[2] & 0x00FF);
//    MonitorData[228]  = (Uint16) (build_loco[5]<<8)  | (Uint16) (build_loco[4] & 0x00FF);
//    MonitorData[229]  = (Uint16) (build_loco[7]<<8)  | (Uint16) (build_loco[6] & 0x00FF);
//
//    // Project Build Date Monitoring
//    MonitorData[230] = (Uint16) (build_date[1]<<8) | (Uint16) (build_date[0] & 0x00FF);
//    MonitorData[231] = (Uint16) (build_date[3]<<8) | (Uint16) (build_date[2] & 0x00FF);
//    MonitorData[232] = (Uint16) (build_date[5]<<8) | (Uint16) (build_date[4] & 0x00FF);
//    MonitorData[233] = (Uint16) (build_date[7]<<8) | (Uint16) (build_date[6] & 0x00FF);
//    MonitorData[234] = (Uint16) (build_date[9]<<8) | (Uint16) (build_date[8] & 0x00FF);
//    MonitorData[235] = (Uint16) (build_date[11]<<8)| (Uint16) (build_date[10] & 0x00FF);
//
//    // Project Build Time Monitoring
//    MonitorData[236] = (Uint16) (build_time[1]<<8) | (Uint16) (build_time[0] & 0x00FF);
//    MonitorData[237] = (Uint16) (build_time[3]<<8) | (Uint16) (build_time[2] & 0x00FF);
//    MonitorData[238] = (Uint16) (build_time[5]<<8) | (Uint16) (build_time[4] & 0x00FF);
//    MonitorData[239] = (Uint16) (build_time[7]<<8) | (Uint16) (build_time[6] & 0x00FF);
}

void PGUREC_WriteFaultData(void)
{
    // CAN Diagnostic Message-1
    Faults[0].all = STestErrFlags.all;
    Faults[1].all = PGUREC_ADCErrFlags.all;
    Faults[2].all = PGUREC_SWProtErrFlags.all;
    Faults[3].all = PGUREC_SWProtCatenaryErrFlags.all;

    // CAN Diagnostic Message-2
    Faults[4].all  = PGUREC_SWProtCatenaryWarnFlags.all;
    Faults[5].all  = PGUREC_SWProtWarnFlags.all;
    Faults[6].all  = PGUREC_TempErrFlags_CKU1.all;                    //Temp Error Flags
    Faults[7].all  = PGUREC_TempWarnFlags_CKU1.all;                   //Temp Warning Flags

    // CAN Diagnostic Message-2
    Faults[8].all   = PGUREC_FLT_REG.all;
    Faults[9].all   = TCPURXMsg.C3.uiBuffer[1].all;                  //TCPU_TIC_FAULT
    Faults[10].all  = TCPURXMsg.C3.uiBuffer[2].all;                  //TCPU_OTHER_FAULT
    Faults[11].all  = PGUREC_TempErrFlags_CKU2.all;

    // CAN Diagnostic Message-4
    Faults[12].all  = FOIO_CANRXMsg.RX_MSG1.bit.Rect1U.all;          //Rec U+, U- Latched Faults
    Faults[13].all  = FOIO_CANRXMsg.RX_MSG1.bit.Rect1V.all;          //Rec V+, V- Latched Faults
    Faults[14].all  = FOIO_CANRXMsg.RX_MSG1.bit.Rect2U.all;          //Inv U+, W- Latched Faults
    Faults[15].all  = FOIO_CANRXMsg.RX_MSG1.bit.Rect2U.all;          //Inv V+, W- Latched Faults

    // CAN Diagnostic Message-5
    Faults[16].all = FOIO_CANRXMsg.RX_MSG2.bit.InvU.all;           //Inv U+, W- Latched Faults
    Faults[17].all = FOIO_CANRXMsg.RX_MSG2.bit.InvV.all;           //Inv V+, W- Latched Faults
    Faults[18].all = FOIO_CANRXMsg.RX_MSG2.bit.InvW.all;           //Inv W+, W- Latched Faults
    Faults[19].all = FOIO_CANRXMsg.RX_MSG2.bit.BP_OVCRFOut.all;    //OVCRF and Backplane Latched Signals

    // CAN Diagnostic Message-6
    Faults[20].all = FOIO_CANRXMsg.RX_MSG2.bit.InvU.all;           //Inv U+, W- Latched Faults
    Faults[21].all = FOIO_CANRXMsg.RX_MSG2.bit.InvV.all;           //Inv V+, W- Latched Faults
    Faults[22].all = FOIO_CANRXMsg.RX_MSG2.bit.InvW.all;           //Inv W+, W- Latched Faults
    Faults[23].all = FOIO_CANRXMsg.RX_MSG2.bit.BP_OVCRFOut.all;    //OVCRF and Backplane Latched Signals


}

void PGUREC_ReadMVBData(void)
{
    PGUREC_CCU1_Lifesign                     = CC1RXMsg.RX_MSG1.uiBuffer[0].all;                //CCU1 Life signal of port
//    ActualTime
    PGUREC_S_Coupling                        = CC1RXMsg.RX_MSG2.uiBuffer[1].all & 0x0003;       //00: No coupling / 10:Coupling is done from SKA1 side / 01:Coupling is done from SKA2 side / 11:Error
    PGUREC_S_Lead_Follow_consist             = (CC1RXMsg.RX_MSG2.uiBuffer[1].all & 0x000C)>>2;  //10: lead consist / 01:follower consist / 00/11: error
    PGUREC_S_CAB_Active                      = (CC1RXMsg.RX_MSG2.uiBuffer[1].all & 0x0030)>>4;  //00: No active cab / 10: cab in SKA1 is active / 01: cab in SKA2 is active / 11: Error
    PGUREC_S_Direction                       = (CC1RXMsg.RX_MSG2.uiBuffer[1].all & 0x00C0)>>6;  //For lead vehicle: 10: Active cab forward/01:Active cab reverse / For follower vehicle: 10: Coupling side forward/01: Coupling side reverse
    PGUREC_CouplingStatus                    = (CC1RXMsg.RX_MSG2.uiBuffer[1].all & 0x0300)>>8;  //01:No coupling(in this case last 3 bit should be 0) / 10:coupling(in this case 6 cars bit configuration is forbidden)
    PGUREC_1stTrainSetConfiguration          = (CC1RXMsg.RX_MSG2.uiBuffer[1].all & 0x0C00)>>10; //(lead vehicle side) 100:4 cars
    PGUREC_2ndTrainSetConfiguration          = (CC1RXMsg.RX_MSG2.uiBuffer[1].all & 0xF000)>>12; //(not lead vehicle side) 100:4 cars

    PGUREC_CCU2_Lifesign                         = CC1RXMsg.RX_MSG3.uiBuffer[0].all;          //CCU2 Life signal of port
    PGUREC_TL_Enable_TC1_SKA1                    = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit0;     //Validation for trainline enable TC signal (0: NOT enable / 1: Enable)
    PGUREC_TL_Enable_TC2_SKA1                    = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit1;     //Validation for trainline enable TC signal (0: NOT enable / 1: Enable)
    PGUREC_TL_Enable_TC1_SKA2                    = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit2;     //Validation for trainline enable TC signal (0: NOT enable / 1: Enable)
    PGUREC_TL_Enable_TC2_SKA2                    = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit3;     //Validation for trainline enable TC signal (0: NOT enable / 1: Enable)
    PGUREC_TL_Normal_Rescue_SKA1                 = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit4;     //Valitaion for trainline Normal/Rescue Mode in a SKA car (reserved) (0: Normal Mode / 1: Rescue Mode)
    PGUREC_TL_Normal_Rescue_SKA2                 = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit5;     //Valitaion for trainline Normal/Rescue Mode in a SKA car (reserved) (0: Normal Mode / 1: Rescue Mode)
    PGUREC_TL_Speed_Limit_SKA1                   = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit6;     //Valitaion for trainline Speed Limit signal in a SKA car (0: Speed limit NOT Active / 1: Speed limit Active)
    PGUREC_TL_Speed_Limit_SKA2                   = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit7;     //Valitaion for trainline Speed Limit signal in a SKA car (0: Speed limit NOT Active / 1: Speed limit Active)
    PGUREC_TL_Cabs_Mode                          = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit8;     //Valitaion for trainline CAB Mode signal in whole train (0: SKA1 active cabin / 1: SKA2 active cabin)
    PGUREC_TL_SKA1_Forward                       = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit9;     //Forward Direction selected in SKA1 (0: Forward NOT selected / 1: Forward selected)
    PGUREC_TL_SKA1_Reverse                       = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit10;    //Reverse Direction selected in SKA1 (0: Reverse NOT selected / 1: Reverse selected)
    PGUREC_TL_SKA2_Forward                       = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit11;    //Forward Direction selected in SKA2 (0: Forward NOT selected / 1: Forward selected)
    PGUREC_TL_SKA2_Reverse                       = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit12;    //Reverse Direction selected in SKA2 (0: Reverse NOT selected / 1: Reverse selected)
    PGUREC_TL_Traction_CutOff_SKA1               = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit13;    //Valitaion for trainline Traction CutOff Loop signal in SKA1 (0: Traction CUTOFF / 1: Traction NOT CUTOFF)
    PGUREC_TL_Traction_CutOff_SKA2               = CC1RXMsg.RX_MSG3.uiBuffer[1].bit.bit14;    //Valitaion for trainline Traction CutOff Loop signal in SKA2 (0: Traction CUTOFF / 1: Traction NOT CUTOFF)
    PGUREC_TL_Relay_Security_Emergency_Loop_SKA1 = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit0;     //Valitaion for trainline Relay Security Emergency Loop signal in SKA1 (0: Emergency Loop NOT OK / 1: Emergency Loop OK)
    PGUREC_TL_Relay_Security_Emergency_Loop_SKA2 = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit1;     //Valitaion for trainline Relay Security Emergency Loop signal in SKA2 (0: Emergency Loop NOT OK / 1: Emergency Loop OK)
    PGUREC_TL_MC_S1                              = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit2;     //Validation active cabin's master controller switch 1 - Traction Command
    PGUREC_TL_MC_S2                              = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit3;     //Validation active cabin's master controller switch 2 - Traction Command
    PGUREC_TL_MC_S3                              = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit4;     //Validation active cabin's master controller switch 3 - Traction Command
    PGUREC_TL_MC_S4                              = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit5;     //Validation active cabin's master controller switch 1 - Brake Command
    PGUREC_TL_MC_S5                              = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit6;     //Validation active cabin's master controller switch 2 - Brake Command
    PGUREC_TL_MC_S6                              = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit7;     //Validation active cabin's master controller switch 3 - Brake Command
    PGUREC_STS_Cutoff_bypass                     = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit8;     //Status of "SL CUT OFF BYPASS" traction cutoff loop bypass switch in SKA1 or SKA2 car. (0: NOT Bypassed / 1: Bypassed)
    PGUREC_TL_VCB_On_Off_OA1                     = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit9;     //VCB Open/Close status in SKA1 (0: VCB open (OFF) / 1: VCB closed (ON))
    PGUREC_TL_VCB_On_Off_OA2                     = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit10;    //VCB Open/Close status in SKA2 (0: VCB open (OFF) / 1: VCB closed (ON))
    PGUREC_VCB_Opening_Warning                   = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit11;    //Warnig to TCU about MCB opening by TCMS (0: NO warning / 1: Warning)
    PGUREC_TC_SKA1_HV_Expected                   = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit12;    //HV is expected at TC input in SKA1. Related HV disconnector is closed, pantograph is up, MCB is closed and transformer is ok. (0: HV is NOT expected / 1: HV is expected)
    PGUREC_TC_SKA2_HV_Expected                   = CC1RXMsg.RX_MSG3.uiBuffer[2].bit.bit13;    //HV is expected at TC input in SKA2. Related HV disconnector is closed, pantograph is up, MCB is closed and transformer is ok. (0: HV is NOT expected / 1: HV is expected)
    PGUREC_Cmd_Traction_Null                     = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit0;     //TCMS command for Traction NULL (inhibit) (0: Traction NULL NOT Commanded / 1: Traction NULL Commanded)
    PGUREC_Cmd_Traction_Cutoff                   = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit1;     //TCMS command for Traction Cutoff. For additional cutroff conditions. (0: Traction CUTOFF NOT Commanded / 1: Traction CUTOFF Commanded)
    PGUREC_Cmd_EDB_Deactivate                    = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit2;     //For brake tests and to disable/enable electrodynamic brake in case of ETCS or driver request. (0: NO Deactivate command / 1: Deactivate command)
    PGUREC_Cmd_Speed_Limit                       = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit3;     //TCMS command to limit traction in case of  BCU request (0: NO Speed Limit command / 1: Speed Limit command)
    PGUREC_Cmd_ASC_Mode                          = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit4;     //Automatic speed control mode ON/OFF status (0: ASC mode OFF / 1: ASC mode ON)
    PGUREC_Cmd_Traction_Reduction_Lvl1_SKA1      = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit8;     //TCMS command to limit traction in case of transformer overtemperature (%25 reduction) (0: NO reduction command / 1: Reduction command)
    PGUREC_Cmd_Traction_Reduction_Lvl2_SKA1      = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit9;     //TCMS command to limit traction in case of transformer overtemperature (%50 reduction) (0: NO reduction command / 1: Reduction command)
    PGUREC_Cmd_Traction_Reduction_Lvl1_SKA2      = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit10;    //TCMS command to limit traction in case of transformer overtemperature (%25 reduction) (0: NO reduction command / 1: Reduction command)
    PGUREC_Cmd_Traction_Reduction_Lvl2_SKA2      = CC1RXMsg.RX_MSG3.uiBuffer[3].bit.bit11;    //TCMS command to limit traction in case of transformer overtemperature (%25 reduction) (0: NO reduction command / 1: Reduction command)
    PGUREC_Cmd_Reset_SKA1_TC1                    = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit0;     //Driver's request to reset TCU via HMI. (0: NO reset command / 1: Reset command)
    PGUREC_Cmd_Reset_SKA1_TC2                    = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit1;     //Driver's request to reset TCU via HMI. (0: NO reset command / 1: Reset command)
    PGUREC_Cmd_Reset_SKA2_TC1                    = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit2;     //Driver's request to reset TCU via HMI. (0: NO reset command / 1: Reset command)
    PGUREC_Cmd_Reset_SKA2_TC2                    = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit3;     //Driver's request to reset TCU via HMI. (0: NO reset command / 1: Reset command)
    PGUREC_Cmd_OOS_SKA1_TC1                      = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit4;     //Driver's request to cutout TCU via HMI. (0: NO out of service command / 1: Out of service command)
    PGUREC_Cmd_OOS_SKA1_TC2                      = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit5;     //Driver's request to cutout TCU via HMI. (0: NO out of service command / 1: Out of service command)
    PGUREC_Cmd_OOS_SKA2_TC1                      = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit6;     //Driver's request to cutout TCU via HMI. (0: NO out of service command / 1: Out of service command)
    PGUREC_Cmd_OOS_SKA2_TC2                      = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit7;     //Driver's request to cutout TCU via HMI. (0: NO out of service command / 1: Out of service command)
    PGUREC_ASC_Target                            = CC1RXMsg.RX_MSG4.uiBuffer[1].byte.byte0;   //Position of ASC lever in active cabin for speed target (4-20mA ASC lever data converted to speed target)
    PGUREC_Train_Speed                           = CC1RXMsg.RX_MSG4.uiBuffer[1].byte.byte1;   //Train speed data from JRU
    PGUREC_SKA1_wheel_diameter_1                 = CC1RXMsg.RX_MSG4.uiBuffer[2].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_SKA1_wheel_diameter_2                 = CC1RXMsg.RX_MSG4.uiBuffer[3].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_SKA1_wheel_diameter_3                 = CC1RXMsg.RX_MSG5.uiBuffer[0].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_SKA1_wheel_diameter_4                 = CC1RXMsg.RX_MSG5.uiBuffer[1].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_SKA2_wheel_diameter_1                 = CC1RXMsg.RX_MSG5.uiBuffer[2].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_SKA2_wheel_diameter_2                 = CC1RXMsg.RX_MSG5.uiBuffer[3].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_SKA2_wheel_diameter_3                 = CC1RXMsg.RX_MSG6.uiBuffer[0].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_SKA2_wheel_diameter_4                 = CC1RXMsg.RX_MSG6.uiBuffer[1].all;          //New wheel diameter: 840 mm, Worn wheel diamter: 770 mm Semi worn wheel diameter is mostly used: 835 mm
    PGUREC_Catenary_Voltage                      = CC1RXMsg.RX_MSG6.uiBuffer[3].all;          //Catenary voltage analog input of TCMS.
}

void PGUREC_WriteMVBData(void)
{
// CCU_1 Messages for PGU_INV
    CC1TXMsg.TX_MSG1.uiBuffer[0].all      = (Uint16) PGUREC_Lifesign;                       //Lifesign:Life signal of port (Increase in cycles)

    if(PGUREC_DIOC1_Inputs_TCPU.bit.ID1 == 1 && PGUREC_DIOC1_Inputs_TCPU.bit.ID2 == 0 && PGUREC_DIOC1_Inputs_TCPU.bit.ID3 == 1) //SKA1 TCU1
    {
        //Ack_Reset:Acknowledge to reset request from TCMS (0: NO reset ACK / 1: Reset ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit0 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit0; //Cmd_Reset_SKA1_TC1

        //Ack_OOS:Acknowledge to driver's out of service (cutoff) request from HMI (0: NO OOS ACK / 1: OOS ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit1 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit4; //Cmd_OOS_SKA1_TC1

        //SKA1_TCU1
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit8  = 1; //TCU_Location_SKA1_1:TCU 1 in SKA1 (0: TCU is NOT SKA1-TCU-1 / 1: TCU is SKA1-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit9  = 0; //TCU_Location_SKA1_2:TCU 2 in SKA1 (0: TCU is NOT SKA1-TCU-2 / 1: TCU is SKA1-TCU-2)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit10 = 0; //TCU_Location_SKA2_1:TCU 1 in SKA2 (0: TCU is NOT SKA2-TCU-1 / 1: TCU is SKA2-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit11 = 0; //TCU_Location_SKA2_2:TCU 2 in SKA2 (0: TCU is NOT SKA2-TCU-2 / 1: TCU is SKA2-TCU-2)

        //DIA_TL_Enable:Diagnostic for signal conflict: Trainline enable TC signal (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit8  = PGUREC_DIOC1_Inputs_TCPU.bit.LocoEnable && PGUREC_TL_Enable_TC1_SKA1;

    }
    else if(PGUREC_DIOC1_Inputs_TCPU.bit.ID1 == 1 && PGUREC_DIOC1_Inputs_TCPU.bit.ID2 == 0 && PGUREC_DIOC1_Inputs_TCPU.bit.ID3 == 0)  //SKA1 TCU2
    {
        //Ack_Reset:Acknowledge to reset request from TCMS (0: NO reset ACK / 1: Reset ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit0 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit1; //Cmd_Reset_SKA1_TC2

        //Ack_OOS:Acknowledge to driver's out of service (cutoff) request from HMI (0: NO OOS ACK / 1: OOS ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit1 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit5; //Cmd_OOS_SKA1_TC2

        //SKA1_TCU2
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit8  = 0; //TCU_Location_SKA1_1:TCU 1 in SKA1 (0: TCU is NOT SKA1-TCU-1 / 1: TCU is SKA1-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit9  = 1; //TCU_Location_SKA1_2:TCU 2 in SKA1 (0: TCU is NOT SKA1-TCU-2 / 1: TCU is SKA1-TCU-2)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit10 = 0; //TCU_Location_SKA2_1:TCU 1 in SKA2 (0: TCU is NOT SKA2-TCU-1 / 1: TCU is SKA2-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit11 = 0; //TCU_Location_SKA2_2:TCU 2 in SKA2 (0: TCU is NOT SKA2-TCU-2 / 1: TCU is SKA2-TCU-2)

        //DIA_TL_Enable:Diagnostic for signal conflict: Trainline enable TC signal (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit8  = PGUREC_DIOC1_Inputs_TCPU.bit.LocoEnable && PGUREC_TL_Enable_TC2_SKA1;

    }
    else if(PGUREC_DIOC1_Inputs_TCPU.bit.ID1 == 0 && PGUREC_DIOC1_Inputs_TCPU.bit.ID2 == 1 && PGUREC_DIOC1_Inputs_TCPU.bit.ID3 == 1)  //SKA2 TCU1
    {
        //Ack_Reset:Acknowledge to reset request from TCMS (0: NO reset ACK / 1: Reset ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit0 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit2;  //Cmd_Reset_SKA2_TC1

        //Ack_OOS:Acknowledge to driver's out of service (cutoff) request from HMI (0: NO OOS ACK / 1: OOS ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit1 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit6; //Cmd_OOS_SKA2_TC1

        //SKA2_TCU1
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit8  = 0; //TCU_Location_SKA1_1:TCU 1 in SKA1 (0: TCU is NOT SKA1-TCU-1 / 1: TCU is SKA1-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit9  = 0; //TCU_Location_SKA1_2:TCU 2 in SKA1 (0: TCU is NOT SKA1-TCU-2 / 1: TCU is SKA1-TCU-2)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit10 = 1; //TCU_Location_SKA2_1:TCU 1 in SKA2 (0: TCU is NOT SKA2-TCU-1 / 1: TCU is SKA2-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit11 = 0; //TCU_Location_SKA2_2:TCU 2 in SKA2 (0: TCU is NOT SKA2-TCU-2 / 1: TCU is SKA2-TCU-2)

        //DIA_TL_Enable:Diagnostic for signal conflict: Trainline enable TC signal (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit8  = PGUREC_DIOC1_Inputs_TCPU.bit.LocoEnable && PGUREC_TL_Enable_TC1_SKA2;

    }
    else if(PGUREC_DIOC1_Inputs_TCPU.bit.ID1 == 0 && PGUREC_DIOC1_Inputs_TCPU.bit.ID2 == 1 && PGUREC_DIOC1_Inputs_TCPU.bit.ID3 == 0)  //SKA2 TCU2
    {
        //Ack_Reset:Acknowledge to reset request from TCMS (0: NO reset ACK / 1: Reset ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit0 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit3;  //Cmd_Reset_SKA2_TC2

        //Ack_OOS:Acknowledge to driver's out of service (cutoff) request from HMI (0: NO OOS ACK / 1: OOS ACK)
        CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit1 = CC1RXMsg.RX_MSG4.uiBuffer[0].bit.bit7; //Cmd_OOS_SKA2_TC2

        //SKA2_TCU2
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit8  = 0; //TCU_Location_SKA1_1:TCU 1 in SKA1 (0: TCU is NOT SKA1-TCU-1 / 1: TCU is SKA1-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit9  = 0; //TCU_Location_SKA1_2:TCU 2 in SKA1 (0: TCU is NOT SKA1-TCU-2 / 1: TCU is SKA1-TCU-2)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit10 = 0; //TCU_Location_SKA2_1:TCU 1 in SKA2 (0: TCU is NOT SKA2-TCU-1 / 1: TCU is SKA2-TCU-1)
        CC1TXMsg.TX_MSG2.uiBuffer[2].bit.bit11 = 1; //TCU_Location_SKA2_2:TCU 2 in SKA2 (0: TCU is NOT SKA2-TCU-2 / 1: TCU is SKA2-TCU-2)

        //DIA_TL_Enable:Diagnostic for signal conflict: Trainline enable TC signal (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit8  = PGUREC_DIOC1_Inputs_TCPU.bit.LocoEnable && PGUREC_TL_Enable_TC2_SKA2;

    }

    if(PGUREC_DIOC1_Inputs_TCPU.bit.ID1 == 1) //SKA1
    {
        //DIA_TL_Normal_Rescue:Trainline Normal/Rescue Mode (0: NO Fault / 1: Fault)
        if((PGUREC_TL_Normal_Rescue_SKA1 == PGUREC_DIOC2_Inputs2.bit.Rescue_Mode) && (PGUREC_TL_Normal_Rescue_SKA1 == !PGUREC_DIOC2_Inputs2.bit.Normal_Mode))
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit9  = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit9  = 1;

        //DIA_TL_Speed_Limit:Diagnostic for signal conflict: Trainline Speed Limit signal (0: NO Fault / 1: Fault)
        if(PGUREC_TL_Speed_Limit_SKA1 == PGUREC_DIOC2_Inputs2.bit.Speed_Lim_Act)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit10 = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit10 = 1;

        //DIA_TL_Forward:Diagnostic for signal conflict: Forward Direction selection (0: NO Fault / 1: Fault)
        if(PGUREC_TL_SKA1_Forward == PGUREC_DIOC2_Inputs1.bit.Forward)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit13 = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit13 = 1;

        //DIA_TL_Reverse:Diagnostic for signal conflict: Reverse Direction selectio (0: NO Fault / 1: Fault)
        if(PGUREC_TL_SKA1_Reverse == PGUREC_DIOC2_Inputs1.bit.Reverse)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit14 = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit14 = 1;

        //DIA_TL_Relay_Security_Emergency_Loop:Diagnostic for signal conflict: Trainline Relay Security Emergency Loop signal (0: NO Fault / 1: Fault)
        if(PGUREC_TL_Relay_Security_Emergency_Loop_SKA1 == PGUREC_TCPU_Inputs.bit.Emerge_LOOP)
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit0 = 0;
        else
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit0 = 1;

        //DIA_TL_VCB_On_Off:Diagnostic for signal conflict: VCB Open/Close status in SKA1 (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit7  = PGUREC_TC_SKA1_HV_Expected && PGUREC_TCPU_Inputs.bit.MCB_ON;

        //DIA_Catenary_Out_Of_Range:TCU reads catenary voltage aout of range when VCB is closed. (when HV expected) (0: NO Fault / 1: Fault)
        if(PGUREC_TC_SKA1_HV_Expected == 1)
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit9  = PGUREC_SWProtCatenaryErrFlags.bit.VsOV;

    }
    else if(PGUREC_DIOC1_Inputs_TCPU.bit.ID1 == 0) //SKA2
    {
        //DIA_TL_Normal_Rescue:Trainline Normal/Rescue Mode (0: NO Fault / 1: Fault)
        if((PGUREC_TL_Normal_Rescue_SKA2 == PGUREC_DIOC2_Inputs2.bit.Rescue_Mode) && (PGUREC_TL_Normal_Rescue_SKA2 == !PGUREC_DIOC2_Inputs2.bit.Normal_Mode))
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit9  = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit9  = 1;

        //DIA_TL_Speed_Limit:Diagnostic for signal conflict: Trainline Speed Limit signal (0: NO Fault / 1: Fault)
        if(PGUREC_TL_Speed_Limit_SKA2 == PGUREC_DIOC2_Inputs2.bit.Speed_Lim_Act)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit10 = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit10 = 1;

        //DIA_TL_Forward:Diagnostic for signal conflict: Forward Direction selection (0: NO Fault / 1: Fault)
        if(PGUREC_TL_SKA2_Forward == PGUREC_DIOC2_Inputs1.bit.Forward)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit13 = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit13 = 1;

        //DIA_TL_Reverse:Diagnostic for signal conflict: Reverse Direction selectio (0: NO Fault / 1: Fault)
        if(PGUREC_TL_SKA2_Reverse == PGUREC_DIOC2_Inputs1.bit.Reverse)
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit14 = 0;
        else
        CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit14 = 1;

        //DIA_TL_Relay_Security_Emergency_Loop:Diagnostic for signal conflict: Trainline Relay Security Emergency Loop signal (0: NO Fault / 1: Fault)
        if(PGUREC_TL_Relay_Security_Emergency_Loop_SKA2 == PGUREC_TCPU_Inputs.bit.Emerge_LOOP)
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit0 = 0;
        else
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit0 = 1;

        //DIA_TL_VCB_On_Off:Diagnostic for signal conflict: VCB Open/Close status in SKA1 (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit7  = PGUREC_TC_SKA2_HV_Expected && PGUREC_TCPU_Inputs.bit.MCB_ON;

        //DIA_Catenary_Out_Of_Range:TCU reads catenary voltage aout of range when VCB is closed. (when HV expected) (0: NO Fault / 1: Fault)
        if(PGUREC_TC_SKA2_HV_Expected == 1)
        CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit9  = PGUREC_SWProtCatenaryErrFlags.bit.VsOV;

    }

    if (PGUREC_CKU1 == 1)
    {

        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit5  = PGUREC_TempErrFlags_CKU1.bit.MOTTemp1;     //DIA_Motor1_OT:Over temperature of traction motor winding 1. (TCU should be reset to work again) (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit7  = PGUREC_TempErrFlags_CKU1.bit.GEARTemp;     //DIA_Motor1_Gearbox_OT:Over temperature of traction motor 1 gear box (bearing). (TCU should be reset to work again) (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit9  = PGUREC_TempErrFlags_CKU1.bit.RECTTemp1;    //DIA_Module1_OT:Over temperature of rectifier 1 (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit10 = PGUREC_TempErrFlags_CKU1.bit.RECTTemp2;    //DIA_Module2_OT:Over temperature of rectifier 2 (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit13 = PGUREC_TempErrFlags_CKU1.bit.CABINTemp;    //DIA_TC_OT:Over temperature of TC cabinet (NOTE: from only one TCU in each SKA) (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit14 = PGUREC_TempErrFlags_CKU1.bit.CABINHum_Hum; //DIA_TC_OH:Over humidity of TC cabinet (NOTE: from only one TCU in each SKA) (0: NO Fault / 1: Fault)


    }
    else if (PGUREC_CKU2 == 1)
    {
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit5  = PGUREC_TempErrFlags_CKU2.bit.MOTTemp1;     //DIA_Motor1_OT:Over temperature of traction motor winding 1. (TCU should be reset to work again) (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit7  = PGUREC_TempErrFlags_CKU2.bit.GEARTemp;     //DIA_Motor1_Gearbox_OT:Over temperature of traction motor 1 gear box (bearing). (TCU should be reset to work again) (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit9  = PGUREC_TempErrFlags_CKU2.bit.RECTTemp1;    //DIA_Module1_OT:Over temperature of rectifier 1 (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit10 = PGUREC_TempErrFlags_CKU2.bit.RECTTemp2;    //DIA_Module2_OT:Over temperature of rectifier 2 (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit13 = PGUREC_TempErrFlags_CKU2.bit.CABINTemp;    //DIA_TC_OT:Over temperature of TC cabinet (NOTE: from only one TCU in each SKA) (0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[1].bit.bit15 = PGUREC_TempErrFlags_CKU2.bit.COOLFlow_Temp;//DIA_Coolant_OT:Over temperature of coolant liquid. (NOTE: from only one TCU in each SKA)(0: NO Fault / 1: Fault)
        CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit0  = PGUREC_TempErrFlags_CKU2.bit.COOLFlow_Flow;//DIA_Low_Coolant_Flow:Low coolant flow fault (NOTE: from only one TCU in each SKA) (NOTE: from only one TCU in each SKA)(0: NO Fault / 1: Fault)

    }

    CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit6  = PGUREC_DIOC2_Inputs2.bit.Cabs_Mode_Act;         //Mode_Cab_SKA1:Active cabin information in TCU software (0: TCU reads active cabin as NOT CAB1 selected / 1: TCU reads active cabin as CAB1 selected)
    CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit7  = !PGUREC_DIOC2_Inputs2.bit.Cabs_Mode_Act;        //Mode_Cab_SKA2:Active cabin information in TCU software (0: TCU reads active cabin as NOT CAB2 selected / 1: TCU reads active cabin as CAB2 selected)
    CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit10 = PGUREC_TractInh;                                //Mode_Traction_Cutoff:TCU reads Traction Cutoff command via digital input from trainline. NO ED brake possible. No traction possible. (0: TCU is NOT in Traction CUTOFF mode / 1: TCU is in Traction CUTOFF mode)
    CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit11 = !PGUREC_CTL_REG.bit.ENABLE;                     //Mode_Traction_OOS:TCU reads Traction Out of service command via HMI from TCMS. NO ED brake possible. No traction possible. (0: TCU is NOT in OUT OF SERVICE mode / 1: TCU is in OUT OF SERVICE mode)
    CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit12 = (PGUREC_FLT_REG.all>0?1:0);                     //Mode_Traction_Failure:TCU is in failure mode due to any of the active faults. Traction is not possible. (0: TCU is NOT in FAILURE mode / 1: TCU is in FAILURE mode)
    CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit13 = PGUREC_MasterContr.MAIN_HAND.bit.EMG_BRAKE;     //Mode_Emergency:TCU reads emergency brake input and acts to cutoff ED brake and traction and switching signal turnoff. (0: TCU is NOT in EMERGENCY mode / 1: TCU is in EMERGENCY mode)
    CC1TXMsg.TX_MSG1.uiBuffer[1].bit.bit14 = !PGUREC_TCPU_Outputs.bit.EDB_ACTIVE_SIG;        //Mode_EDB_Cutoff:Stauts of ED brake cutoff. Commanded via BCU or TCMS. (0: ED Brake is NOT CUTOFF / 1: ED Brake is CUTOFF)
    CC1TXMsg.TX_MSG1.uiBuffer[2].bit.bit2  = PGUREC_DIOC2_Outputs.bit.HV_Presence;           //V_HV_Presence:Validation signal for trainline HV_Presence_To_Traction_TC (0: TCU's digital output is LOW / 1: TCU's digital output is HIGH)
    CC1TXMsg.TX_MSG1.uiBuffer[2].bit.bit3  = PGUREC_DIOC2_Outputs.bit.Trac_DCLink_OK;        //V_Traction_DC_Link_Ok:Validation signal for trainline Traction_DC_Link_OK_TC (0: TCU's digital output is LOW / 1: TCU's digital output is HIGH)
    CC1TXMsg.TX_MSG1.uiBuffer[2].bit.bit4  = PGUREC_DIOC2_Outputs.bit.Pantograph_Permission; //V_Pantograph_Permission:Validation signal for trainline Pantograph_Permission_TC (0: TCU's digital output is LOW / 1: TCU's digital output is HIGH)
    CC1TXMsg.TX_MSG1.uiBuffer[2].bit.bit7  = PGUREC_TCPU_Outputs.bit.MCB_TRIP;               //V_VCB_Loop_Out:Validation signal for trainline VCB_Loop_Out_TC (0: TCU's digital output is LOW / 1: TCU's digital output is HIGH)
    CC1TXMsg.TX_MSG1.uiBuffer[2].bit.bit10 = PGUREC_TCPU_Outputs.bit.System_RST;             //V_System_Reset:Validation signal for trainline System_Reset (0: TCU's digital output is LOW / 1: TCU's digital output is HIGH)
    CC1TXMsg.TX_MSG1.uiBuffer[3].bit.bit0  = PGUREC_TCPU_Inputs.bit.MC1_NO;                                            //STS_Main_Cont1:Main contactor-1 ON/OFF status (Converter input contactor) (Cont3 for TCU2) (0: Contactor is OPEN (OFF) / 1: Contactor is CLOSED (ON))
    CC1TXMsg.TX_MSG1.uiBuffer[3].bit.bit1  = PGUREC_TCPU_Inputs.bit.MC2_NO;                                            //STS_Main_Cont2:Main contactor-2 ON/OFF status (Converter input contactor) (Cont4 for TCU2) (0: Contactor is OPEN (OFF) / 1: Contactor is CLOSED (ON))
    CC1TXMsg.TX_MSG1.uiBuffer[3].bit.bit2  = PGUREC_TCPU_Inputs.bit.PCC1_NO;                 //STS_Pre_Cont1:Pre-charge contactor-1 ON/OFF status (Pre-Cont3 for TCU2) (0: Contactor is OPEN (OFF) / 1: Contactor is CLOSED (ON))
    CC1TXMsg.TX_MSG1.uiBuffer[3].bit.bit3  = PGUREC_TCPU_Inputs.bit.PCC2_NO;                 //STS_Pre_Cont2:Pre-charge contactor-2 ON/OFF status (Pre-Cont4 for TCU2) (0: Contactor is OPEN (OFF) / 1: Contactor is CLOSED (ON))
    CC1TXMsg.TX_MSG1.uiBuffer[3].bit.bit4  = PGUREC_DIOC1_Inputs_TCPU.bit.Limit_Switch;      //STS_TC_Cover_Open:Traction converter's cover is open. Traction is not possible. (0: Cover is CLOSED / 1: Cover is OPEN)
    CC1TXMsg.TX_MSG1.uiBuffer[3].bit.bit5  = PGUREC_TCPU_Inputs.bit.MCB_ON;                                            //STS_TL_VCB:Main circuit breaker open/close status. (0: VCB is OPEN / 1: VCB is CLOSED)
    CC1TXMsg.TX_MSG2.uiBuffer[0].all       = VCatenary;                                      //Catenary_Voltage
    CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit11 = PGUREC_TL_Cabs_Mode && PGUREC_DIOC2_Inputs2.bit.Cabs_Mode_Act;     //DIA_TL_Cabs_Mode:Diagnostic for signal conflict: Trainline CAB Mode signal (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit12 = PGUREC_Cmd_Traction_Null && PGUREC_TCPU_Inputs.bit.Trac_Null;      //DIA_TL_Traction_Null:Diagnostic for signal conflict: Trainline Traction_Null signal (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG2.uiBuffer[3].bit.bit15 = PGUREC_Cmd_Traction_Cutoff && PGUREC_TCPU_Inputs.bit.Trac_CuttOff; //DIA_TL_Traction_CutOff:Diagnostic for signal conflict: Trainline Traction CutOff  Loop signal (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit1  = PGUREC_TL_MC_S1 && PGUREC_DIOC2_Inputs1.bit.Master_Cont1;          //DIA_TL_MC_S1:Diagnostic for signal conflict: Active cabin's master controller switch 1 - Traction Command (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit2  = PGUREC_TL_MC_S2 && PGUREC_DIOC2_Inputs1.bit.Master_Cont2;          //DIA_TL_MC_S2:Diagnostic for signal conflict: Active cabin's master controller switch 2 - Traction Command (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit3  = PGUREC_TL_MC_S3 && PGUREC_DIOC2_Inputs1.bit.Master_Cont3;          //DIA_TL_MC_S3:Diagnostic for signal conflict: Active cabin's master controller switch 3 - Traction Command (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit4  = PGUREC_TL_MC_S4 && PGUREC_DIOC2_Inputs1.bit.Master_Cont4;          //DIA_TL_MC_S4:Diagnostic for signal conflict: Active cabin's master controller switch 4 - Brake Command (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit5  = PGUREC_TL_MC_S5 && PGUREC_DIOC2_Inputs1.bit.Master_Cont5;          //DIA_TL_MC_S5:Diagnostic for signal conflict: Active cabin's master controller switch 5 - Brake Command (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit6  = PGUREC_TL_MC_S6 && PGUREC_DIOC2_Inputs1.bit.Master_Cont6;          //DIA_TL_MC_S6:Diagnostic for signal conflict: Active cabin's master controller switch 6 - Brake Command (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit8  = ((PGUREC_Catenary_Voltage -  VCatenary > 5000) || (VCatenary - PGUREC_Catenary_Voltage > 5000)); //DIA_Conflict_Catenary_Voltage:Difference between analog input and MVB signal is bigger than 5 kV. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit10 = PGUREC_SWProtErrFlags.bit.VdcOV;                           //DIA_Conflict_Catenary_Voltage:DC link over voltage (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit11 = PGUREC_SWProtErrFlags.bit.VdcLV;                           //DIA_DC_Link_LV:DC link low voltage (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit12 = PGUREC_SWProtErrFlags.bit.Is1OC;                           //DIA_Input1_OC:Input 1 over current. (To be used by TCMS to detect ovrecurrent reason. TCU or Trafo) (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit13 = PGUREC_SWProtErrFlags.bit.Is2OC;                           //DIA_Input2_OC:Input 2 over current. (To be used by TCMS to detect ovrecurrent reason. TCU or Trafo) (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit14 = PGUREC_SWProtErrFlags.bit.Rec1OL;                          //DIA_Input1_OL:Input 1 overload (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[0].bit.bit15 = PGUREC_SWProtErrFlags.bit.Rec2OL;                          //DIA_Input2_OL:Input 2 overload (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit2  = !PGUREC_DIOC1_Inputs1.bit.Level1_STA;                        //DIA_Coolant_Lvl_Warning:Cooling liquid level is low (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit3  = !PGUREC_DIOC1_Inputs1.bit.Level2_STA;                        //DIA_Coolant_Lvl_Fault:Cooling liquid level is too low (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit4  = PGUREC_DIOC1_Inputs1.bit.Cooling_FAN1_MPS_STA || PGUREC_DIOC1_Inputs1.bit.Cooling_FAN2_MPS_STA;  //DIA_Coolant_Fan_CB:Circuit breaker of coolant fan is OFF (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit5  = PGUREC_DIOC1_Inputs1.bit.Cabin_FAN1_2_FUSE_STA;              //DIA_Cabinet_Fan_CB:Circuit breaker of cabinet fan is OFF (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit6  = PGUREC_DIOC1_Inputs1.bit.CKU_FAN1_2_FUSE_STA;                //DIA_TCU_Fan_CB:Circuit breaker of TCU fan is OFF (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit7  = PGUREC_DIOC1_Inputs1.bit.Cooling_PUMP_MPS_STA;               //DIA_Pump_CB:Circuit breaker of pump is OFF (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit8  = PGU_ContacErrFlags1.bit.MC_CER;                              //DIA_Input_Contactor1_Jammed:TCU cannot open its own input contactor. For that reason, TCU opened VCB. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit9  = PGU_ContacErrFlags2.bit.MC_CER;                              //DIA_Input_Contactor2_Jammed:TCU cannot open its own input contactor. For that reason, TCU opened VCB. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit10 = PGU_ContacErrFlags1.bit.MC_OER;                              //DIA_Input_Contactor1_OER:TCU's own input contactor cannot be closed. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit11 = PGU_ContacErrFlags2.bit.MC_OER;                              //DIA_Input_Contactor2_OER:TCU's own input contactor cannot be closed. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit12 = PGU_ContacErrFlags1.bit.PCC_CER;                             //DIA_PreCharge_Contactor1_Jammed:TCU cannot open precharge contactor. For that reason, TCU opened VCB. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit13 = PGU_ContacErrFlags2.bit.PCC_CER;                             //DIA_PreCharge_Contactor2_Jammed:TCU cannot open precharge contactor. For that reason, TCU opened VCB. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit14 = PGU_ContacErrFlags1.bit.PCC_OER;                             //DIA_PreCharge_Contactor1_OER:TCU's precharge contactor cannot be closed. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit15 = PGU_ContacErrFlags2.bit.PCC_OER;                             //DIA_PreCharge_Contactor2_OER:TCU's precharge contactor cannot be closed. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit0  = PGUREC_DIOC1_Inputs_TCPU.bit.Condansator_Pressure;           //DIA_Capacitor_Fault:One or more capacitor blow circuit tripped (0: NO Fault / 1: Fault)
//    CC1TXMsg.TX_MSG3.uiBuffer[2].bit.bit1  = ;  //DIA_110VDC_Input_Fault:TCU 110VDC input supply fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit2  = !PGUREC_TCPU_Faults_Others.bit.Batlow;                       //DIA_15VDC_GPLV_Fault:Internal 15 VDC gate driver supply fault (gate power low voltage) (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit3  = PGUREC_TCPU_Faults_Others.bit.VA_24V_P;                      //DIA_24VDC_P_Fault:Internal 24 VDC supply positive side fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit4  = PGUREC_TCPU_Faults_Others.bit.VA_24V_N;                      //DIA_24VDC_N_Fault:Internal 24 VDC supply negative side fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit5  = (!PGUREC_TCPU_Faults_Others.bit.VD1_5V || !PGUREC_TCPU_Faults_Others.bit.VD2_5V);  //DIA_5VDC_D_Fault:Internal 5 VDC digital supply fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit6  = (!PGUREC_TCPU_Faults_Others.bit.VA_5V_P || !PGUREC_TCPU_Faults_Others.bit.VA_5V_N); //DIA_5VDC_A_Fault:Internal 5 VDC analog supply fault (0: NO Fault / 1: Fault)
////    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit7  = ;  //DIA_CPU_Fault:General CPU fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit8  = FOIO_CANRXMsg.RX_MSG1.bit.Rect1U.Plus.CFD;                   //DIA_Rec1_IGBT_UP_Fault:Rectifier-1 IGBT's U+ phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit9  = FOIO_CANRXMsg.RX_MSG1.bit.Rect1U.Minus.CFD;                  //DIA_Rec1_IGBT_UN_Fault:Rectifier-1 IGBT's U- phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit10 = FOIO_CANRXMsg.RX_MSG1.bit.Rect1V.Plus.CFD;                   //DIA_Rec1_IGBT_VP_Fault:Rectifier-1 IGBT's V+ phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit11 = FOIO_CANRXMsg.RX_MSG1.bit.Rect1V.Minus.CFD;                  //DIA_Rec1_IGBT_VN_Fault:Rectifier-1 IGBT's V- phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit12 = FOIO_CANRXMsg.RX_MSG1.bit.Rect2U.Plus.CFD;                   //DIA_Rec2_IGBT_UP_Fault:Rectifier-2 IGBT's U+ phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit13 = FOIO_CANRXMsg.RX_MSG1.bit.Rect2U.Minus.CFD;                  //DIA_Rec2_IGBT_UN_Fault:Rectifier-2 IGBT's U- phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit14 = FOIO_CANRXMsg.RX_MSG1.bit.Rect2V.Plus.CFD;                   //DIA_Rec2_IGBT_VP_Fault:Rectifier-2 IGBT's V+ phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[3].bit.bit15 = FOIO_CANRXMsg.RX_MSG1.bit.Rect2V.Minus.CFD;                  //DIA_Rec2_IGBT_VN_Fault:Rectifier-2 IGBT's V- phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit0  = FOIO_CANRXMsg.RX_MSG2.bit.InvU.Plus.CFD;                     //DIA_Inv_IGBT_UP_Fault:Inverter IGBT's U+ phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit1  = FOIO_CANRXMsg.RX_MSG2.bit.InvU.Minus.CFD;                    //DIA_Inv_IGBT_UN_Fault:Inverter IGBT's U- phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit2  = FOIO_CANRXMsg.RX_MSG2.bit.InvV.Plus.CFD;                     //DIA_Inv_IGBT_VP_Fault:Inverter IGBT's V+ phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit3  = FOIO_CANRXMsg.RX_MSG2.bit.InvV.Minus.CFD;                    //DIA_Inv_IGBT_VN_Fault:Inverter IGBT's V- phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit4  = FOIO_CANRXMsg.RX_MSG2.bit.InvW.Plus.CFD;                     //DIA_Inv_IGBT_WP_Fault:Inverter IGBT's W+ phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit5  = FOIO_CANRXMsg.RX_MSG2.bit.InvW.Minus.CFD;                    //DIA_Inv_IGBT_WN_Fault:Inverter IGBT's W- phase fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit6  = FOIO_CANRXMsg.RX_MSG2.bit.BP_OVCRFOut.OVCRFOut.CFD;          //DIA_Chop_IGBT_OVP_Fault:Chopper over voltage protection IGBT fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit7  = FOIO_CANRXMsg.RX_MSG2.bit.BP_OVCRFOut.BPSignals.CFD;         //DIA_Chop_IGBT_FWD_Fault:Chopper free wheeling diode IGBT fault (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit8  = (FOIO_CANRXMsg.RX_MSG1.all || FOIO_CANRXMsg.RX_MSG2.all);    //DIA_CFD_Fault:Commutation failure. Can be caused from any gate driver failure, IGBT failure, internal commutation failure. (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit9  = PGUREC_TCPU_Inputs.bit.Insulation_Device_STA;                //DIA_Insulation_Fault:Insulation fault in TC or motor (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit10 = (PGUTXMsg.C6.uiBuffer[0].bit.bit1 || PGUTXMsg.C6.uiBuffer[0].bit.bit3); //DIA_PreCh_Fault:Precharge routine unsuccessful (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit11 = (PGUREC_SWProtCatenaryErrFlags.bit.VsLFreq || PGUREC_SWProtCatenaryErrFlags.bit.VsOFreq); //DIA_Frequency_Irregular:Irregular catenary voltage frequency fault. (For that reason, TCU opened VCB) (0: NO Fault / 1: Fault)
    CC1TXMsg.TX_MSG3.uiBuffer[4].bit.bit12 = PGUREC_SWProtCatenaryErrFlags.bit.VsWave; //DIA_WF_Irregular:Irregular catenary voltage waveform fault. (For that reason, TCU opened VCB) (0: NO Fault / 1: Fault)


// CCU_2 Messages for PGU_INV
    CC1TXMsg.TX_MSG5.uiBuffer[0].all = (Uint16) PGUREC_Lifesign;   //Lifesign:Life signal of port (Increase in cycles)
////    CC1TXMsg.TX_MSG5.uiBuffer[1].all =                               //Traction_Achieved:Actual achieved value of traction after slip/slide compensation per axle.
////    CC1TXMsg.TX_MSG5.uiBuffer[2].all =                               //ED_Brake_Achieved:Actual ED Brake torque per axle measured from traction motor current per axle.

    if (PGUREC_CKU1 == 1)
    {
        //Temp_Converter:Traction converter cabinet temperature
        CC1TXMsg.TX_MSG5.uiBuffer[3].byte.byte0 = PGUREC_TemperatureLPF_CKU1.CabinTemp;

        //Temp_Power_Module:Maximum power module temperature of traction converter
        if (PGUREC_TemperatureLPF_CKU1.RectifierTemp1 >= PGUREC_TemperatureLPF_CKU1.RectifierTemp2)
        CC1TXMsg.TX_MSG5.uiBuffer[3].byte.byte1 = PGUREC_TemperatureLPF_CKU1.RectifierTemp1;
        else
        CC1TXMsg.TX_MSG5.uiBuffer[3].byte.byte1 = PGUREC_TemperatureLPF_CKU1.RectifierTemp2;

        //Temp_Motor1:Traction motor-1 temperature (winding)
        CC1TXMsg.TX_MSG6.uiBuffer[0].byte.byte1 = PGUREC_TemperatureLPF_CKU1.MotorTemp1;

        //Temp_Gear_Box1:Traction motor-1 gear box temperature (bearing)
        CC1TXMsg.TX_MSG6.uiBuffer[1].byte.byte1 = PGUREC_TemperatureLPF_CKU1.GearTemp;
    }
    else if (PGUREC_CKU2 == 1)
    {
        //Temp_Converter:Traction converter cabinet temperature
        CC1TXMsg.TX_MSG5.uiBuffer[3].byte.byte0 = PGUREC_TemperatureLPF_CKU2.CabinTemp;

        //Temp_Power_Module:Maximum power module temperature of traction converter
        if (PGUREC_TemperatureLPF_CKU2.RectifierTemp1 >= PGUREC_TemperatureLPF_CKU2.RectifierTemp2)
        CC1TXMsg.TX_MSG5.uiBuffer[3].byte.byte1 = PGUREC_TemperatureLPF_CKU2.RectifierTemp1;
        else
        CC1TXMsg.TX_MSG5.uiBuffer[3].byte.byte1 = PGUREC_TemperatureLPF_CKU2.RectifierTemp2;

        //Temp_Coolant:Coolant temperature of traction converter
        CC1TXMsg.TX_MSG6.uiBuffer[0].byte.byte0 = PGUREC_TemperatureLPF_CKU2.CoolingFlow_Temp;

        //Temp_Motor1:Traction motor-1 temperature (winding)
        CC1TXMsg.TX_MSG6.uiBuffer[0].byte.byte1 = PGUREC_TemperatureLPF_CKU2.MotorTemp1;

        //Temp_Gear_Box1:Traction motor-1 gear box temperature (bearing)
        CC1TXMsg.TX_MSG6.uiBuffer[1].byte.byte1 = PGUREC_TemperatureLPF_CKU2.GearTemp;
    }

    CC1TXMsg.TX_MSG7.uiBuffer[0].all        = (PGUREC_IRec1RMS.RMS*0.1);                        //Secondary_Current1:Converter input current 1
    CC1TXMsg.TX_MSG7.uiBuffer[1].all        = (PGUREC_IRec2RMS.RMS*0.1);                        //Secondary_Current2:Converter input current 2
}


