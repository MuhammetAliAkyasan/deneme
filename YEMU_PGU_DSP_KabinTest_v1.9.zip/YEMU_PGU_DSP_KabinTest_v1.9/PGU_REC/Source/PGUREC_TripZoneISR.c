#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUREC_Common.h"

interrupt void PGUREC_TripZoneISR(void)
{

	if((!IO_READ(PGUREC_TZ1GPIO))||(!IO_READ(PGUREC_TZ2GPIO)))       // Bekleme durumunda hata ??
	{
	    PGUGateOFF
	    FOIOGateOFF

	    PGUREC_FLT_REG.bit.HWPROT    = 1; 		// Hardware fault
	    PGUREC_CTL_REG.bit.STATE     = 15;		// Hardware Hata durumu
        PGUREC_RCTL_REG.bit.Enable   = 0;

        PCC1_REG.bit.OPEN = 1;       // Precharge kontakt�r� a�ma sinyali uyguland�
//        PGU_IO_SET(PCCSig)
        PGUREC_TCPU_Outputs.bit.PCC1_SIG=1;


        PCC2_REG.bit.OPEN = 1;       // Precharge kontakt�r� a�ma sinyali uyguland�
//        PGU_IO_SET(PCCSig)
        PGUREC_TCPU_Outputs.bit.PCC2_SIG=1;


        MCAUX_REG1.bit.OPEN = 1;        // Ana kontakt�r� a�ma sinyali uyguland�
        IO_SET(MCSig1)

        MCAUX_REG2.bit.OPEN = 1;        // Ana kontakt�r� a�ma sinyali uyguland�
        IO_SET(MCSig2)

	}
	else
	{
	    PGUREC_RCTL_REG.bit.Enable	= 2;
	}
}


//.OPEN = 1
