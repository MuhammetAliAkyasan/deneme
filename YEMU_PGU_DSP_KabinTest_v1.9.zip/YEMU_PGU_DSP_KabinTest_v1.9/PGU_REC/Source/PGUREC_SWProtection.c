#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUREC_Common.h"

//PGUREC_SWProtection

void PGUREC_SWProtectionCatenary(PGUREC_SWPROT_Catenary Fdbs, PGUREC_SWPROTLEVELS_Catenary WarnLimits, PGUREC_SWPROTLEVELS_Catenary ErrLimits, PGUREC_SWPROTFLTCatenary_REG * WarnFlags, PGUREC_SWPROTFLTCatenary_REG * ErrFlags , PGUREC_SWPROTCOUNTCatenary * ErrTime,PGUREC_SWPROTCOUNTCatenary * ErrCount)

{
    //------------------------------------------------------------------//
    //-------------- Supply voltage level error check ------------------//
    //------------------------------------------------------------------//
        // Over voltage check
        if (Fdbs.Vs >= ErrLimits.VsOV)
        {
            if(ErrCount->VsOV < ErrTime->VsOV)
            {
                ErrCount->VsOV++;
                WarnFlags->bit.VsOV = 1;
            }
            else
            {
                ErrFlags->bit.VsOV = 1;
            }
        }
        else
        {
            ErrCount->VsOV = 0;
            if (Fdbs.Vs>= WarnLimits.VsOV)
            {
                WarnFlags->bit.VsOV     = 1;
                if(TORQLIM_REG.bit.SUPPLYH == 1)
                {
                    PGUREC_Torque.SupplyHLimFactor     = 1.0 - (Fdbs.Vs - WarnLimits.VsOV)/(ErrLimits.VsOV - WarnLimits.VsOV);         // Maximum cutback limiter
                }
                else
                {
                    PGUREC_Torque.SupplyHLimFactor     = 1.0;
                }
            }
            else
            {
                WarnFlags->bit.VsOV = 0;
                PGUREC_Torque.SupplyHLimFactor     = 1.0;
            }
        }

        // Low voltage check
        if (Fdbs.Vs <= ErrLimits.VsLV && MCAUX_REG1.bit.STATUS == 1 && MCAUX_REG2.bit.STATUS == 1 && MC1_Status == 0 && MC2_Status == 0)
        {
            if(ErrCount->VsLV < ErrTime->VsLV)
            {
                ErrCount->VsLV++;
                WarnFlags->bit.VsLV = 1;
            }
            else
            {
                ErrFlags->bit.VsLV = 1;
            }
        }
        else
        {
            ErrCount->VsLV = 0;
            if (Fdbs.Vs <= WarnLimits.VsLV && MCAUX_REG1.bit.STATUS == 1  && MCAUX_REG2.bit.STATUS == 1 && MC1_Status == 0  && MC2_Status == 0)
            {
                WarnFlags->bit.VsLV     = 1;
                if(TORQLIM_REG.bit.SUPPLYL == 1)
                {
                    PGUREC_Torque.SupplyLLimFactor = (Fdbs.Vs - ErrLimits.VsLV)/(WarnLimits.VsLV - ErrLimits.VsLV);
                }
                else
                {
                    PGUREC_Torque.SupplyLLimFactor = 1.0;
                }
            }
            else
            {
                WarnFlags->bit.VsLV     = 0;
                PGUREC_Torque.SupplyLLimFactor = 1.0;
            }
        }


    // Over THD check
          if (Fdbs.VsWave >= ErrLimits.VsWave)
          {
              if(ErrCount->VsWave < ErrTime->VsWave)
              {
                  ErrCount->VsWave++;
                  WarnFlags->bit.VsWave = 1;
              }
              else
              {
                  ErrFlags->bit.VsWave = 1;
              }
          }
          else
          {
              ErrCount->VsWave = 0;
              if (Fdbs.Vs>= WarnLimits.VsWave)
              {
                  WarnFlags->bit.VsWave     = 1;
              }
              else
              {
                  WarnFlags->bit.VsWave = 0;
              }
          }



    //------------------------------------------------------------------//
    //-------------- Supply voltage frequency error check --------------//
    //------------------------------------------------------------------//
           // Over frequency check

           if (Fdbs.VsFreq >= ErrLimits.VsOFreq)
           {
               if(ErrCount->VsOFreq < ErrTime->VsOFreq )
               {
                   ErrCount->VsOFreq++;
                   WarnFlags->bit.VsOFreq = 1;
               }
               else
               {
                   ErrFlags->bit.VsOFreq = 1;
               }
           }
           else
           {
               ErrCount->VsOFreq = 0;
               if (Fdbs.VsFreq>= WarnLimits.VsOFreq)
               {
                   WarnFlags->bit.VsOFreq     = 1;
               }
               else
               {
                   WarnFlags->bit.VsOFreq = 0;
               }
           }


           // Low frequency check
           if (Fdbs.VsFreq <= ErrLimits.VsLFreq && MCAUX_REG1.bit.STATUS == 1  && MC1_Status ==0 && MCAUX_REG2.bit.STATUS == 1  && MC2_Status ==0)
           {
               if(ErrCount->VsLFreq < ErrTime->VsLFreq)
               {
                   ErrCount->VsLFreq++;
                   WarnFlags->bit.VsLFreq = 1;
               }
               else
               {
                   ErrFlags->bit.VsLFreq = 1;
               }
           }
           else
           {
               ErrCount->VsLFreq = 0;
               if (Fdbs.VsFreq <= WarnLimits.VsLFreq && MCAUX_REG1.bit.STATUS == 1  && MC1_Status ==0 && MCAUX_REG2.bit.STATUS == 1  && MC2_Status ==0)
               {
                   WarnFlags->bit.VsLFreq     = 1;
               }
               else
               {
                   WarnFlags->bit.VsLFreq     = 0;
               }
           }

   //------------------------------------------------------------------//
   //----------- Supply voltage power factor error check --------------//
   //------------------------------------------------------------------//

   // Low power factor check

             if (Fdbs.VsPowFac <= ErrLimits.Vs_Low_PF && MCAUX_REG1.bit.STATUS == 1  && MC1_Status ==0 && MCAUX_REG2.bit.STATUS == 1  && MC2_Status ==0)
             {
                 if(ErrCount->Vs_Low_PF < ErrTime->Vs_Low_PF)
                 {
                     ErrCount->Vs_Low_PF++;
                     WarnFlags->bit.Vs_Low_PF = 1;
                 }
                 else
                 {
                     ErrFlags->bit.Vs_Low_PF = 1;
                 }
             }
             else
             {
                 ErrCount->Vs_Low_PF = 0;
                 if (Fdbs.VsPowFac <= WarnLimits.Vs_Low_PF && MCAUX_REG1.bit.STATUS == 1  && MC1_Status ==0 && MCAUX_REG2.bit.STATUS == 1  && MC2_Status ==0)
                 {
                     WarnFlags->bit.Vs_Low_PF     = 1;
                 }
                 else
                 {
                     WarnFlags->bit.Vs_Low_PF     = 0;
                 }
             }


}

void PGUREC_SWProtection(PGUREC_SWPROT Fdbs, PGUREC_SWPROTLEVELS WarnLimits, PGUREC_SWPROTLEVELS ErrLimits, PGUREC_SWPROTFLT_REG * WarnFlags, PGUREC_SWPROTFLT_REG * ErrFlags , PGUREC_SWPROTCOUNT * ErrTime,PGUREC_SWPROTCOUNT * ErrCount)
{

    //------------------------------------------------------------------//
    //-------------- Secondary over current-1 error check ----------------//
    //------------------------------------------------------------------//

        if (Fdbs.Is1 >= ErrLimits.Is1OC)
        {
            if(ErrCount->Is1OC < ErrTime->Is1OC)
            {
                ErrCount->Is1OC++;
                WarnFlags->bit.Is1OC = 1;
            }
            else
            {
                ErrFlags->bit.Is1OC = 1;
            }
        }
        else
        {
            ErrCount->Is1OC = 0;
            if (Fdbs.Is1 >= WarnLimits.Is1OC)
            {
                WarnFlags->bit.Is1OC = 1;
            }
            else
            {
                WarnFlags->bit.Is1OC = 0;
            }
        }


//------------------------------------------------------------------//
//-------------- Secondary over current-2 error check ----------------//
//------------------------------------------------------------------//

        if (Fdbs.Is2 >= ErrLimits.Is2OC)
        {
            if(ErrCount->Is2OC < ErrTime->Is2OC)
            {
                ErrCount->Is2OC++;
                WarnFlags->bit.Is2OC = 1;
            }
            else
            {
                ErrFlags->bit.Is2OC = 1;
            }
        }
        else
        {
            ErrCount->Is2OC = 0;
            if (Fdbs.Is2 >= WarnLimits.Is2OC)
            {
                WarnFlags->bit.Is2OC = 1;
            }
            else
            {
                WarnFlags->bit.Is2OC = 0;
            }
        }


    //------------------------------------------------------------------//
    //-------------- DC bus voltage level error check ------------------//
    //------------------------------------------------------------------//
        // Over voltage check
        if (Fdbs.Vdc >= ErrLimits.VdcOV)
        {
            if(ErrCount->VdcOV < ErrTime->VdcOV)
            {
                ErrCount->VdcOV++;
                WarnFlags->bit.VdcOV = 1;
            }
            else
            {
                ErrFlags->bit.VdcOV = 1;
            }
        }
        else
        {
            ErrCount->VdcOV = 0;
            if (Fdbs.Vdc  >= WarnLimits.VdcOV)
            {
                WarnFlags->bit.VdcOV    = 1;
                if(TORQLIM_REG.bit.VDC == 1)
                {
                    PGUREC_Torque.VdcLimFactor     = 1.0 - (Fdbs.Vdc - WarnLimits.VdcOV)/(ErrLimits.VdcOV - WarnLimits.VdcOV);
                }
                else
                {
                    PGUREC_Torque.VdcLimFactor     = 1.0;
                }
            }
            else
            {
                WarnFlags->bit.VdcOV = 0;
                PGUREC_Torque.VdcLimFactor     = 1.0;
            }
        }


        // Low voltage check
        if ((Fdbs.Vdc  <= ErrLimits.VdcLV) && (MCAUX_REG1.bit.STATUS == 1  && MC1_Status ==0 && MCAUX_REG2.bit.STATUS == 1 && MC2_Status ==0))
        {
            if(ErrCount->VdcLV < ErrTime->VdcLV)
            {
                ErrCount->VdcLV++;
                WarnFlags->bit.VdcLV = 1;
            }
            else
            {
                ErrFlags->bit.VdcLV = 1;
            }
        }
        else
        {
            ErrCount->VdcLV = 0;
            if (Fdbs.Vdc  <= WarnLimits.VdcLV && MCAUX_REG1.bit.STATUS == 1 && MC1_Status ==0 && MCAUX_REG2.bit.STATUS == 1 && MC2_Status ==0)
            {
                WarnFlags->bit.VdcLV= 1;
            }
            else
            {
                WarnFlags->bit.VdcLV = 0;
            }
        }




//------------------------------------------------------------------//
//---------------- Rectifier-1 over load check ---------------------//
//------------------------------------------------------------------//

    if ( Fdbs.Rec1InPow >= ErrLimits.Rec1OL)
    {
        if(ErrCount->Rec1OL < ErrTime->Rec1OL)
        {
            ErrCount->Rec1OL++;
            WarnFlags->bit.Rec1OL = 1;
        }
        else
        {
            ErrFlags->bit.Rec1OL = 1;
        }
    }
    else
    {
        ErrCount->Rec1OL = 0;
        if (Fdbs.Rec1InPow  >= WarnLimits.Rec1OL)
        {
            WarnFlags->bit.Rec1OL = 1;
            if(TORQLIM_REG.bit.INPOW == 1)
            {
                PGUREC_Torque.InPowLimFactor   = 1.0 - (Fdbs.Rec1InPow - WarnLimits.Rec1OL)/(ErrLimits.Rec1OL - WarnLimits.Rec1OL);
            }
            else
            {
                PGUREC_Torque.InPowLimFactor   = 1.0;
            }
        }
        else
        {
            WarnFlags->bit.Rec1OL = 0;
            PGUREC_Torque.InPowLimFactor = 1.0;
        }
    }

//------------------------------------------------------------------//
//---------------- Rectifier-2 over load check ---------------------//
//------------------------------------------------------------------//

    if ( Fdbs.Rec2InPow >= ErrLimits.Rec2OL)
    {
        if(ErrCount->Rec2OL < ErrTime->Rec2OL)
        {
            ErrCount->Rec2OL++;
            WarnFlags->bit.Rec2OL = 1;
        }
        else
        {
            ErrFlags->bit.Rec2OL = 1;
        }
    }
    else
    {
        ErrCount->Rec2OL = 0;
        if (Fdbs.Rec2InPow  >= WarnLimits.Rec2OL)
        {
            WarnFlags->bit.Rec2OL = 1;
            if(TORQLIM_REG.bit.INPOW == 1)
            {
                PGUREC_Torque.InPowLimFactor   = 1.0 - (Fdbs.Rec2InPow - WarnLimits.Rec2OL)/(ErrLimits.Rec2OL - WarnLimits.Rec2OL);
            }
            else
            {
                PGUREC_Torque.InPowLimFactor   = 1.0;
            }
        }
        else
        {
            WarnFlags->bit.Rec2OL = 0;
            PGUREC_Torque.InPowLimFactor = 1.0;
        }
    }


    //------------------------------------------------------------------//
    //-------------- Rectifiers Input Current sensors difference (unbalanced load) check -------------------//
    //------------------------------------------------------------------//

        if ( Fdbs.IsDiff >= ErrLimits.Is_Unbalanced)
        {
            if(ErrCount->Is_Unbalanced < ErrTime->Is_Unbalanced)
            {
                ErrCount->Is_Unbalanced++;
                WarnFlags->bit.Is_Unbalanced = 1;
            }
            else
            {
                ErrFlags->bit.Is_Unbalanced = 1;
            }
        }
        else
        {
            ErrCount->Is_Unbalanced = 0;
            if (Fdbs.IsDiff  >= WarnLimits.Is_Unbalanced)
            {
                WarnFlags->bit.Is_Unbalanced = 1;
            }
            else
            {
                WarnFlags->bit.Is_Unbalanced = 0;
            }
        }




}

void PGUREC_TemperatureProtection1(PGUREC_TEMPERATURE_CKU1 temp, PGUREC_TEMPERATURE_CKU1 warn, PGUREC_TEMPERATURE_CKU1 err, PGUREC_TEMPSTS_REG_CKU1 *warnflag, PGUREC_TEMPSTS_REG_CKU1 *errflag)
{
	float32 *t  = &(temp.RectifierTemp1);
	float32 *w	= &(warn.RectifierTemp1);
	float32 *e	= &(err.RectifierTemp1);

	// Inverter over temperature error check
	Uint16 i;
	for(i=0;i<PGUREC_TEMPChNUM_CKU1;i++)
	{
		if (*(t+i) >= *(e+i))
		{
			errflag->all |= 1<<i;
		}
		else if(*(t+i) >= *(w+i))
		{
			warnflag->all |= 1<<i;
		}
		else
		{
			warnflag->all &= ~(1<<i);
		}
	}
}

void PGUREC_TemperatureProtection2(PGUREC_TEMPERATURE_CKU2 temp, PGUREC_TEMPERATURE_CKU2 warn, PGUREC_TEMPERATURE_CKU2 err, PGUREC_TEMPSTS_REG_CKU2 *warnflag, PGUREC_TEMPSTS_REG_CKU2 *errflag)
{
    float32 *t  = &(temp.RectifierTemp1);
    float32 *w  = &(warn.RectifierTemp1);
    float32 *e  = &(err.RectifierTemp1);

    // Inverter over temperature error check
    Uint16 i;
    for(i=0;i<PGUREC_TEMPChNUM_CKU2;i++)
    {
        if (*(t+i) >= *(e+i))
        {
            errflag->all |= 1<<i;
        }
        else if(*(t+i) >= *(w+i))
        {
            warnflag->all |= 1<<i;
        }
        else
        {
            warnflag->all &= ~(1<<i);
        }
    }
}
//  Capacitive_Power
