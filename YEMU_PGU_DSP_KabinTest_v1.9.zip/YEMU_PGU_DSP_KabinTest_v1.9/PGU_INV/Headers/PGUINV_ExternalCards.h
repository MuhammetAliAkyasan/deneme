/*
 * PGUINV_ExternalCards.h
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_EXTERNALCARDS_H_
#define PGUINV_EXTERNALCARDS_H_

extern void     PGUINV_InitFOIO();
extern void     PGUINV_InitTCPU();
extern void     PGUINV_HWFaultLimitSet();
extern void     PGUINV_HWFaultLimitCalc();
extern void     PGUINV_TemperatureRead1();
extern void     PGUINV_TemperatureRead2();

#endif /* PGUINV_EXTERNALCARDS_H_ */
