/*
 * PGUINV_Tasks.h
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_TASKS_H_
#define PGUINV_TASKS_H_

// PGUINV_Tasks.c
extern void PGUINV_TaskInit(void);
extern void PGUINV_TaskLoop(void);
extern void PGUINV_A0(void);
extern void PGUINV_B0(void);
extern void PGUINV_C0(void);
extern void PGUINV_A1(void);
extern void PGUINV_A2(void);
extern void PGUINV_A3(void);
extern void PGUINV_B1(void);
extern void PGUINV_B2(void);
extern void PGUINV_B3(void);
extern void PGUINV_C1(void);
extern void PGUINV_C2(void);
extern void PGUINV_C3(void);
extern void (*PGUINV_Alpha_State_Ptr)(void);
extern void (*PGUINV_A_Task_Ptr)(void);
extern void (*PGUINV_B_Task_Ptr)(void);
extern void (*PGUINV_C_Task_Ptr)(void);

extern int16   PGUINV_VTimer0[4];     //  Virtual Timers slaved off CPU Timer 0 (A events)
extern int16   PGUINV_VTimer1[4];     //  Virtual Timers slaved off CPU Timer 1 (A events)
extern int16   PGUINV_VTimer2[4];     //  Virtual Timers slaved off CPU Timer 2 (A events)


#endif /* PGUINV_TASKS_H_ */
