/*
 * PGUINV_PWM.h
 *
 *  Created on: 10 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_PWM_H_
#define PGUINV_PWM_H_

//**************************************************************************
// Default PWMGEN Initializer Object for PGUINV
//**************************************************************************
/*-----------------------------------------------------------------------------
    Define the structure of the PWM Driver Object
-----------------------------------------------------------------------------*/
typedef struct {
        Uint16 PeriodMax;       // Parameter: PWM Half-Period in CPU clock cycles
        Uint16 Deadband;        // Parameter: PWM deadband in CPU clock cycles
        float32 MfuncC;         // Input: EPWMx A&B Duty cycle ratio   ETSEL.bit.SOCAEN
        }
PWMGEN ;

// Rectifier Parameters
#define PGUINV_ISR_FREQUENCY        0.8                                                   // Inverter  ISR = 800 Hz
#define PGUINV_MAINISR_S_DIV        8.0                                                   // Main ISR Sampling period / Inverter Switching period
#define PGUINV_TS_SW                0.001/PGUINV_ISR_FREQUENCY                            // Inverter Switching period (sec)
#define PGUINV_TS                   0.001/PGUINV_ISR_FREQUENCY/2.0                        // Inverter Sampling period (sec)
#define PGUINV_TS_MAINISR           0.001/PGUINV_ISR_FREQUENCY/PGUINV_MAINISR_S_DIV
#define PGUINV_BRK_PWM_PERIOD       SYSTEM_FREQUENCY*1000000*PGUINV_TS_SW/4.0             // TBPRD = TBfreq / PWMfreq / 2 = (SYSCLKOUT / TBprescale) / PWMfreq / 2

#define PGUINV_MAINISR_PWM_PERIOD   PGUINV_BRK_PWM_PERIOD/PGUINV_MAINISR_S_DIV            // HS control loop period

#define PGUINV_PWM_DEADBAND         DB_4uS

#define PGUINV_INVPWM_GEN_INIT  {   PGUINV_MAINISR_PWM_PERIOD * PGUINV_MAINISR_S_DIV, \
                                    PGUINV_PWM_DEADBAND    ,   \
                                    0.0         ,   \
                                }

#define PGUINV_ISR_PWM_GEN_INIT  {   PGUINV_MAINISR_PWM_PERIOD  , \
                                     PGUINV_PWM_DEADBAND    ,   \
                                     0.0         ,   \
                                }

extern PWMGEN      PGUINV_IsrPWM;             //  ISR PWM instance and initialization  DBFED

extern PWMGEN      PGUINV_InvPWM1;            //  Inv PWM instance and initialization
extern PWMGEN      PGUINV_InvPWM2;            //  Inv PWM instance and initialization
extern PWMGEN      PGUINV_InvPWM3;            //  Inv PWM instance and initialization

extern PWMGEN      PGUINV_BrkPWM;             //  Break PWM instance and initialization


#endif /* PGUINV_PWM_H_ */
