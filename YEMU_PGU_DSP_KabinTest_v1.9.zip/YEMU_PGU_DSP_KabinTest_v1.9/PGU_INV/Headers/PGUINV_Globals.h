/*
 * PGUINV_Globals.h
 *
 *  Created on: 10 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_GLOBALS_H_
#define PGUINV_GLOBALS_H_

// Master controller Reverse Switch register bit definitions */
struct REV_SWITCH_BITS {          // bits   description
   Uint16 INITIAL:1;            // 0
   Uint16 OFF:1;                // 1
   Uint16 FORWARD:1;            // 2
   Uint16 REVERSE:1;            // 3
   Uint16 rsvd:12;              // 15:4
};

union REV_SWITCH_REG {
   Uint16                 all;
   struct REV_SWITCH_BITS   bit;
};

// Master controller Main Handle register bit definitions */
struct MAIN_HANDLE_BITS {       // bits   description
   Uint16 POWERING:1;           // 0
   Uint16 NEUTRAL:1;            // 1
   Uint16 BRAKING:1;            // 2
   Uint16 EMG_BRAKE:1;          // 3
   Uint16 rsvd:12;              // 15:4
};

union MAIN_HANDLE_REG {
   Uint16                 all;
   struct MAIN_HANDLE_BITS   bit;
};

// Master controller Status register bit definitions */
struct MASTER_STA_BITS {       // bits   description
   Uint16 REV_SW_EN:1;          // 0
   Uint16 MAIN_H_EN:1;          // 1
   Uint16 POWER_OFF:1;          // 2
   Uint16 rsvd2:1;              // 3
   Uint16 rsvd3:12;             // 15:4
};

union MASTER_STA_REG {
   Uint16                 all;
   struct MASTER_STA_BITS   bit;
};

//  Define the structure of the Master Controller Object

typedef struct {
   union  REV_SWITCH_REG     REV_SW;     // Master controller Reverse Switch register
   union  MAIN_HANDLE_REG    MAIN_HAND;     // Master controller Main Handle register
   union  MAIN_HANDLE_REG    ENABLE;     // Master controller Main Handle register
   union  MASTER_STA_REG     STA;        // Master controller Status register
   float32                   TORQUEREF;  // Torque reference
}MASTERC_REGS;


// Converter control register bit definitions */
struct CONVCTL_BITS {           // bits   description
   Uint16 ENABLE:1;             // 0   1: close 0: open
   Uint16 START:1;              // 1
   Uint16 STOP:1;               // 2
   Uint16 PAUSE:1;              // 3
   Uint16 RESET:2;              // 5:4
   Uint16 ON:1;                 // 6   Reserved1
   Uint16 POWER:1;              // 7   Reserved2
   Uint16 DEGRADED:1;           // 8
   Uint16 OPMODE:3;             // 11:9
   Uint16 STATE :4;             // 15:12
};

typedef union{
   Uint16                all;
   struct CONVCTL_BITS   bit;
}CONVCTL_REG;

// Torque limiters enable register bit definitions */
struct TORQUELIM_BITS {         // bits     description
   Uint16 TOTAL:1;              // 0        Total limiting enable
   Uint16 MOTSPEED1:1;           // 1        Speed based limiting enable
   Uint16 MOTSPEED2:1;           // 1        Speed based limiting enable
   Uint16 TEMP:1;               // 2        Temperature based limiting enable
   Uint16 VDC:1;                // 3        Vdc based limiting enable
   Uint16 SUPPLYH:1;            // 4        Supply voltage (high) based limiting enable
   Uint16 SUPPLYL:1;            // 5        Supply voltage (low) based limiting enable
   Uint16 INPOW:1;              // 6        Input Power based limiting enable
   Uint16 rsvd:8;               // 15:7     Reserved
};

typedef union{
   Uint16                all;
   struct TORQUELIM_BITS   bit;
}TORQUELIM_REG;

// Converter Fault register bit definitions */
struct CONVFLT_BITS {           // bits   description
    Uint16 STEST:1;             // 0
    Uint16 ADC:1;               // 1
    Uint16 SWPROT:1;            // 2
    Uint16 TEMP:1;              // 3
    Uint16 CONTAC:1;            // 4
    Uint16 HWPROT:1;            // 5
    Uint16 VSSYNC:1;            // 6
    Uint16 CTL:1;               // 7
    Uint16 PRECH:1;             // 8
    Uint16 VSPOL:1;             // 9
    Uint16 STELHS:1;            // 10      Tiva HandShake Error
    Uint16 rsvd1:5;             // 15:10   Reserved1
};

typedef union {
   Uint16                all;
   struct CONVFLT_BITS   bit;
}CONVFLT_REG;


typedef struct  {
    float32 DCinit;
    float32 DClimit;
    float32 Energy;
    Uint16  Ticker;
    Uint16  PCCopentime;
    Uint16  PCCmaxclosetime;
    Uint16  MCmaxclosetime;
    Uint16  DCbuildtime;
}PRECH;

/*-----------------------------------------------------------------------------
    Define the structure of the Temperature Measurement Object
-----------------------------------------------------------------------------*/
typedef struct {
        float32 InverterTemp1;        // Output: NTC   Type
        float32 InverterTemp2;        // Output: NTC   Type
        float32 Cooling_Temp;         // Output: NTC   Type
        float32 Cooling_Press;        // Output: NTC   Type
        float32 MotorTemp1;           // Output: PT100 Type
        float32 MotorTemp2;           // Output: PT100 Type
        float32 MotorTemp3;           // Output: PT100 Type
        float32 MotorTempBearing;     // Output: PT100 Type
//        float32 rsvd1;              // Output: NTC   Type
//        float32 rsvd2;              // Output: Level Sensor
//        float32 rsvd3;              // Output: PT100 Type
        }
PGUINV_TEMPERATURE_CKU1 ;

typedef struct {
        float32 InverterTemp1;        // Output: NTC   Type
        float32 InverterTemp2;        // Output: NTC   Type
        float32 MotorTemp1;           // Output: PT100 Type
        float32 MotorTemp2;           // Output: PT100 Type
        float32 MotorTemp3;           // Output: PT100 Type
        float32 MotorTempBearing;     // Output: PT100 Type
//        float32 rsvd1;              // Output: NTC   Type
//        float32 rsvd2;              // Output: Level Sensor
//        float32 rsvd3;              // Output: PT100 Type
        }
PGUINV_TEMPERATURE_CKU2 ;


/*-----------------------------------------------------------------------------
    Define the structure of the Temperature Measurement Object
-----------------------------------------------------------------------------*/
typedef struct {
//        Uint16 RSVD1;               //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
        Uint16 INVTemp1;            //  NTC   Type
        Uint16 INVTemp2;            //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
        Uint16 COOLTemp;            //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
        Uint16 COOLPress;            // Output: Pressure Sensor
//        Uint16 RSVD2;               // Output: Level Sensor
        Uint16 MOTTemp1;            // Output: PT100 Type
        Uint16 MOTTemp2;            // Output: PT100 Type
        Uint16 MOTTemp3;            // Output: PT100 Type
        Uint16 MOTTempBear;         // Output: PT100 Type
//        Uint16 RSVD3;               // Output: PT100 Type
}
PGUINV_TEMP_CHSEL_CKU1 ;

typedef struct {
//        Uint16 RSVD1;               //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
        Uint16 INVTemp1;            //  NTC   Type
        Uint16 INVTemp2;            //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
//        Uint16 COOLTemp;            //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
//        Uint16 RSVD1;               //  NTC   Type
//        Uint16 COOLPress;            // Output: Pressure Sensor
//        Uint16 RSVD2;               // Output: Level Sensor
        Uint16 MOTTemp1;            // Output: PT100 Type
        Uint16 MOTTemp2;            // Output: PT100 Type
        Uint16 MOTTemp3;            // Output: PT100 Type
        Uint16 MOTTempBear;         // Output: PT100 Type
//        Uint16 RSVD3;               // Output: PT100 Type
}
PGUINV_TEMP_CHSEL_CKU2 ;

/*------------------------------------------------------------------------------
    Default Initializers for the Temperature Measurement Object
------------------------------------------------------------------------------*/
#define PGUINV_TEMP_MEAS_INIT_CKU1    { 0, 0, 0, 0, 0, 0, 0, 0 }
#define PGUINV_TEMP_MEAS_INIT_CKU2    { 0, 0, 0, 0, 0, 0 }

/*------------------------------------------------------------------------------
    Default Initializers for the Temperature Protection Warning Limit Object
------------------------------------------------------------------------------*/
#define PGUINV_TEMP_WARN_INIT_CKU1     { 70.0, 70.0, 70.0, 70.0, 70.0, 70.0, 70.0, 70.0 }
#define PGUINV_TEMP_WARN_INIT_CKU2     { 70.0, 70.0, 70.0, 70.0, 70.0, 70.0 }

/*------------------------------------------------------------------------------
    Default Initializers for the Temperature Protection Error Limit Object
------------------------------------------------------------------------------*/
#define PGUINV_TEMP_ERR_INIT_CKU1      { 80.0, 80.0, 80.0, 80.0, 80.0, 80.0, 80.0, 80.0 }
#define PGUINV_TEMP_ERR_INIT_CKU2      { 80.0, 80.0, 80.0, 80.0, 80.0, 80.0}

/*------------------------------------------------------------------------------
    Default Initializers for the Temperature Channel selection and sensor type Object
------------------------------------------------------------------------------*/
#define PGUINV_TEMP_CHSEL_INIT_CKU1    { PGUINV_INVTEMP1, PGUINV_INVTEMP2, PGUINV_COOLTEMP, PGUINV_COOLPRESS, PGUINV_MOTTEMP1, PGUINV_MOTTEMP2,  PGUINV_MOTTEMP3, PGUINV_MOTTEMP_BEAR  }
#define PGUINV_TEMP_CHSEL_INIT_CKU2    { PGUINV_INVTEMP1, PGUINV_INVTEMP2, PGUINV_MOTTEMP1, PGUINV_MOTTEMP2,  PGUINV_MOTTEMP3, PGUINV_MOTTEMP_BEAR  }

// Temperature Fault register bit definitions */
struct PGUINV_TEMPSTS_BITS_CKU1 {                   // bits   description
//      Uint16 RSVD1:1;           //
//      Uint16 RSVD1:1;           //
      Uint16 INVTemp1:1;        //  2
      Uint16 INVTemp2:1;        //  3
//      Uint16 RSVD1:1;           //
      Uint16 COOLTemp:1;        //  4
//      Uint16 RSVD1:1;           //
//      Uint16 RSVD1:1;           //
      Uint16 COOLPress:1;        //  7
//      Uint16 RSVD2:1;           //  9
      Uint16 MOTTemp1:1;        //  8
      Uint16 MOTTemp2:1;        //  9
      Uint16 MOTTemp3:1;        //  10
      Uint16 MOTTempBear:1;     //  11
//      Uint16 RSVD3:1;           //  14
      Uint16 Rsvd:4;           //  15-11
};

typedef union{
   Uint16                             all;
   struct PGUINV_TEMPSTS_BITS_CKU1    bit;
}PGUINV_TEMPSTS_REG_CKU1;

// Temperature Fault register bit definitions */
struct PGUINV_TEMPSTS_BITS_CKU2 {                   // bits   description
//      Uint16 RSVD1:1;           //
//      Uint16 RSVD1:1;           //
      Uint16 INVTemp1:1;        //  2
      Uint16 INVTemp2:1;        //  3
//      Uint16 RSVD1:1;           //
//      Uint16 COOLTemp:1;        //  4
//      Uint16 RSVD1:1;           //
//      Uint16 RSVD1:1;           //
//      Uint16 COOLPress:1;        //  7
//      Uint16 RSVD2:1;           //  9
      Uint16 MOTTemp1:1;        //  8
      Uint16 MOTTemp2:1;        //  9
      Uint16 MOTTemp3:1;        //  10
      Uint16 MOTTempBear:1;     //  11
//      Uint16 RSVD3:1;           //  14
      Uint16 Rsvd:4;           //  15-11
};

typedef union{
   Uint16                             all;
   struct PGUINV_TEMPSTS_BITS_CKU2    bit;
}PGUINV_TEMPSTS_REG_CKU2;

// Software Protection Fault register bit definitions */
struct PGUINV_SWPROTFLT_BITS {         // bits   description
    Uint16 InvOL:1;             // 3    Inverter  Over Load
    Uint16 VdcOV:1;             // 5    DC voltage Over
    Uint16 VdcLV:1;             // 6   DC voltage Low
    Uint16 MotOC_U:1;           // 8   Motor over current  Phase U
    Uint16 MotOC_W:1;           // 9   Motor over current  Phase W
    Uint16 Ibrk_OC:1;           // 9   Motor over current  Break
    Uint16 Mot1_Speed:1;          // 11   Motor Speed (RPM)
    Uint16 Mot2_Speed:1;          // 11   Motor Speed (RPM)
    Uint16 Rsvd:8;              //  15-11
      };

typedef union{
   Uint16                        all;
   struct PGUINV_SWPROTFLT_BITS   bit;
}PGUINV_SWPROTFLT_REG;




/*-----------------------------------------------------------------------------
    Define the structure of the Software Protection Levels Object
-----------------------------------------------------------------------------*/
typedef struct {
    float32 InvOL;              //  Inverter  Over Load (kVA)
    float32 VdcOV;              //  DC voltage Over
    float32 VdcLV;              //  DC voltage Low
    float32 MotOC_U;            //  Motor over current  Phase U
    float32 MotOC_W;            //  Motor over current  Phase W
    float32 Ibrk_OC;            //  Motor over current  Break
    float32 Mot1_Speed;           //  Motor Speed
    float32 Mot2_Speed;           //  Motor Speed
        }
PGUINV_SWPROTLEVELS ;


/*------------------------------------------------------------------------------
    Default Initializers for the Software Protection Warning Limit Object
------------------------------------------------------------------------------*/
#define PGUINV_SWPROT_WARN_INIT      {   600.0,         2050.0,      1450.0,    300.0,                \
                                         300.0,         300.0,       3050.0,    3050.0                \
                                     }


/*------------------------------------------------------------------------------
    Default Initializers for the Software Protection Error Limit Object
------------------------------------------------------------------------------*/
#define PGUINV_SWPROT_ERR_INIT     { 650.0,         2150.0,      1400.0,    350.0,                \
                                     350.0,         400.0,       3200.0,     3200.0               \
                                    }



/*-----------------------------------------------------------------------------
    Define the structure of the Software Protection Levels Object
-----------------------------------------------------------------------------*/
typedef struct {
    Uint16 InvOL;               //  Inverter  Over Load (kVA)
    Uint16 VdcOV;               //  DC voltage Over
    Uint16 VdcLV;               //  DC voltage Low
    Uint16 MotOC_U;             //  Motor over current  Phase U
    Uint16 MotOC_W;             //  Motor over current  Phase V
    Uint16 Ibrk_OC;             //  Break over current
    Uint16 Mot1_Speed;          //  Motor Speed
    Uint16 Mot2_Speed;          //  Motor Speed
           }
PGUINV_SWPROTCOUNT ;


/*------------------------------------------------------------------------------
    Default Initializers for the Software Protection Counter Object
------------------------------------------------------------------------------*/
#define PGUINV_SWPROT_COUNT_INIT     { 0,0,0,0,      \
                                      0,0,0,0      \
                                    }

/*-----------------------------------------------------------------------------
    Define the structure of the Software Protection Object
-----------------------------------------------------------------------------*/
typedef struct {
    float32 InvOutPow;          //  Inverter  Output Power
    float32 Vdc;                //  DC voltage
    float32 MotCur_U;           //  Motor over current  Phase U
    float32 MotCur_W;           //  Motor over current  Phase V
    float32 BrkCur;           //  Motor over current  Phase V
    float32 Mot1_Speed;           //  Motor Speed (RPM)
    float32 Mot2_Speed;           //  Motor Speed (RPM)
        }
PGUINV_SWPROT ;


/*------------------------------------------------------------------------------
    Default Initializers for the Software Protection Object
------------------------------------------------------------------------------*/
#define PGUINV_SWPROT_INIT     {  0.0,0.0,0.0,0.0,0.0,0.0,0.0}


/*-----------------------------------------------------------------------------
    Define the structure of the Hardware Protection Limit Objects
-----------------------------------------------------------------------------*/
typedef struct {
        float32 MOCErrVoltage;       // Output: Motor over current limit value
        float32 VDCErrVoltage;       // Output: DC Bus sensor over voltage limit value
        float32 BRKErrVoltage;       // Output: Break resistor over current limit value
        float32 Rsvd1;               // Output: Reserved channel limit value
        float32 Rsvd2;               // Output: Reserved channel limit value
        float32 Rsvd3;               // Output: Reserved channel limit value
        float32 Rsvd4;               // Output: Reserved channel limit value
        float32 Rsvd5;               // Output: Reserved channel limit value
        }
PGUINV_HWPROT ;

/*------------------------------------------------------------------------------
    Default Initializers for the Hardware Protection DAC Limit Object
------------------------------------------------------------------------------*/
#define PGUINV_HW_PROT_DAC_LIMITS_INIT    { 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0}


/*------------------------------------------------------------------------------
    Default Initializers for the Hardware Protection Levels Object
------------------------------------------------------------------------------*/
#define PGUINV_HW_PROT_LEVELS_INIT    {                                                      \
        295.0,      /* MOCErrVoltage    Motor over current limit value*/                    \
        0.0,        /* Reserved channel limit value*/                                       \
        0.0,        /* Reserved channel limit value*/                                       \
        0.0,        /* Reserved channel limit value*/                                       \
        0.0,        /* Reserved channel limit value*/                                       \
        0.0,        /* Reserved channel limit value*/                                       \
        0.0,        /* Reserved channel limit value*/                                       \
        0.0,        /* Not used Channel*/                                                   \
        }


typedef struct {
    float32 Vdc_Est ;
    float32 Vdc_BSF ;
    float32 Idc_BSF ;
}DC;


//--MACRO VARIABLES and INSTANCES
extern MASTERC_REGS         PGUINV_MasterContr;
extern TORQUELIM_REG        PGUINV_TORQLIM_REG;

extern CONVCTL_REG          PGUINV_CTL_REG;
extern CONVFLT_REG          PGUINV_FLT_REG;

extern PGUINV_TEMPSTS_REG_CKU1    PGUINV_TempErrFlags_CKU1;
extern PGUINV_TEMPSTS_REG_CKU1    PGUINV_TempWarnFlags_CKU1;

extern PGUINV_TEMPSTS_REG_CKU2    PGUINV_TempErrFlags_CKU2;
extern PGUINV_TEMPSTS_REG_CKU2    PGUINV_TempWarnFlags_CKU2;

extern PGUINV_SWPROTFLT_REG       PGUINV_SWProtErrFlags;
extern PGUINV_SWPROTFLT_REG       PGUINV_SWProtWarnFlags;

extern PGUINV_TEMPERATURE_CKU1    PGUINV_Temperature_CKU1;        //  Temperature measurement instance and initialization
extern PGUINV_TEMPERATURE_CKU1    PGUINV_TemperatureLPF_CKU1;      //  Temperature measurement instance and initialization
extern PGUINV_TEMPERATURE_CKU1    PGUINV_TempWarnLimits_CKU1;     //  Temperature measurement warning limits
extern PGUINV_TEMPERATURE_CKU1    PGUINV_TempErrLimits_CKU1;      //  Temperature measurement error limits

extern PGUINV_TEMP_CHSEL_CKU1     PGUINV_Temperature_ChSel_CKU1;    //  Temperature measurement channel selection and sensor types

extern PGUINV_TEMPERATURE_CKU2    PGUINV_Temperature_CKU2;        //  Temperature measurement instance and initialization
extern PGUINV_TEMPERATURE_CKU2    PGUINV_TemperatureLPF_CKU2;      //  Temperature measurement instance and initialization
extern PGUINV_TEMPERATURE_CKU2    PGUINV_TempWarnLimits_CKU2;     //  Temperature measurement warning limits
extern PGUINV_TEMPERATURE_CKU2    PGUINV_TempErrLimits_CKU2;      //  Temperature measurement error limits

extern PGUINV_TEMP_CHSEL_CKU2     PGUINV_Temperature_ChSel_CKU2;    //  Temperature measurement channel selection and sensor types


extern PGUINV_SWPROT         PGUINV_SWProtFdbs;        //  Software Protection Feedback Signals
extern PGUINV_SWPROTLEVELS   PGUINV_SWProtWarnLimits;  //  Software Protection Feedback Signals warning limits
extern PGUINV_SWPROTLEVELS   PGUINV_SWProtErrLimits;   //  Software Protection Feedback Signals error limits
extern PGUINV_SWPROTCOUNT    PGUINV_SWProtErrTime;
extern PGUINV_SWPROTCOUNT    PGUINV_SWProtErrCount;

extern PGUINV_HWPROT         PGUINV_DACChannels;    //  HW Protection DAC Limits (0-3V range)
extern PGUINV_HWPROT         PGUINV_HWProtLevels;       //  HW Protection Levels (actual values)

extern CONVFLT_REG          PGUDM_FLT_REG;
extern CONVFLT_REG          PGUDM2_FLT_REG;





extern  DC              PGUINV_Dc;

#endif /* PGUINV_GLOBALS_H_ */
