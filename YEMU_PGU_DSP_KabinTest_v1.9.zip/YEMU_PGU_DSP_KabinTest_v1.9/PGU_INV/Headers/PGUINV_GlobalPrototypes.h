/*
 * PGUINV_GlobalPrototypes.h
 *
 *  Created on: 10 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_GLOBALPROTOTYPES_H_
#define PGUINV_GLOBALPROTOTYPES_H_


// PGUINV_MainISR.c
extern void PGUINV_MainISRInit(void);
extern void PGUINV_ProtectionInit(void);

extern void PGUINV_main(void);

extern interrupt void PGUINV_MainISR(void);
extern void PGUINV_Protection(void);
extern void PGUINV_CommandProcess(void);
extern void ContacRoutine(void);
extern void PGUINV_CommandRead(void);
extern void PGU_PreChargeRoutine(void);
extern void PGUINV_TivaLifeCheck(Uint16 Time);

// PGUINV_TripZoneISR.c
extern interrupt void PGUINV_TripZoneISR(void);

// PGU_Inv3.c - 3 Phase PWM Inverter
extern void  Inv3_Init(void);
extern void  Inv3_ISR(void);
//extern void  InvStartUp(void);
extern void  EthernetTest(void);



// PGUINV_Data.c
extern void PGUINV_WriteMonData(Uint16 WriteCount);
extern void PGUINV_WriteCANData(Uint16 WriteCount);
extern void PGUINV_ReadCANData(void);
extern void PGUINV_WriteFaultData(void);
extern void PGUINV_ReadMVBData(void);
extern void PGUINV_WriteMVBData(void);

extern void BuildTimeInit(void);
extern void SWUpdateCheck(void);


#endif /* PGUINV_GLOBALPROTOTYPES_H_ */
