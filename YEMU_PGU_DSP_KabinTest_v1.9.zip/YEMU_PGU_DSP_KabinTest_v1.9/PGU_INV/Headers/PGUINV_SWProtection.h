/*
 *PGUINV_SWProtection
 *
 *  Created on: 11 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_SWPROTECTION_H_
#define PGUINV_SWPROTECTION_H_

#define FOIOGateOFF     IO_SET(PGUINV_SGOFF)
#define FOIOGateON      IO_CLR(PGUINV_SGOFF)

#define PGUGateOFF                          \
        EALLOW;                             \
        EPwm6Regs.TZFRC.bit.OST = 1;        \
        EPwm5Regs.TZFRC.bit.OST = 1;        \
        EPwm4Regs.TZFRC.bit.OST = 1;        \
        EPwm3Regs.TZFRC.bit.OST = 1;        \
        EDIS;

#define PGUInvGateOFF                       \
        EALLOW;                             \
        EPwm6Regs.TZFRC.bit.OST = 1;        \
        EPwm5Regs.TZFRC.bit.OST = 1;        \
        EPwm3Regs.TZFRC.bit.OST = 1;        \
        EDIS;

#define PGUBrkGateOFF                       \
        EALLOW;                             \
        EPwm4Regs.TZFRC.bit.OST = 1;        \
        EDIS;

//#define PGUInvGateON                                                              \
//        EALLOW;                                                                   \
//        EPwm5Regs.TZFLG.all = 0;                                                  \
//        EPwm5Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/            \
//        EPwm6Regs.TZFLG.all = 0;                                                  \
//        EPwm6Regs.TZCLR.all = 0x5;      /* Clear trip zone OST and INT event*/    \
//        EDIS;                                                                     \
//        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

#define PGUInvGateON                                                             \
        EALLOW;                                                                 \
        EPwm6Regs.TZFLG.all = 0;                                                \
        EPwm6Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
        EPwm5Regs.TZFLG.all = 0;                                                \
        EPwm5Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
        EPwm3Regs.TZFLG.all = 0;                                                \
        EPwm3Regs.TZCLR.all = 0x5;     /* Clear trip zone OST and INT event*/   \
        EDIS;                                                                   \
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

#define PGUInvUGateON                                                             \
        EALLOW;                                                                 \
        EPwm3Regs.TZFLG.all = 0;                                                \
        EPwm3Regs.TZCLR.all = 0x5;     /* Clear trip zone OST and INT event*/   \
        EDIS;                                                                   \
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;


#define PGUInvVGateON                                                             \
        EALLOW;                                                                 \
        EPwm5Regs.TZFLG.all = 0;                                                \
        EPwm5Regs.TZCLR.all = 0x5;     /* Clear trip zone OST and INT event*/   \
        EDIS;                                                                   \
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;


#define PGUInvWGateON                                                             \
        EALLOW;                                                                 \
        EPwm6Regs.TZFLG.all = 0;                                                \
        EPwm6Regs.TZCLR.all = 0x5;     /* Clear trip zone OST and INT event*/   \
        EDIS;                                                                   \
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;


#define PGUBrkGateON                                                            \
        EALLOW;                                                                 \
        EPwm4Regs.TZFLG.all = 0;                                                \
        EPwm4Regs.TZCLR.all = 0x5;      /* Clear trip zone OST event*/          \
        EDIS;                                                                   \
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

//#define PGURecGateON                                                               \
//        EALLOW;                                                                 \
//        EPwm2Regs.TZFLG.all = 0;                                                \
//        EPwm2Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EPwm1Regs.TZFLG.all = 0;                                                \
//        EPwm1Regs.TZCLR.all = 0x5;      /* Clear trip zone OST event*/          \
//        EDIS;                                                                   \
//        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2; // Acknowledge this interrupt to receive more interrupts    from group 2    (EPWM1_TZINT)
//
////
//#define PGURecUGateON                                                               \
//        EALLOW;                                                                 \
//        EPwm1Regs.TZFLG.all = 0;                                                \
//        EPwm1Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EDIS;
//#define PGURecVGateON                                                               \
//        EALLOW;                                                                 \
//        EPwm2Regs.TZFLG.all = 0;                                                \
//        EPwm2Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EDIS;
//#define PGUInvUGateON                                                               \
//        EALLOW;                                                                 \
//        EPwm3Regs.TZFLG.all = 0;                                                \
//        EPwm3Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EDIS;
//#define PGUInvVGateON                                                               \
//        EALLOW;                                                                 \
//        EPwm5Regs.TZFLG.all = 0;                                                \
//        EPwm5Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EDIS;
//#define PGUInvWGateON                                                               \
//        EALLOW;                                                                 \
//        EPwm6Regs.TZFLG.all = 0;                                                \
//        EPwm6Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EDIS;
//#define PGUInvUVGateON                                                               \
//        EALLOW;                                                                 \
//        EPwm3Regs.TZFLG.all = 0;                                                \
//        EPwm3Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EPwm5Regs.TZFLG.all = 0;                                                \
//        EPwm5Regs.TZCLR.all = 0x4;      /* Clear trip zone OST event*/          \
//        EDIS;

extern void     PGUINV_TemperatureProtection_CKU1(PGUINV_TEMPERATURE_CKU1 temp,PGUINV_TEMPERATURE_CKU1 warn,       PGUINV_TEMPERATURE_CKU1 err,       PGUINV_TEMPSTS_REG_CKU1 *warnflag, PGUINV_TEMPSTS_REG_CKU1 *errflag);
extern void     PGUINV_TemperatureProtection_CKU2(PGUINV_TEMPERATURE_CKU2 temp,PGUINV_TEMPERATURE_CKU2 warn,       PGUINV_TEMPERATURE_CKU2 err,       PGUINV_TEMPSTS_REG_CKU2 *warnflag, PGUINV_TEMPSTS_REG_CKU2 *errflag);
extern void     PGUINV_SWProtection(PGUINV_SWPROT Fdbs, PGUINV_SWPROTLEVELS WarnLimits, PGUINV_SWPROTLEVELS   ErrLimits, PGUINV_SWPROTFLT_REG * WarnFlags, PGUINV_SWPROTFLT_REG * ErrFlags, PGUINV_SWPROTCOUNT * ErrTime,PGUINV_SWPROTCOUNT * ErrCount);

#endif /* PGUINV_SWPROTECTION_H_ */
