/*
 * PGUINV_ADC.h
 *
 *  Created on: 10 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_ADC_H_
#define PGUINV_ADC_H_

#define DCOFFSET            1.50            // DC offset for AC Channels , 1.50V
#define DCOFFSET1           1.498
#define DCOFFSET2           1.490
#define DCOFFSET3           1.494
#define DCOFFSET4           1.51
#define ADCCONVRATIO        (3.0/4095.0)    // ADC conversion ratio , 3.0/4095.0,  0-3 V:0-4095 Decimal
#define PGUINV_AICCHGAIN     1.0/1.0        // Analog Input Card channel gain
#define PGUINV_AICCHGAIN1    1.0/0.97       // Analog Input Card channel gain
#define PGUINV_AICCHGAIN2    1.0/0.98       // Analog Input Card channel gain
#define PGUINV_AICCHGAIN3    1.0/0.99       // Analog Input Card channel gain
#define PGUINV_AICCHGAIN4    1.0/0.93       // Analog Input Card channel gain

// Sensor Conversion Ratios
#define HRS1000_RATIO       5000.0          // PETERCEM HRS1000-T-014 Current Sensor Ratio [A/A]
#define DVM2000_RATIO       40000.0         // LEM DVM2000 Voltage Sensor Ratio [V/A]

#define RES_CUR_INV             8.20 //4.70            // 3ph PWM Inverter Output Current Measurement Resistor Value
#define RES_VOLT_DCBus          47.0 //56.0     // DC Bus Voltage Sensor Measurement Resistor Value
#define RES_CUR_BRK             8.2            // OVP  Current Measurement Resistor Value

#define PGUINV_ADC_ERR_INIT                    {0x0000}
//**************************************************************************
// ADC Channels and MACROs for PGU
//**************************************************************************
/*-----------------------------------------------------------------------------
    Define ADC Channels for PGU
-----------------------------------------------------------------------------*/

#define ADC_I_MOTU           0    // Motor Input Current ph1                   @ ADC A0
#define ADC_I_MOTW           1    // Motor Input Current ph2                   @ ADC A1
#define ADC_Res1             2    // Reserved Channel measurement              @ ADC A2
#define ADC_VDC              3    // DC bus voltage measurement                @ ADC A3
#define ADC_Res2             4    // Reserved Channel measurement              @ ADC A4
#define ADC_Res3             5    // Reserved Channel measurement              @ ADC A5
#define ADC_I_BRK            6    // OVP Unit branch current                   @ ADC A6
#define ADC_Res4             7    // Reserved Channel measurement              @ ADC A7
#define ADC_Res5             8    // Reserved Channel measurement              @ ADC B0
#define ADC_Res6             9    // Reserved Channel measurement              @ ADC B1
#define ADC_Res7            10    // Reserved Channel measurement              @ ADC B2
#define ADC_V_Ref           11    // 1.5 V Referans Current                    @ ADC B3
#define ADC_Res8            12    // Reserved Channel measurement              @ ADC B4
#define ADC_Res9            13    // Reserved Channel measurement              @ ADC B5
#define ADC_Res10           14    // Reserved Channel measurement              @ ADC B6
#define ADC_Res11           15    // Reserved Channel measurement              @ ADC B7


/*-----------------------------------------------------------------------------
    Define ADC Conversions for PGU
-----------------------------------------------------------------------------*/
#define PGUINV_ADC_CHANNELS   {                                                       \
                                ADC_I_MOTU,         /* @ ADC A0 */ /*ADCRESULT0 */    \
                                ADC_I_MOTU,         /* @ ADC A1 */ /*ADCRESULT1 */    \
                                ADC_I_MOTU,         /* @ ADC A2 */ /*ADCRESULT2 */    \
                                ADC_I_MOTW,         /* @ ADC A3 */ /*ADCRESULT3 */    \
                                ADC_I_MOTW,         /* @ ADC A4 */ /*ADCRESULT4 */    \
                                ADC_I_MOTW,         /* @ ADC A5 */ /*ADCRESULT5 */    \
                                ADC_VDC,            /* @ ADC A6 */ /*ADCRESULT6 */    \
                                ADC_VDC,            /* @ ADC A7 */ /*ADCRESULT7 */    \
                                                                                      \
                                ADC_VDC,            /* @ ADC B0*/ /*ADCRESULT8  */    \
                                ADC_I_BRK,          /* @ ADC B1*/ /*ADCRESULT9  */    \
                                ADC_I_BRK,          /* @ ADC B2*/ /*ADCRESULT10 */    \
                                ADC_I_BRK,          /* @ ADC B3*/ /*ADCRESULT11 */    \
                                ADC_Res1,           /* @ ADC B4*/ /*ADCRESULT12 */    \
                                ADC_Res1,           /* @ ADC B5*/ /*ADCRESULT13 */    \
                                ADC_Res1,           /* @ ADC B6*/ /*ADCRESULT14 */    \
                                ADC_Res1,           /* @ ADC B7*/ /*ADCRESULT15 */    \
                              }

/*-----------------------------------------------------------------------------
    Define the structure of the ADC Channels Object for PGU
-----------------------------------------------------------------------------*/
typedef struct {
                    float32 Cur_MotInputU;            // Output: Motor Sensor Measurement ph1
                    float32 Cur_MotInputW;            // Output: Motor Sensor Measurement ph2
                    float32 Volt_DCLink;              // Output: DC Link Voltage Sensor Sensor Measurement
                    float32 Cur_BRK;                  // Output: Break Resistor Current Sensor Measurement
                }
PGUINV_MEASUREMENTVARIABLES;

typedef struct {
    PGUINV_MEASUREMENTVARIABLES     Result;        // Result = (ChValue-DCOffset)*Ratio-Offset;
    PGUINV_MEASUREMENTVARIABLES     ChValue;       // ChValue = ADCRESULTX *(3.0/4095.0);  ChValue: 0-3V range
    PGUINV_MEASUREMENTVARIABLES     DCOffset;      // Calibration Offset
    PGUINV_MEASUREMENTVARIABLES     Ratio;         // Ratio = (Sensor Ratio/R);
    PGUINV_MEASUREMENTVARIABLES     Offset;        // Measurement Offset
}
PGUINV_MEASUREMENT;

/*------------------------------------------------------------------------------
    Default Initializers for the ADC Measurement Object
------------------------------------------------------------------------------*/
#define PGUINV_MEASUREMENT_INIT {                                                    \
                                /*Result*/                                          \
                                0, 0, 0, 0, \
                                /*ChValue*/                                         \
                                0, 0, 0, 0, \
                                /*DCOffset*/                                        \
                               DCOFFSET, DCOFFSET, 0.0, 0.0,   \
                                /*Ratio*/                                           \
                                0, 0, 0, 0.0,  \
                                /*Offset*/                                          \
                                0, 0, 0, 0.0,  \
                              }
/*-----------------------------------------------------------------------------
    Measurement fault register bit definitions for PGUINV
-----------------------------------------------------------------------------*/
struct PGUINV_ADC_FLT_BITS {
                                       // bits   description
        Uint16 Cur_MotInputU:1;        // 0
        Uint16 Cur_MotInputW:1;        // 1
        Uint16 Volt_DCLink:1;          // 7
        Uint16 Cur_BRK:1;              // 6
        Uint16 Rsrvd:12;

};

typedef union{
   Uint16                       all;
   struct PGUINV_ADC_FLT_BITS    bit;
}PGUINV_ADC_FLT_REG;

/*-----------------------------------------------------------------------------
    Default Initializers for the PGUINV_MEASUREMENT_FLT_REG
-----------------------------------------------------------------------------*/
#define PGUINV_ADC_OFFSET_INIT {                 \
                60.0,    /* Cur_MotInputU; */      \
                60.0,    /* Cur_MotInputW; */      \
                60.0,    /* DC_Voltage; */      \
                60.0,    /* Cur_Break;    */      \
                }

/*------------------------------------------------------------------------------
    PGUINV Measurement Ratio Calc. Macro
------------------------------------------------------------------------------*/
#define PGUINV_ADC_RATIO_CALC(v)                                                             \
                v.Ratio.Cur_MotInputU       =   PGUINV_AICCHGAIN2*(HRS1000_RATIO    / RES_CUR_INV         );                 \
                v.Ratio.Cur_MotInputW       =   PGUINV_AICCHGAIN2*(HRS1000_RATIO    / RES_CUR_INV         );                 \
                v.Ratio.Volt_DCLink         =   PGUINV_AICCHGAIN2*(DVM2000_RATIO    / RES_VOLT_DCBus      );                 \
                v.Ratio.Cur_BRK             =   PGUINV_AICCHGAIN2*(HRS1000_RATIO    / RES_CUR_BRK         );  /* Break resistor (2x1.5ohm) */        \


/*------------------------------------------------------------------------------
    PGUINV Measurement Ratio Calc. Macro
------------------------------------------------------------------------------*/
#define PGUINV_ADC_CHANNEL_READ(v)                                                                                                  \
                v.ChValue.Cur_MotInputU        =   (AdcMirror.ADCRESULT0+AdcMirror.ADCRESULT1+AdcMirror.ADCRESULT2)*(1.0/3.0) * ADCCONVRATIO;         \
                v.ChValue.Cur_MotInputW        =   (AdcMirror.ADCRESULT3+AdcMirror.ADCRESULT4+AdcMirror.ADCRESULT5)*(1.0/3.0) * ADCCONVRATIO;         \
                v.ChValue.Volt_DCLink          =   (AdcMirror.ADCRESULT6+AdcMirror.ADCRESULT7+AdcMirror.ADCRESULT8)*(1.0/3.0) * ADCCONVRATIO;         \
                v.ChValue.Cur_BRK              =   (AdcMirror.ADCRESULT9+AdcMirror.ADCRESULT10+AdcMirror.ADCRESULT11)*(1.0/3.0) * ADCCONVRATIO;                             \


/*------------------------------------------------------------------------------
    PGUINV Measurement Read Macro
------------------------------------------------------------------------------*/
#define PGUINV_ADC_MEASUREMENT(v)                                                                                                                              \
    v.Result.Cur_MotInputU          = ((v.ChValue.Cur_MotInputU       - v.DCOffset.Cur_MotInputU    ) * v.Ratio.Cur_MotInputU)     - v.Offset.Cur_MotInputU;   \
    v.Result.Cur_MotInputW          = ((v.ChValue.Cur_MotInputW       - v.DCOffset.Cur_MotInputW    ) * v.Ratio.Cur_MotInputW)     - v.Offset.Cur_MotInputW;   \
    v.Result.Volt_DCLink            = ((v.ChValue.Volt_DCLink         - v.DCOffset.Volt_DCLink     ) * v.Ratio.Volt_DCLink)      - v.Offset.Volt_DCLink;       \
    v.Result.Cur_BRK                = ((v.ChValue.Cur_BRK             - v.DCOffset.Cur_BRK          ) * v.Ratio.Cur_BRK)           - v.Offset.Cur_BRK;         \


#define PGUINV_ADC_OFFSET_COMP(v,div)                                                                                               \
if(div==0.0)                                                                                                                        \
{                                                                                                                                   \
    v.Offset.Cur_MotInputU      += ((v.ChValue.Cur_MotInputU       - v.DCOffset.Cur_MotInputU    ) * v.Ratio.Cur_MotInputU   ) ;    \
    v.Offset.Cur_MotInputW      += ((v.ChValue.Cur_MotInputW       - v.DCOffset.Cur_MotInputW    ) * v.Ratio.Cur_MotInputW   ) ;    \
    v.Offset.Volt_DCLink        += ((v.ChValue.Volt_DCLink         - v.DCOffset.Volt_DCLink      ) * v.Ratio.Volt_DCLink    ) ;     \
    v.Offset.Cur_BRK            += ((v.ChValue.Cur_BRK             - v.DCOffset.Cur_BRK          ) * v.Ratio.Cur_BRK  ) ;           \
}  \
else                                              \
{                                                 \
    v.Offset.Cur_MotInputU    *= div;             \
    v.Offset.Cur_MotInputW    *= div;             \
    v.Offset.Volt_DCLink      = 0.0;              \
    v.Offset.Cur_BRK          = 0.0;              \
}                                                 \


//**************************************************************************
//
//**************************************************************************

extern Uint16                       PGUINV_DSPADCChSel[16];       //  ADC init macro channel assignment for PGUINV

extern PGUINV_MEASUREMENT              PGUINV_Measure;               //  ADC measurement instance and initialization
extern PGUINV_MEASUREMENTVARIABLES     PGUINV_ADCOffsets;            //  ADC measurement offset instance
extern PGUINV_ADC_FLT_REG              PGUINV_ADCErrFlags;

#endif /* PGUINV_ADC_H_ */

