/*
 * PGUINV_Settings.h
 *
 *  Created on: 10 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_SETTINGS_H_
#define PGUINV_SETTINGS_H_

#define PGUINV_RSV1        1               // Reserved PWM @ EPWM1
#define PGUINV_RSV2        2               // Reserved PWM @ EPWM2
#define PGUINV_IPWMU       3               // Inverter U leg PWM @ EPWM3
#define PGUINV_BRKPWM      4               // Break      leg PWM @ EPWM4
#define PGUINV_IPWMV       5               // Inverter V leg PWM @ EPWM5
#define PGUINV_IPWMW       6               // Inverter W leg PWM @ EPWM6

#define ms_100          160                // 1600 = 1s;
#define PGUINV_VDC_MIN             (1250.0)


// Outputs
#define PGUINV_FOIORst             GPADAT.bit.GPIO26     //PT_DSPClk
#define PGUINV_FDPCRst             GPADAT.bit.GPIO27     //PT_SWReset
#define PGUINV_SGOFF               GPBDAT.bit.GPIO48     // PGU_OptoEnable
#define PGUINV_WDTog               GPBTOGGLE.bit.GPIO49  //DSP_WDOG_TOGGLE
#define PGUINV_TZ1GPIO             GPADAT.bit.GPIO12     // TripZone1- FP_CFD
#define PGUINV_TZ2GPIO             GPADAT.bit.GPIO13     // TripZone2- TCPU_HgOFF
#define PGUINV_TZ3GPIO             GPADAT.bit.GPIO14     // TripZone3- FP_CFD2 (Unused)
#define PGUINV_TZ4GPIO             GPADAT.bit.GPIO15     // TripZone4- TP_Trip (Unused)

#define PGUINV_EDB_Active          GPBDAT.bit.GPIO58     // PT_IO1  EDB_Active
#define PGUINV_TractionON          GPBDAT.bit.GPIO59     // PT_IO2  TractionON (�eki� Aktif bobin r�le �ektirme)
#define PGUINV_PT_IO3              GPBDAT.bit.GPIO61     // I-PT_IO3 ---> PT_IO5 (Unused)
#define PGUINV_to_PGUREC           GPBDAT.bit.GPIO60     // I-PT_IO4 ---> I-RSV1_BP(pin goes to MCU input)

#define DO_ENABLE                  GPADAT.bit.GPIO20     // Digital output enable signal

#define TRACTON                    GPADAT.bit.GPIO22     // TP_IO1    Traction active relay status
//#define Speed_Lim_Active         GPADAT.bit.GPIO23     // I-TP_IO2  <--- D2-DT_DI3_BP  (DIOC2_DI3=Speed Limit Active) (DIOC-2 TCU-ID geliyor. SetSeri de yok.)
#define Emergency_Loop             GPADAT.bit.GPIO21     // TP_IO4    Emergency_Loop

// Task Periods
#define PGUINV_TASKA_PERIOD        mSec1
#define PGUINV_TASKB_PERIOD        mSec50
#define PGUINV_TASKC_PERIOD        mSec10

// PGUINV HW Fault Channel Definitions
#define LIMMOC      TLV5630_DAC_A       // Motor Phase Current HW Fault Setting Channel   CTL.REG.bit.STATE

// Temperature Sensor types
#define NTCTYPE             0
#define NTC2TYPE            1
#define PT100TYPE           4


// Cooling System Sensor types
#define PRESSURETYPE_NTC    2
#define PRESSURETYPE        3



//--TIC channels--
#ifdef  LAB_DYNO

// NTC channels,           Sensor Type: 0
#define PGUINV_INVTEMP1      0x0800  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"
#define PGUINV_INVTEMP2      0x0A00  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"
//// PT100 chaneels,       Sensor Type: 1
#define PGUINV_MOTTEMP1      0x0301  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"


#else

// NTC (30K) channels,      Sensor Type: 0
#define PGUINV_INVTEMP1        0x0200  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"
#define PGUINV_INVTEMP2        0x0300  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"

// NTC2 (2.2K) channels,    Sensor Type: 4
#define PGUINV_COOLTEMP        0x0502  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"

// Flow channels,           Sensor Type: 3
#define PGUINV_COOLPRESS       0x0803  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"

// PT100 channels,          Sensor Type: 2
#define PGUINV_MOTTEMP1        0x0A04  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"
#define PGUINV_MOTTEMP2        0x0B04  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"
#define PGUINV_MOTTEMP3        0x0C04  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"
#define PGUINV_MOTTEMP_BEAR    0x0D04  // Most significant two bytes:"ChNo", Least significant two bytes:"Sensor Type"


#endif

// Speed sensor parameters
#define MOTOR_ENCODER_PULSE 250     // Decimal, Max: 65536 Min: 1
#define CENTER_FREQUENCY     2*PI*50.0
#define INV_DUTY_MAX        (0.97)
#define INV_DUTY_MIN        (-0.97)

#endif /* PGUINV_SETTINGS_H_ */
