
//###########################################################################
// $TI Release: F2833x/F2823x Header Files and Peripheral Examples V141 $
// $Release Date: November  6, 2015 $
// $Copyright: Copyright (C) 2007-2015 Texas Instruments Incorporated -
//             http://www.ti.com/ ALL RIGHTS RESERVED $
//###########################################################################

//#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
//#include "Example_posspeed.h"   // Example specific Include file

#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"


void POSSPEED_Calc(POSSPEED *p)
{
    unsigned int temp1;
    float32 Tmp1;

//**** Position calculation - mechanical and electrical motor angle  ****//
     p->DirectionQep = EQep1Regs.QEPSTS.bit.QDF;    // Motor direction: 0=CCW/reverse, 1=CW/forward

//**** Low-speed computation using QEP capture counter ****//
	if(EQep1Regs.QEPSTS.bit.UPEVNT==1)                 // Unit position event
	{
		if(EQep1Regs.QEPSTS.bit.COEF==0)               // No Capture overflow
			temp1=(unsigned long)EQep1Regs.QCPRD;      // temp1 = t2-t1
		else							               // Capture overflow, saturate the result
			temp1=0xFFFF;

		p->Speed_pr = (p->SpeedScaler/(float32)temp1);    // p->Speed_pr = p->SpeedScaler/temp1
		Tmp1=p->Speed_pr;

		if (Tmp1>1.0)
	 		p->Speed_pr = 1.0;
		else
	 		p->Speed_pr = Tmp1;

	    // Convert p->Speed_pr to RPM
		if (p->DirectionQep==0)                                 // Reverse direction = negative
			p->SpeedRpm_pr = -(p->BaseRpm*p->Speed_pr); 	    // Q0 = Q0*GLOBAL_Q => _IQXmpy(), X = GLOBAL_Q
		else                                                    // Forward direction = positive
			p->SpeedRpm_pr = (p->BaseRpm*p->Speed_pr); 	        // Q0 = Q0*GLOBAL_Q => _IQXmpy(), X = GLOBAL_Q


		EQep1Regs.QEPSTS.all=0x88;					// Clear Unit position event flag
													// Clear overflow error flag
	}

    //FillAnalogBuffer(p->SpeedRpm_pr, AnaBuff.buff10, 10);
}


