/*
 * PhaseShift.c
 *
 *  Created on: 9 Oca 2020
 *      Author: fozturk
 */


//#define T     ParamRealData(0,0)  //sample period

#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

float32 TRef    = 0;    //  Output(0)  //
float32 SCSig   = 0;    //  Output(1)  //
float32 SandSig = 0;    //  Output(2)  //
float32 SCEn = 0;

float32 T, ComVal, K1, K2, dwTh, ConRateLim;
float32 MeanPhaseHigh, MeanPhaseHigh1, MeanPhaseHigh2, MeanPhaseHigh3, MeanPhaseLow1, MeanPhaseLow2, MeanPhaseLow3;
float32 LimTor, wlim1, wlim2;

float32 w_K1,ddw, dwK1, ddwK1;

float32 TRefK1, TRefT, TMax;
float32 Ll, Lu;

float32 dw                  = 0.0;
float32 PhaseShift          = 0.0;
float32 PhaseShiftLimited   = 0.0;
float32 PhaseShiftLPF1      = 0.0;
float32 PhaseShiftLPF2      = 0.0;

float32 TmpElecSpeed       = 0.0;
float32 Inertia            = 25.0;

void PhaseShiftSCInit (void)
{
   // Constants
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   T                = 1.0/2100.0;                                         // Sample Time [s]
   ComVal           = 0.5;                                                // Comparison Value for Boolean Operations
   K1               = 0.9852;                                             //(*)Filter Parameter 1 [exp(-K2*T)]
   K2               = 31.415926535897931;                                 //(*)Filter Parameter 2 [2*PI*(Filter Cut-Off Frequency[Hz]) = 2*PI*(5Hz)]
   dwTh             = 20.0;                                               //(*)Angular Acceleration Threshold [Maximum Vehicle Acceleration*Gear Ratio/Wheel Radius = 1*6.21/0.5]
   ConRateLim       = 500.0*T;                                            //(*)Control Period Torque Change Rate Limit [500Nm*T]
   MeanPhaseHigh1   = -65.0;                                              // Highest Value of Band Defined for Control of Phase Shift for (w < wlim1) [Deg]
   MeanPhaseHigh2   = -75.0;                                              // Highest Value of Band Defined for Control of Phase Shift (wlim2 > w >= wlim1)[Deg]
   MeanPhaseLow1    = -80.0;                                              // Lowest Value of Band Defined for Control of Phase Shift [Deg]
   MeanPhaseLow2    = -85.0;                                              // Lowest Value of Band Defined for Control of Phase Shift [Deg]
   MeanPhaseLow3    = -95.0;                                              // Lowest Value of Band Defined for Control of Phase Shift [Deg]
   LimTor           = 300.0;                                              // Limit Value for Reference Motor Torque [Nm]
   wlim1            = 60.0;                                               // Motor Speed Limit 1 for MeanPhaseHigh Change [rad/s]
   wlim2            = 180.0;                                              // Motor Speed Limit 2 for MeanPhaseHigh Change [rad/s]
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   // Variables
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   w_K1             = 0.0;                                                // (k-1)th Value of Motor Speed [rad/s]
   dw               = 0.0;                                                //#ok<NASGU> // Initial Value of Motor Acceleration [rad/s2]
   dwK1             = 0.0;                                                // (k-1)th Value of Motor Acceleration [rad/s2]
   ddw              = 0.0;                                                //#ok<NASGU> // Initial Value of Motor Jerk [rad/s3]
   ddwK1            = 0.0;                                                // (k-1)th Value of Motor Jerk [rad/s3]
   TRefK1           = 0.0;                                                // (k-1)th Value of Reference Motor Torque [Nm]
   TRefT            = 0.0;                                                //#ok<NASGU> // Initial Value of Temporary Reference Motor Torque [Nm]
   TRef             = 0.0;                                                //#ok<NASGU> // Initial Value of Reference Motor Torque [Nm]
   Ll               = 0.0;                                                //#ok<NASGU> // Lower Limit for Reference Motor Torque [Nm]
   Lu               = 0.0;                                                //#ok<NASGU> // Upper Limit for Reference Motor Torque [Nm]
   PhaseShift       = 0.0;                                                //#ok<NASGU> // Initial Value of Phase Shift [Deg]
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

void PhaseShiftSC(float32 w, float32 TDes,  float32 Enable)
{
    //---------------------------------------------------------------------%
    // Low-Pass Filters
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     dw               = (K1*dwK1)+K2*(w-w_K1);                               // Filtering Motor Acceleration
     ddw              = (K1*ddwK1)+K2*(dw-dwK1);                             // Filtering Motor Jerk
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     //---------------------------------------------------------------------%
     // Update of Internal States
     //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      ddwK1      = ddw;                                                     // Update of (k-1)th Value of Derivative of Motor Jerk [rad/s3]
      dwK1       = dw;                                                      // Update of (k-1)th Value of Motor Acceleration [rad/s2]
      w_K1       = w;                                                       // Update of (k-1)th Value of Motor Speed [rad/s]
     //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if (Enable > ComVal)
    {
       //---------------------------------------------------------------------%
       // Default State Reference Torque Generation
       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        TRefT            = TDes;                                              // Temporary Reference Torque Generation
       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

       //---------------------------------------------------------------------%
       // Control Mode
       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        if(fabs(w)<10.0)
        {
            MeanPhaseLow1 = -150.0;
            MeanPhaseLow2 = -150.0;
            MeanPhaseLow3 = -150.0;
            MeanPhaseHigh1 = -100.0;
            MeanPhaseHigh2 = -100.0;
        }
        else
        {
            MeanPhaseLow1 = -80.0;
            MeanPhaseLow2 = -85.0;
            MeanPhaseLow3 = -95.0;
            MeanPhaseHigh2 = -65.0;
            MeanPhaseHigh2 = -75.0;
        }

        if (PhaseShiftLPF2 < MeanPhaseLow3)
        {
            if (TRefK1 > 0.0)
            {
                TRefT   = TRefK1-8*ConRateLim;

                if(TRefK1<TRefK1-Inertia*dw)
                {
                    TMax = TRefK1;
                }
                else
                {
                    TMax = TRefK1-Inertia*dw;
                }

                if (TRefT < TMax)                                                                                                                                   \
                {                                                                                                                                                                     \
                    TRefT = TMax;                                                                                                                                   \
                }

                if (TRefT < LimTor)
                {
                    TRefT = LimTor;
                     }
            }
            else if(TRefK1 < 0.0)
            {
                TRefT   = TRefK1+8*ConRateLim;

                if(TRefK1>TRefK1-Inertia*dw)
                {
                    TMax = TRefK1;
                }
                else
                {
                    TMax = TRefK1-Inertia*dw;
                }

                if (TRefT > TMax)                                                                                                                                   \
                {                                                                                                                                                                     \
                    TRefT = TMax;                                                                                                                                   \
                }

                if (TRefT  > -LimTor)
                {
                    TRefT  = -LimTor;

                }

            }
            else
            {
                TRefT = TDes;
            }
        }
        else if (PhaseShiftLPF2 < MeanPhaseLow2)
        {
            TMax     = TRefK1-Inertia*dw;        /* Detected Available Adhesion Torque         */

            if (TRefK1 > 0.0)
            {
                TRefT   = TRefK1-4*ConRateLim;

                if(TRefK1<TRefK1-Inertia*dw)
                {
                    TMax = TRefK1;
                }
                else
                {
                    TMax = TRefK1-Inertia*dw;
                }

                if (TRefT < TMax)                                                                                                                                   \
                {                                                                                                                                                                     \
                    TRefT = TMax;                                                                                                                                   \
                }

                if (TRefT < LimTor)
                {
                    TRefT = LimTor;
                     }
            }
            else if(TRefK1 < 0.0)
            {
                TRefT   = TRefK1+4*ConRateLim;

                if(TRefK1>TRefK1-Inertia*dw)
                {
                    TMax = TRefK1;
                }
                else
                {
                    TMax = TRefK1-Inertia*dw;
                }

                if (TRefT > TMax)                                                                                                                                   \
                {                                                                                                                                                                     \
                    TRefT = TMax;                                                                                                                                   \
                }

                if (TRefT  > -LimTor)
                {
                    TRefT  = -LimTor;

                }

            }
            else
            {
                TRefT = TDes;
            }
        }
        else if (PhaseShiftLPF2 < MeanPhaseLow1)
        {
            TMax     = TRefK1-Inertia*dw;        /* Detected Available Adhesion Torque         */

            if (TRefK1 > 0.0)
            {
                TRefT   = TRefK1-1.0*ConRateLim;

                if(TRefK1<TRefK1-Inertia*dw)
                {
                    TMax = TRefK1;
                }
                else
                {
                    TMax = TRefK1-Inertia*dw;
                }

                if (TRefT < TMax)                                                                                                                                   \
                {                                                                                                                                                                     \
                    TRefT = TMax;                                                                                                                                   \
                }

                if (TRefT < LimTor)
                {
                    TRefT = LimTor;
                     }
            }
            else if(TRefK1 < 0.0)
            {
                TRefT   = TRefK1+1.0*ConRateLim;

                if(TRefK1>TRefK1-Inertia*dw)
                {
                    TMax = TRefK1;
                }
                else
                {
                    TMax = TRefK1-Inertia*dw;
                }

                if (TRefT > TMax)                                                                                                                                   \
                {                                                                                                                                                                     \
                    TRefT = TMax;                                                                                                                                   \
                }

                if (TRefT  > -LimTor)
                {
                    TRefT  = -LimTor;

                }

            }
            else
            {
                TRefT = TDes;
            }
        }
        else if  (PhaseShiftLPF2 > MeanPhaseHigh1)
        {
            if (TRefK1 > 0.0)
            {
                TRefT   = TRefK1+0.5*ConRateLim;
            }
            else if (TRefK1 < 0.0)
            {
                TRefT   = TRefK1-0.5*ConRateLim;
            }
            else
            {
                TRefT = TDes;
            }
        }
        else if  (PhaseShiftLPF2 > MeanPhaseHigh2)
        {
            if (TRefK1 > 0.0)
            {
                TRefT   = TRefK1+0.3*ConRateLim;
            }
            else if (TRefK1 < 0.0)
            {
                TRefT   = TRefK1-0.3*ConRateLim;
            }
            else
            {
                TRefT = TDes;
            }
        }
        else
        {
            TRefT   = TRefK1;
        }

       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


       //---------------------------------------------------------------------%
       // Limitation of Reference Torque
       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if  (TDes < 0.0)
        {
            Ll    = TDes;                                                     // Lower Limit for Reference Torque (Brake) [Nm]
            Lu    = 0.0;                                                      // Upper Limit for Reference Torque (Brake) [Nm]
        }
        else
        {
            Ll    = 0.0;                                                      // Lower Limit for Reference Torque (Traction) [Nm]
            Lu    = TDes;                                                     // Upper Limit for Reference Torque (Traction) [Nm]

        }

        if (TRefT < Ll)
        {
            TRef  = Ll;                                                       // Limitation of Reference Torque (Brake) [Nm]
        }
        else if  (TRefT > Lu)
        {
            TRef  = Lu;                                                       // Limitation of Reference Torque (Traction) [Nm]
        }
        else
        {
            TRef  = TRefT;
        }
       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

       //---------------------------------------------------------------------%
       // Update of Internal States
       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        TRefK1     = TRef;                                                    // Update of (k-1)th Value of Reference Motor Torque [Nm]
       //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    }
    else
    {

        TRef             = TDes;                                              // Reference Motor Torque [Nm]
        TRefK1           = 0.0;                                               // (k-1)th Value of Reference Motor Torque [Nm]
        TRefT            = 0.0;                                               // Initial Value of Temporary Reference Motor Torque [Nm]
        Ll               = 0.0;                                               // Lower Limit for Reference Motor Torque [Nm]
        Lu               = 0.0;                                               // Upper Limit for Reference Motor Torque [Nm]
    }
}

