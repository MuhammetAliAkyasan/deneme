/*
 * PhaseShift.c
 *
 *  Created on: 9 Oca 2020
 *      Author: fozturk
 */


//#define T     ParamRealData(0,0)  //sample period

#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

float32 wK1, wK2, wK3, wK4, wf, wfK1, wfK2, wfK3, wfK4;
float32 numdbp1, numdbp2, numdbp3, numdbp4, numdbp5, dendbp1, dendbp2, dendbp3, dendbp4, dendbp5;
float32 numdbs1, numdbs2, numdbs3, numdbs4, numdbs5, dendbs1, dendbs2, dendbs3, dendbs4, dendbs5;
float32 MultiplySin, MultiplySinK1, MultiplySinK2, MultiplySinK3, MultiplySinK4;
float32 MultiplyCos, MultiplyCosK1, MultiplyCosK2, MultiplyCosK3, MultiplyCosK4;
float32 FilMultiplySin, FilMultiplySinK1, FilMultiplySinK2, FilMultiplySinK3, FilMultiplySinK4;
float32 FilMultiplyCos, FilMultiplyCosK1, FilMultiplyCosK2, FilMultiplyCosK3, FilMultiplyCosK4;

void PhaseShiftCalcInit (void)
{
    // Constants
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    numdbp1          = 0.0;                                                // First Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    numdbp2          = 4.387067642018803e-04;                              // Second Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    numdbp3          = -4.473705576188664e-04;                             // Third Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    numdbp4          = -4.213791774257708e-04;                             // Fourth Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    numdbp5          = 4.300429708427568e-04;                              // Fifth Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    dendbp1          = 1.0;                                                // First Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    dendbp2          = -3.939282726798868;                                 // Second Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    dendbp3          = 5.820533580814271;                                  // Third Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    dendbp4          = -3.823165436077300;                                 // Fourth Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    dendbp5          = 0.941915359768588;                                  // Fifth Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    numdbs1          = 1.0;                                                // First Element of Numerator of Digital Band-Stop Filter (DigitalFilters.m)
    numdbs2          = -3.991261680855314;                                 // Second Element of Numerator of Digital Band-Stop Filter (DigitalFilters.m)
    numdbs3          = 5.980748849514287;                                  // Third Element of Numerator of Digital Band-Stop Filter (DigitalFilters.m)
    numdbs4          = -3.987688267990890;                                 // Fourth Element of Numerator of Digital Band-Stop Filter (DigitalFilters.m)
    numdbs5          = 0.998213173148281;                                  // Fifth Element of Numerator of Digital Band-Stop Filter (DigitalFilters.m)
    dendbs1          = 1.0;                                                // First Element of Denominator of Digital Band-Stop Filter (DigitalFilters.m)
    dendbs2          = -3.876881240027380;                                 // Second Element of Denominator of Digital Band-Stop Filter (DigitalFilters.m)
    dendbs3          = 5.641382756856235;                                  // Third Element of Denominator of Digital Band-Stop Filter (DigitalFilters.m)
    dendbs4          = -3.651693987980478;                                 // Fourth Element of Denominator of Digital Band-Stop Filter (DigitalFilters.m)
    dendbs5          = 0.887204544967988;                                  // Fifth Element of Denominator of Digital Band-Stop Filter (DigitalFilters.m)
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Variables
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    PhaseShift       = 0.0;                                                //#ok<NASGU> // Initial Value of Phase Shift [Deg]
    wK1              = w;                                                  // (k-1)th Value of Motor Speed [rad/s]
    wK2              = w;                                                  // (k-2)th Value of Motor Speed [rad/s]
    wK3              = w;                                                  // (k-3)th Value of Motor Speed [rad/s]
    wK4              = w;                                                  // (k-4)th Value of Motor Speed [rad/s]
    wf               = 0.0;                                                //#ok<NASGU> // Initial Value of Filtered Motor Speed [rad/s]
    wfK1             = 0.0;                                                // (k-1)th Value of Filtered Motor Speed [rad/s]
    wfK2             = 0.0;                                                // (k-2)th Value of Filtered Motor Speed [rad/s]
    wfK3             = 0.0;                                                // (k-3)th Value of Filtered Motor Speed [rad/s]
    wfK4             = 0.0;                                                // (k-4)th Value of Filtered Motor Speed [rad/s]
    MultiplySin      = 0.0;                                                //#ok<NASGU> // Initial Value of Cross Correlation Sinus Function [Nm]
    MultiplySinK1    = 0.0;                                                // (k-1)th Value of Cross Correlation Sinus Function [Nm]
    MultiplySinK2    = 0.0;                                                // (k-2)th Value of Cross Correlation Sinus Function [Nm]
    MultiplySinK3    = 0.0;                                                // (k-3)th Value of Cross Correlation Sinus Function [Nm]
    MultiplySinK4    = 0.0;                                                // (k-4)th Value of Cross Correlation Sinus Function [Nm]
    MultiplyCos      = 0.0;                                                //#ok<NASGU> // Initial Value of Cross Correlation Cosinus Function [Nm]
    MultiplyCosK1    = 0.0;                                                // (k-1)th Value of Cross Correlation Cosinus Function [Nm]
    MultiplyCosK2    = 0.0;                                                // (k-2)th Value of Cross Correlation Cosinus Function [Nm]
    MultiplyCosK3    = 0.0;                                                // (k-3)th Value of Cross Correlation Cosinus Function [Nm]
    MultiplyCosK4    = 0.0;                                                // (k-4)th Value of Cross Correlation Cosinus Function [Nm]
    FilMultiplySin   = 0.0;                                                //#ok<NASGU> // Initial Value of Filtered Cross Correlation Sinus Function [Nm]
    FilMultiplySinK1 = 0.0;                                                // (k-1)th Value of Filtered Cross Correlation Sinus Function [Nm]
    FilMultiplySinK2 = 0.0;                                                // (k-2)th Value of Filtered Cross Correlation Sinus Function [Nm]
    FilMultiplySinK3 = 0.0;                                                // (k-3)th Value of Filtered Cross Correlation Sinus Function [Nm]
    FilMultiplySinK4 = 0.0;                                                // (k-4)th Value of Filtered Cross Correlation Sinus Function [Nm]
    FilMultiplyCos   = 0.0;                                                //#ok<NASGU> // Initial Value of Filtered Cross Correlation Cosinus Function [Nm]
    FilMultiplyCosK1 = 0.0;                                                // (k-1)th Value of Filtered Cross Correlation Cosinus Function [Nm]
    FilMultiplyCosK2 = 0.0;                                                // (k-2)th Value of Filtered Cross Correlation Cosinus Function [Nm]
    FilMultiplyCosK3 = 0.0;                                                // (k-3)th Value of Filtered Cross Correlation Cosinus Function [Nm]
    FilMultiplyCosK4 = 0.0;                                                // (k-4)th Value of Filtered Cross Correlation Cosinus Function [Nm]
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

void PhaseShiftCalc (float32 w,float32 TestSin,float32 TestCos)
{
    //-----------------------------------------------------------------%
    // Filtering Test Frequency Components of Motor Speed [Band Pass Filter]
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     wf = 1.0/dendbp1*(numdbp1*w+numdbp2*wK1+numdbp3*wK2+numdbp4*wK3+        \
     numdbp5*wK4-dendbp2*wfK1-dendbp3*wfK2-dendbp4*wfK3-dendbp5*wfK4);
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    //-----------------------------------------------------------------%
    // Cross Correlation of Motor Speed and Test Signals
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     MultiplySin = wf*TestCos;
     MultiplyCos = wf*TestSin;
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    //-----------------------------------------------------------------%
    // Filtering Test Signal Frequency Components of Cross Correlation Outputs [Band Stop Filter]
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     FilMultiplySin = 1.0/dendbs1*(numdbs1*MultiplySin+numdbs2*MultiplySinK1  \
        +numdbs3*MultiplySinK2+numdbs4*MultiplySinK3+numdbs5*MultiplySinK4    \
        -dendbs2*FilMultiplySinK1-dendbs3*FilMultiplySinK2                    \
        -dendbs4*FilMultiplySinK3-dendbs5*FilMultiplySinK4);

     FilMultiplyCos = 1.0/dendbs1*(numdbs1*MultiplyCos+numdbs2*MultiplyCosK1  \
         +numdbs3*MultiplyCosK2+numdbs4*MultiplyCosK3+numdbs5*MultiplyCosK4   \
         -dendbs2*FilMultiplyCosK1-dendbs3*FilMultiplyCosK2                   \
         -dendbs4*FilMultiplyCosK3-dendbs5*FilMultiplyCosK4);
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    //-----------------------------------------------------------------%
    // Calculation of PhaseShift of the Trasfer Function
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     PhaseShift     = 180.0/PI*atan2(FilMultiplySin, FilMultiplyCos);

     if (PhaseShift>80.0)
     {
         PhaseShiftLimited = -180.0;
     }
     else
     {
         PhaseShiftLimited = PhaseShift;
     }

     PhaseShiftLPF1  = LPF(PhaseShiftLimited,   PhaseShiftLPF1, 2*PI*25*PGUINV_TS);
     PhaseShiftLPF2  = LPF(PhaseShiftLPF1,      PhaseShiftLPF2, 2*PI*25*PGUINV_TS);


    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

     FillAnalogBuffer(wf,               AnaBuff.buff4, 4);
     FillAnalogBuffer(PhaseShift,       AnaBuff.buff5, 5);
     FillAnalogBuffer(PhaseShiftLPF1,   AnaBuff.buff9, 9);
     FillAnalogBuffer(PhaseShiftLPF2,   AnaBuff.buff10, 10);

    //-----------------------------------------------------------------%
    // Update of Internal States
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     wK4              = wK3;                                           // Update of (k-4)th Value of Motor Speed [rad/s]
     wK3              = wK2;                                           // Update of (k-3)th Value of Motor Speed [rad/s]
     wK2              = wK1;                                           // Update of (k-2)th Value of Motor Speed [rad/s]
     wK1              = w;                                             // Update of (k-1)th Value of Motor Speed [rad/s]

     wfK4             = wfK3;                                          // Update of (k-4)th Value of Filtered Motor Speed [rad/s]
     wfK3             = wfK2;                                          // Update of (k-3)th Value of Filtered Motor Speed [rad/s]
     wfK2             = wfK1;                                          // Update of (k-2)th Value of Filtered Motor Speed [rad/s]
     wfK1             = wf;                                            // Update of (k-1)th Value of Filtered Motor Speed [rad/s]

     MultiplySinK4    = MultiplySinK3;                                 // Update of (k-4)th Value of Cross Correlation Sinus Function [Nm]
     MultiplySinK3    = MultiplySinK2;                                 // Update of (k-3)th Value of Cross Correlation Sinus Function [Nm]
     MultiplySinK2    = MultiplySinK1;                                 // Update of (k-2)th Value of Cross Correlation Sinus Function [Nm]
     MultiplySinK1    = MultiplySin;                                   // Update of (k-1)th Value of Cross Correlation Sinus Function [Nm]

     MultiplyCosK4    = MultiplyCosK3;                                 // Update of (k-4)th Value of Cross Correlation Cosinus Function [Nm]
     MultiplyCosK3    = MultiplyCosK2;                                 // Update of (k-3)th Value of Cross Correlation Cosinus Function [Nm]
     MultiplyCosK2    = MultiplyCosK1;                                 // Update of (k-2)th Value of Cross Correlation Cosinus Function [Nm]
     MultiplyCosK1    = MultiplyCos;                                   // Update of (k-1)th Value of Cross Correlation Cosinus Function [Nm]

     FilMultiplySinK4 = FilMultiplySinK3;                              // Update of (k-4)th Value of Filtered Cross Correlation Sinus Function [Nm]
     FilMultiplySinK3 = FilMultiplySinK2;                              // Update of (k-3)th Value of Filtered Cross Correlation Sinus Function [Nm]
     FilMultiplySinK2 = FilMultiplySinK1;                              // Update of (k-2)th Value of Filtered Cross Correlation Sinus Function [Nm]
     FilMultiplySinK1 = FilMultiplySin;                                // Update of (k-1)th Value of Filtered Cross Correlation Sinus Function [Nm]

     FilMultiplyCosK4 = FilMultiplyCosK3;                              // Update of (k-4)th Value of Filtered Cross Correlation Cosinus Function [Nm]
     FilMultiplyCosK3 = FilMultiplyCosK2;                              // Update of (k-3)th Value of Filtered Cross Correlation Cosinus Function [Nm]
     FilMultiplyCosK2 = FilMultiplyCosK1;                              // Update of (k-2)th Value of Filtered Cross Correlation Cosinus Function [Nm]
     FilMultiplyCosK1 = FilMultiplyCos;                                // Update of (k-1)th Value of Filtered Cross Correlation Cosinus Function [Nm]
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

}

