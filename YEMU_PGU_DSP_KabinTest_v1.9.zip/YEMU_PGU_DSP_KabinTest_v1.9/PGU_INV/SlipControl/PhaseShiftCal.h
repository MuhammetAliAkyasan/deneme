/*
 * PhaseShift.h
 *
 *  Created on: 9 Oca 2020
 *      Author: fozturk
 */

#ifndef PGUDE_CONTROL_PHASESHIFTCAL_H_
#define PGUDE_CONTROL_PHASESHIFTCAL_H_


#include "PGU_DSP_Math.h"

extern void PhaseShiftCalcInit(void);
extern void PhaseShiftCalc(float32 w,float32 TestSin,float32 TestCos);

#endif /* PGUDE_CONTROL_PHASESHIFTCAL_H_ */
