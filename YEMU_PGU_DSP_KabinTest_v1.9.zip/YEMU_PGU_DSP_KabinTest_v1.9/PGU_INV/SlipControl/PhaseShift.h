/*
 * PhaseShift.h
 *
 *  Created on: 9 Oca 2020
 *      Author: fozturk
 */

#ifndef PGUDE_CONTROL_PHASESHIFT_H_
#define PGUDE_CONTROL_PHASESHIFT_H_


#include "PGU_DSP_Math.h"


extern float32 TRef;
extern float32 SCSig;
extern float32 SandSig;
extern float32 SCEn;


extern float32 dw;
extern float32 PhaseShift;
extern float32 PhaseShiftLimited;
extern float32 PhaseShiftLPF1;
extern float32 PhaseShiftLPF2;

extern float32 TmpElecSpeed;


extern void PhaseShiftSCInit(void);
extern void PhaseShiftSC(float32 w, float32 TDes, float32 Enable);

#endif /* PGUDE_CONTROL_PHASESHIFT_H_ */
