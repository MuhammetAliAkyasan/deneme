#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"



// FOIO Functions
void PGUINV_InitFOIO(void)
{
    // FOIO Initial Reset Procedure
    IO_CLR(PGUINV_FOIORst)                     //  Boot-up reset value is high. Clear FOIO reset signal
    DELAY_US(1);
    IO_SET(PGUINV_FOIORst)                     //  Set FOIO reset signal
    DELAY_US(1);
    IO_CLR(PGUINV_FOIORst)                     //  Clear FOIO reset signal
}

// FDPC Functions
void PGUINV_InitTCPU(void)
{
    // FDPC Initial Reset Procedure
    IO_CLR(PGUINV_FDPCRst)                     //  Boot-up reset value is high. Clear FDPC reset signal
    DELAY_US(1);
    IO_SET(PGUINV_FDPCRst)                     //  Set FDPC reset signal
    DELAY_US(1);
    IO_CLR(PGUINV_FDPCRst)                     //  Clear FDPC reset signal
}

void PGUINV_HWFaultLimitSet()
{
#ifdef LAB_DYNO

    SPIDACWrite(LIMMOC,     PGUINV_DACChannels.MOCErrVoltage);
    SPIDACWrite(1,     2.9);
    SPIDACWrite(2,     2.9);
    SPIDACWrite(3,     2.9);
    SPIDACWrite(4,     2.9);
    SPIDACWrite(5,     2.869); // DC Voltage (1900V/40000.0)*60.4ohm = 2.869V
    SPIDACWrite(6,     2.869); // DC Voltage (1900V/40000.0)*60.4ohm = 2.869V
    SPIDACWrite(7,     2.9);


#else

    SPIDACWrite(0,     PGUINV_DACChannels.MOCErrVoltage);         //Giri� ak�m�
    SPIDACWrite(1,     3.0); //PGUINV_DACChannels.VDCErrVoltage);         //��k�� ak�m� PGUINV_DACChannels.Rsvd1
    SPIDACWrite(2,     3.0);
    SPIDACWrite(3,     3.0); //
    SPIDACWrite(4,     PGUINV_DACChannels.BRKErrVoltage);
    SPIDACWrite(5,     3.0);
    SPIDACWrite(6,     3.0);
    SPIDACWrite(7,     3.0);
    SPIDAC2Write(0,    3.0); //
    }
#endif

void PGUINV_HWFaultLimitCalc()
{

    PGUINV_DACChannels.MOCErrVoltage      = 1.50 + (PGUINV_HWProtLevels.MOCErrVoltage    / PGUINV_Measure.Ratio.Cur_MotInputU)    *0.99;      // Motor over current limit value
    PGUINV_DACChannels.VDCErrVoltage    =          (PGUINV_HWProtLevels.VDCErrVoltage    / PGUINV_Measure.Ratio.Volt_DCLink)      *0.99;      // DC link over voltage limit value
    PGUINV_DACChannels.BRKErrVoltage    =          (PGUINV_HWProtLevels.BRKErrVoltage    / PGUINV_Measure.Ratio.Cur_BRK)          *0.99;      //
}

void PGUINV_TemperatureRead1()
{
    // NTC denklemi - y=Sicaklik x=Gerilim - y = -14,05x3 + 70,352x2 - 151,78x + 188,13


    float32   ChV;
    Uint16    Ch;
    Uint16    SType;
    Uint16    ind;
    float32  *dest;
    float32  *destLPF;
    float32  *source;
    Uint16   *ChSelSource;

    dest        = &(PGUINV_Temperature_CKU1.InverterTemp1);
    destLPF     = &(PGUINV_TemperatureLPF_CKU1.InverterTemp1);
    source      = &(SPIADCValues.CH0);
    ChSelSource = &(PGUINV_Temperature_ChSel_CKU1.INVTemp1);

    for(ind=0;ind<PGUINV_TEMPChNUM_CKU1;ind++)
    {
        Ch    = ((*(ChSelSource+ind))&0xFF00)>>8;
        SType = ((*(ChSelSource+ind))&0x00FF);

        ChV   = (*(source+(Ch)));

#ifdef LAB_DYNO

        if(SType==NTCTYPE)
        {
            *(dest+ind)= 0.0; //-14.05*(ChV*ChV*ChV) + 70.352*(ChV*ChV) - 151.78*ChV + 188.13;
        }
        else if (SType==PT100TYPE)
        {
            *(dest+ind)=56.67 * ChV - 24.00;
        }
        else
        {
            *(dest+ind)=0.0;
        }

#else

        if      (SType==NTCTYPE)
                {
                    *(dest+ind)=-16.265*(ChV*ChV*ChV) + 80.591*(ChV*ChV) - 160.55*ChV + 165.59;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else if (SType==NTC2TYPE)
                {
                   *(dest+ind)=-19.724*(ChV*ChV*ChV) + 98.216*(ChV*ChV)- 180.48*ChV + 141.65;//-31.05*logf(ChV) + 25.085;
                }


        else if (SType==PT100TYPE)
                {
        //          *(dest+ind)=59.567 * ChV - 18.495;    //Eski PT100 denklemi
                    *(dest+ind)=96.918 * ChV - 30.161;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }
        else if (SType==PRESSURETYPE )
                {
                    *(dest+ind)=3.591*ChV - 1.7237; //Bar;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);

                }

        else if (SType==PRESSURETYPE_NTC )
                {
                    *(dest+ind)= -16.875*(ChV*ChV*ChV) + 82.418* (ChV*ChV) -162.37*ChV + 168.38;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);

                }

        else
                {
                    *(dest+ind)=0.0;
                }

#endif

    }
}

void PGUINV_TemperatureRead2()
{
    // NTC denklemi - y=Sicaklik x=Gerilim - y = -14,05x3 + 70,352x2 - 151,78x + 188,13


    float32   ChV;
    Uint16    Ch;
    Uint16    SType;
    Uint16    ind;
    float32  *dest;
    float32  *destLPF;
    float32  *source;
    Uint16   *ChSelSource;

    dest        = &(PGUINV_Temperature_CKU2.InverterTemp1);
    destLPF     = &(PGUINV_TemperatureLPF_CKU2.InverterTemp1);
    source      = &(SPIADCValues.CH0);
    ChSelSource = &(PGUINV_Temperature_ChSel_CKU2.INVTemp1);

    for(ind=0;ind<PGUINV_TEMPChNUM_CKU2;ind++)
    {
        Ch    = ((*(ChSelSource+ind))&0xFF00)>>8;
        SType = ((*(ChSelSource+ind))&0x00FF);

        ChV   = (*(source+(Ch)));


#ifdef LAB_DYNO

        if(SType==NTCTYPE)
        {
            *(dest+ind)= 0.0; //-14.05*(ChV*ChV*ChV) + 70.352*(ChV*ChV) - 151.78*ChV + 188.13;
        }
        else if (SType==PT100TYPE)
        {
            *(dest+ind)=56.67 * ChV - 24.00;
        }
        else
        {
            *(dest+ind)=0.0;
        }

#else

        if      (SType==NTCTYPE)
                {
                    *(dest+ind)=-16.265*(ChV*ChV*ChV) + 80.591*(ChV*ChV) - 160.55*ChV + 165.59;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else if (SType==NTC2TYPE)
                {
                   *(dest+ind)=-19.724*(ChV*ChV*ChV) + 98.216*(ChV*ChV)- 180.48*ChV + 141.65;//-31.05*logf(ChV) + 25.085;
                   *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);

                }


        else if (SType==PT100TYPE)
                {
        //          *(dest+ind)=59.567 * ChV - 18.495;    //Eski PT100 denklemi
                    *(dest+ind)=96.918 * ChV - 30.161;
                    *(destLPF+ind)= LPF(*(dest+ind), *(destLPF+ind), 0.2*0.15);
                }

        else
                {
                    *(dest+ind)=0.0;
                }

#endif

    }
}







