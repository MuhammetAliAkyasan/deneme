#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

// Virtual Timers
int16	PGUINV_VTimer0[4]={0,0,0,0};		// 	Virtual Timers slaved off CPU Timer 0 (A events)
int16	PGUINV_VTimer1[4]={0,0,0,0}; 	// 	Virtual Timers slaved off CPU Timer 1 (B events)
int16	PGUINV_VTimer2[4]={0,0,0,0};     // 	Virtual Timers slaved off CPU Timer 2 (C events)

Uint16  PGUINV_FaultDataDelayCnt = 0;          // Delay Counter for writing first fault data


// State Machine variable declarations
void (*PGUINV_Alpha_State_Ptr)(void);    //  Base States pointer
void (*PGUINV_A_Task_Ptr)(void);         //  State pointer A branch
void (*PGUINV_B_Task_Ptr)(void);         //  State pointer B branch
void (*PGUINV_C_Task_Ptr)(void);         //  State pointer C branch

//=================================================================================
//	STATE-MACHINE SEQUENCING AND SYNCRONIZATION FOR SLOW BACKGROUND TASKS
//=================================================================================

void PGUINV_TaskInit(void)
{
    // Tasks State-machine init
    PGUINV_Alpha_State_Ptr = &PGUINV_A0;
    PGUINV_A_Task_Ptr = &PGUINV_A1;
    PGUINV_B_Task_Ptr = &PGUINV_B1;
    PGUINV_C_Task_Ptr = &PGUINV_C1;
}

void PGUINV_TaskLoop(void)
{
    // State machine entry & exit point
    //===========================================================
    (*PGUINV_Alpha_State_Ptr)();   // jump to an Alpha state (A0,B0,...)
    //===========================================================
}

//--------------------------------- FRAMEWORK -------------------------------------
void PGUINV_A0(void)
{
	// loop rate synchronizer for A-tasks
	if(CpuTimer0Regs.TCR.bit.TIF == 1)
	{
		CpuTimer0Regs.TCR.bit.TIF = 1;	// clear flag
		//-----------------------------------------------------------
		(*PGUINV_A_Task_Ptr)();		    // jump to an A Task (A1,A2,A3,...)
		//-----------------------------------------------------------

		PGUINV_VTimer0[0]++;			    // virtual timer 0, instance 0 (spare)
	}

	PGUINV_Alpha_State_Ptr = &PGUINV_B0;	// Jump to State B0
}

void PGUINV_B0(void)
{
	// loop rate synchronizer for B-tasks
	if(CpuTimer1Regs.TCR.bit.TIF == 1)
	{
		CpuTimer1Regs.TCR.bit.TIF = 1;	// clear flag

		//-----------------------------------------------------------
		(*PGUINV_B_Task_Ptr)();		    // jump to a B Task (B1,B2,B3,...)
		//-----------------------------------------------------------
		PGUINV_VTimer1[0]++;			    // virtual timer 1, instance 0 (spare)
	}

	PGUINV_Alpha_State_Ptr = &PGUINV_C0;	// Jump to State C0
}

void PGUINV_C0(void)
{
	// loop rate synchronizer for C-tasks
	if(CpuTimer2Regs.TCR.bit.TIF == 1)
	{
		CpuTimer2Regs.TCR.bit.TIF = 1;	// clear flag

		//-----------------------------------------------------------
		(*PGUINV_C_Task_Ptr)();		    // jump to a C Task (C1,C2,C3,...)
		//-----------------------------------------------------------
		PGUINV_VTimer2[0]++;			    //virtual timer 2, instance 0 (spare)
	}

	PGUINV_Alpha_State_Ptr = &PGUINV_A0;	// Back to State A0
}

//=================================================================================
//	PGUINV_A - TASKS
//=================================================================================


//-----------------------------------------
void PGUINV_A1(void)
//-----------------------------------------
{
    SWUpdateCheck();

    PGUINV_HWFaultLimitCalc();
    PGUINV_HWFaultLimitSet();            // HW Protection Value Set

	PGUINV_A_Task_Ptr = &PGUINV_A2;		//the next time CpuTimer0 'counter' reaches Period value go to A2
	PGUINV_VTimer0[1]++;
}

//-----------------------------------------
void PGUINV_A2(void)
//-----------------------------------------
{
	PGUINV_A_Task_Ptr = &PGUINV_A3;		//the next time CpuTimer0 'counter' reaches Period value go to A3
	PGUINV_VTimer0[2]++;
}

//-----------------------------------------
void PGUINV_A3(void)
//-----------------------------------------
{
	PGUINV_A_Task_Ptr = &PGUINV_A1;		//the next time CpuTimer0 'counter' reaches Period value go to A1
	PGUINV_VTimer0[3]++;
}

//=================================================================================
//	PGUINV_B - TASKS
//=================================================================================
//----------------------------------------
void PGUINV_B1(void)
//----------------------------------------
{
	PGUINV_B_Task_Ptr = &PGUINV_B2;		//the next time CpuTimer1 'counter' reaches Period value go to B2
	PGUINV_VTimer1[1]++;
}

//----------------------------------------
void PGUINV_B2(void)
//----------------------------------------
{
    SPIADCRead(&(SPIADCValues.CH0));

    if(PGUINV_CKU1 == 1)         // 6s Delay = 400*15ms
           {
        PGUINV_TemperatureRead1();            // Temperature Read from TSC
           }

       if(PGUINV_CKU2 == 1)         // 6s Delay = 400*15ms
           {
           PGUINV_TemperatureRead2();            // Temperature Read from TSC
           }

	PGUINV_B_Task_Ptr = &PGUINV_B3;		//the next time CpuTimer1 'counter' reaches Period value go to B3
	PGUINV_VTimer1[2]++;
}

//----------------------------------------
void PGUINV_B3(void)
//----------------------------------------
{
    PGUINV_WriteMonData(PGUINV_VTimer1[3]);     // Ethernet Monitoring Data Exchange via Dual Port Memory

	PGUINV_B_Task_Ptr = &PGUINV_B1;		//the next time CpuTimer1 'counter' reaches Period value go to B1
	PGUINV_VTimer1[3]++;
}

//=================================================================================
//	PGUINV_C - TASKS
//=================================================================================
//----------------------------------------
void PGUINV_C1(void)
//----------------------------------------
{
//    if(PGUINV_RecSuccessfull == 6)     // Rectifier anahtarlama basarili
//    {

    if(EnableTC == 1)       { EnableSC = 1; }
    else                    { EnableSC = 0; }

    if(PGUINV_DC_Counter == 1500)
       {
          if  (EnableVC == 1) {   EnableTC = 1;}
          else                {   EnableTC = 0;}
          PGUINV_DC_Counter = 1501;
       }

    if  (EnableCC == 1) {   EnableVC = 1;}
    else                {   EnableVC = 0;}

    if  (EnableFO == 1) {   EnableCC = 1;}
    else                {   EnableCC = 0;}

    if(PGUINV_DC_Counter > 1000)
       {
          EnableFO = 1.0;
       }
//    }

    PGUINV_C_Task_Ptr = &PGUINV_C2;		//the next time CpuTimer2 'counter' reaches Period value go to C2
	PGUINV_VTimer2[1]++;
}

//----------------------------------------
void PGUINV_C2(void)
//----------------------------------------
{

    PGUINV_WriteCANData((Uint16)PGUINV_VTimer2[2]);     // CAN Data Exchange via Dual Port Memory

	PGUINV_C_Task_Ptr = &PGUINV_C3;				//the next time CpuTimer2 'counter' reaches Period value go to C3
	PGUINV_VTimer2[2]++;
}

//-----------------------------------------
void PGUINV_C3(void)
//-----------------------------------------
{

    if(PGUINV_FaultDataDelayCnt< 400)         // 6s Delay = 400*15ms
      {
          PGUINV_FaultDataDelayCnt++;
      }
      else
      {
          PGUINV_WriteFaultData();
      }
	PGUINV_C_Task_Ptr = &PGUINV_C1;		//the next time CpuTimer2 'counter' reaches Period value go to C1
	PGUINV_VTimer2[3]++;
}


