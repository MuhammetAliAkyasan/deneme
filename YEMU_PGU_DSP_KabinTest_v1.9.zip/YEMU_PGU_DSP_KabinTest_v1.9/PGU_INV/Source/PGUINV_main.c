/*
 * PGUDREC_main.c
 *
 *  Created on: 1 Tem 2022
 *      Author: hasan.ertugrul  PWMGEN
 */

#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

//  Structs Initialization Values

PWMGEN    PGUINVPWM       = PGUINV_INVPWM_GEN_INIT;             //  General PWM instance and initialization

PWMGEN    PGUINV_InvPWM1  = PGUINV_INVPWM_GEN_INIT;             //  PWM Inverter instance and initialization
PWMGEN    PGUINV_InvPWM2  = PGUINV_INVPWM_GEN_INIT;             //  PWM Inverter instance and initialization
PWMGEN    PGUINV_InvPWM3  = PGUINV_INVPWM_GEN_INIT;             //  PWM Inverter instance and initialization

PWMGEN    PGUINV_BrkPWM   = PGUINV_ISR_PWM_GEN_INIT; //PGUINV_INVPWM_GEN_INIT;             //  Break PWM instance and initialization

PWMGEN    PGUINV_IsrPWM   = PGUINV_ISR_PWM_GEN_INIT;            //  Interrupt Service Routine(ISR) PWM instance and initialization

void PGUINV_main(void)
{

    // Initialize CPUTimers
// ***************************************************
    ConfigCPUTimers(PGUINV_TASKA_PERIOD, PGUINV_TASKB_PERIOD, PGUINV_TASKC_PERIOD);           // Background tasks init
    PGUINV_TaskInit();

    ClearAnalogBuffer(AnaBuff.buff1, 1);       // Clear Analog Buffer in External Memory Analog Buffer Section
    ClearAnalogBuffer(AnaBuff.buff2, 2);       // Clear Analog Buffer in External Memory Analog Buffer Section
    ClearAnalogBuffer(AnaBuff.buff3, 3);       // Clear Analog Buffer in External Memory Analog Buffer Section
    ClearAnalogBuffer(AnaBuff.buff4, 4);       // Clear Analog Buffer in External Memory Analog Buffer Section
    ClearAnalogBuffer(AnaBuff.buff5, 5);       // Clear Analog Buffer in External Memory Analog Buffer Section
    ClearAnalogBuffer(AnaBuff.buff6, 6);       // Clear Analog Buffer in External Memory Analog Buffer Section
    ClearAnalogBuffer(AnaBuff.buff7, 7);       // Clear Analog Buffer in External Memory Analog Buffer Section

// ***************************************************
// Initialize ADC
// ***************************************************
    ConfigADC(PGUINV_DSPADCChSel);                           // Configure ADC module
    PGUINV_ADC_RATIO_CALC(PGUINV_Measure);

// ***************************************************
// Initialize PWM & DMA & QEP
// ***************************************************
    ConfigPWM();   // Config all PWM modules according to initial values

    ConfigPWMModule(PGUINVPWM.PeriodMax, PGUINVPWM.Deadband,  PGUINV_RSV1,0);

// Config Break PWM modules according to initial values
    ConfigPWMModule(PGUINV_BrkPWM.PeriodMax, PGUINV_BrkPWM.Deadband,  PGUINV_BRKPWM,0);

// Config 3 phase inverter PWM modules according to initial values
    ConfigPWMModule(PGUINV_InvPWM1.PeriodMax, PGUINV_InvPWM1.Deadband,  PGUINV_IPWMU,0);
    ConfigPWMModule(PGUINV_InvPWM2.PeriodMax, PGUINV_InvPWM2.Deadband,  PGUINV_IPWMV,0);
    ConfigPWMModule(PGUINV_InvPWM3.PeriodMax, PGUINV_InvPWM3.Deadband,  PGUINV_IPWMW,0);

    ConfigPWMModule(PGUINV_IsrPWM.PeriodMax,  PGUINV_IsrPWM.Deadband,   PGUINV_RSV2,0);

//
/* PGUINV_RSV2 (PWM2) channel is used for starting of conversion of ADC  (PGUINV_MainISR is triggered regularly by a SEQ1INT interrupt. )*/

   (*ePWM[PGUINV_RSV2]).ETSEL.bit.SOCAEN  = 1;    /* Enable SOCA */
   (*ePWM[PGUINV_RSV2]).ETSEL.bit.SOCASEL = 1;    /* Enable CNT_ZERO event for SOCA */
   (*ePWM[PGUINV_RSV2]).ETPS.bit.SOCAPRD  = 1;    /* Generate SOCA on the 1st event */
   (*ePWM[PGUINV_RSV2]).ETCLR.bit.SOCA    = 1;    /* Clear SOCA flag */

    EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;              // Change EPwm1 Sync Output to CTR = EPWMSYNCI
    EALLOW;

    EPwm1Regs.TZEINT.bit.OST     = 1;                        // Enable TZ interrupt on any TZ event
    EDIS;

    InitDSPEPwm3Gpio();
    InitDSPEPwm4Gpio();
    InitDSPEPwm5Gpio();
    InitDSPEPwm6Gpio();

    InitDSPTz1Gpio();
    InitDSPTz2Gpio();

// ***************************************************
// Initialize QEP
// ***************************************************

//    DMAInitialize();                            // Initialize DMA

    ConfigQEP(1, MOTOR_ENCODER_PULSE);          // Config QEP module (Speed calculaion based on QPOSMAX)
    InitDSPEQep1Gpio();

    ConfigQEP(2, MOTOR_ENCODER_PULSE);          // Config QEP module (Speed calculaion based on QPOSMAX)
    InitDSPEQep2Gpio();

// ***************************************************
// Initialize other GPIO pins
// ***************************************************

    InitDSPIOGpio_INV();

// ***************************************************
// SPI cofiguration for Hardware Fault
// ***************************************************

    PGUINV_MainISRInit();    // Call before PGUINV_HWFaultLimitSet
    PGUINV_HWFaultLimitCalc();
    PGUINV_HWFaultLimitSet();

// ***************************************************
// DSP related peripheral cards initial (FOIO,TCPU)
// ***************************************************

    PGUINV_InitFOIO();                          // Initialize FOIO and reset FOIO
    PGUINV_InitTCPU();                          // Initialize TCPU and reset TCPU


#if (TRIPMANAGEMENT)
                // Enable Rectifier Trips

    EALLOW;

    #if (BREAK_CONTROL)

    // Enable Break Trips

        EPwm4Regs.TZSEL.all = ENABLE_TZ1_OST;       // CFD
        EPwm4Regs.TZSEL.all |= ENABLE_TZ2_OST;      // HGOFF

   #endif


    #if (INVERTER_CONTROL)

   // Enable Inverter Trips

        EPwm3Regs.TZSEL.all = ENABLE_TZ1_OST;       // CFD
        EPwm3Regs.TZSEL.all |= ENABLE_TZ2_OST;      // HGOFF

        EPwm5Regs.TZSEL.all = ENABLE_TZ1_OST;       // CFD
        EPwm5Regs.TZSEL.all |= ENABLE_TZ2_OST;      // HGOFF

        EPwm6Regs.TZSEL.all = ENABLE_TZ1_OST;       // CFD
        EPwm6Regs.TZSEL.all |= ENABLE_TZ2_OST;      // HGOFF

    #endif

      EDIS;

#endif

// Inverter Control
// ***************************************************
#if (BREAK_CONTROL || INVERTER_CONTROL)

       Inv3_Init();                                 // Initialize Inverter Control Structures and Params

       // Reassign  Main ISR

       PieCtrlRegs.PIEIER1.bit.INTx1 = 1;              // Enable PIE group 1 interrupt 1 for SEQ1_INT

       EALLOW;
       PieVectTable.SEQ1INT        = &PGUINV_MainISR;          // SEQ1 INT is assigned to HS_ISR
       EDIS;


     DELAY_US(2000000);                          // 2 Saniye bekle (Analog filtreler i�in)

     PieCtrlRegs.PIEIER2.bit.INTx3 = 1;              // Enable PIE group 2 interrupt 3 for EPWM3_TZINT


   // Reassign Software Protection ISR
      EALLOW;
      PieVectTable.EPWM1_TZINT    = &PGUINV_TripZoneISR;
      EDIS;

      EnableInterrupts();                         // This function enables the PIE module and CPU interrupts
#endif


    for(;;)
       {
        PGUINV_TaskLoop();
       }
}
