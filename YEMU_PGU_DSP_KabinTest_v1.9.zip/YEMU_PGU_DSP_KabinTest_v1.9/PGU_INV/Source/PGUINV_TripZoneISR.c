#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

interrupt void PGUINV_TripZoneISR(void)
{

	if((!IO_READ(PGUINV_TZ1GPIO))||(!IO_READ(PGUINV_TZ2GPIO)))       // Bekleme durumunda hata ??
	{
	    PGUGateOFF
	    FOIOGateOFF
	    PGUINV_FLT_REG.bit.HWPROT    = 1; 		// Hardware fault
	    PGUINV_CTL_REG.bit.STATE     = 15;		// Hardware Hata durumu
	}
	else
	{
	    PGU_INVCTL_REG.bit.Enable	= 2;
	}
}


