#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"


//--MACRO VARIABLES and INSTANCES
Uint16   PGUINV_DSPADCChSel[16]   = PGUINV_ADC_CHANNELS;     //  ADC init macro channel assignment for PGUINV

PGUINV_MEASUREMENT                 PGUINV_Measure         = PGUINV_MEASUREMENT_INIT;         //  ADC measurement instance and initialization for PGUINV
PGUINV_MEASUREMENTVARIABLES        PGUINV_ADCOffsets      = PGUINV_ADC_OFFSET_INIT;  //  ADC measurement offset instance for PGUINV
PGUINV_ADC_FLT_REG                 PGUINV_ADCErrFlags     = PGUINV_ADC_ERR_INIT;       //  Measurement error flags initialization


MASTERC_REGS        PGUINV_MasterContr             = {0x0000,0x0000,0x0000,0.0};
TORQUELIM_REG       PGUINV_TORQLIM_REG             = {0x0000};

CONVCTL_REG		    PGUINV_CTL_REG 	               = {0x0000};
CONVFLT_REG		    PGUINV_FLT_REG 	               = {0x0000};

PGUINV_TEMPSTS_REG_CKU1     PGUINV_TempErrFlags_CKU1 	    = {0x0000};
PGUINV_TEMPSTS_REG_CKU1     PGUINV_TempWarnFlags_CKU1	    = {0x0000};

PGUINV_TEMPSTS_REG_CKU2     PGUINV_TempErrFlags_CKU2        = {0x0000};
PGUINV_TEMPSTS_REG_CKU2     PGUINV_TempWarnFlags_CKU2       = {0x0000};

PGUINV_SWPROTFLT_REG	    PGUINV_SWProtErrFlags           = {0x0000};
PGUINV_SWPROTFLT_REG	    PGUINV_SWProtWarnFlags          = {0x0000};

PGUINV_TEMPERATURE_CKU1 	PGUINV_Temperature_CKU1 	      = PGUINV_TEMP_MEAS_INIT_CKU1;			    // 	Temperature measurement instance and initialization
PGUINV_TEMPERATURE_CKU1     PGUINV_TemperatureLPF_CKU1        = PGUINV_TEMP_MEAS_INIT_CKU1;             //  Temperature measurement instance and initialization
PGUINV_TEMPERATURE_CKU1 	PGUINV_TempWarnLimits_CKU1        = PGUINV_TEMP_WARN_INIT_CKU1;			    //	Temperature measurement warning limits
PGUINV_TEMPERATURE_CKU1 	PGUINV_TempErrLimits_CKU1 	      = PGUINV_TEMP_ERR_INIT_CKU1;			    //	Temperature measurement error limits

PGUINV_TEMP_CHSEL_CKU1      PGUINV_Temperature_ChSel_CKU1     = PGUINV_TEMP_CHSEL_INIT_CKU1;            //  Temperature measurement initialization for channel selection and sensor types

PGUINV_TEMPERATURE_CKU2     PGUINV_Temperature_CKU2           = PGUINV_TEMP_MEAS_INIT_CKU2;             //  Temperature measurement instance and initialization
PGUINV_TEMPERATURE_CKU2     PGUINV_TemperatureLPF_CKU2        = PGUINV_TEMP_MEAS_INIT_CKU2;             //  Temperature measurement instance and initialization
PGUINV_TEMPERATURE_CKU2     PGUINV_TempWarnLimits_CKU2        = PGUINV_TEMP_WARN_INIT_CKU2;             //  Temperature measurement warning limits
PGUINV_TEMPERATURE_CKU2     PGUINV_TempErrLimits_CKU2         = PGUINV_TEMP_ERR_INIT_CKU2;              //  Temperature measurement error limits

PGUINV_TEMP_CHSEL_CKU2      PGUINV_Temperature_ChSel_CKU2     = PGUINV_TEMP_CHSEL_INIT_CKU2;            //  Temperature measurement initialization for channel selection and sensor types


PGUINV_SWPROT 		        PGUINV_SWProtFdbs		    = PGUINV_SWPROT_INIT;

PGUINV_SWPROTLEVELS	        PGUINV_SWProtWarnLimits     = PGUINV_SWPROT_WARN_INIT;   	//  Feedback Signals warning limits
PGUINV_SWPROTLEVELS	        PGUINV_SWProtErrLimits	    = PGUINV_SWPROT_ERR_INIT;  	    //  Feedback Signals error limits


PGUINV_SWPROTCOUNT	        PGUINV_SWProtErrTime	    = PGUINV_SWPROT_COUNT_INIT;
PGUINV_SWPROTCOUNT	        PGUINV_SWProtErrCount	    = PGUINV_SWPROT_COUNT_INIT;

PGUINV_HWPROT	            PGUINV_DACChannels          = PGUINV_HW_PROT_DAC_LIMITS_INIT;	// 	HW Protection Limit instance, FDPC LIMIT VALUES (RAW Data)
PGUINV_HWPROT	            PGUINV_HWProtLevels	        = PGUINV_HW_PROT_LEVELS_INIT;		// 	HW Protection Levels (actual values)





