#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"



void PGUINV_SWProtection(PGUINV_SWPROT Fdbs, PGUINV_SWPROTLEVELS WarnLimits, PGUINV_SWPROTLEVELS ErrLimits, PGUINV_SWPROTFLT_REG * WarnFlags, PGUINV_SWPROTFLT_REG * ErrFlags , PGUINV_SWPROTCOUNT * ErrTime,PGUINV_SWPROTCOUNT * ErrCount)
{
//------------------------------------------------------------------//
//-------------- Motor phase over current check --------------------//
//------------------------------------------------------------------//

    // Motor phase U over current check
    if (Fdbs.MotCur_U >= ErrLimits.MotOC_U)
    {
        if(ErrCount->MotOC_U < ErrTime->MotOC_U)
        {
            ErrCount->MotOC_U++;
            WarnFlags->bit.MotOC_U = 1;
        }
        else
        {
            ErrFlags->bit.MotOC_U = 1;
        }
    }
    else
    {
        ErrCount->MotOC_U = 0;
        if (Fdbs.MotCur_U  >= WarnLimits.MotOC_U)
        {
            WarnFlags->bit.MotOC_U = 1;
        }
        else
        {
            WarnFlags->bit.MotOC_U = 0;
        }
    }


    // Motor phase W over current check
    if (Fdbs.MotCur_W  >= ErrLimits.MotOC_W)
    {
        if(ErrCount->MotOC_W < ErrTime->MotOC_W)
        {
            ErrCount->MotOC_W++;
            WarnFlags->bit.MotOC_W = 1;
        }
        else
        {
            ErrFlags->bit.MotOC_W = 1;
        }
    }
    else
    {
        ErrCount->MotOC_W = 0;
        if (Fdbs.MotCur_W  >= WarnLimits.MotOC_W)
        {
            WarnFlags->bit.MotOC_W = 1;
        }
        else
        {
            WarnFlags->bit.MotOC_W = 0;
        }
    }


//------------------------------------------------------------------//
//--------- Break resistor over current check---------------//
//------------------------------------------------------------------//

    // Break resistor current check
    if (Fdbs.BrkCur >= ErrLimits.Ibrk_OC)
    {
        if(ErrCount->Ibrk_OC < ErrTime->Ibrk_OC)
        {
            ErrCount->Ibrk_OC++;
            WarnFlags->bit.Ibrk_OC = 1;
        }
        else
        {
            ErrFlags->bit.Ibrk_OC = 1;
        }
    }
    else
    {
        ErrCount->Ibrk_OC = 0;
        if (Fdbs.BrkCur  >= WarnLimits.Ibrk_OC)
        {
            WarnFlags->bit.Ibrk_OC = 1;
        }
        else
        {
            WarnFlags->bit.Ibrk_OC = 0;
        }
    }

//------------------------------------------------------------------//
//-------------- DC bus voltage level error check ------------------//
//------------------------------------------------------------------//
    // Over voltage check
    if (Fdbs.Vdc >= ErrLimits.VdcOV)
    {
        if(ErrCount->VdcOV < ErrTime->VdcOV)
        {
            ErrCount->VdcOV++;
            WarnFlags->bit.VdcOV = 1;
        }
        else
        {
            ErrFlags->bit.VdcOV = 1;
        }
    }
    else
    {
        ErrCount->VdcOV = 0;
        if (Fdbs.Vdc  >= WarnLimits.VdcOV)
        {
            WarnFlags->bit.VdcOV    = 1;
            if(PGUINV_TORQLIM_REG.bit.VDC == 1)
            {
                PGUINV_Torque.VdcLimFactor     = 1.0 - (Fdbs.Vdc - WarnLimits.VdcOV)/(ErrLimits.VdcOV - WarnLimits.VdcOV);
            }
            else
            {
                PGUINV_Torque.VdcLimFactor     = 1.0;
            }
        }
        else
        {
            WarnFlags->bit.VdcOV = 0;
            PGUINV_Torque.VdcLimFactor     = 1.0;
        }
    }

    // Low voltage check
    if (Fdbs.Vdc  <= ErrLimits.VdcLV   && MC_Status ==1)
    {
        if(ErrCount->VdcLV < ErrTime->VdcLV)
        {
            ErrCount->VdcLV++;
            WarnFlags->bit.VdcLV = 1;
        }
        else
        {
            ErrFlags->bit.VdcLV = 1;
        }
    }
    else
    {
        ErrCount->VdcLV = 0;
        if (Fdbs.Vdc  <= WarnLimits.VdcLV  && MC_Status ==1)
        {
            WarnFlags->bit.VdcLV= 1;
        }
        else
        {
            WarnFlags->bit.VdcLV = 0;
        }
    }



//------------------------------------------------------------------//
//---------------- Inverter over load check -----------------------//
//------------------------------------------------------------------//

if ( Fdbs.InvOutPow  >= ErrLimits.InvOL)
{
    if(ErrCount->InvOL < ErrTime->InvOL)
    {
        ErrCount->InvOL++;
        WarnFlags->bit.InvOL = 1;
    }
    else
    {
        ErrFlags->bit.InvOL = 1;
    }
}
else
{
    ErrCount->InvOL = 0;
    if (Fdbs.InvOutPow  >= WarnLimits.InvOL)
    {
        WarnFlags->bit.InvOL = 1;
    }
    else
    {
        WarnFlags->bit.InvOL = 0;
    }
}



//------------------------------------------------------------------//
//-------------- Speed check -1 -------------------//
//------------------------------------------------------------------//

if ( Fdbs.Mot1_Speed >= ErrLimits.Mot1_Speed)
{
    if(ErrCount->Mot1_Speed < ErrTime->Mot1_Speed)
    {
        ErrCount->Mot1_Speed++;
        WarnFlags->bit.Mot1_Speed = 1;
    }
    else
    {
        ErrFlags->bit.Mot1_Speed = 1;
    }
}
else
{
    ErrCount->Mot1_Speed = 0;
    if (Fdbs.Mot1_Speed >= WarnLimits.Mot1_Speed)
    {
        WarnFlags->bit.Mot1_Speed = 1;
        if(PGUINV_TORQLIM_REG.bit.MOTSPEED1 == 1)
        {
            PGUINV_Torque.SpeedLimFactor1   = 1.0 - (Fdbs.Mot1_Speed - WarnLimits.Mot1_Speed)/(ErrLimits.Mot1_Speed - WarnLimits.Mot1_Speed);
        }
        else
        {
            PGUINV_Torque.SpeedLimFactor1   = 1.0;
        }
    }
    else
    {
        WarnFlags->bit.Mot1_Speed = 0;
        PGUINV_Torque.SpeedLimFactor1   = 1.0;
    }
}

//------------------------------------------------------------------//
//-------------- Speed check -2 -------------------//
//------------------------------------------------------------------//

    if ( Fdbs.Mot2_Speed >= ErrLimits.Mot2_Speed)
    {
        if(ErrCount->Mot2_Speed < ErrTime->Mot2_Speed)
        {
            ErrCount->Mot2_Speed++;
            WarnFlags->bit.Mot2_Speed = 1;
        }
        else
        {
            ErrFlags->bit.Mot2_Speed = 1;
        }
    }
    else
    {
        ErrCount->Mot2_Speed = 0;
        if (Fdbs.Mot2_Speed >= WarnLimits.Mot2_Speed)
        {
            WarnFlags->bit.Mot2_Speed = 1;
            if(PGUINV_TORQLIM_REG.bit.MOTSPEED2 == 1)
            {
                PGUINV_Torque.SpeedLimFactor2   = 1.0 - (Fdbs.Mot2_Speed - WarnLimits.Mot2_Speed)/(ErrLimits.Mot2_Speed - WarnLimits.Mot2_Speed);
            }
            else
            {
                PGUINV_Torque.SpeedLimFactor2   = 1.0;
            }
        }
        else
        {
            WarnFlags->bit.Mot2_Speed = 0;
            PGUINV_Torque.SpeedLimFactor2   = 1.0;
        }
    }

}

void PGUINV_TemperatureProtection_CKU1 (PGUINV_TEMPERATURE_CKU1 temp, PGUINV_TEMPERATURE_CKU1 warn, PGUINV_TEMPERATURE_CKU1 err, PGUINV_TEMPSTS_REG_CKU1 *warnflag, PGUINV_TEMPSTS_REG_CKU1 *errflag)
{
	float32 *t  = &(temp.InverterTemp1);
	float32 *w	= &(warn.InverterTemp1);
	float32 *e	= &(err.InverterTemp1);

	// Inverter over temperature error check
	Uint16 i;
	for(i=0;i<PGUINV_TEMPChNUM_CKU1;i++)
	{
		if (*(t+i) >= *(e+i))
		{
			errflag->all |= 1<<i;
		}
		else if(*(t+i) >= *(w+i))
		{
			warnflag->all |= 1<<i;
		}
		else
		{
			warnflag->all &= ~(1<<i);
		}
	}
}

void PGUINV_TemperatureProtection_CKU2 (PGUINV_TEMPERATURE_CKU2 temp, PGUINV_TEMPERATURE_CKU2 warn, PGUINV_TEMPERATURE_CKU2 err, PGUINV_TEMPSTS_REG_CKU2 *warnflag, PGUINV_TEMPSTS_REG_CKU2 *errflag)
{
    float32 *t  = &(temp.InverterTemp1);
    float32 *w  = &(warn.InverterTemp1);
    float32 *e  = &(err.InverterTemp1);

    // Inverter over temperature error check
    Uint16 i;
    for(i=0;i<PGUINV_TEMPChNUM_CKU2;i++)
    {
        if (*(t+i) >= *(e+i))
        {
            errflag->all |= 1<<i;
        }
        else if(*(t+i) >= *(w+i))
        {
            warnflag->all |= 1<<i;
        }
        else
        {
            warnflag->all &= ~(1<<i);
        }
    }
}




