#ifndef __BPF_H__
#define __BPF_H__

/********** DECLARATION OF STRUCTS **********/
typedef struct 
{
	float32 In; 		/*Input signal*/
} BPF_IN;

typedef struct 
{
	float32 Out; 	    /*Filtered output signal*/
} BPF_OUT;

typedef struct 
{
    float32 InK1;   // (k-1)th Value of Input Signal
    float32 InK2;   // (k-2)th Value of Input Signal
    float32 InK3;   // (k-3)th Value of Input Signal
    float32 InK4;   // (k-4)th Value of Input Signal
    float32 OutK1;  // (k-1)th Value of Filtered Signal
    float32 OutK2;  // (k-2)th Value of Filtered Signal
    float32 OutK3;  // (k-3)th Value of Filtered Signal
    float32 OutK4;  // (k-4)th Value of Filtered Signal
} BPF_VAR;

typedef struct 
{
    float32 numdbp1;   // First Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 numdbp2;   // Second Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 numdbp3;   // Third Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 numdbp4;   // Fourth Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 numdbp5;   // Fifth Element of Numerator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 dendbp1;   // First Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 dendbp2;   // Second Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 dendbp3;   // Third Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 dendbp4;   // Fourth Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
    float32 dendbp5;   // Fifth Element of Denominator of Digital Band-Pass Filter (DigitalFilters.m)
} BPF_PAR;

/********** CONSTRUCTION OF OBJECT **********/
typedef struct
{
    BPF_IN	    i;
    BPF_OUT 	o;
    BPF_VAR	    v;
    BPF_PAR	    p;
} BPF;

/********** DEFAULT VALUES FOR STRUCTS **********/
#define BPF_IN_DEFAULTS 	{0.0}
#define BPF_OUT_DEFAULTS    {0.0}
#define BPF_VAR_DEFAULTS    {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}
#define BPF_PAR_DEFAULTS    {0.0, 4.387067642018803e-04, -4.473705576188664e-04, -4.213791774257708e-04, 4.300429708427568e-04, \
                             1.0, -3.939282726798868,     5.820533580814271,     -3.823165436077300,     0.941915359768588}

/********** DEFINITON OF MACRO **********/
#define BPF_MACRO(x)                                                                    \
    /*-----------------------------------------------------------------*/               \
    /*-------------------[Band Pass Filter]----------------------------*/               \
    /*-----------------------------------------------------------------*/               \
    x.o.Out = 1.0/x.p.dendbp1*( x.p.numdbp1*x.i.In      + x.p.numdbp2*x.v.InK1 +        \
                                x.p.numdbp3*x.v.InK2    + x.p.numdbp4*x.v.InK3 +        \
                                x.p.numdbp5*x.v.InK4    - x.p.dendbp2*x.v.OutK1 -       \
                                x.p.dendbp3*x.v.OutK2   - x.p.dendbp4*x.v.OutK3 -       \
                                x.p.dendbp5*x.v.OutK4);                                 \
                                                                                        \
    x.v.OutK4  = x.v.OutK3;    /* Update of (k-4)th Value of Output Signal */           \
    x.v.OutK3  = x.v.OutK2;    /* Update of (k-3)th Value of Output Signal */           \
    x.v.OutK2  = x.v.OutK1;    /* Update of (k-2)th Value of Output Signal */           \
    x.v.OutK1  = x.o.Out;      /* Update of (k-1)th Value of Output Signal */           \
                                                                                        \
    x.v.InK4   = x.v.InK3;     /* Update of (k-4)th Value of Input Signal  */           \
    x.v.InK3   = x.v.InK2;     /* Update of (k-3)th Value of Input Signal  */           \
    x.v.InK2   = x.v.InK1;     /* Update of (k-2)th Value of Input Signal  */           \
    x.v.InK1   = x.i.In;       /* Update of (k-1)th Value of Input Signal  */


// END OF MACRO DEFINITON

#endif // __BPF_H__
