/*
 * PGUINV_MainISR.c
 *
 *  Created on: 01 Sub 2021
 *      Author: GA - HFE
 */

#ifndef PGUINV_MAINISR_C_
#define PGUINV_MAINISR_C_

#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

volatile float32 PGUINV_TeRefCAN              = 0.0;
volatile float32 PGUINV_TeRefRateLimited      = 0.0;
volatile float32 PGUINV_Vdc_ref               = 120.0;
float32 PGUINV_wLPF   = 314.16;
Uint16 tripcounter = 0;

// Inverter Devreye alma s�ras�nda kullan�lan de�i�kenler
Uint16  PGUINV_CtrlStartCntr     = 0;
Uint16  PGUINV_CtrlStopCntr      = 0;
Uint16  PGUINV_CtrlStopCntrOld   = 0;
Uint16  PGUINV_CtrlStopFlag      = 0;
Uint16  PGUINV_FOIOGateOnFlag    = 0;

Uint16  PGUINV_DCLinkLVFlag      = 0;
Uint16  PGUINV_DCLinkLVCntr      = 0;

float32 PGUINV_MainIsrTotalTime  = 0.0;

Uint16  PGUINV_TivaRegWFlag      = 0;
Uint16  PGUINV_TivaRegRCount     = 0;

volatile Uint16  Success        = 0;
volatile Uint16  DC_Counter     = 0;

float32 DutyDeneme_INV        = 0.0;

float32 DMin_Inv     = -0.97;
float32 DMax_Inv     = 0.97;
float32 PGUINV_VdcUpdateScale = 0.0;

Uint16    AnahtarlamaBaslat_INV    = 0;

float32 AverageElecSpeed = 0;
float32 AverageSpeedRPM  = 0;
float32 VehicleSpeed     = 0;

float32 MxSpeedFc   = 0;

float32 M1SpeedRPM      = 0.0;
float32 M1ElecSpeed     = 0.0;
float32 M2SpeedRPM      = 0.0;
float32 M2ElecSpeed     = 0.0;

// Supply control and synchronization
Uint16  PGUINV_BufferIlk =0;
Uint16  PGUINV_ControlTicker= 0;

// ContacRoutine Variables
Uint16 MC_Status       = 0;

Uint16 CKU_Ident0_INV=0;
Uint16 CKU_Ident1_INV=0;
Uint16 CKU_Ident2_INV=0;
Uint16 CKU_Ident3_INV=0;

Uint16  PGUINV_CKU1=0;
Uint16  PGUINV_CKU2=0;

Uint16 PGUREC_FAULT=0;
Uint16 PGUREC_TorqueLimFactor=0;
Uint16 PGUINV_RecSuccessfull=0;
Uint16 PGUINV_DC_Counter=0;

///////////////////////////////////////////S� D�zenleme///////////////////////////////////////////////////////
//A�a��daki sat�rlar eklendi.
Uint16 CabinTemp_Rec = 0;
Uint16 ConvHumidity_Temp_Rec = 0;
Uint16 ConvHumidity_Hum_Rec = 0;
Uint16 Volt_Catenary_Rec = 0;
Uint16 Volt_DCLink_Rec = 0;
Uint16 Cur_RectInput1_Rec = 0;
Uint16 Cur_RectInput2_Rec = 0;
Uint16 RectifierTemp1_Rec  = 0;
Uint16 RectifierTemp2_Rec  = 0;
Uint16 MotorTemp1_Rec   = 0;
Uint16 MotorTemp2_Rec   = 0;
Uint16 GearTemp_Rec = 0;

Uint16 CabinTemp2_Rec = 0;
Uint16 CoolingFlow_Flow_Rec = 0;
Uint16 CoolingFlow_Temp_Rec = 0;
Uint16 Rectifier2Temp1_Rec = 0;
Uint16 Rectifier2Temp2_Rec = 0;
Uint16 MotorTemp3_Rec = 0;
Uint16 MotorTemp4_Rec = 0;
Uint16 GearTemp2_Rec = 0;

Uint16 GerilimsizAnahtarlama_INV = 0;
Uint16 Prech1_INV = 0;
Uint16 Prech2_INV = 0;
Uint16 Prech1_Basarili =0;
Uint16 Prech2_Basarili =0;
Uint16 Prech1_Hatali =0;
Uint16 Prech2_Hatali =0;
Uint16 AnahtarlamaBaslat = 0;
Uint16 MotorDirection = 0;
Uint16 MotorVFEnable = 0;
Uint16 SpeedRef = 0;
Uint16 DCBaraBosalt = 0;

Uint16 Labview_Sayac = 0;
Uint16 Labview_Sayac_old = 0;
Uint16 Labview_Sayac_cnt = 0;
Uint16 Labview_Sayac_cntmax = 1600;
Uint16 Eth_Hata = 0;

Uint16  PGUINV_Lifesign = 0;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

Uint16 PGUINV_Emergency_Degraded=0;
Uint16 PGUINV_Emergency1=0;
Uint16 PGUINV_Emergency2=0;
Uint16 PGUINV_Emergency3=0;

float32 BrakePowMax    = 0.0;
float32 BrakePow       = 0.0;
float32 BrakeDuty      = 0.0;
float32 PowInLPF        = 0.0;
float32 IdcLPF          = 0.0;
float32 IBrakeLPF      = 0.0;

Uint16  BrakeEn            = 0.0;
Uint16  BrakeOLCntr   = 0.0;
Uint16  BrakeOLCntr2   = 0.0;

float32 MechPow         = 0.0;
float32 MechPowLPF      = 0.0;
float32 VDCBusLPF       = 0.0;
float32 VDCBusLPF2      = 0.0;

Uint16  PGUINV_MasterContrStat   = 0;
Uint16  PGUINV_ConvEnable        = 0;
Uint16  PGUINV_TractInh          = 0;
Uint16  PGUINV_ERTMSBrake        = 0;
Uint16  PGUINV_VCBStatus         = 0;
Uint16  PGUINV_EmergencyLoop     = 0;
Uint16  PGUINV_EDBrakeCut        = 0;

float32 PGUINV_MotTeCurve        = 0.0;
float32 PGUINV_TeRefLimited_T    = 0.0;
float32 PGUINV_TeRefLimited_B    = 0.0;
float32 PGUINV_MotTeRef          = 0.0;

Uint16  PGUINV_EDBrakeActive     = 0.0;
Uint16  PGUINV_InvActive         = 0.0;

Uint16  PGUINV_Reverser          = 0;
Uint16  PGUINV_ReverserNew       = 0;
Uint16  PGUINV_ReverserOld       = 0;
Uint16  PGUINV_ReverserCnt       = 0;

float32 PGUINV_Mot1_Speed          = 0.0;
float32 PGUINV_Mot1_SpeedAbs       = 0.0;

float32 PGUINV_Mot2_Speed          = 0.0;
float32 PGUINV_Mot2_SpeedAbs       = 0.0;

float32 PGUINV_MotTorque         = 0.0;
float32 PGUINV_AvailMotTorque    = 0.0;

float32 PGUINV_Mot1_SpeedSum       = 0.0;
float32 PGUINV_Mot1_SpeedMean      = 0.0;

float32 PGUINV_Mot2_SpeedSum       = 0.0;
float32 PGUINV_Mot2_SpeedMean      = 0.0;

Uint16  PGUINV_ControlEnable   = 0;
Uint16  PGUINV_CardSlot        = 0;

Uint16  PGUINV_FaultFlagsClear = 0;
Uint16  PGUINV_SelfTestErrClear= 0;

Uint16  PGUINV_InvTripClear    = 0;

// RMS value of AC signals
float32 IMot_U      = 0.0;
float32 IMot_W      = 0.0;
float32 IBrk        = 0.0;

//------------------------------------
// Global Variables
//------------------------------------

    //--TICK COUNTERS
Uint32  PGUINV_InvIsrTicker  = 0;        //  Inverter ISR Ticker
Uint32  PGUINV_MainIsrTicker = 0;

Uint16  PGUINV_DOCounter = 0;

Uint16  PGUINV_MotSpeedMeanCntr = 0;
float32 PGUINV_SpeedSensorDir = 1;    // Cer Motor manyetik alan y�n� di�er lokomotiflere g�re ters

Uint16  PGUINV_InvPowMeanCntr = 0;

    //--OTHERS
Uint16  PGUINV_FPGAsReset    = 0;        //  Trip Zone error clear control variable
Uint16  PGUINV_TripZoneClear = 0;

    //--TEST VARIABLES
float32 PGUINV_MotSpeedRef   = 0.0;      //
float32 PGUINV_MotTorqueRef  = 0.0;      //



// Inverter Structs Initialization Values
TORQUE          PGUINV_Torque    = TORQUE_DEFAULTS;               //  Torque reference generation struct initialization
REGEN           PGUINV_EDBraking = REGEN_DEFAULTS;                //  Regenerative braking limit (based on speed) struct initialization

RMS             PGUINV_IMotURMS      = RMS_DEFAULTS;              //  Default initalizer for the RMS object.
RMS             PGUINV_IMotWRMS      = RMS_DEFAULTS;              //  Default initalizer for the RMS object.
RMS             PGUINV_IBrkRMS       = RMS_DEFAULTS;              //  Default initalizer for the RMS object.

QSG             PGUINV_VdcQSG          = QSG_DEFAULTS;                                                                     // DC Voltage Processing module initialization
DCRC            PGUINV_DCest           = {DCRC_IN_DEFAULTS,DCRC_OUT_DEFAULTS,DCRC_VAR_DEFAULTS,DCRC_PAR_DEFAULTS};         // DC estimation module initialization

INVHS           invhs           = {0.0,0.0,1.0};                                      //  Default initalizer for Space Vector modulator input VaB & Vdc.

PGU_FDB_INV     PGUINV_InvFdb            =  {0.0,0.0,0.0,0.0,0.0};                    //  Inverter Feedback initialization
//PGU_FDB_INV     PGU_3PHInvFdbHs          =  {0.0,0.0,0.0,0.0,0.0,0.0};              //  High Speed Feedback initialization

PGUINV_CTRL_VAR     PGU_INVCTL_REG          = {0x0000};                               //  Inverter control variable initialization

SPEED           invSPEED1        = SPEED_DEFAULTS;                                    // SPEED module initialization
SPEED           invSPEED2        = SPEED_DEFAULTS;                                    // SPEED module initialization

SVGEN           invSVGEN        = SVGEN_DEFAULTS;                                     // SVPWM generation module initialization

//===========================================================================
// Local Variables Instantiation
//===========================================================================

float32 PGUINV_MainIsrStartTime        = 0.0;
float32 PGUINV_MainIsrFinishTime       = 0.0;
Uint16  PGUINV_ADCOffsetCntr           = 0;
Uint16  PGUINV_NeutralCnt_PowerOff     = 0;

Uint16  PGUINV_NeutralCnt              = 0;
Uint16  PGUINV_PoweringCnt             = 0;
Uint16  BrakingCnt                     = 0;
Uint16  PGUINV_EMGBrakeCnt             = 0;

float32 PGUINV_RMSPeriod             = 0.0;
float32 Mot1_RMSPeriod               = 0.0;
float32 Mot2_RMSPeriod               = 0.0;

Uint16  PGUINV_TivaWriteToggle       = 0;

 volatile   DIOC1_RXMSG1_REG PGUINV_DIOC1_Inputs1          = {0x0000};
 volatile   DIOC1_RXMSG2_REG PGUINV_DIOC1_Inputs1N         = {0xFFFF};

 volatile   DIOC1_RXMSG3_REG PGUINV_DIOC1_Inputs_TCPU      = {0x0000};
 volatile   DIOC1_RXMSG4_REG PGUINV_DIOC1_InputsN_TCPU     = {0xFFFF};

 volatile   DIOC2_RXMSG1_REG PGUINV_DIOC2_Inputs1          = {0x0000};
 volatile   DIOC2_RXMSG2_REG PGUINV_DIOC2_Inputs1N         = {0xFFFF};
 volatile   DIOC2_RXMSG3_REG PGUINV_DIOC2_Inputs2          = {0x0000};
 volatile   DIOC2_RXMSG4_REG PGUINV_DIOC2_Inputs2N         = {0xFFFF};

 volatile   DIOC1_TXMSG1_REG PGUINV_DIOC1_Outputs          = {0xFFFF};
 volatile   DIOC2_TXMSG1_REG PGUINV_DIOC2_Outputs          = {0xFFFF};

 volatile   TCPU_RXMSG1_REG PGUINV_TCPU_Inputs             = {0x0000};
 volatile   TCPU_RXMSG2_REG PGUINV_TCPU_DIOC_Inputs        = {0x0000};
 volatile   TCPU_RXMSG3_REG PGUINV_TCPU_Faults_TIC         = {0x0000};
 volatile   TCPU_RXMSG4_REG PGUINV_TCPU_Faults_Others      = {0x0000};
 volatile   TCPU_RXMSG5_REG PGUINV_TCPU_Fault_Action       = {0x0000};

 volatile   TCPU_TXMSG_REG PGUINV_TCPU_Outputs             = {0xFFFF};

void PGUINV_MainISRInit(void)
{
	PGUINV_ProtectionInit();
/*------------------------------------------------------------------------------
	RMS module initialization
------------------------------------------------------------------------------*/

	PGUINV_IMotURMS.Ts	= PGUINV_TS_MAINISR;
	PGUINV_IMotWRMS.Ts	= PGUINV_TS_MAINISR;
	PGUINV_IBrkRMS.Ts   = PGUINV_TS_MAINISR;

/*------------------------------------------------------------------------------
            SPEED module initialization
------------------------------------------------------------------------------*/

    invSPEED1.LineEncoder    = MOTOR_ENCODER_PULSE;
    invSPEED1.MechScaler     = 0.25/MOTOR_ENCODER_PULSE;
    invSPEED1.PolePairs      = 2.0;
    invSPEED1.wc             = 2*PI*5;
    invSPEED1.Tsample        = PGUINV_TS_MAINISR;

    invSPEED2.LineEncoder    = MOTOR_ENCODER_PULSE;
    invSPEED2.MechScaler     = 0.25/MOTOR_ENCODER_PULSE;
    invSPEED2.PolePairs      = 2.0;
    invSPEED2.wc             = 2*PI*5;
    invSPEED2.Tsample        = PGUINV_TS_MAINISR;

/*------------------------------------------------------------------------------
            DCest module initialization
------------------------------------------------------------------------------*/
    PGUINV_DCest.p.Enable      = 1;
    PGUINV_DCest.p.Tadv        = 0.75* (1.0/1600.0);
    PGUINV_DCest.p.w           = 2*PI*100;
    PGUINV_DCest.p.ThetaAdv    = PGUINV_DCest.p.w*PGUINV_DCest.p.Tadv;
    PGUINV_DCest.p.Cterm       = cos(PGUINV_DCest.p.ThetaAdv);
    PGUINV_DCest.p.Sterm       = sin(PGUINV_DCest.p.ThetaAdv);

/*------------------------------------------------------------------------------
            QSG module initialization
------------------------------------------------------------------------------*/

    PGUINV_VdcQSG.wc       = 2*CENTER_FREQUENCY;
    PGUINV_VdcQSG.Gain     = 0.25;
    PGUINV_VdcQSG.Ts_12    = (PGUINV_TS_MAINISR/12);

}


//===============================================================================
//	Main ISR
//===============================================================================
interrupt void PGUINV_MainISR(void)
{
    PGUINV_MainIsrStartTime = ((float32) EPwm4Regs.TBCTR
            / (float32) EPwm4Regs.TBPRD) * 0.5 * PGUINV_TS_MAINISR * 1000000.0; //Microsecond

    //Reset the watchdog counter
    ServiceDog();

//        IO_SET(PGUINV_DORes1)							// Start of ISR Indicator

    IO_TOGGLE(PGUINV_WDTog)

    PGUINV_MainIsrTicker++;                         // Verifying the ISR
    PGUINV_ControlTicker++;
    PGUINV_DOCounter++;

    if (PGUINV_Lifesign > 65534)
    {
        PGUINV_Lifesign = 0;
    }
    else
        PGUINV_Lifesign++;


    if (PGUINV_DOCounter > 6300)
    {
        IO_CLR(DO_ENABLE)
        PGUINV_DOCounter = 6301;
    }

    if (PGUINV_DIOC1_Inputs_TCPU.bit.Condansator_Pressure == 0)
    {
        PGUGateOFF
        FOIOGateOFF
    }

/*------------------------------------------------------------------------------
             READ Message from other CKU Card (DIOC1-,DIOC2,TCPU,PGU)
------------------------------------------------------------------------------*/

    //----------DIOC_1 to PGU----------//

    PGUINV_DIOC1_Inputs_TCPU.all       = DIOC1RXMsg.C1.uiBuffer[0].all;       // Read DIOC Inputs
    PGUINV_DIOC1_InputsN_TCPU.all      = DIOC1RXMsg.C1.uiBuffer[2].all;       // Read DIOC Inputs
    PGUINV_DIOC1_Inputs1.all           = DIOC1RXMsg.C1.uiBuffer[1].all;       // Read DIOC Inputs
    PGUINV_DIOC1_Inputs1N.all          = DIOC1RXMsg.C1.uiBuffer[3].all;       // Read DIOC Inputs

    //----------DIOC_2 to PGU----------//

    PGUINV_DIOC2_Inputs1.all          = DIOC2RXMsg.C1.uiBuffer[0].all;        // Read DIOC Inputs
    PGUINV_DIOC2_Inputs1N.all         = DIOC2RXMsg.C1.uiBuffer[2].all;        // Read DIOC Inputs
    PGUINV_DIOC2_Inputs2.all          = DIOC2RXMsg.C1.uiBuffer[1].all;        // Read DIOC Inputs
    PGUINV_DIOC2_Inputs2N.all         = DIOC2RXMsg.C1.uiBuffer[3].all;        // Read DIOC Inputs

    //----------PGUINV TO DIOC_1 ----------//

        DIOC1TXMsg.C1.uiBuffer[0].bit.bit0 = PGUINV_DIOC1_Outputs.bit.Cabin_Fan;
        DIOC1TXMsg.C1.uiBuffer[0].bit.bit1 = PGUINV_DIOC1_Outputs.bit.RSVD1;
        DIOC1TXMsg.C1.uiBuffer[0].bit.bit2 = PGUINV_DIOC1_Outputs.bit.CIFR;
        DIOC1TXMsg.C1.uiBuffer[0].bit.bit3 = PGUINV_DIOC1_Outputs.bit.RVSD2;
        DIOC1TXMsg.C1.uiBuffer[0].bit.bit4 = PGUINV_DIOC1_Outputs.bit.TRAC_OK1;
        DIOC1TXMsg.C1.uiBuffer[0].bit.bit5 = PGUINV_DIOC1_Outputs.bit.TRAC_OK2;

//        //----------PGU TO DIOC_2 ----------//
//
        DIOC2TXMsg.C1.uiBuffer[0].bit.bit0 = PGUINV_DIOC2_Outputs.bit.Motor1_OK;
        DIOC2TXMsg.C1.uiBuffer[0].bit.bit1 = PGUINV_DIOC2_Outputs.bit.Motor2_OK;
        DIOC2TXMsg.C1.uiBuffer[0].bit.bit2 = PGUINV_DIOC2_Outputs.bit.HV_Presence;
        DIOC2TXMsg.C1.uiBuffer[0].bit.bit3 = PGUINV_DIOC2_Outputs.bit.Trac_DCLink_OK;
        DIOC2TXMsg.C1.uiBuffer[0].bit.bit4 = PGUINV_DIOC2_Outputs.bit.Pantograph_Permission;
        DIOC2TXMsg.C1.uiBuffer[0].bit.bit5 = PGUINV_DIOC2_Outputs.bit.RSVD1;
//
//    //----------TCPU_TO_PGU----------//
//
      PGUINV_TCPU_Inputs.all        = TCPURXMsg.C1.uiBuffer[3].all;        // Read TCPU Inputs
//
      PGUINV_TCPU_DIOC_Inputs.all   = TCPURXMsg.C3.uiBuffer[0].all;        // Read TCPU Inputs
      PGUINV_TCPU_Faults_TIC.all    = TCPURXMsg.C3.uiBuffer[1].all;        // Read TCPU Inputs
      PGUINV_TCPU_Faults_Others.all = TCPURXMsg.C3.uiBuffer[2].all;        // Read TCPU Inputs
      PGUINV_TCPU_Fault_Action.all  = TCPURXMsg.C3.uiBuffer[3].all;        // Read TCPU Inputs

    //----------PGU_X to TCPU----------//

    TCPUTXMsg.C1.uiBuffer[0].all  = PGUINV_TCPU_Outputs.all;             // Write TCPU Outputs

//----------PGU_INV to PGU_REC ----------//

//    PGUREC_FAULT                  = PGURXMsg.C1.uiBuffer[0].all;         // Read PGU_REC Msg
//    PGUREC_TorqueLimFactor        = PGURXMsg.C1.uiBuffer[1].all;         // Read PGU_REC Msg
//    PGUINV_RecSuccessfull         = PGURXMsg.C1.uiBuffer[2].all;         // Read PGU_REC Msg
//    PGUINV_DC_Counter             = PGURXMsg.C1.uiBuffer[3].all;         // Read PGU_REC Msg
////    PGUINV_RecSuccessfull         = Success;         // Read PGU_REC Msg
////    PGUINV_DC_Counter             = DC_Counter;         // Read PGU_REC Msg
//
//    PGUTXMsg.C1.uiBuffer[0].all   = PGUINV_FLT_REG.all;                  // Write PGU_REC Msg
//    PGUTXMsg.C1.uiBuffer[1].all   = PGUINV_IMotURMS.RMS;                  // Write PGU_REC Msg
//    PGUTXMsg.C1.uiBuffer[2].all   = PGUINV_IMotWRMS.RMS;                  // Write PGU_REC Msg
//    PGUTXMsg.C1.uiBuffer[3].all   = PGUINV_IBrkRMS.RMS;                  // Write PGU_REC Msg

    ///////////////////////////////////////////S� D�zenleme///////////////////////////////////////////////////////
    //A�a��daki sat�rlar eklendi.

    PGUTXMsg.C1.uiBuffer[0].bit.bit0   = PGUINV_TCPU_Outputs.bit.MCB_TRIP;                    // Write PGU_REC Msg
    PGUTXMsg.C1.uiBuffer[0].bit.bit1   = PGUINV_TCPU_Outputs.bit.MCCAUX1_SIG;                  // Write PGU_REC Msg
    PGUTXMsg.C1.uiBuffer[0].bit.bit2   = PGUINV_TCPU_Outputs.bit.MCCAUX2_SIG;                  // Write PGU_REC Msg
    PGUTXMsg.C1.uiBuffer[0].bit.bit3   = GerilimsizAnahtarlama_INV;                                 // Write PGU_REC Msg
    PGUTXMsg.C1.uiBuffer[0].bit.bit4   = Prech1_INV;                                               // Write PGU_REC Msg
    PGUTXMsg.C1.uiBuffer[0].bit.bit5   = Prech2_INV;                                               // Write PGU_REC Msg
    PGUTXMsg.C1.uiBuffer[0].bit.bit6   = AnahtarlamaBaslat;                                    // Write PGU_REC Msg
    PGUTXMsg.C1.uiBuffer[0].bit.bit7   = PGUINV_TCPU_Outputs.bit.PCC1_SIG;
    PGUTXMsg.C1.uiBuffer[0].bit.bit8   = PGUINV_TCPU_Outputs.bit.PCC2_SIG;

     CabinTemp_Rec                = PGURXMsg.C1.uiBuffer[0].all;     // Read PGU_REC Msg
     ConvHumidity_Temp_Rec        = PGURXMsg.C1.uiBuffer[1].all;     // Read PGU_REC Msg
     ConvHumidity_Hum_Rec         = PGURXMsg.C1.uiBuffer[2].all;     // Read PGU_REC Msg
     Volt_Catenary_Rec            = PGURXMsg.C1.uiBuffer[3].all;     // Read PGU_REC Msg
     Volt_DCLink_Rec              = PGURXMsg.C2.uiBuffer[0].all;     // Read PGU_REC Msg
     RectifierTemp1_Rec           = PGURXMsg.C2.uiBuffer[1].all;     // Read PGU_REC Msg
     RectifierTemp2_Rec           = PGURXMsg.C2.uiBuffer[2].all;     // Read PGU_REC Msg
     Cur_RectInput1_Rec           = PGURXMsg.C2.uiBuffer[3].all;     // Read PGU_REC Msg
     Cur_RectInput2_Rec           = PGURXMsg.C3.uiBuffer[0].all;     // Read PGU_REC Msg
     MotorTemp1_Rec               = PGURXMsg.C3.uiBuffer[1].all;     // Read PGU_REC Msg
     MotorTemp2_Rec               = PGURXMsg.C3.uiBuffer[2].all;     // Read PGU_REC Msg
     GearTemp_Rec                 = PGURXMsg.C3.uiBuffer[3].all;     // Read PGU_REC Msg

     CabinTemp2_Rec               = PGURXMsg.C4.uiBuffer[0].all;     // Read PGU_REC Msg
     CoolingFlow_Flow_Rec         = PGURXMsg.C4.uiBuffer[1].all;     // Read PGU_REC Msg
     CoolingFlow_Temp_Rec         = PGURXMsg.C4.uiBuffer[2].all;     // Read PGU_REC Msg
     Rectifier2Temp1_Rec          = PGURXMsg.C4.uiBuffer[3].all;     // Read PGU_REC Msg
     Rectifier2Temp2_Rec          = PGURXMsg.C5.uiBuffer[0].all;     // Read PGU_REC Msg
     MotorTemp3_Rec               = PGURXMsg.C5.uiBuffer[1].all;     // Read PGU_REC Msg
     MotorTemp4_Rec               = PGURXMsg.C5.uiBuffer[2].all;     // Read PGU_REC Msg
     GearTemp2_Rec                = PGURXMsg.C5.uiBuffer[3].all;     // Read PGU_REC Msg

     Prech1_Basarili              = PGURXMsg.C6.uiBuffer[0].bit.bit0;
     Prech1_Hatali                = PGURXMsg.C6.uiBuffer[0].bit.bit1;
     Prech2_Basarili              = PGURXMsg.C6.uiBuffer[0].bit.bit2;
     Prech2_Hatali                = PGURXMsg.C6.uiBuffer[0].bit.bit3;


     //////////////////////////////////////////////////////////////////////////////////////////////////////////////

     if(Prech1_INV == 1 || Prech2_INV == 1)
     {
         PGUINV_ReverserNew = 2;
     }
     else
     {
         PGUINV_ReverserNew = 3;
         PGUINV_MasterContrStat=3;
     }


/*------------------------------------------------------------------------------
             Identfy CKU From TCPU & DIOC Input
             ID PIN comes to DIOC1 Card is connect to TCPU via backplane
------------------------------------------------------------------------------*/
     ///////////////////////////////////////////S� D�zenleme///////////////////////////////////////////////////////
     //A�a��daki sat�r eklendi.
//    if (PGUINV_TCPU_DIOC_Inputs.bit.ID5 == 0
//            && PGUINV_DIOC1_Inputs_TCPU.bit.ID5 == 0
//            && PGUINV_DIOC1_InputsN_TCPU.bit.N_ID5 == 1)
//    {
//        PGUINV_CKU1 = 1;
//        PGUINV_CKU2 = 0;
//    }
//
//    if (PGUINV_TCPU_DIOC_Inputs.bit.ID5 == 1
//            && PGUINV_DIOC1_Inputs_TCPU.bit.ID5 == 1
//            && PGUINV_DIOC1_InputsN_TCPU.bit.N_ID5 == 0)
//    {
//        PGUINV_CKU2 = 1;
//        PGUINV_CKU1 = 0;
//    }
         if (PGUINV_TCPU_DIOC_Inputs.bit.ID3 == 1
                 && PGUINV_DIOC1_Inputs_TCPU.bit.ID3 == 1
                 && PGUINV_DIOC1_InputsN_TCPU.bit.N_ID3 == 0)
         {
             PGUINV_CKU1 = 1;
             PGUINV_CKU2 = 0;
         }

         if (PGUINV_TCPU_DIOC_Inputs.bit.ID3 == 0
                 && PGUINV_DIOC1_Inputs_TCPU.bit.ID3 == 0
                 && PGUINV_DIOC1_InputsN_TCPU.bit.N_ID3 == 1)
         {
             PGUINV_CKU2 = 1;
             PGUINV_CKU1 = 0;
         }


    EthernetTest();

//    PGUINV_ReadMVBData();
//
//    PGUINV_WriteMVBData();

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////

    if (PGUINV_ControlEnable == 1)
    {
        PGUINV_MotSpeedMeanCntr++;                   // Motor Speed Mean Counter

        if(PGUINV_FOIOGateOnFlag == 1)
        {
            PGUINV_FOIOGateOnFlag = 0;
            FOIOGateON
        }

        PGUINV_ADC_CHANNEL_READ(PGUINV_Measure)
        PGUINV_ADC_MEASUREMENT(PGUINV_Measure)      // Read ADC variables

//	    INV_FDB_MACRO(PGU_3PHInvFdbHs,PGUINV_Measure)

    /*------------------------------------------------------------------------------
                 Motor1 & Motor2 Speed Read
    ------------------------------------------------------------------------------*/

 // SPEED read (MOTOR1)
    SPEED_MACRO(1,invSPEED1)
    M1SpeedRPM    =  PGUINV_SpeedSensorDir * invSPEED1.ElecSpeed;
    M1ElecSpeed   =  invSPEED1.SpeedRPM;

    PGUINV_Mot1_SpeedAbs   = fabs(invSPEED1.SpeedRPM);
    PGUINV_Mot1_Speed      = PGUINV_SpeedSensorDir * invSPEED1.SpeedRPM;

 // SPEED read (MOTOR2)
    SPEED_MACRO(2,invSPEED2)
    M2SpeedRPM      =  PGUINV_SpeedSensorDir * invSPEED2.ElecSpeed;
    M2ElecSpeed    =  invSPEED2.SpeedRPM;

    PGUINV_Mot2_SpeedAbs   = fabs(invSPEED2.SpeedRPM);
    PGUINV_Mot2_Speed      = PGUINV_SpeedSensorDir * invSPEED2.SpeedRPM;

// Motor Speed Mean (MOTOR1)
    PGUINV_Mot1_SpeedSum  += PGUINV_Mot1_Speed;

    if(PGUINV_MotSpeedMeanCntr >= 128)  // 20ms ortalama alma
    {
        PGUINV_MotSpeedMeanCntr = 0;

        PGUINV_Mot1_SpeedMean    = PGUINV_Mot1_SpeedSum * (1.0/128.0);
        PGUINV_Mot1_SpeedSum     = 0.0;
    }

// Motor Speed Mean (MOTOR2)
    PGUINV_Mot2_SpeedSum  += PGUINV_Mot2_Speed;

    if(PGUINV_MotSpeedMeanCntr >= 128)  // 20ms ortalama alma
    {
       PGUINV_MotSpeedMeanCntr = 0;

       PGUINV_Mot2_SpeedMean    = PGUINV_Mot2_SpeedSum * (1.0/128.0);
       PGUINV_Mot2_SpeedSum     = 0.0;
    }

    AverageElecSpeed= (invSPEED1.ElecSpeed + invSPEED2.ElecSpeed )*(1.0/MOTORN);
    AverageSpeedRPM     = AverageElecSpeed*30.0/(p*PI);

    if(ABS(AverageSpeedRPM)<200.0)
        MxSpeedFc = 1.0 + ABS(AverageSpeedRPM)*0.02;
    else
        MxSpeedFc = 5.0;

    PGUINV_InvFdb.ElecSpeed    =  PGUINV_Torque.Dir * AverageElecSpeed;
    PGUINV_EDBraking.SpeedRPM  =  AverageSpeedRPM;


    /*------------------------------------------------------------------------------
                 RMS current of Motor & Break resistor
    ------------------------------------------------------------------------------*/

     Mot1_RMSPeriod = sat(3*fabs((2*PI)/(invSPEED1.ElecSpeed)) , 0.5 ,0.001); //0.5s ve 1ms aras�nda hesaplanmas� i�in
     Mot2_RMSPeriod = sat(3*fabs((2*PI)/(invSPEED2.ElecSpeed)) , 0.5 ,0.001); //0.5s ve 1ms aras�nda hesaplanmas� i�in

     PGUINV_RMSPeriod    = 0.1;

     PGUINV_IMotURMS.In	    = PGUINV_Measure.Result.Cur_MotInputU;
     PGUINV_IMotURMS.Period   = PGUINV_RMSPeriod;
     RMS_MACRO(PGUINV_IMotURMS)

     PGUINV_IMotWRMS.In       = PGUINV_Measure.Result.Cur_MotInputW;
     PGUINV_IMotWRMS.Period   = PGUINV_RMSPeriod;
     RMS_MACRO(PGUINV_IMotWRMS)

     PGUINV_IBrkRMS.In       = PGUINV_Measure.Result.Cur_BRK;
     PGUINV_IBrkRMS.Period   = PGUINV_RMSPeriod;
     RMS_MACRO(PGUINV_IBrkRMS)

     IMot_U=PGUINV_IMotURMS.RMS ;               // RMS value of motor current - Phase U
     IMot_W=PGUINV_IMotWRMS.RMS ;               // RMS value of motor current - Phase W
     IBrk=PGUINV_IBrkRMS.RMS ;                  // RMS value of break resistor- Break Resistor


// =================================== DC Voltage Processing =========================================

     //  Connect inputs of the VdcQSG module and call the QSG macro
     PGUINV_VdcQSG.In               = PGUINV_Measure.Result.Volt_DCLink - PGUINV_Vdc_ref;
     PGUINV_VdcQSG.wc               = 2*PGUINV_wLPF;       // 2*CENTER_FREQUENCY
     QSG_MACRO(PGUINV_VdcQSG)

     PGUINV_Dc.Vdc_BSF      = PGUINV_Measure.Result.Volt_DCLink - PGUINV_VdcQSG.Alpha;

     PGUINV_DCest.i.Udc         = PGUINV_Measure.Result.Volt_DCLink;
     PGUINV_DCest.i.Ur_alpha    = PGUINV_VdcQSG.Alpha;
     PGUINV_DCest.i.Ur_beta     = PGUINV_VdcQSG.Beta;
     PGUINV_DCest.i.we          = 2*PGUINV_wLPF;
     DCMACRO(PGUINV_DCest)

     PGUINV_Dc.Vdc_Est          = PGUINV_DCest.o.UdcEst;
//
// ========================================= Control Loops =========================================

    if(PGUINV_ControlTicker==1)
    {
        PGUINV_TivaLifeCheck(43);
    }

    if(PGUINV_ControlTicker==2)
    {
                PGUINV_CommandRead();
                PGUINV_CommandProcess();
    }


    if(PGUINV_ControlTicker==3)
    {
        PGUINV_Protection();

    }

    if(((float32)EPwm3Regs.TBCTR < (0.09)*(float32)EPwm3Regs.TBPRD && EPwm3Regs.TBSTS.bit.CTRDIR==1)
            ||((float32)EPwm3Regs.TBCTR>(0.91)*(float32)EPwm3Regs.TBPRD && EPwm3Regs.TBSTS.bit.CTRDIR==0))
    {
        Inv3_ISR();
        PGUINV_ControlTicker = 0;
    }

// ===================================== Duty Update =====================================

    PGUINV_VdcUpdateScale = (invhs.Vdc /(PGUINV_Dc.Vdc_Est));
    PGUINV_VdcUpdateScale = sat(PGUINV_VdcUpdateScale  , 1.020 ,0.980);

//  if (PGUINV_MasterContrStat==2)
//    {
        if(PGUINV_BufferIlk<1024)
           {
            PGUINV_BufferIlk++;

//            FillAnalogBuffer(Pll_QSG_Osc.Sine, AnaBuff.buff14, 14);
//            FillAnalogBuffer(Volt_LabGiris,   AnaBuff.buff15, 15);
           }


    FillAnalogBuffer(PGUINV_Measure.Result.Cur_MotInputU,   AnaBuff.buff1, 1);
    FillAnalogBuffer(PGUINV_Measure.Result.Cur_MotInputW,   AnaBuff.buff2, 2);
    FillAnalogBuffer(PGUINV_Measure.Result.Cur_BRK,         AnaBuff.buff3, 3);
    FillAnalogBuffer(PGUINV_Measure.Result.Volt_DCLink,     AnaBuff.buff4, 4);

    if(AnahtarlamaBaslat== 1)
    {
        if (tripcounter == 0)
        {
            PGUINV_InvTripClear = 1;
            tripcounter =1;
        }
    }
    else
    {
        PGUINV_InvTripClear = 0;
        tripcounter = 0;
    }

    if(AnahtarlamaBaslat == 1 && MotorVFEnable == 1)
    {
        Success                   = 1;
        SpeedRef                  = EthRxData[6];
        PGUINV_MasterContrStat    = 2;
        PGUINV_RecSuccessfull     = 1;
     }
     else
     {
        Success                   = 0;
        SpeedRef                  = 0;
        PGUINV_MasterContrStat    = 3;
        PGUINV_RecSuccessfull     = 0;
     }


//    if(AnahtarlamaBaslat == 1)
//    {
//     if(PGURXMsg.C6.uiBuffer[0].bit.bit4 == 1)
//     {
//        PGUINV_RecSuccessfull     = 6;
//        if (MotorVFEnable)
//         {
////             PGUINV_RecSuccessfull     = 6;
//             Success                   = 1;
//             PGUINV_MasterContrStat    = 2;
//             SpeedRef                  = EthRxData[6];
//         }
//         else
//         {
////             PGUINV_RecSuccessfull     = 0;
//             Success                   = 0;
//             PGUINV_MasterContrStat    = 3;
//             SpeedRef                  = 0;
//         }
//     }
//     else
//         PGUINV_RecSuccessfull     = 0;
//    }
//    else
//    {
//        PGUINV_RecSuccessfull     = 0;
//        Success                   = 0;
//        PGUINV_MasterContrStat    = 3;
//        SpeedRef                  = 0;
//    }


    if(AnahtarlamaBaslat != 1)
    {

        if(GerilimsizAnahtarlama_INV==1 && !(PGUINV_TCPU_Inputs.bit.MC1_NO) && !(PGUINV_TCPU_Inputs.bit.MC2_NO) && !(PGUINV_DIOC1_Inputs_TCPU.bit.MCAUX_STA1 &&!(PGUINV_DIOC1_Inputs_TCPU.bit.MCAUX_STA2)))
            {
                PGUInvGateON
                FOIOGateON
            }
        else
            {
                FOIOGateOFF
                PGUGateOFF
            }
    }

    // SVPWM generation
    invSVGEN.Usn_alpha = invhs.Usn_alpha* PGUINV_VdcUpdateScale;
    invSVGEN.Usn_beta  = invhs.Usn_beta * PGUINV_VdcUpdateScale;
    SVGEN_MACRO(invSVGEN)

    // PWM generation
    // Inverter Output Generation
    PGUINV_InvPWM1.MfuncC = CLAMP(invSVGEN.Ta,DMin_Inv,DMax_Inv);
    PGUINV_InvPWM2.MfuncC = CLAMP(invSVGEN.Tb,DMin_Inv,DMax_Inv);
    PGUINV_InvPWM3.MfuncC = CLAMP(invSVGEN.Tc,DMin_Inv,DMax_Inv);

    if(GerilimsizAnahtarlama_INV==1)
    {
        PGUINV_InvPWM1.MfuncC = 0.0;
        PGUINV_InvPWM2.MfuncC = 0.0;
        PGUINV_InvPWM3.MfuncC = 0.0;
    }

    PWMDutyUpdate(PGUINV_IPWMU,PGUINV_InvPWM1.MfuncC);
    PWMDutyUpdate(PGUINV_IPWMV,PGUINV_InvPWM2.MfuncC);
    PWMDutyUpdate(PGUINV_IPWMW,PGUINV_InvPWM3.MfuncC);

    // Break Output Generation

    if(DCBaraBosalt && !(PGUINV_TCPU_Inputs.bit.MC1_NO) && !(PGUINV_TCPU_Inputs.bit.MC2_NO) && !(PGUINV_DIOC1_Inputs_TCPU.bit.MCAUX_STA1 &&!(PGUINV_DIOC1_Inputs_TCPU.bit.MCAUX_STA2)))
    {
        PGUBrkGateON
        PGUINV_BrkPWM.MfuncC      = CLAMP(BrakeDuty,DMin_Inv,DMax_Inv);
        PWMDutyUpdate(PGUINV_BRKPWM,PGUINV_BrkPWM.MfuncC);
    }
    else
    {
        PGUBrkGateOFF
    }

//    PGUINV_BrkPWM.MfuncC      =  CLAMP(PGUINV_BrkPWM.MfuncC*PGUINV_VdcUpdateScale,INV_DUTY_MIN,INV_DUTY_MAX);
//    PWMDutyUpdate(PGUINV_BRKPWM,PGUINV_BrkPWM.MfuncC);

	}
	else
	{
		if(PGUINV_ADCOffsetCntr < PGUINV_ADCOffsetPRD)
		{
            PGUINV_ADC_CHANNEL_READ(PGUINV_Measure)

		    PGUINV_ADC_OFFSET_COMP(PGUINV_Measure,0.0)	   // ADC offset compensation macro
		    PGUINV_ADCOffsetCntr++;					       // Increase sample counter
			PGUINV_ControlEnable = 0;
		}
		else
		{
			if(PGUINV_ADCOffsetCntr == PGUINV_ADCOffsetPRD)
			{
				PGUINV_ControlEnable = 1;

				PGUINV_ADC_OFFSET_COMP(PGUINV_Measure,(1.0/PGUINV_ADCOffsetPRD))
				PGUINV_ADCOffsetCntr = 1+PGUINV_ADCOffsetPRD;

				Uint16 i = 0;
				for(i=0 ;i<PGUINV_ADCChNUM;i++)
				{
					if(fabs(*((&PGUINV_Measure.Offset.Cur_MotInputU)+ i))>(*((&PGUINV_ADCOffsets.Cur_MotInputU)+ i)))
					{
					    PGUINV_ADCErrFlags.all |= (1<<i);
					}
				}

				if(PGUINV_ADCErrFlags.all > 0)
				{
				    PGUINV_FLT_REG.bit.ADC = 1 ;
				}
			}
		}
	}

 	 if(EPwm4Regs.TBSTS.bit.CTRDIR==0)
 	 {
 	    PGUINV_MainIsrFinishTime = (1.0+(float32)EPwm4Regs.TBCTR /(float32)EPwm4Regs.TBPRD)* 0.5 *PGUINV_TS_MAINISR * 1000000.0; //Microsecond
 	 }
 	 else
 	 {
 	    PGUINV_MainIsrFinishTime = ((float32)EPwm4Regs.TBCTR /(float32)EPwm4Regs.TBPRD)* 0.5 *PGUINV_TS_MAINISR * 1000000.0; //Microsecond
 	 }

// 	IO_CLR(PGUINV_DORes1)							// End of ISR Indicator

 	PGUINV_MainIsrTotalTime = PGUINV_MainIsrFinishTime - PGUINV_MainIsrStartTime;

	 // Reinitialize for next ADC sequence
  	 AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;         // Reset SEQ1
   	 AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;       // Clear INT SEQ1 bit
  	 PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;   // Acknowledge interrupt to PIE

}

void PGUINV_ProtectionInit(void)
{

    PGUINV_TORQLIM_REG.bit.TOTAL        = 1;
    PGUINV_TORQLIM_REG.bit.INPOW        = 1;
    PGUINV_TORQLIM_REG.bit.TEMP         = 1;
    PGUINV_TORQLIM_REG.bit.SUPPLYH      = 1;
    PGUINV_TORQLIM_REG.bit.MOTSPEED1    = 1;
    PGUINV_TORQLIM_REG.bit.MOTSPEED2    = 1;

    /*--------------------------------------------------------------------------
        Hardware_Protection module initialization
    ---------------------------------------------------------------------------*/

	PGUINV_HWProtLevels.MOCErrVoltage        = 175.0;   // Hardware Fault Limit of the Motor Over Current
	PGUINV_HWProtLevels.VDCErrVoltage        = 100.0;   // Hardware Fault Limit of the DC Link Maximum Voltage
	PGUINV_HWProtLevels.BRKErrVoltage        = 50.0;    // Hardware Fault Limit of the DC Link Maximum Voltage

	/*--------------------------------------------------------------------------
		Software_Protection module initialization
	---------------------------------------------------------------------------*/

    //  Converter Check
    PGUINV_SWProtErrLimits.InvOL        = 150000.0;     //     Inverter  Over Load (kVA) Error Limit
    PGUINV_SWProtErrLimits.VdcOV        = 2100.0;       //     DC voltage Over Error Limit
    PGUINV_SWProtErrLimits.VdcLV        = 50.0;         //     DC voltage Low Error Limit
    PGUINV_SWProtErrLimits.MotOC_U      = 125.0;        //     Motor over current Error Limit Phase U
    PGUINV_SWProtErrLimits.MotOC_W      = 125.0;        //     Motor over current Error Limit Phase W
    PGUINV_SWProtErrLimits.Ibrk_OC      = 20.0;         //     Motor over current Error Limit Break
    PGUINV_SWProtErrLimits.Mot1_Speed   = 3500.0;       //     Motor-1 Speed Error Limit
    PGUINV_SWProtErrLimits.Mot2_Speed   = 3500.0;       //     Motor-2 Speed Error Limit



	PGUINV_SWProtErrTime.InvOL          = (Uint16)(100.0 / (PGUINV_TS_SW*1000));
	PGUINV_SWProtErrTime.VdcOV          = (Uint16)(50.0  / (PGUINV_TS_SW*1000));
	PGUINV_SWProtErrTime.VdcLV          = (Uint16)(100.0 / (PGUINV_TS_SW*1000));
	PGUINV_SWProtErrTime.MotOC_U        = (Uint16)(200.0 / (PGUINV_TS_SW*1000));
	PGUINV_SWProtErrTime.MotOC_W        = (Uint16)(200.0 / (PGUINV_TS_SW*1000));
    PGUINV_SWProtErrTime.Ibrk_OC        = (Uint16)(200.0 / (PGUINV_TS_SW*1000));
	PGUINV_SWProtErrTime.Mot1_Speed     = (Uint16)(100.0 / (PGUINV_TS_SW*1000));
    PGUINV_SWProtErrTime.Mot2_Speed     = (Uint16)(100.0 / (PGUINV_TS_SW*1000));


	PGUINV_SWProtWarnLimits.InvOL        = 1400.0;
	PGUINV_SWProtWarnLimits.VdcOV        = 1950.0;
	PGUINV_SWProtWarnLimits.VdcLV        = 1200.0;
	PGUINV_SWProtWarnLimits.MotOC_U      = 500.0;
	PGUINV_SWProtWarnLimits.MotOC_W      = 500.0;
    PGUINV_SWProtWarnLimits.Ibrk_OC      = 500.0;
	PGUINV_SWProtWarnLimits.Mot1_Speed   = 3200.0;
    PGUINV_SWProtWarnLimits.Mot2_Speed   = 3200.0;


    //  Temperature & Cooling Check

    PGUINV_TempErrLimits_CKU1.InverterTemp1          = 85.0;
    PGUINV_TempErrLimits_CKU1.InverterTemp2          = 85.0;
    PGUINV_TempErrLimits_CKU1.Cooling_Temp           = 85.0;
    PGUINV_TempErrLimits_CKU1.Cooling_Press          = 4.0;
    PGUINV_TempErrLimits_CKU1.MotorTemp1             = 300.0;
    PGUINV_TempErrLimits_CKU1.MotorTemp2             = 300.0;
    PGUINV_TempErrLimits_CKU1.MotorTemp3             = 3000.0;
    PGUINV_TempErrLimits_CKU1.MotorTempBearing       = 300.0;

    PGUINV_TempWarnLimits_CKU1.InverterTemp1         = 75.0;
    PGUINV_TempWarnLimits_CKU1.InverterTemp2         = 75.0;
    PGUINV_TempWarnLimits_CKU1.Cooling_Temp          = 75.0;
    PGUINV_TempWarnLimits_CKU1.Cooling_Press         = 3.0;
    PGUINV_TempWarnLimits_CKU1.MotorTemp1            = 140.0;
    PGUINV_TempWarnLimits_CKU1.MotorTemp2            = 140.0;
    PGUINV_TempWarnLimits_CKU1.MotorTemp3            = 140.0;
    PGUINV_TempWarnLimits_CKU1.MotorTempBearing      = 110.0;


    PGUINV_TempErrLimits_CKU2.InverterTemp1          = 85.0;
    PGUINV_TempErrLimits_CKU2.InverterTemp2          = 85.0;
    PGUINV_TempErrLimits_CKU2.MotorTemp1             = 300.0;
    PGUINV_TempErrLimits_CKU2.MotorTemp2             = 300.0;
    PGUINV_TempErrLimits_CKU2.MotorTemp3             = 3000.0;
    PGUINV_TempErrLimits_CKU2.MotorTempBearing       = 300.0;

    PGUINV_TempWarnLimits_CKU2.InverterTemp1         = 75.0;
    PGUINV_TempWarnLimits_CKU2.InverterTemp2         = 75.0;
    PGUINV_TempWarnLimits_CKU2.MotorTemp1            = 140.0;
    PGUINV_TempWarnLimits_CKU2.MotorTemp2            = 140.0;
    PGUINV_TempWarnLimits_CKU2.MotorTemp3            = 140.0;
    PGUINV_TempWarnLimits_CKU2.MotorTempBearing      = 110.0;


    PGUINV_FLT_REG.all			        = 0x0000;
//	STestErrFlags.all	                = 0x0000;
	PGUINV_ADCErrFlags.all		        = 0x0000;
	PGUINV_SWProtErrFlags.all	        = 0x0000;
	PGUINV_TempErrFlags_CKU1.all	    = 0x0000;
    PGUINV_TempErrFlags_CKU2.all        = 0x0000;


	int ind;
    for(ind=0;ind<16;ind++)         // DualPort Ram Ar�za b�lgelerini temizleme
    {
        Faults[ind].all = 0;
    }
}

// Protection Routine
void PGUINV_Protection(void)
{
	// ====================================Protection==========================================


    PGUINV_SWProtFdbs.InvOutPow        = InvPowMean;
    PGUINV_SWProtFdbs.Vdc              = PGUINV_Measure.Result.Volt_DCLink;
    PGUINV_SWProtFdbs.MotCur_U         = PGUINV_IMotURMS.RMS;
    PGUINV_SWProtFdbs.MotCur_W         = PGUINV_IMotWRMS.RMS;
    PGUINV_SWProtFdbs.BrkCur           = PGUINV_Measure.Result.Cur_BRK;
    PGUINV_SWProtFdbs.Mot1_Speed       = PGUINV_Mot1_SpeedAbs;
    PGUINV_SWProtFdbs.Mot2_Speed       = PGUINV_Mot2_SpeedAbs;

//    PGUINV_SWProtErrLimits.VdcLV       = Supply.Rms * (1.414*0.75);

// Analog protection
	PGUINV_SWProtection(PGUINV_SWProtFdbs, 	PGUINV_SWProtWarnLimits,	PGUINV_SWProtErrLimits, &PGUINV_SWProtWarnFlags,	&PGUINV_SWProtErrFlags, &PGUINV_SWProtErrTime , &PGUINV_SWProtErrCount);

	if (PGUINV_SWProtErrFlags.all > 0) //  if (PGU_SWProtErrFlags.all > 0  )
	{
	    PGUINV_FLT_REG.bit.SWPROT   = 1; 	// Software fault
	}

// Temperature protection

    if (PGUINV_CKU1 == 1  &&  PGUINV_CKU2 == 0 )   // NOT= DEGRADED MODA ALINACAK
        {
            PGUINV_TemperatureProtection_CKU1(PGUINV_TemperatureLPF_CKU1,   PGUINV_TempWarnLimits_CKU1,   PGUINV_TempErrLimits_CKU1, &PGUINV_TempWarnFlags_CKU1, &PGUINV_TempErrFlags_CKU1);

            if (PGUINV_TempErrFlags_CKU1.all > 0)   // NOT= DEGRADED MODA ALINACAK
            {
                PGUINV_FLT_REG.bit.TEMP   = 1; 	// Temperature fault
            }
        }

    if (PGUINV_CKU2 == 1 &&  PGUINV_CKU1 == 0)   // NOT= DEGRADED MODA ALINACAK
        {
            PGUINV_TemperatureProtection_CKU2(PGUINV_TemperatureLPF_CKU2,   PGUINV_TempWarnLimits_CKU2,   PGUINV_TempErrLimits_CKU2, &PGUINV_TempWarnFlags_CKU2, &PGUINV_TempErrFlags_CKU2);

            if (PGUINV_TempErrFlags_CKU2.all > 0)   // NOT= DEGRADED MODA ALINACAK
            {
                PGUINV_FLT_REG.bit.TEMP   = 1;     // Temperature fault
            }
        }

//// Self test error
//	if (STestErrFlags.all > 0)
//	{
//	    PGUINV_FLT_REG.bit.STEST  = 1; 	// Self Test fault
//	}

// Hardware fault
	if((!IO_READ(PGUINV_TZ1GPIO))||(!IO_READ(PGUINV_TZ2GPIO)))   //HW hata olu�ursa
	{
	    PGUINV_FLT_REG.bit.HWPROT  = 1; 	// Hardware fault
	}


	if (PGUINV_FLT_REG.all > 0)
	{
	    PGU_INVCTL_REG.bit.Enable	 = 0;
//        PRECHCTL_REG.bit.STATUS  = 0;           // PreCharge ba�lang�� durumunda

//        PGUGateOFF
//		FOIOGateOFF

		if( PGU_INVCTL_REG.bit.CtrlState == 1)
		{
		    PGU_INVCTL_REG.bit.CtrlState      = 2;    // �al��ma sonras�nda hata meydana geldi
		    PGUINV_CTL_REG.bit.STATE 		= 12;	  // Inverter koruma hata verdi
		}
		else if ( PGU_INVCTL_REG.bit.CtrlState == 0)
		{
		    PGU_INVCTL_REG.bit.CtrlState      = 3;	 // �al��ma �ncesinde hata var
		}
	}
}

// Command Process Routine    INVCTL_REG
void PGUINV_CommandProcess(void)
{

//----------    PGUINV_ERTMSBrake Check     ---------------//  // Aksiyon TCPU 'da al�nmayacaksa aktif edilecek

//   if(PGUINV_TeRefCAN != 0.0)FOIO_CANRXMsg
//   {
//       if(PGUINV_ERTMSBrake ==1)              // ERTMS Break Active  = 1
//       {
//           PGUINV_TeRefCAN = 0.0;
//           PGUGateOFF
//           FOIOGateOFF
//       }
//       else                                 // ERTMS Break Passive  = 0
//       {
//           PGUINV_TeRefCAN = ((fabs(PGUINV_TeRefCAN) - 400.0)/3600.0)*4000.0;    // 400-4000 Nm aras� referans 0-4000 Nm aras�na scale edildi.
//
//       }
//   }


//---------- 	PGUINV_TractInh Check   	 ---------------//   // Aksiyon TCPU 'da al�nmayacaksa aktif edilecek
//	if(PGUINV_TeRefCAN != 0.0)
//	{
//		if(PGUINV_TractInh==1)              // Traction Inhibit Passive  = 1
//		{
//
//            PGUINV_TeRefCAN = ((fabs(PGUINV_TeRefCAN) - 400.0)/3600.0)*4000.0;    // 400-4000 Nm aras� referans 0-4000 Nm aras�na scale edildi.
//
//		}
//		else                               // Traction Inhibit Active  = 0
//		{
//            PGUINV_TeRefCAN = 0.0;
//            PGUGateOFF
//            FOIOGateOFF
//		}
//	}

//---------- 	EDB_Cut Check   	 ---------------//      // Aksiyon TCPU 'da al�nmayacaksa aktif edilecek
	if(PGUINV_EDBrakeCut == 1)
	{
		if(PGUINV_MasterContr.MAIN_HAND.bit.BRAKING==1 || PGUINV_MasterContr.MAIN_HAND.bit.EMG_BRAKE==1)
		{
			PGUINV_TeRefCAN = 0.0;
		}
	}

	PGUINV_MasterContr.TORQUEREF = fabs(PGUINV_TeRefCAN*(1/4000.0));


// ------------------------------------------------------------------------------
//  Control start command check (Duzeltilecek)
// ------------------------------------- -----------------------------------------

    if (PGUINV_FLT_REG.all == 0 && PGUINV_RecSuccessfull == 1 )
    {
        PGU_INVCTL_REG.bit.CtrlState = 1;
    }


//----------    Converter ON - OFF Routine       ---------------//

    if(PGUINV_MasterContr.STA.bit.POWER_OFF==1)                    // N�tr pozisyonda beklenildi ve reverser y�n de�i�tirdi.
    {
        PGUINV_CTL_REG.bit.POWER   = 0;                      // Anahtarlama durdurma sinyali uyguland�
//        IO_CLR(PGUINV_TractionON)
    }


    if(PGUINV_MasterContr.REV_SW.bit.FORWARD==1)                   // Hareket kolu ileri y�nde ise
    {
        PGUINV_CTL_REG.bit.ON = 1;                           // Konvert�r devreye alma sinyali uyguland�

        if (PGUINV_MasterContr.ENABLE.bit.NEUTRAL==1)              // Cer Kolu N�trde ise
        {
            PGUINV_Torque.Ref = 0.0;                       // �eki� Referans� s�f�rland�.
            PGUINV_CTL_REG.bit.POWER  = 0;
        }

        else if(PGUINV_MasterContr.ENABLE.bit.POWERING==1)         // Cer Kolu G��te ise
        {
            PGUINV_CTL_REG.bit.POWER   = 1;                  // Anahtarlama ba�latma sinyali uyguland�
            PGUINV_Torque.Ref = PGUINV_MasterContr.TORQUEREF;
        }
        else if (PGUINV_MasterContr.ENABLE.bit.BRAKING==1 || PGUINV_MasterContr.ENABLE.bit.EMG_BRAKE==1)          // Cer Kolu Frende ise
        {
            PGUINV_CTL_REG.bit.POWER   = 1;                  // Anahtarlama ba�latma sinyali uyguland�

            if(PGUINV_EDBraking.SpeedRPM > PGUINV_EDBraking.SpeedRPMLim2)         // Rejeneratif fren s�n�rland�rma gerekli mi?
            {
                PGUINV_Torque.Ref  = -PGUINV_MasterContr.TORQUEREF;
            }
            else if(PGUINV_EDBraking.SpeedRPM > PGUINV_EDBraking.SpeedRPMLim1)
            {
                PGUINV_EDBraking.LimFactor   = (PGUINV_EDBraking.SpeedRPM - PGUINV_EDBraking.SpeedRPMLim1)/(PGUINV_EDBraking.SpeedRPMLim2 - PGUINV_EDBraking.SpeedRPMLim1);
                PGUINV_Torque.Ref          = -PGUINV_MasterContr.TORQUEREF * PGUINV_EDBraking.LimFactor; //
            }
            else
            {
                PGUINV_Torque.Ref = 0.0;                               // Referans s�f�rland�.
            }
        }
    }
    else if(PGUINV_MasterContr.REV_SW.bit.REVERSE==1)                          // Hareket kolu geri y�nde ise
    {
        PGUINV_CTL_REG.bit.ON = 1;                                       // Konvert�r devreye alma sinyali uyguland�

        if (PGUINV_MasterContr.ENABLE.bit.NEUTRAL==1)
        {
            PGUINV_Torque.Ref = 0.0;                                   // Referans s�f�rland�.
        }
        else if(PGUINV_MasterContr.ENABLE.bit.POWERING==1)
        {
            PGUINV_CTL_REG.bit.POWER     = 1;                            // Anahtarlama ba�latma sinyali uyguland�
            PGUINV_Torque.Ref          = -PGUINV_MasterContr.TORQUEREF;
        }
        else if (PGUINV_MasterContr.ENABLE.bit.BRAKING==1 || PGUINV_MasterContr.ENABLE.bit.EMG_BRAKE==1)
        {
            PGUINV_CTL_REG.bit.POWER   = 1;                            // Anahtarlama ba�latma sinyali uyguland�

            if(PGUINV_EDBraking.SpeedRPM < -PGUINV_EDBraking.SpeedRPMLim2)            // Rejeneratif fren s�n�rland�rma gerekli mi
            {
                PGUINV_Torque.Ref = PGUINV_MasterContr.TORQUEREF;
            }
            else if(PGUINV_EDBraking.SpeedRPM < -PGUINV_EDBraking.SpeedRPMLim1)
            {
                PGUINV_EDBraking.LimFactor   = (-PGUINV_EDBraking.SpeedRPM - PGUINV_EDBraking.SpeedRPMLim1)/(PGUINV_EDBraking.SpeedRPMLim2 - PGUINV_EDBraking.SpeedRPMLim1);
                PGUINV_Torque.Ref          = PGUINV_MasterContr.TORQUEREF * PGUINV_EDBraking.LimFactor;  //
            }
            else
            {
                PGUINV_Torque.Ref = 0.0;   // �eki� referans� s�f�rland�.
            }
        }
    }
    else                                    // Hareket kolu ba�lang�� ya da kapal� konumunda ise
    {
        PGUINV_CTL_REG.bit.ON      = 0;      // Konvert�r devreden ��karma sinyali uyguland�
        PGUINV_CTL_REG.bit.POWER   = 0;      // Anahtarlama durdurma sinyali uyguland�
        PGUINV_Torque.Ref        = 0.0;    // �eki� referans� s�f�rland�.
    }
//----------    Traction Reference Limiting    ---------------//

    PGUINV_Torque.TotalLimFactor =       (PGUINV_Torque.SpeedLimFactor1+PGUINV_Torque.SpeedLimFactor2)/2   * \
                                         PGUINV_Torque.TempLimFactor                                       * \
                                         PGUINV_Torque.VdcLimFactor                                        * \
                                         PGUINV_Torque.SupplyHLimFactor                                    * \
                                         PGUINV_Torque.SupplyLLimFactor                                    * \
                                         PGUINV_Torque.InPowLimFactor;

    PGUINV_Torque.TotalLimFactor = CLAMP( PGUINV_Torque.TotalLimFactor* PGUREC_TorqueLimFactor, 0.0, 1.0);

	if (PGUINV_Torque.TotalLimFactor < 1.0)
	{
	    PGUINV_CTL_REG.bit.DEGRADED = 1;                            //  S�cakl�k, gerilim vb durumlarda limitler a��l�rsa k�s�tlanm�� modda �al���r.
	}
	else
	{
	    PGUINV_CTL_REG.bit.DEGRADED = 0;
	}

	if(PGUINV_TORQLIM_REG.bit.TOTAL == 1)
	{
	    PGUINV_Torque.RefLimited	= PGUINV_Torque.TotalLimFactor * PGUINV_Torque.Ref;
	}
	else
	{
	    PGUINV_Torque.RefLimited	= PGUINV_Torque.Ref;
	}
// =================================== Reference Processing =========================================

    // Torque reference preprocessing
	PGUINV_Mot1_SpeedAbs  = ABS(PGUINV_InvFdb.ElecSpeed*10.0/PI);


	if(PGUINV_MasterContr.ENABLE.bit.POWERING==1)
	{
		PGUINV_TeRefLimited_B = 0.0;

        if (PGUINV_Mot1_SpeedAbs < 269.0)
            PGUINV_MotTeCurve = (-3.3028*PGUINV_Mot1_SpeedAbs + 5144.2);//PGUINV_MotTeCurve = 4000.0;
        else if (PGUINV_Mot1_SpeedAbs >= 269.0 && PGUINV_Mot1_SpeedAbs < 3000.0)
            PGUINV_MotTeCurve = 120000/((2*PI*PGUINV_Mot1_SpeedAbs)/60);  // Torque=Power/Speed
        else
            PGUINV_MotTeCurve = 0.0;

		PGUINV_AvailMotTorque = PGUINV_Torque.RefLimited* PGUINV_MotTeCurve ;

		PGUINV_TeRefLimited_T = CLAMPRATE(fabs(PGUINV_AvailMotTorque), PGUINV_TeRefLimited_T, PGUINV_TS_SW, -4000.0, 500.0); //4.0Nm/ms
		PGUINV_MotTeRef = SIGN(PGUINV_Torque.RefLimited) * PGUINV_TeRefLimited_T;
	}
	else if(PGUINV_MasterContr.ENABLE.bit.BRAKING==1 || PGUINV_MasterContr.ENABLE.bit.EMG_BRAKE==1)
	{
		PGUINV_TeRefLimited_T = 0.0;

		if (PGUINV_Mot1_SpeedAbs < 800.0)
		    PGUINV_MotTeCurve = 3000.0;
		else if (PGUINV_Mot1_SpeedAbs >= 800.0 && PGUINV_Mot1_SpeedAbs < 3000.0)
		    PGUINV_MotTeCurve = 250000.0/(PGUINV_Mot1_SpeedAbs*PI/30.0);
		else
		    PGUINV_MotTeCurve = 0.0;

        PGUINV_AvailMotTorque = PGUINV_Torque.RefLimited* PGUINV_MotTeCurve ;

		PGUINV_TeRefLimited_B = CLAMPRATE(fabs(PGUINV_AvailMotTorque), PGUINV_TeRefLimited_B, PGUINV_TS_SW, -400.0, 600.0); //4.0Nm/ms
		PGUINV_MotTeRef = SIGN(PGUINV_Torque.RefLimited) * PGUINV_TeRefLimited_B;
	}
	else
	{
        PGUINV_AvailMotTorque = 0.0;
		PGUINV_TeRefLimited_T = 0.0;
		PGUINV_TeRefLimited_B = 0.0;



		if(fabs(PGUINV_Mot1_Speed) >= 166.5) // 0 tork durumunda rejeneratif frenlemeyi engellemek i�in (166.5rpm=5km/h).
		{
	        PGUINV_MotTeRef       = CLAMP(4000.0/(PGUINV_Mot1_Speed*PI/30.0),-100.0,100.0);;
		}
		else
		{
            PGUINV_MotTeRef       = 0.0;
		}

	}

//---------- 	Converter start flag set  	 ---------------//

	if((PGUINV_CTL_REG.bit.ON==1)&&(PGUINV_CTL_REG.bit.ENABLE==1)&&(PGUINV_CTL_REG.bit.STATE==0))
	{
	    PGUINV_CTL_REG.bit.START = 1;
	}
	else
	{
	    PGUINV_CTL_REG.bit.START = 0;
	}

//---------- 	Converter stop flag set  	 ---------------//
	if((PGUINV_CTL_REG.bit.ON==0)&&(PGUINV_CTL_REG.bit.STATE > 0))
	{
	    PGUINV_CTL_REG.bit.STOP = 1;
	}
	else
	{
	    PGUINV_CTL_REG.bit.STOP = 0;
	}

//---------- 	Converter pause flag set  	 ---------------//
    if(PGUINV_CTL_REG.bit.STATE==6 && (PGUINV_CTL_REG.bit.POWER == 0))
    {
        PGUINV_CTL_REG.bit.PAUSE =1;
	}
	else
	{
	    PGUINV_CTL_REG.bit.PAUSE =0;
	}

//---------- 	Converter start-stop operation  	 ---------------//

	if(PGUINV_CTL_REG.bit.POWER == 1)
	{
		if(PGUINV_CTL_REG.bit.STATE==3)
		{
		    PGUINV_CTL_REG.bit.STATE = 4; // PreCharge tamamland� Rectifier kontrol baslatma durumuna gecildi
		}
		else if(PGUINV_CTL_REG.bit.STATE==9)
		{
		    PGUINV_CTL_REG.bit.RESET =1;
		    PGUINV_CTL_REG.bit.STATE =4;
		}
	}


//---------- 	Converter start operation  	 ---------------//
	if(	PGUINV_CTL_REG.bit.START == 1)
	{	PGUINV_CTL_REG.bit.START = 0;					// Baslama isareti temizlendi
		if(PGUINV_CTL_REG.bit.OPMODE==0)
		{
		    PGUINV_CTL_REG.bit.RESET	= 1;
		    PGUINV_CTL_REG.bit.STATE   = 1;            // Baslangic reset ve hata temizleme durumuna gecildi

//			if(!MCAUX_REG.bit.STATUS && MC_Status)
//			{
//				PGUINV_CTL_REG.bit.STATE	= 1;			// Baslangic reset ve hata temizleme durumuna gecildi
//			}
//			else
//			{
//				PGUINV_CTL_REG.bit.STATE	= 3;			// Ana kontakt�r devrede durumu
//			}
		}
	}

//----------    Converter stop operation     ---------------//
	    if( PGUINV_CTL_REG.bit.STOP ==1 )
	    {   PGUINV_CTL_REG.bit.STOP = 0;

	        PGUINV_CTL_REG.bit.STATE       = 0;
	        PGUINV_CTL_REG.bit.OPMODE      = 0;
	        PGU_INVCTL_REG.bit.Enable   = 0;

//	        PRECHCTL_REG.bit.STATUS  = 0;           // PreCharge ba�lang�� durumunda, kontakt�rler a��k

	        PGUGateOFF
	        FOIOGateOFF
	    }

//----------    Converter Pause operation    ---------------//
    if( PGUINV_CTL_REG.bit.PAUSE==1 )
    {   PGUINV_CTL_REG.bit.PAUSE= 0;

        PGUINV_CTL_REG.bit.STATE        = 9;        // Pause state
        PGUINV_CTL_REG.bit.OPMODE       = 0;
        PGU_INVCTL_REG.bit.Enable       = 0;

        PGUGateOFF
        FOIOGateOFF
    }


    if(PGUINV_CTL_REG.bit.STATE==9 )
    {
        if((!IO_READ(PGUINV_TZ1GPIO))||(!IO_READ(PGUINV_TZ2GPIO)))    // Gate off durumunda HW hata olu�ursa
        {
            PGUINV_FLT_REG.bit.HWPROT  = 1;        // Hardware fault
            PGUINV_CTL_REG.bit.STATE   = 15;       // Hardware Hata durumu
            PGU_INVCTL_REG.bit.Enable  = 0;
            PGUGateOFF
            FOIOGateOFF
        }

      if(PGUINV_FLT_REG.bit.HWPROT  == 1)
      {
          PGUINV_CTL_REG.bit.STATE    = 15;       // Hardware Hata durumu
      }
    }


////---------- 	Converter Precharge start flag set ---------------//
//
//	    if(PGUINV_CTL_REG.bit.STATE == 2)
//	    {
//	        if(PRECHCTL_REG.bit.STATUS<3)
//	        {
//	            PRECHCTL_REG.bit.START = 1;
//	        }
//	    }

    if(PGUINV_CTL_REG.bit.STATE == 2)
    {
        if(PGUINV_FLT_REG.all == 0)
        {
            PGUINV_CTL_REG.bit.STATE = 3;
        }
        else
        {
            PGUINV_CTL_REG.bit.OPMODE      = 2;            // Hata var
            PGUINV_CTL_REG.bit.STATE       = 10;           // PreCharge baslatilamadi
        }
    }


//---------- 	Converter Reset operation  	 ---------------//

	if(PGUINV_CTL_REG.bit.RESET == 1)
	{
		PGUINV_FaultFlagsClear = 1;				// Hata bayraklar� temizleme isareti set edildi
		PGUINV_FPGAsReset		= 1;				// Fiber kartlar reset isareti set edildi
		PGUINV_TripZoneClear			= 1;				// PWM TRIP temizleme isareti set edildi
		PGUINV_CTL_REG.bit.OPMODE	= 0;
	}


	if(PGUINV_FaultFlagsClear==1)
	{
	    PGUINV_FLT_REG.all			        = 0x0000;
	    PGUINV_SWProtErrFlags.all	        = 0x0000;
	    PGUINV_TempErrFlags_CKU1.all	    = 0x0000;
        PGUINV_TempErrFlags_CKU2.all        = 0x0000;

		if(STestErrFlags.all > 0)
		{
			PGUINV_SelfTestErrClear += 1;
			if(PGUINV_SelfTestErrClear>=1)
			{
			    STestErrFlags.all	= 0x0000;
			}
		}

		PGUINV_FaultFlagsClear = 2;
	}

	if (PGUINV_FPGAsReset==1)
	{
		PGUINV_FPGAsReset=2;						// Clear flag

		IO_SET(PGUINV_SGOFF)						// Apply software gate off signal
		DELAY_US(4);

		IO_SET(PGUINV_FOIORst)						// Apply FOIO reset signal
		DELAY_US(4);						// Minimum Delay 1us. It should be applied due to BP propagation delay.

		IO_SET(PGUINV_FDPCRst)						// Apply FDPC reset signal
		DELAY_US(4);						// Valid reset signal delay for FDPC

		IO_CLR(PGUINV_FDPCRst)						// Clear FDPC reset signal
		DELAY_US(4);						// Minimum Delay 2us. It should be applied due to BP propagation delay.

		IO_CLR(PGUINV_FOIORst)						// Clear FOIO reset signal
		DELAY_US(4);
	}

	if (PGUINV_TripZoneClear==1)
	{
		PGUINV_TripZoneClear = 2;						// Clear flag

		if(PGUINV_CTL_REG.bit.STATE==1)
		{
		    PGUINV_CTL_REG.bit.STATE = 2;			// Baslangic reset ve hata temizleme tamamlandi
		}

		FOIOGateOFF							// FOIO Software gate off
		PGUInvGateON

		PGUINV_CTL_REG.bit.RESET = 2;
	}





// ------------------------------------------------------------------------------
//	Control start command check
// ------------------------------------------------------------------------------
	if(PGUINV_CTL_REG.bit.STATE==4 && PGUINV_FLT_REG.all == 0 && PGUINV_CTL_REG.bit.RESET == 2)
	{
	    PGU_INVCTL_REG.bit.Enable 	    = 1;
	    PGU_INVCTL_REG.bit.CtrlStart    = 1;    // Rectifier kontrol baslatma isareti set edildi

        PGUINV_CTL_REG.bit.STATE         = 5;    // Inverter kontrol dongusu devreye alindi

	}


// ------------------------------------------------------------------------------
//  Inverter Control start command check
// ------------------------------------------------------------------------------

    if(PGU_INVCTL_REG.bit.CtrlState==1)
    {
        if(PGU_INVCTL_REG.bit.Enable !=1)
        {
            PGU_INVCTL_REG.bit.CtrlState    = 0;
        }

        //  PGUINV_FOIOGateOnFlag = 1;

        PGUINV_CTL_REG.bit.STATE       = 6;    // Inverter anahtarlama basladi
        PGUINV_CTL_REG.bit.OPMODE      = 1;

        if(PGUINV_CtrlStopFlag == 0)
        {
            PGUINV_CtrlStopCntrOld = PGUINV_CtrlStopCntr;
            PGUINV_CtrlStopFlag = 1;
        }
        PGUINV_CtrlStopCntr = 10*ms_100;

        if(PGUINV_CtrlStartCntr < PGUINV_CtrlStopCntrOld + 3*ms_100)
        {
            PGUINV_CtrlStartCntr ++;
        }

        if(EnableCC == 1)
        {
            PGUINV_FOIOGateOnFlag = 1;
        }

    }
    else
    {
        if(PGUINV_CtrlStopCntr>0)
        {
            PGUINV_CtrlStopCntr--;
        }

        if(PGUINV_CTL_REG.bit.STATE >= 6)
        {
//            PGUGateOFF
//            FOIOGateOFF
        }

        EnableTC = 0;
        EnableVC = 0;
        EnableCC = 0;
        EnableFO = 0;
        EnableSC = 0;

        PGUINV_CTL_REG.bit.OPMODE  = 0;

        PGUINV_CtrlStartCntr     = 0;
        PGUINV_CtrlStopFlag      = 0;
    }


// ------------------------------------------------------------------------------
//	ED_BRK check
// ------------------------------------------------------------------------------
	if(PGUINV_CTL_REG.bit.STATE==6)
	{
		if(PGUINV_MasterContr.MAIN_HAND.bit.BRAKING==1 || PGUINV_MasterContr.MAIN_HAND.bit.EMG_BRAKE==1)
		{
			PGUINV_EDBrakeActive = 1;
		}
		else
		{
			PGUINV_EDBrakeActive = 0;

		}
	}
	else
	{
		PGUINV_EDBrakeActive = 0;
	}

}


// Command Read Routine
void PGUINV_CommandRead(void)
{
//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------

//    PGUINV_ReadCANData();

    PGUINV_MasterContr.TORQUEREF = PGUINV_TeRefCAN;    //
    PGUINV_CTL_REG.bit.ENABLE  = 1;             // PGUINV_ConvEnable


// Reverser ge�i�leri aras� gecikme
	if(PGUINV_ReverserNew != PGUINV_ReverserOld)
	{
		PGUINV_ReverserCnt++;
		if(PGUINV_ReverserCnt > REVERSER_DEBOUNCE_COUNT)
		{
			PGUINV_ReverserCnt = 0;
			PGUINV_ReverserOld = PGUINV_ReverserNew;
			PGUINV_MasterContr.STA.bit.POWER_OFF = 1;  //Reverser konumu de�i�ti anahtarlamay� durdur.
		}
	}
	else
	{
		PGUINV_ReverserCnt = 0;
		PGUINV_Reverser	= PGUINV_ReverserOld;
	}


// 	REVERSER_STAT:2	;       // 1:0    	11:Neutral - 10:Forward - 01:Reverse - 00:initial
	switch (PGUINV_Reverser)
	{
	case 0:	PGUINV_MasterContr.REV_SW.all 		   = 0;
	        PGUINV_MasterContr.REV_SW.bit.INITIAL = 1;
		break;
	case 1:	PGUINV_MasterContr.REV_SW.all 		   = 0;
	        PGUINV_MasterContr.REV_SW.bit.REVERSE = 1;
		break;
	case 2:	PGUINV_MasterContr.REV_SW.all 		   = 0;
	        PGUINV_MasterContr.REV_SW.bit.FORWARD = 1;
		break;
	case 3:	PGUINV_MasterContr.REV_SW.all 		   = 0;
	        PGUINV_MasterContr.REV_SW.bit.OFF     = 1;
		break;
	}

//	MASTERCONT_STAT:2;       // 3:2    	11:Neutral - 10:Power	- 01:Brake   - 00:Em.Brake
	switch (PGUINV_MasterContrStat)
	{
	case 0:	PGUINV_MasterContr.MAIN_HAND.all 		   	= 0;
	        PGUINV_MasterContr.MAIN_HAND.bit.EMG_BRAKE= 1;
		break;
	case 1:	PGUINV_MasterContr.MAIN_HAND.all 		   	= 0;
	        PGUINV_MasterContr.MAIN_HAND.bit.BRAKING  = 1;
		break;
	case 2:	PGUINV_MasterContr.MAIN_HAND.all 		   	= 0;
	        PGUINV_MasterContr.MAIN_HAND.bit.POWERING = 1;
		break;
	case 3:	PGUINV_MasterContr.MAIN_HAND.all 		   	= 0;
	        PGUINV_MasterContr.MAIN_HAND.bit.NEUTRAL  = 1;
		break;
	}

// Reverse switch OFF pozisyonuna �ekilmeden konverter aksiyon almamas� i�in
	if((PGUINV_MasterContr.REV_SW.bit.OFF==1)&&(PGUINV_MasterContr.STA.bit.REV_SW_EN == 0))
	{
	    PGUINV_MasterContr.STA.bit.REV_SW_EN = 1;
	}

	if(PGUINV_MasterContr.STA.bit.REV_SW_EN == 0)
	{
	    PGUINV_MasterContr.REV_SW.all =0;
	}

// Main Handle NEUTRAL pozisyonuna �ekilmeden konverter aksiyon almamas� i�in
	if((PGUINV_MasterContr.MAIN_HAND.bit.NEUTRAL==1)&&(PGUINV_MasterContr.STA.bit.MAIN_H_EN == 0))
	{
	    PGUINV_MasterContr.STA.bit.MAIN_H_EN = 1;
	}

	if(PGUINV_MasterContr.STA.bit.MAIN_H_EN == 0)
	{
	    PGUINV_MasterContr.MAIN_HAND.all = 0;
	}

// NEUTRAL pozisyonunda 10 sn beklenmesi halinde anahtarlamay� durdur.
	if(PGUINV_MasterContr.MAIN_HAND.bit.NEUTRAL==1)
	{
		if(PGUINV_NeutralCnt_PowerOff< NEUTRAL_POWEROFF_COUNT)
		{
		    PGUINV_NeutralCnt_PowerOff++;
		}
		else
		{
		    PGUINV_MasterContr.STA.bit.POWER_OFF=1;	// N�tr pozisyonunda belirlenen s�re (10 second)kadar bekledi anahtarlamay� durdur.
		}
	}
	else
	{
	    PGUINV_NeutralCnt_PowerOff = 0;
	    PGUINV_MasterContr.STA.bit.POWER_OFF=0;
	}


// Main Handle ge�i�leri aras� gecikme
    if(PGUINV_MasterContr.MAIN_HAND.bit.NEUTRAL==1)
    {
        if(PGUINV_NeutralCnt<1050)
        {
            PGUINV_NeutralCnt++;
        }
        else
        {
            PGUINV_MasterContr.ENABLE.bit.NEUTRAL=1;
        }
    }
    else
    {
        PGUINV_NeutralCnt = 0;
        PGUINV_MasterContr.ENABLE.bit.NEUTRAL = 0;
    }

// Main Handle ge�i�leri aras� gecikme
    if(PGUINV_MasterContr.MAIN_HAND.bit.POWERING==1)
    {
        if(PGUINV_PoweringCnt<1050)
        {
            PGUINV_PoweringCnt++;
        }
        else
        {
            PGUINV_MasterContr.ENABLE.bit.POWERING=1;
        }
    }
    else
    {
        PGUINV_PoweringCnt = 0;
        PGUINV_MasterContr.ENABLE.bit.POWERING = 0;
    }

// Main Handle ge�i�leri aras� gecikme
    if(PGUINV_MasterContr.MAIN_HAND.bit.BRAKING==1)
    {
        if(BrakingCnt<1050)
        {
            BrakingCnt++;
        }
        else
        {
            PGUINV_MasterContr.ENABLE.bit.BRAKING=1;
        }
    }
    else
    {
        BrakingCnt = 0;
        PGUINV_MasterContr.ENABLE.bit.BRAKING = 0;
    }

// Main Handle ge�i�leri aras� gecikme
    if(PGUINV_MasterContr.MAIN_HAND.bit.EMG_BRAKE==1)
    {
        if(PGUINV_EMGBrakeCnt<1050)
        {
            PGUINV_EMGBrakeCnt++;
        }
        else
        {
            PGUINV_MasterContr.ENABLE.bit.EMG_BRAKE = 1;
        }
    }
    else
    {
        PGUINV_EMGBrakeCnt = 0;
        PGUINV_MasterContr.ENABLE.bit.EMG_BRAKE = 0;
    }

}

// Tiva Life Check Routine
void PGUINV_TivaLifeCheck(Uint16 Time)
{

	if(PGUINV_TivaRegWFlag == 0)
	{
		if(PGUINV_TivaWriteToggle == 0)
		{
			DSP2TivaRegs.regs.CheckReg = 0xA55A;
			PGUINV_TivaWriteToggle = 1;
		}
		else
		{
			DSP2TivaRegs.regs.CheckReg = 0x55AA;
			PGUINV_TivaWriteToggle = 0;
		}

		PGUINV_TivaRegWFlag = 1;
		PGUINV_TivaRegRCount = 0;
	}
	else
	{
		if(PGUINV_TivaRegRCount > Time)
		{
//		    PGUINV_FLT_REG.bit.STELHS = 1;
			PGUINV_TivaRegWFlag  = 0;
		}
		else
		{
			if(Tiva2DSPRegs.regs.CheckReg == ~DSP2TivaRegs.regs.CheckReg)
			{
				PGUINV_TivaRegWFlag = 0;
			}
			else
			{
				PGUINV_TivaRegRCount++;
			}
		}
	}
}

#endif /* PGUINV_MAINISR_C_ */
