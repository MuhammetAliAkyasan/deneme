/* ==============================================================================
System Name:    E5000 LOCO

File Name:      PGU_Inv3.c

Description:    E5000_LOCO - 1 ph PWM rectifier control

Originator:     E5000 project group

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 01-10-2018 Version 1.0
=================================================================================  */

#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

///////////////////////////////////////////S� D�zenleme///////////////////////////////////////////////////////
//Alt sat�rlar eklendi
Uint16 OffCounter = 0;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct PGU_ETHRX_BITS {         // bits   description
    Uint16 PreCharge_Eth:1;             // 0    RampUp
    Uint16 MainContactor_Eth:1;           // 1    RampDown
    Uint16 MCB_Trip_Eth:1;               // 2    MELS1 - Cer naklinde ar�za var ikaz lambas�
    Uint16 Reserved_Eth:1;              // 3    MSG1 - CK� patinaj ikaz lambas�
    Uint16 Traction_Eth:1;            // 4    Traction Active Signal
    Uint16 Edb_Eth:1;                  // 5    Pump Contactor - 5QA01
    Uint16 CabinFan_Eth:1;            // 6    Fan Contactor - 5QA02
    Uint16 CKUFan_Eth:1;             // 7    Discharge Contactor - 7QA01
    Uint16 CIFR_Eth:1;                 // 8    HVAC Contactor - 5QA04
    Uint16 SystemReset_Eth:1;            // 9 BEE4 Signal - QA02
    Uint16 Reserved2_Eth:6;             // 15:10 Reserved
    };

typedef union{
   Uint16                        all;
   struct PGU_ETHRX_BITS   bit;
}PGU_ETHRX_REG;
//
//struct PGU_ETHTX_BITS {         // bits   description
//    Uint16 MCCAUX_SIG:1;                      // 0
//    Uint16 PCC_SIG:1;                         // 1
//    Uint16 MCB_TRIP:1;                        // 2
//    Uint16 RVSD1:1;                           // 3
//    Uint16 TRAC_ACTIVE_SIG:1;                 // 4
//    Uint16 EDB_ACTIVE_SIG:1;                  // 5
//    Uint16 Cabin_FAN:1;                       // 6
//    Uint16 CKU_FAN:1;                         // 7
//    Uint16 CIFR:1;                            // 8
//    Uint16 System_RST:1;                      // 9
//    Uint16 Level1_STA:1;                // 0
//    Uint16 Level2_STA:1;                // 1
//    Uint16 Prefuse:1;                   // 2
//    Uint16 Emerge_DEGRADED:1;           // 3
//    Uint16 Emerge_POWER1:1;             // 4
//    Uint16 Emerge_POWER2:1;             // 5
//    Uint16 Emerge_POWER3:1;             // 6
//    Uint16 Direction_Forward:1;         // 7
//    Uint16 Direction_Backward:1;        // 8
//    Uint16 ID0:1;                       // 0
//    Uint16 ID1:1;                       // 1
//    Uint16 ID2:1;                       // 2
//    Uint16 ID3:1;                       // 3
//    Uint16 LimitSwitch:1;               // 4
//    Uint16 EarthSwitch:1;               // 5
//    Uint16 MCBTrip_STA:1;               // 6
//    Uint16 MCAUX_STA:1;                 // 7
//    Uint16 LocoEnable:1;                // 8
//    Uint16 MCBOFF_STA:1;                // 9
//    };
//
//typedef union{
//   Uint16                        all;
//   struct PGU_ETHTX_BITS   bit;
//}PGU_ETHTX_REG;
//
//
//


PGU_ETHRX_REG     PGU_DO_EthRx          = {0x0000};
//PGU_ETHTX_REG     PGU_DI_EthTx          = {0x0000};

void EthernetTest(void)
{
///////////////////////////////////////////S� D�zenleme///////////////////////////////////////////////////////
//Alt sat�rlar comment yap�ld�.  PGUINV_IMotURMS
//Yeni kodlar eklendi.

//    ETH_RX_DATA           : origin = 0x004480, length = 0x000080     /* Ethernet Receive Data Memory Area - 256 Byte  */
    if(EthRxData[1] == 0x444E)
          {
                 OffCounter = 0;

                 Labview_Sayac = EthRxData[7]; // ba�lant� kopma durumuna kar�� koruma i�in


                 if (Labview_Sayac == Labview_Sayac_old)
                 {
                     Labview_Sayac_cnt++;
                     if (Labview_Sayac_cnt > Labview_Sayac_cntmax)
                     {
                         PGUINV_DIOC1_Outputs.all          = 0xFFFF;
                         PGUINV_DIOC2_Outputs.all          = 0xFFFF;
                         PGUINV_TCPU_Outputs.all           = 0xFFFF;

                         GerilimsizAnahtarlama_INV                = 0;
                         Prech1_INV                               = 0;
                         Prech2_INV                               = 0;
                         AnahtarlamaBaslat                        = 0;
                         DCBaraBosalt                             = 0;

                         MotorDirection                           = 0;
                         MotorVFEnable                            = 0;
                         SpeedRef                                 = 0;

                         IO_CLR(PGUINV_EDB_Active)
                         IO_CLR(PGUINV_TractionON)

                         Eth_Hata = 1;

                     }
                 }
                 else
                 {
                     Labview_Sayac_old = Labview_Sayac;
                     Eth_Hata = 0;
                     Labview_Sayac_cnt = 0.0;

                     PGUINV_TCPU_Outputs.bit.Cooling_Contactor_FANS  = EthRxData[3] & 0x01;
                     PGUINV_TCPU_Outputs.bit.Cooling_Contactor_PUMP  = (EthRxData[3] & 0x02)>>1;
                     PGUINV_TCPU_Outputs.bit.CKU_FAN  = (EthRxData[3] & 0x04)>>2;
                     PGUINV_DIOC1_Outputs.bit.Cabin_Fan  = (EthRxData[3] & 0x08)>>3;
                     PGUINV_DIOC2_Outputs.bit.Motor1_OK = EthRxData[4] & 0x01;
                     PGUINV_DIOC2_Outputs.bit.Motor2_OK = (EthRxData[4] & 0x02)>>1;
                     PGUINV_DIOC2_Outputs.bit.HV_Presence = (EthRxData[4] & 0x04)>>2;
                     PGUINV_DIOC2_Outputs.bit.Trac_DCLink_OK = (EthRxData[4] & 0x08)>>3;
                     PGUINV_DIOC2_Outputs.bit.Pantograph_Permission = (EthRxData[4] & 0x10)>>4;
                     PGUINV_DIOC1_Outputs.bit.TRAC_OK1 = (EthRxData[4] & 0x20)>>5;
                     PGUINV_DIOC1_Outputs.bit.TRAC_OK2 = (EthRxData[4] & 0x40)>>6;
                     PGUINV_DIOC1_Outputs.bit.CIFR = (EthRxData[4] & 0x80)>>7;
                     PGUINV_TCPU_Outputs.bit.System_RST = (EthRxData[4] & 0x0100)>>8;
                     PGUINV_TCPU_Outputs.bit.TRAC_ACTIVE_SIG = (EthRxData[4] & 0x0200)>>9;
                     PGUINV_TCPU_Outputs.bit.EDB_ACTIVE_SIG = (EthRxData[4] & 0x0400)>>10;
                     PGUINV_TCPU_Outputs.bit.MCB_TRIP = (EthRxData[4] & 0x0800)>>11;

                     GerilimsizAnahtarlama_INV                = (EthRxData[5] & 0x10)>>4;
                     Prech1_INV                               = (EthRxData[5] & 0x20)>>5;
                     Prech2_INV                               = (EthRxData[5] & 0x40)>>6;
                     AnahtarlamaBaslat                        = (EthRxData[5] & 0x80)>>7;
                     DCBaraBosalt                             = (EthRxData[5] & 0x0400)>>10;

                     MotorDirection                           = (EthRxData[5] & 0x0100)>>8;
                     MotorVFEnable                            = (EthRxData[5] & 0x0200)>>9;

                     TestTeRef                  = ((EthRxData[8])-4000.0);

                     PGUINV_TCPU_Outputs.bit.PCC1_SIG = EthRxData[5] & 0x01;
                     PGUINV_TCPU_Outputs.bit.PCC2_SIG = (EthRxData[5] & 0x02)>>1;
                     PGUINV_TCPU_Outputs.bit.MCCAUX1_SIG = (EthRxData[5] & 0x04)>>2;
                     PGUINV_TCPU_Outputs.bit.MCCAUX2_SIG = (EthRxData[5] & 0x08)>>3;


                     if ((EthRxData[4] & 0x0400)>>10)
                     {
                         IO_CLR(PGUINV_EDB_Active)
                     }
                     else
                     {
                         IO_SET(PGUINV_EDB_Active)
                     }

                     if ((EthRxData[4] & 0x0200)>>9)
                     {
                         IO_CLR(PGUINV_TractionON)
                     }
                     else
                     {
                         IO_SET(PGUINV_TractionON)
                     }


                 }

          }
          else
          {
              OffCounter++;

              if (OffCounter > 30)
              {

//                  PGUINV_DIOC1_Outputs.all          = 0xFFFF;
//                  PGUINV_DIOC2_Outputs.all          = 0xFFFF;
//                  PGUINV_TCPU_Outputs.all           = 0xFFFF;
//
//                  GerilimsizAnahtarlama_INV                = 0;
//                  Prech1_INV                               = 0;
//                  Prech2_INV                               = 0;
//                  AnahtarlamaBaslat                        = 0;
//                  DCBaraBosalt                             = 0;
//
//                  MotorDirection                           = 0;
//                  MotorVFEnable                            = 0;
//                  SpeedRef                                 = 0;
//
//                  IO_SET(PGUINV_EDB_Active)
//                  IO_SET(PGUINV_TractionON)

              }

          }
////////////////////////////////////////////////////////////////////////////////////////////////////////////


//    PGU_DO_EthRx.all = EthRxData[13];//MonitorData[221];
//
//
//    if(PGU_DO_EthRx.bit.PreCharge_Eth == 1)
//            {
//                    IO_CLR(PCCSig)
//            }
//    else
//            {
//                    IO_SET(PCCSig)
//            }
//
//    if(PGU_DO_EthRx.bit.Traction_Eth == 1)
//            {
//                  IO_CLR(PGUINV_TractionON)
//            }
//    else
//            {
//                 IO_SET(PGUINV_TractionON)
//            }
//
//    if(PGU_DO_EthRx.bit.MainContactor_Eth == 1)
//            {
//                  IO_CLR(MCSig)
//            }
//    else
//            {
//                 IO_SET(MCSig)
//            }
//
//    if(PGU_DO_EthRx.bit.MCB_Trip_Eth == 1)
//            {
//                  IO_CLR(PGUINV_MCBTrip)
//            }
//    else
//            {
//
//                 IO_SET(PGUINV_MCBTrip)
//            }
//
//    if(PGU_DO_EthRx.bit.CKUFan_Eth == 1)
//            {
//                  TCPU_Outputs.bit.CKU_FAN=0;
//            }
//    else
//            {
//
//                  TCPU_Outputs.bit.CKU_FAN=1;
//            }
//
//    if(PGU_DO_EthRx.bit.CabinFan_Eth == 1)
//            {
//                  TCPU_Outputs.bit.Cabin_FAN=0;
//            }
//    else
//            {
//
//                  TCPU_Outputs.bit.Cabin_FAN=1;
//            }
//
//    if(PGU_DO_EthRx.bit.CIFR_Eth == 1)
//            {
//                  TCPU_Outputs.bit.CIFR=0;
//            }
//    else
//            {
//
//                  TCPU_Outputs.bit.CIFR=1;
//            }
//
//    if(PGU_DO_EthRx.bit.Edb_Eth == 1)
//            {
//                  TCPU_Outputs.bit.EDB_ACTIVE_SIG=0;
//            }
//    else
//            {
//
//                  TCPU_Outputs.bit.EDB_ACTIVE_SIG=1;
//            }
//
//    if(PGU_DO_EthRx.bit.Reserved_Eth == 1)
//            {
//                  TCPU_Outputs.bit.RVSD1=0;
//            }
//    else
//            {
//
//                  TCPU_Outputs.bit.RVSD1=1;
//            }
//
//    MonitorData[130]=DIOC_Inputs_TCPU.bit.EarthSwitch;
//    MonitorData[131]=DIOC_Inputs_TCPU.bit.LimitSwitch;
//    MonitorData[132]=DIOC_Inputs_TCPU.bit.MCBTrip_STA;
//    MonitorData[133]=DIOC_Inputs_TCPU.bit.LocoEnable;
//    MonitorData[134]=DIOC_Inputs_TCPU.bit.MCAUX_STA;
//    MonitorData[136]=DIOC_Inputs_TCPU.bit.MCBOFF_STA;
//    MonitorData[137]=DIOC_Inputs_TCPU.bit.ID0;
//    MonitorData[138]=DIOC_Inputs_TCPU.bit.ID1;
//    MonitorData[139]=DIOC_Inputs_TCPU.bit.ID2;
//    MonitorData[140]=DIOC_Inputs_TCPU.bit.ID3;
//    MonitorData[141]=!TCPU_Inputs.bit.EDB_ACTIVE; //418
//    MonitorData[142]=!TCPU_Inputs.bit.Emerge_LOOP; //420
//    MonitorData[143]=!TCPU_Inputs.bit.ERTMS; //422
//    MonitorData[144]=!TCPU_Inputs.bit.Traction_ACTIVE; //424
//    MonitorData[145]=!TCPU_Inputs.bit.Insulation_Device_STA; //426
//    MonitorData[146]=!IO_READ(PCCSig); //428
//    MonitorData[147]=!IO_READ(MCSig); //430
//    MonitorData[148]=!TCPU_Inputs.bit.MCB_ON; //432
//    MonitorData[149]=!TCPU_Inputs.bit.MC_NC; //434
//    MonitorData[150]=!TCPU_Inputs.bit.MC_NO; //436
//    MonitorData[151]=!TCPU_Inputs.bit.PCC_NC; //438
//    MonitorData[152]=!TCPU_Inputs.bit.PCC_NO; //440
//    MonitorData[153]=!TCPU_Inputs.bit.Trac_INHIBIT; //442
//    MonitorData[154]=!IO_READ(EDB_CUTOUT);  //444
//    MonitorData[155]=!DIOC_Inputs1.bit.Direction_Backward; //446
//    MonitorData[156]=!DIOC_Inputs1.bit.Direction_Forward; //448
//    MonitorData[157]=!DIOC_Inputs1.bit.Emerge_DEGRADED; //450
//    MonitorData[158]=!DIOC_Inputs1.bit.Emerge_POWER1; //452
//    MonitorData[159]=!DIOC_Inputs1.bit.Emerge_POWER2; //454
//    MonitorData[160]=!DIOC_Inputs1.bit.Emerge_POWER3;  //456
//    MonitorData[161]=!DIOC_Inputs1.bit.Level1_STA; //458
//    MonitorData[162]=!DIOC_Inputs1.bit.Level2_STA; //460
//    MonitorData[163]=!DIOC_Inputs1.bit.Prefuse;  //462
//
//

}



