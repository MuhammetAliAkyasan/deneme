/* ==============================================================================
System Name:  	YEMU Traction Motor Control System

File Name:		PGU_INV.h

Description:	Primary system header file for the Real Implementation of
          		Field Orientation Control for Traction Motor

Originator:		YEMU project group

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 01-10-2018	Version 1.0
=================================================================================  */

#ifndef PGUINV_INVERTER_H_
#define PGUINV_INVERTER_H_

/*-------------------------------------------------------------------------------
Next, Include project specific include files.
-------------------------------------------------------------------------------*/

#include "PGU_DSP_Math.h"

//***********  Inv  ******************
extern float32 InvPin;
extern float32 InvPF;
extern float32 UdcLPF;
extern float32 InvIs;

extern float32 InvPow;
extern float32 InvPowLPF;
extern float32 Us_alpha_d;
extern float32 Us_beta_d;

extern float32 InvPowSum;
extern float32 InvPowMean;

extern float32 Is_d;
extern float32 Is_q;

extern Uint16  VelEstErr;
extern float32 SCSanding;
extern Uint16  SCActive;

extern float32 MotTeRef;
extern float32 TestTeRef;

extern float32 Umot;
extern float32 Imot;
extern float32 ws_mot;
extern float32 wr_mot;

//------------------------------------
// Inverter Control Variables
//------------------------------------
//References
extern float32 DRef_a;
extern float32 DRef_b;
extern float32 DRef_c;
extern float32 fsRef;
extern float32 DirRef;
extern float32 UsRef_d;
extern float32 UsRef_q;
extern float32 IsRef_d;
extern float32 IsRef_q;

//Feedbacks
extern float32 Is_a;
extern float32 Is_b;
extern float32 Is_c;
extern float32 Udc;
extern float32 w;
extern float32 wsLPF;

//Limits
extern float32 DMin;
extern float32 DMax;
extern float32 UsMax;

//Enables
extern volatile Uint16 EnableFO;
extern volatile Uint16 EnableCC;
extern volatile Uint16 EnableVC;
extern volatile Uint16 EnableTC;
extern volatile Uint16 EnableSC;

//*********************************************
// Plant Parameters
//*********************************************
// Motor Parameters
extern volatile float32 Rs;
extern volatile float32 kr2Rr;
extern volatile float32 Lsig;
extern volatile float32 Lsigp;
extern volatile float32 p;

// Inverter Parameters
extern volatile float32 fsw;
extern volatile float32 UdcN;
extern volatile float32 IsMax;
extern volatile float32 IsMin_d;
extern volatile float32 IsMax_d;
extern volatile float32 Tdt;
extern volatile float32 Uth;

// Controller Parameters
extern volatile float32 Kcc; // 0<Kcc<fsw/3
extern volatile float32 Kco;    // 1<p/z<2
extern volatile float32 fco;
extern volatile float32 Kvc;
extern volatile float32 fcUs;
extern volatile float32 fs0;
extern volatile float32 Ks;

extern float32 alpha;
extern float32 Td;
extern float32 Rsig;
extern float32 Tsig;
extern float32 Tdp;
extern float32 Rsigp;
extern float32 Tsigp;

#define INV_FDB_MACRO(r,m)                                                      \
    r.Vdc       = m.Result.Volt_DCLink;     /* Inverter DC bus voltage */          \
    r.Cur_MotU  = m.Result.Cur_MotInputU;        /* Inverter Motor Phase U current*/    \
    r.Cur_MotW  = m.Result.Cur_MotInputW;        /* Inverter Motor Phase  current*/    \
    r.Cur_BRK   = m.Result.Cur_BRK;        /* Inverter Break Resistor*/


#endif /* PGU_INV_H_ */

