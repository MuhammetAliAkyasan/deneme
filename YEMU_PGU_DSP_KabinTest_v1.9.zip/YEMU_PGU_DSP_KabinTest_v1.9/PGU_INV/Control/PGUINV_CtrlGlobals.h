/*
 * PGUINV_CtrlGlobals.h
 *
 *  Created on: 15 Eki 2018
 *      Author: fozturk
 */

#ifndef PGUINV_CTRLGLOBALS_H_
#define PGUINV_CTRLGLOBALS_H_


#define PGUINV_ADCOffsetPRD	      (1600.0)        // 2100Hz kontrol d�ng�s� = 1 Saniye
#define PGUINV_ADCChNUM		      (4)			  // Okuma yap�lan ADC kanal say�s�
#define PGUINV_TEMPChNUM_CKU1     (8)             // �l��m yap�lan s�cakl�k say�s�
#define PGUINV_TEMPChNUM_CKU2     (6)             // �l��m yap�lan s�cakl�k say�s�

#define MOTOR1  1.0
#define MOTOR2  1.0

#define MOTORN  (MOTOR1 + MOTOR2)
#define MOTORNp (MOTORN * 1.0)

#define BRAKE_RESISTOR 3.2

// Inverter control register bit definitions */
struct RCTL_BITS {          	// bits   description
   Uint16 Enable:2;         	// 0
   Uint16 CtrlState:2;          // 1
   Uint16 CtrlStart:1;          // 2
   Uint16 TripSource:1;         // 3
   Uint16 TripForce:1;        	// 4
   Uint16 Reset:1;       		// 6
   Uint16 PoweringMode:1;       // 7
   Uint16 RegenMode:1;       	// 8
   Uint16 CapacitivePF:1;       // 9
   Uint16 InductivePF:1;       // 10
   Uint16 rsvd2:4;       		// 15-11
};

typedef union{
   Uint16             	 all;
   struct RCTL_BITS   bit;
}PGUINV_CTRL_VAR;


typedef struct {
    float32 Usn_alpha;
    float32 Usn_beta;
    float32 Vdc;
}INVHS;


typedef struct  {

    float32 ElecSpeed;      // Input : Electrical speed
    float32 Cur_MotU;       // Input : 3ph Rect Input Current 1
    float32 Cur_MotW;       // Input : 3ph Rect Input Current 2
    float32 Vdc;         // Output: 3 ph Rectifier Input Voltage Sensor Measurement
    float32 Cur_BRK;       // Input : 3ph Rect Input Current 3

}PGU_FDB_INV;


// �eki� referans� �retimi i�in kullan�lan de�i�kenler.
typedef struct  {
	float32 Ref;				// Koldan al�nan y�ne g�re anlamland�r�lm�� de�er. min:0.0 maks:1.0
	float32 Dir;                // Referans de�eri anlamland�rmak i�in kullan�lan h�z sens�r� y�n de�i�keni (-1,+1)
	float32 RefLimited;			// Koruma aksiyonlar� sonucu s�n�rland�r�lm�� referans de�er
	float32 TotalLimFactor;		// Toplam limitleme fakt�r� 						min:0.0 maks:1.0
	float32	SpeedLimFactor1;		// H�z korumas� kaynakl� limitleme fakt�r� 			min:0.0 maks:1.0
    float32 SpeedLimFactor2;     // H�z korumas� kaynakl� limitleme fakt�r�          min:0.0 maks:1.0
	float32	TempLimFactor;		// S�cakl�k korumas� kaynakl� limitleme fakt�r� 	min:0.0 maks:1.0
	float32	VdcLimFactor;		// DC gerilim korumas� kaynakl� limitleme fakt�r� 	min:0.0 maks:1.0
	float32	SupplyHLimFactor;	// �ebeke korumas� kaynakl� limitleme fakt�r� 		min:0.0 maks:1.0
	float32	SupplyLLimFactor;	// �ebeke korumas� kaynakl� limitleme fakt�r� 		min:0.0 maks:1.0
	float32	InPowLimFactor;		// Giri� g�c� korumas� kaynakl� limitleme fakt�r� 	min:0.0 maks:1.0
    float32 CapacitivePowLimFactor;     // Kapasitive g�c kaynakl� limitleme fakt�r�   min:0.0 maks:1.0
    float32 InductivePowLimFactor;      // Kapasitive g�c kaynakl� limitleme fakt�r�   min:0.0 maks:1.0
}TORQUE;

#define TORQUE_DEFAULTS { 	    							\
							(0.0),  /* Ref             */	\
							(0.0),  /* Dir             */   \
							(0.0),  /* RefLimited      */	\
							(1.0),  /* TotalLimFactor  */	\
							(1.0),  /* SpeedLimFactor  */	\
							(1.0),  /* SpeedLimFactor  */   \
							(1.0),  /* TempLimFactor   */	\
							(1.0),  /* VdcLimFactor    */	\
							(1.0),  /* SupplyHLimFactor*/	\
							(1.0),  /* SupplyLLimFactor*/	\
							(1.0)   /* InPowLimFactor  */   }

// Rejeneratif frenlemeyi h�za ba�l� s�n�rland�rmak i�in kullan�lan de�i�kenler.
typedef struct  {
	float32 SpeedRPM;		// Motor h�z�, CCW + olarak kabul edilir.
	float32 LimFactor;		// Limiting factor min: 0.0 maks:1.0
	float32	SpeedRPMLim1;   // Rejeneratif frenin kesilece�i h�z.
	float32	SpeedRPMLim2;   // Rejeneratif frenin s�n�rland�r�lmaya ba�layaca�� h�z.
}REGEN;

#define REGEN_DEFAULTS { 	    								\
							(0.0),  /* SpeedRPM 	  */		\
							(1.0),  /* LimFactor  	  */		\
							(1.0),  /* SpeedRPMLim1 */			\
							(336.0)   /* SpeedRPMLim2 */		}

#endif /* PGUINV_CTRLGLOBALS_H_ */

