/* ==============================================================================
System Name:    E5000 LOCO

File Name:      PGUINV_Inv3.c

Description:    E5000_LOCO - 1 ph PWM rectifier control

Originator:     E5000 project group

=====================================================================================
 History:
-------------------------------------------------------------------------------------
 01-10-2018 Version 1.0
=================================================================================  */

#include "DSP28x_Project.h"
#include "PGU_Common.h"
#include "PGUINV_Common.h"

#define OPEN_LOOP
#if (INVERTER_CONTROL)

//void BrakeCntrl();

//***********  Inv  ******************
float32 InvPin   = 0.0;
float32 InvPF    = 0.0;
float32 UdcLPF   = 0.0;
float32 InvIs    = 0.0;


float32 DMinBrake = -0.98;
float32 DMaxBrake = 0.98;

float32 InvPow      = 0.0;
float32 InvPowLPF   = 0.0;
float32 Us_alpha_d  = 0.0;
float32 Us_beta_d   = 0.0;

float32 InvPowSum   = 0.0;
float32 InvPowMean  = 0.0;


float32 Is_d    = 0.0;
float32 Is_q    = 0.0;

Uint16  VelEstErr  = 1;
float32 SCSanding   = 0.0;
Uint16  SCActive    = 0.0;

float32 MotTeRef    = 0.0;
float32 TestTeRef   = 0.0;

float32 Umot    = 0.0;
float32 Imot    = 0.0;
float32 ws_mot  = 0.0;
float32 wr_mot  = 0.0;

//References
float32 DRef_a  = 0.0;
float32 DRef_b  = 0.0;
float32 DRef_c  = 0.0;
float32 fsRef   = 0.0;
float32 DirRef  = 0.0;
float32 UsRef_d = 0.0;
float32 UsRef_q = 0.0;
float32 IsRef_d = 0.0;
float32 IsRef_q = 0.0;


//Feedbacks
float32 Is_a    = 0.0;
float32 Is_b    = 0.0;
float32 Is_c    = 0.0;
float32 Udc     = 0.0;
float32 w       = 0.0;
float32 wsLPF   = 0.0;

//Limits
float32 DMin    = -0.97;
float32 DMax    = 0.97;
float32 UsMax   = 0.0;

//Enables
volatile Uint16 EnableFO = 0.0;
volatile Uint16 EnableCC = 0.0;
volatile Uint16 EnableVC = 0.0;
volatile Uint16 EnableTC = 0.0;
volatile Uint16 EnableSC = 0.0;

//*********************************************
// Plant Parameters
//*********************************************
// Motor Parameters
volatile float32 Rs     = 0.13205;
volatile float32 kr2Rr  = 0.165;
volatile float32 Lsig   = 0.003267;
volatile float32 Lsigp  = 0.06586; //0.22;
volatile float32 p      = 3.0;

// Inverter Parameters
volatile float32 fsw     = 1050.0;
volatile float32 UdcN    = 1800.0;
volatile float32 IsMax   = 215.0;
volatile float32 IsMin_d = 5.0;
volatile float32 IsMax_d = 90.0;
volatile float32 Tdt     = 1.0/1000000.0*4.0;
volatile float32 Uth     = 1.25;
// Controller Parameters
volatile float32 Kcc    = 1050.0/3.0*0.75; //0.75; // 0<Kcc<fsw/3
volatile float32 Kco    = 1.05;    // 1<p/z<2
volatile float32 fco    = 5.0;//10.0;//
volatile float32 Kvc    = 0.075;
volatile float32 fcUs   = 10.0;
volatile float32 fs0    = 10.0;
volatile float32 Ks     = 0.95;

float32 alpha   = 0.0;
float32 Td      = 0.0;
float32 Rsig    = 0.0;
float32 Tsig    = 0.0;
float32 Tdp     = 0.0;
float32 Rsigp   = 0.0;
float32 Tsigp   = 0.0;

//#define OPEN_LOOP

    CLARKE invCLARKE = CLARKE_DEFAULTS;
    PARK invPARK = PARK_DEFAULTS;
    IPARK invIPARK = IPARK_DEFAULTS;
    AG invAG = AG_DEFAULTS;

// Instance controller and observer modules
    VC invVC = {VC_IN_DEFAULTS, VC_OUT_DEFAULTS, VC_VAR_DEFAULTS, VC_PAR_DEFAULTS};
    TC invTC = {TC_IN_DEFAULTS, TC_OUT_DEFAULTS, TC_VAR_DEFAULTS, TC_PAR_DEFAULTS};
    FO invFO = {FO_IN_DEFAULTS, FO_OUT_DEFAULTS, FO_VAR_DEFAULTS, FO_PAR_DEFAULTS};
    CC invCC = {CC_IN_DEFAULTS, CC_OUT_DEFAULTS, CC_VAR_DEFAULTS, CC_PAR_DEFAULTS};
    NC invNC = {NC_IN_DEFAULTS, NC_OUT_DEFAULTS, NC_VAR_DEFAULTS, NC_PAR_DEFAULTS};
//MM invMM = {MM_IN_DEFAULTS, MM_OUT_DEFAULTS, MM_VAR_DEFAULTS, MM_PAR_DEFAULTS};
    SCPI invSCPI = {SCPI_IN_DEFAULTS, SCPI_OUT_DEFAULTS, SCPI_VAR_DEFAULTS, SCPI_PAR_DEFAULTS};
    SCRB invSCRB = {SCRB_IN_DEFAULTS, SCRB_OUT_DEFAULTS, SCRB_VAR_DEFAULTS, SCRB_PAR_DEFAULTS};

    DC              PGUINV_Dc              = {0.0,0.0,0.0};

//    BPF SpeedBPF1 = {BPF_IN_DEFAULTS, BPF_OUT_DEFAULTS, BPF_VAR_DEFAULTS, BPF_PAR_DEFAULTS};
//    BPF SpeedBPF2 = {BPF_IN_DEFAULTS, BPF_OUT_DEFAULTS, BPF_VAR_DEFAULTS, BPF_PAR_DEFAULTS};

void Inv3_Init(void)
{
// Initialize the rule based slip control module
    invSCRB.p.SampleTime = PGUINV_TS;
    invSCRB.p.K2 = 2.0*PI*2.5;
    invSCRB.p.K1 = exp(-invSCRB.p.K2*invSCRB.p.SampleTime);
    invSCRB.p.J = 25.0;
    invSCRB.p.dwTh = 20.0;
    invSCRB.p.IntRateLim = 1.0;//42000.0/2100.0;
    invSCRB.p.ConRateLim = 0.1;
    invSCRB.p.PosRateLim = 0.1;

//// Initialize the phase shift based slip control module
//    PhaseShiftSCInit();
//  PhaseShiftCalcInit();


// Initialize the rule based slip control module
    invSCPI.p.SampleTime = PGUINV_TS;
    invSCPI.p.nSandTh = 0.8/PGUINV_TS;

// Initialize the voltage controller module
    invVC.p.IsMax_d = IsMax_d;
    invVC.p.IsMin_d = IsMin_d;
    invVC.p.ws0     = 2*PI*fs0;
    invVC.p.K       = Kvc;
    invVC.p.Lsig    = Lsig;
    invVC.p.T_Tr    = PGUINV_TS*kr2Rr/Lsigp;
    invVC.p.T_Tusf  = PGUINV_TS*(2*PI*fcUs);

// Initialize the torque controller module
    invTC.p.Ks      = Ks;
    invTC.p.Lsig    = Lsig;
    invTC.p.Lm      = Lsigp;
    invTC.p.Lr      = Lsigp+Lsig;
    invTC.p.p       = p;
    invTC.p.IsMax   = IsMax;
    invTC.p.IsMax_d = IsMax_d;
    invTC.p.PsiRMin = 0.5;

// Initialize the current controller module
    Td      = 1.5*PGUINV_TS;
    Rsig    = Rs+kr2Rr;
    Tsig    = Lsig/Rsig;
    alpha   = 1.05*2.0*(2.0*PI*150.0)/(1/Td+1/Tsig) - 1.0;  // alphaopt=2*wsmax/(1/Td+1/Tsig)-1 %for zeta=sqrt(2)/2 and wsmax=2*pi*150;
    Tdp     = 1.0/(0.5*(1/Td+1/Tsig)*(1+alpha));    //used in delay
    Rsigp   = (1.0-SQR(alpha))/4.0*(Td+Tsig)*(1.0/Td+1.0/Tsig)*Rsig;
    Tsigp   = 1.0/(0.5*(1/Td+1/Tsig)*(1-alpha));  //used in system

    invCC.p.KRsigpT     = Kcc*Rsigp*PGUINV_TS;
    invCC.p.KRsigpTsigp = Kcc*Rsigp*Tsigp;
    invCC.p.Ra          = Rsigp-Rsig;
    invCC.p.T           = PGUINV_TS;
    invCC.p.T_Td        = PGUINV_TS/Td;
    invCC.p.T_Tdp       = PGUINV_TS/Tdp;
    invCC.p.T_Tsigp     = PGUINV_TS/Tsigp;
    invCC.p.Tdp_Td      = Tdp/Td;

// Initialize the flux observer module
    invFO.p.Kpo     = 62.73185332; //2.0*(0.34356075*2*PI*fco);
    invFO.p.Kio     = 6.273185332; //2.0*SQR(0.34356075*2*PI*fco);
    invFO.p.Lm      = Lsigp;//Lsigp;
    invFO.p.Lr      = Lsigp+Lsig;//Lsig+Lsigp;
    invFO.p.Rs      = Rs;
    invFO.p.Lsig    = Lsig;
    invFO.p.T       = PGUINV_TS;
    invFO.p.T_Tr    = PGUINV_TS*kr2Rr/Lsigp;
    invFO.p.p       = p;
    invFO.p.T_Twr   = 0.01;
    invFO.p.PsiRMin = 0.5;

// Initialize the nonlinearity compensation module
    invNC.p.Tdt = 0.0*Tdt;
    invNC.p.fsw = fsw;
    invNC.p.Uth = 0.0*Uth;

// Initialize angle generator module
    invAG.T = PGUINV_TS;

//    ClearAnalogBuffer(AnaBuff.buff1, 1);
//    ClearAnalogBuffer(AnaBuff.buff2, 2);
//    ClearAnalogBuffer(AnaBuff.buff3, 3);
//    ClearAnalogBuffer(AnaBuff.buff4, 4);
//    ClearAnalogBuffer(AnaBuff.buff5, 5);
//    ClearAnalogBuffer(AnaBuff.buff6, 6);
//    ClearAnalogBuffer(AnaBuff.buff7, 7);

//  Uint16 PGUDE_BuffCntr = 0;
//  float32 w_e = 0.0;
//  float32 Theta_e = 0.0;
//  float32 ExcGainRatio  = 0.1;
//  float32 ExcGain  = 0.0;
//  float32 Exc     = 0.0;
}
Uint16 PGUINV_BuffCntr = 0;
//=================================================================================
//  INV ISR
//=================================================================================
void Inv3_ISR(void)
{
// Verifying the ISR
    PGUINV_InvIsrTicker++;
    PGUINV_InvPowMeanCntr++;

// =================================== Feedback Acquisition =========================================
    INV_FDB_MACRO(PGUINV_InvFdb,PGUINV_Measure)

    if(BrakeEn == 1)
    {
//        FillAnalogBuffer(PGUINV_Measure.Result.Volt_DCLink, AnaBuff.buff10, 10);
    }

//    if(DCBaraBosalt && !(PGUINV_TCPU_Inputs.bit.MC1_NO) && !(PGUINV_TCPU_Inputs.bit.MC2_NO) && !(PGUINV_DIOC1_Inputs_TCPU.bit.MCAUX_STA1 &&!(PGUINV_DIOC1_Inputs_TCPU.bit.MCAUX_STA2)))
//    {
////        PGUINV_BrkPWM.MfuncC      = CLAMP(BrakeDuty,INV_DUTY_MIN,INV_DUTY_MAX);
////        PWMDutyUpdate(PGUINV_BRKPWM,PGUINV_BrkPWM.MfuncC);
//        PGUBrkGateON
//    }
//    else
//    {
//        PGUBrkGateOFF
//    }


    UdcLPF= LPF(PGUINV_InvFdb.Vdc, UdcLPF, 2*PI*10*PGUINV_TS);
    UsMax = UdcLPF*ISQRT3;

//// =================================== Braking Check =========================================

//    ElecSpeedLPF = LPF(PGUINV_InvFdb.ElecSpeed,       ElecSpeedLPF,    2*PI*5*PGUINV_TS);

    VDCBusLPF    = LPF(PGUINV_Measure.Result.Volt_DCLink,  VDCBusLPF,     2*PI*10*PGUINV_TS);
    VDCBusLPF2   = LPF(PGUINV_Measure.Result.Volt_DCLink,  VDCBusLPF2,    2*PI*300*PGUINV_TS);

//    BrakeCntrl();

// ================================== Enable Dynamic Modules =======================================
    invFO.p.Enable  = EnableFO;
    invTC.p.Enable  = EnableTC;
    invVC.p.Enable  = EnableVC;
    invCC.p.Enable  = EnableCC;
    invNC.p.Enable  = 1;

    if (EnableSC > 0)
    {
        if (VelEstErr > 0)
        {
            invSCRB.i.Enable = 1.0;
            invSCPI.p.Enable = 0.0;
        }
        else
        {
            invSCRB.i.Enable = 0.0;
            invSCPI.p.Enable = 1.0;
        }
    }
    else
    {
        invSCRB.i.Enable = 0.0;
        invSCPI.p.Enable = 0.0;
    }

// =================================== Feedback Processing =========================================
    // Clarke transformation
    invCLARKE.Is_a  = PGUINV_InvFdb.Cur_MotU;
    invCLARKE.Is_b  = -(PGUINV_InvFdb.Cur_MotU+PGUINV_InvFdb.Cur_MotW);
    invCLARKE.Is_c  = PGUINV_InvFdb.Cur_MotW;
    CLARKE_MACRO(invCLARKE)

//  invFO.p.Rs      = motRs;
//  invFO.p.T_Tr    = PGUINV_TS*motkr2Rr/Lsigp;

    // Flux observer
    invFO.i.Is_alpha    = invCLARKE.Is_alpha;
    invFO.i.Is_beta     = invCLARKE.Is_beta;
    invFO.i.Us_alpha    = invIPARK.Us_alpha;
    invFO.i.Us_beta     = invIPARK.Us_beta;

    /////////////////////////////

//   SpeedBPF1.i.In = TmpElecSpeed;
//      BPF_MACRO(SpeedBPF1);
//
//      FillAnalogBuffer(TmpElecSpeed,              AnaBuff.buff12, 12);
//      FillAnalogBuffer(PGUDE_InvFdb.ElecSpeed,    AnaBuff.buff13, 13);
//
//      SpeedBPF2.i.In = PGUDE_InvFdb.ElecSpeed;
//      BPF_MACRO(SpeedBPF2);
//
//      if(fabs(PGUDE_MotSpeed)>50.0)
//      {
//          invFO.i.w       = PGUDE_InvFdb.ElecSpeed;// SpeedRpm_pr*(3.0*PI/30.0);
//      }
//      else
//      {
//          invFO.i.w       = PGUDE_InvFdb.ElecSpeed;
//      }

    ///////////////////////////////

    invFO.i.w           = PGUINV_InvFdb.ElecSpeed;
    invFO.p.Enable      = 1;
    FO_MACRO(invFO)

    PGUINV_MotTorque    = invFO.o.Te;
    wr_mot              = invFO.v.wrLPF;

#ifdef OPEN_LOOP// Open Loop
    invAG.Enable        = 1;
    if (MotorDirection==1)
    {
    invAG.Direction     = 1.0;
    }
    else
    {
    invAG.Direction     = -1.0;
    }
    fsRef               = SpeedRef*0.0334;//4 kutuplu motor, 4/120=0.0334
    invAG.f             = CLAMPRATE(fsRef, invAG.f, PGUINV_TS, -0.2, 0.2);
    AG_MACRO(invAG)
#endif

    // Park transformation
    invPARK.Is_alpha    = invCLARKE.Is_alpha;
    invPARK.Is_beta     = invCLARKE.Is_beta;

#ifdef OPEN_LOOP
    invPARK.cosTheta    = cos(invAG.Theta);
    invPARK.sinTheta    = sin(invAG.Theta);
#else
    invPARK.cosTheta    = invFO.o.cosTheta;
    invPARK.sinTheta    = invFO.o.sinTheta;
#endif

    PARK_MACRO(invPARK)

    InvIs = sqrt(SQR(invPARK.Is_d)+SQR(invPARK.Is_q));


    // Slip controllers
    // Rule-based slip controller
    invSCRB.i.Td = PGUINV_MotTeRef;
    invSCRB.i.w  = invFO.i.w / 3.0;
    SCRB_MACRO(invSCRB)


    // PI slip controller
    invSCPI.i.EstVel = 0.0;
    invSCPI.i.Td = PGUINV_MotTeRef;
    invSCPI.i.w = invFO.i.w / 3.0;
    SCPI_MACRO(invSCPI)

    if (invSCRB.i.Enable == 1.0)
    {
        MotTeRef = invSCRB.o.Tr;
        SCActive = (Uint16)invSCRB.o.SSSignal;
        SCSanding = (Uint16)invSCRB.o.Sanding;
    }
    else if (invSCPI.p.Enable == 1.0)
    {
        MotTeRef = invSCPI.o.Tr;
        SCActive = (Uint16)invSCPI.o.SSSignal;
        SCSanding = (Uint16)invSCPI.o.Sanding;
    }
    else
    {
        MotTeRef = 0.0;
        SCActive = 0;
        SCSanding = 0;
    }

    // Torque controller

    TestTeRef = CLAMP(TestTeRef,-4000.0,4000.0);
    invTC.i.TeRef   = CLAMPRATE(TestTeRef, invTC.i.TeRef, PGUINV_TS, -50.0, 50.0);

    invTC.i.IsRef_d = invCC.i.IsRef_d;
    invTC.i.PsiR    = invFO.o.PsiR;
    invTC.i.PsiS_d  = invFO.o.PsiS_d;
    invTC.i.PsiS_q  = invFO.o.PsiS_q;
    TC_MACRO(invTC)

    //PGUINV_AvailMotTorque     = invTC.i.TeRef; //fabs(TeRefL); //

    Umot    = sqrt((invCC.o.Us_d *invCC.o.Us_d)+(invCC.o.Us_q *invCC.o.Us_q));
    Imot    = sqrt(SQR(invCLARKE.Is_alpha)+SQR(invCLARKE.Is_beta))*(0.707107);
    ws_mot  = invFO.o.ws;

    // Voltage controller
    invVC.i.UsMax   = 0.95*UsMax;
    invVC.i.Us      = invCC.o.Us;
    invVC.i.Is_q    = invTC.o.IsRef_q;
    invVC.i.ws      = invFO.o.ws;
    invVC.i.PsiR_d  = invFO.o.PsiR;
    VC_MACRO(invVC)

// =================================== Current Controller =========================================
    // Current controller module
    invCC.i.IsRef_d = invVC.o.IsRef_d;
    invCC.i.IsRef_q = invTC.o.IsRef_q; //IsRef_q;
    invCC.i.Is_d    = invPARK.Is_d;
    invCC.i.Is_q    = invPARK.Is_q;
    invCC.i.PsiR_d  = invFO.o.PsiR;
    invCC.i.ws      = invFO.o.ws;
    invCC.i.UsMax   = UsMax;
    CC_MACRO(invCC)


    if(invCC.p.Enable==1)
    {
        if(PGUINV_InvTripClear==1)
        {
            PGUINV_InvTripClear++;
        }
        else
        {
            PGUINV_InvTripClear = 3;
            PGUInvGateON
        }
    }

    Is_d            = invCC.i.Is_d;
    Is_q            = invCC.i.Is_q;
    IsRef_d         = invCC.i.IsRef_d;
    IsRef_q         = invCC.i.IsRef_q;

// ==================================== Output Processing ==========================================
    // Inverse park transformation
#ifdef OPEN_LOOP
    UsRef_d = sat((2.0 + 25.0 * invAG.f), invVC.i.UsMax ,0.0);

    invIPARK.Us_d       = UsRef_d ;
    invIPARK.Us_q       = UsRef_q;
#else
    invIPARK.Us_d       = invCC.o.Usr_d;
    invIPARK.Us_q       = invCC.o.Usr_q;
#endif
    invIPARK.cosTheta   = invPARK.cosTheta;
    invIPARK.sinTheta   = invPARK.sinTheta;
    IPARK_MACRO(invIPARK)

    // Inverter nonlinearity compensation
    invNC.i.Udc         = PGUINV_InvFdb.Vdc;
    invNC.i.Us_alpha    = invIPARK.Us_alpha;
    invNC.i.Us_beta     = invIPARK.Us_beta;
    invNC.i.signIs_a    = SIGN(invCLARKE.Is_a);
    invNC.i.signIs_b    = SIGN(invCLARKE.Is_b);
    invNC.i.signIs_c    = SIGN(invCLARKE.Is_c);
    NC_MACRO(invNC)

    invhs.Usn_alpha     = invNC.o.Usn_alpha;
    invhs.Usn_beta      = invNC.o.Usn_beta;
    invhs.Vdc           = PGUINV_InvFdb.Vdc;

//// ===================================== Duty Update =====================================
//// SVPWM generation
//    invSVGEN.Usn_alpha = invNC.o.Usn_alpha;
//    invSVGEN.Usn_beta  = invNC.o.Usn_beta;
//    SVGEN_MACRO(invSVGEN)
//
//// PWM generation
//    // Inverter Output Generation
//    PGUINV_InvPWM1.MfuncC = CLAMP(invSVGEN.Ta,DMin,DMax);
//    PGUINV_InvPWM2.MfuncC = CLAMP(invSVGEN.Tb,DMin,DMax);
//    PGUINV_InvPWM3.MfuncC = CLAMP(invSVGEN.Tc,DMin,DMax);
//
//    PWMDutyUpdate(PGUINV_IPWMU,PGUINV_InvPWM1.MfuncC);
//    PWMDutyUpdate(PGUINV_IPWMV,PGUINV_InvPWM2.MfuncC);
//    PWMDutyUpdate(PGUINV_IPWMW,PGUINV_InvPWM3.MfuncC);


    if(PGUINV_BuffCntr<1024)
    {
        if (SpeedRef>0)
        {
            PGUINV_BuffCntr++;
//    FillAnalogBuffer(PGUINV_Measure.Result.Volt_DCLink1, AnaBuff.buff1, 1);
//    FillAnalogBuffer(PGUINV_Measure.Result.Cur_MotInputU, AnaBuff.buff2, 2);
//    FillAnalogBuffer(invhs.Usn_alpha ,   AnaBuff.buff3, 3);
//    FillAnalogBuffer(invhs.Usn_beta ,   AnaBuff.buff4, 4);
//    FillAnalogBuffer(UsRef_d, AnaBuff.buff5, 5);
//    FillAnalogBuffer(invAG.f, AnaBuff.buff6, 6);
//    FillAnalogBuffer(PGUINV_Measure.Result.Cur_RectInput, AnaBuff.buff7, 7);
//    FillAnalogBuffer(PGUINV_Measure.Result.Cur_Primer, AnaBuff.buff8, 8);
//    FillAnalogBuffer(invAG.f, AnaBuff.buff11, 11);
//    FillAnalogBuffer(invhs.Usn_alpha ,   AnaBuff.buff12, 12);
//    FillAnalogBuffer(invhs.Usn_beta ,   AnaBuff.buff13, 13);
        }
   }
//    FillAnalogBuffer(PGUINV_Measure.Result.Volt_DCLink,   AnaBuff.buff3, 3);
//    FillAnalogBuffer(PGUINV_Measure.Result.Cur_RectInput,   AnaBuff.buff4, 4);
//    FillAnalogBuffer(PGUINV_Measure.Result.Cur_MotInputW,   AnaBuff.buff5, 5);
//    FillAnalogBuffer(PGUINV_Measure.Result.Cur_MotInputU,   AnaBuff.buff8, 8);
//    FillAnalogBuffer(PGUINV_Measure.Result.Cur_MotInputW,   AnaBuff.buff10, 10);
//    FillAnalogBuffer(PGUINV_Temperature_CKU1.MotorTemp1, AnaBuff.buff9, 9);
//    FillAnalogBuffer(PGUINV_Temperature_CKU1.MotorTempBearing, AnaBuff.buff11, 11);
//    FillAnalogBuffer(PGUINV_Temperature_CKU1.MotorTemp2 ,   AnaBuff.buff12, 12);
//    FillAnalogBuffer(PGUINV_Temperature_CKU1.MotorTemp3 ,   AnaBuff.buff13, 13);

// ==================================== Power Calculation ==========================================c
    InvPin      = invTC.i.TeRef*PGUINV_InvFdb.ElecSpeed/3.0;//1.5*(invIPARK.Us_alpha*invPARK.Is_alpha + invIPARK.Us_beta*invPARK.Is_beta);
    //Isrms         = sqrt(SQR(invCLARKE.Is_alpha)+SQR(invCLARKE.Is_beta));
    InvPF       = - invPARK.Is_q / PGUINV_IMotURMS.RMS;

    MechPow     = ((float32)invTC.p.Enable)*invFO.o.Te*PGUINV_InvFdb.ElecSpeed/p;
    MechPowLPF  = LPF(MechPow, MechPowLPF, 2*PI*10*PGUINV_TS);

    InvPow      = 1.5*(Us_alpha_d * invCLARKE.Is_alpha + Us_beta_d * invCLARKE.Is_beta);
    InvPowLPF   = LPF(InvPow, InvPowLPF, 2*PI*100*PGUINV_TS);

    Us_alpha_d  = invIPARK.Us_alpha;
    Us_beta_d   = invIPARK.Us_beta;

    InvPowSum  += InvPowLPF;
    if(PGUINV_InvPowMeanCntr >= 8)  // 4ms ortalama alma
    {
        PGUINV_InvPowMeanCntr = 0;

        InvPowMean    = InvPowSum * (1.0/8.0);
        InvPowSum     = 0.0;
    }
// ====================================Monitoring==========================================
//
//    if(PGUINV_BuffCntr<1024)
//    {
//        PGUINV_BuffCntr++;
//        FillAnalogBuffer(invIPARK.Us_alpha, AnaBuff.buff1, 1);
////        FillAnalogBuffer(PGUINV_Measure.Result.Cur_MotU, AnaBuff.buff2, 2);
//        FillAnalogBuffer(InvPow, AnaBuff.buff3, 3);
//        FillAnalogBuffer(InvPowLPF, AnaBuff.buff4, 4);
////        FillAnalogBuffer(InvPow2, AnaBuff.buff5, 5);
////        FillAnalogBuffer(InvPow2LPF, AnaBuff.buff6, 6);
//        FillAnalogBuffer(PGUINV_MotSpeed, AnaBuff.buff7, 7);
//    }

// ====================================DC BUS Confirmation==========================================
    if (Success > 0)
        {
        if(PGUINV_DC_Counter < 1500)
            {
                PGUINV_DC_Counter++;
            }
        }
    else if (Success == 0)
                {
                    PGUINV_DC_Counter=0;
                }
}

//
//void BrakeCntrl(void)
//{
//    BrakePowMax = (VDCBusLPF*VDCBusLPF)/BRAKE_RESISTOR;
//
// //   PowInLPF = VDCBusLPF * IdcLPF;
//    PowInLPF = InvPin;
//
//
//    BrakePow = BrakeDuty * BrakePowMax;
//
//    IBrakeLPF = LPF((float32)BrakeEn*BrakeDuty*0.01*VDCBusLPF/BRAKE_RESISTOR, IBrakeLPF, 2*PI*5*PGUINV_TS);
//
//    if((VDCBusLPF > 1820) && (MechPowLPF<-5000))
//    {
//        BrakeEn = 1;
//        BrakeDuty = (MOTORN/3.0)*(VDCBusLPF2-1820)*2;       // 50V = %100 Duty
//    }
//    else
//    {
//        BrakeEn = 0;
//        BrakeDuty = 0;
//    }
//
//    if(BrakeEn==1)
//    {
//        if(PowInLPF > 10000)
//        {
//            BrakeOLCntr2++;
//
//            if(BrakeOLCntr2 > 5000)  //2s 1s = 2500
//            {
//                BrakeOLCntr = 0;
//                BrakeEn = 0;
//            }
//        }
//        else
//        {
//            BrakeOLCntr2 = 0;
//        }
//
//        if(BrakePow > fabs(1.3 * MechPowLPF))
//        {
//            BrakeOLCntr++;
//            if(BrakeOLCntr > 5000)  //2s 1s = 2500
//            {
//                BrakeOLCntr = 0;
//                BrakeEn = 0;
//            }
//        }
//        else
//        {
//            BrakeOLCntr = 0;
//        }
//    }
//
//    BrakeDuty = CLAMP(BrakeDuty,1.0,60.0);
//
//    // Inverter Output Generation
//
//    PGUINV_BrkPWM.MfuncC = CLAMP((0.02*BrakeDuty - 1.0),DMinBrake,0.0);
//
//
//
//}

// InvISR Ends Here
#endif
