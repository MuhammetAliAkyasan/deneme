/*
 * main.h
 *
 *  Created on: 30 Haz 2022
 *      Author: hasan.ertugrul
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "DSP28x_Project.h"         //DSP28x Project Headerfile and Examples Include File
#include "PGU_Common.h"
#include "PGUREC_GlobalPrototypes.h"
#include "PGUINV_GlobalPrototypes.h"

#endif /* MAIN_H_ */
